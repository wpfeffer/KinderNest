# Bullet 4 Overlay: Onboarding Procedure Signatures and Skeletons

This overlay contains the provider-family onboarding stored procedures.

## Included procedures
- `dpa/child/Stored Procedures/usp_ProviderPortal_Family_Onboard.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_Family_List.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_Family_GetDetail.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_Guardian_Upsert.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_PickupAuthorization_Upsert.sql`

## Scope
These are signature-first, implementation-forward skeletons. They are meant to give you:
- stable proc names
- stable parameter lists
- transaction boundaries
- basic access validation
- first-pass write/read behavior

They are not the final gold-plated business rules engine yet.

## Dependencies
This overlay assumes:
- bullet 1 committed household tables are present
- bullet 3 reporting/detail views are present

## Important note on code columns
New household-facing objects use `INT` FK code IDs.
The current base schema still contains some legacy string code columns, for example:
- `child.ChildEnrollment.EnrollmentStatusCode`
- `child.ChildPersonRelationship.RelationshipTypeCode`

These procedures bridge both worlds for now:
- household role values are resolved from `ref.CodeValue`
- legacy child relationship/enrollment fields still write string values where the existing table design requires them

## Notable exclusions
- Guardian invitation token creation is intentionally not generated here yet
- Canonical person/address/phone de-dup is not fully implemented here
- This pack does not include image-upload procedures

## Patch notes
Patch stubs are included for:
- `dpa/dpa.sqlproj`
- `dpa/Install/master_install.sql`

No GitHub push was performed for this package.
