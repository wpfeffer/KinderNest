CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_GetDetail
    @PortalUserID                    INT,
    @HouseholdID                     INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        INNER JOIN party.Household h
            ON h.ProviderID = s.ProviderID
           AND h.HouseholdID = @HouseholdID
           AND h.IsDeleted = 0
           AND h.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 51020, 'The current provider user cannot access the requested household.', 1;
    END;

    SELECT
        hs.HouseholdID,
        hs.ProviderID,
        hs.ProviderName,
        hs.HouseholdDisplayName,
        hs.PrimaryAddressID,
        hs.AddressLine1,
        hs.AddressLine2,
        hs.City,
        hs.StateProvinceCode,
        hs.PostalCode,
        hs.ChildCount,
        hs.ActiveEnrollmentCount,
        hs.GuardianCount,
        hs.PrimaryContactPersonID,
        hs.PrimaryContactDisplayName,
        hs.PrimaryContactEmail,
        hs.CreatedUTC,
        hs.ModifiedUTC
    FROM rpt.vwProviderHouseholdSummary hs
    WHERE hs.HouseholdID = @HouseholdID;

    SELECT
        hc.ChildHouseholdID,
        hc.ChildID,
        hc.SiteID,
        hc.SiteName,
        hc.ChildDisplayName,
        hc.FirstName,
        hc.MiddleName,
        hc.LastName,
        hc.DateOfBirth,
        hc.SpecialDietNotes,
        hc.SpecialNeedsNotes,
        hc.ChildEnrollmentID,
        hc.EnrollmentStartDate,
        hc.EnrollmentEndDate,
        hc.ScheduleSummary,
        hc.FinancialArrangementNotes,
        hc.EnrollmentStatusCode,
        hc.IsPrimaryHousehold,
        hc.ChildHouseholdIsActive,
        hc.CreatedUTC,
        hc.ModifiedUTC
    FROM rpt.vwProviderHouseholdChildDetail hc
    WHERE hc.HouseholdID = @HouseholdID
    ORDER BY hc.LastName, hc.FirstName, hc.ChildID;

    SELECT
        hp.HouseholdPersonID,
        hp.PersonID,
        hp.PersonDisplayName,
        hp.FirstName,
        hp.MiddleName,
        hp.LastName,
        hp.DateOfBirth,
        hp.PrimaryEmail,
        hp.HouseholdRoleCodeValueID,
        hp.HouseholdRoleCodeDomain,
        hp.HouseholdRoleCode,
        hp.HouseholdRoleCodeName,
        hp.IsPrimaryContact,
        hp.EffectiveStartUTC,
        hp.EffectiveEndUTC,
        hp.HouseholdPersonIsActive,
        hp.CreatedUTC,
        hp.ModifiedUTC
    FROM rpt.vwProviderHouseholdPersonDetail hp
    WHERE hp.HouseholdID = @HouseholdID
    ORDER BY hp.IsPrimaryContact DESC, hp.PersonDisplayName, hp.PersonID;

    SELECT
        pa.PickupDropoffAuthorizationID,
        pa.ChildID,
        pa.ChildDisplayName,
        pa.PersonID,
        pa.AuthorizedPersonDisplayName,
        pa.PrimaryEmail,
        pa.CanPickup,
        pa.CanDropoff,
        pa.IsEmergencyContact,
        pa.Notes,
        pa.EffectiveStartDate,
        pa.EffectiveEndDate,
        pa.IsActive,
        pa.CreatedUTC,
        pa.ModifiedUTC
    FROM rpt.vwProviderHouseholdPickupAuthorizationDetail pa
    WHERE pa.HouseholdID = @HouseholdID
    ORDER BY pa.ChildDisplayName, pa.AuthorizedPersonDisplayName, pa.PickupDropoffAuthorizationID;

    SELECT
        gi.GuardianInvitationID,
        cpr.ChildPersonRelationshipID,
        cpr.ChildID,
        ChildDisplayName = CONCAT(c.FirstName, N' ', c.LastName),
        cpr.PersonID,
        GuardianDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        gi.InvitationEmail,
        gi.TokenExpiresUTC,
        gi.RedeemedUTC,
        gi.RevokedUTC,
        gi.InvitationStatusCode,
        gi.CreatedUTC,
        gi.ModifiedUTC
    FROM child.GuardianInvitation gi
    INNER JOIN child.ChildPersonRelationship cpr
        ON cpr.ChildPersonRelationshipID = gi.ChildPersonRelationshipID
       AND cpr.IsDeleted = 0
       AND cpr.IsActive = 1
    INNER JOIN child.ChildHousehold chh
        ON chh.ChildID = cpr.ChildID
       AND chh.HouseholdID = @HouseholdID
       AND chh.IsDeleted = 0
       AND chh.IsActive = 1
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
       AND c.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = cpr.PersonID
       AND p.IsDeleted = 0
    ORDER BY gi.CreatedUTC DESC, gi.GuardianInvitationID DESC;
END;
GO
