CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_List
    @PortalUserID                    INT,
    @SiteID                          INT = NULL,
    @SearchTerm                      NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH AllowedProviders AS
    (
        SELECT DISTINCT s.ProviderID
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
          AND (@SiteID IS NULL OR s.SiteID = @SiteID)
    )
    SELECT
        hs.HouseholdID,
        hs.ProviderID,
        hs.ProviderName,
        hs.HouseholdDisplayName,
        hs.PrimaryContactPersonID,
        hs.PrimaryContactDisplayName,
        hs.PrimaryContactEmail,
        hs.ChildCount,
        hs.ActiveEnrollmentCount,
        hs.GuardianCount,
        hs.AddressLine1,
        hs.AddressLine2,
        hs.City,
        hs.StateProvinceCode,
        hs.PostalCode,
        hs.CreatedUTC,
        hs.ModifiedUTC
    FROM rpt.vwProviderHouseholdSummary hs
    INNER JOIN AllowedProviders ap
        ON ap.ProviderID = hs.ProviderID
    WHERE
        @SearchTerm IS NULL
        OR hs.HouseholdDisplayName LIKE CONCAT(N'%', @SearchTerm, N'%')
        OR hs.PrimaryContactDisplayName LIKE CONCAT(N'%', @SearchTerm, N'%')
        OR hs.PrimaryContactEmail LIKE CONCAT(N'%', @SearchTerm, N'%')
        OR hs.City LIKE CONCAT(N'%', @SearchTerm, N'%')
        OR hs.PostalCode LIKE CONCAT(N'%', @SearchTerm, N'%')
    ORDER BY hs.HouseholdDisplayName, hs.PrimaryContactDisplayName;
END;
GO
