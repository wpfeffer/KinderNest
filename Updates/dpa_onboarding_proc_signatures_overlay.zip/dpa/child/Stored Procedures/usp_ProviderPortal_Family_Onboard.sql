CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_Onboard
    @PortalUserID                    INT,
    @SiteID                          INT,
    @ChildFirstName                  NVARCHAR(100),
    @ChildMiddleName                 NVARCHAR(100) = NULL,
    @ChildLastName                   NVARCHAR(100),
    @DateOfBirth                     DATE,
    @EnrollmentStartDate             DATE,
    @SpecialDietNotes                NVARCHAR(MAX) = NULL,
    @SpecialNeedsNotes               NVARCHAR(MAX) = NULL,
    @ScheduleSummary                 NVARCHAR(MAX) = NULL,
    @FinancialArrangementNotes       NVARCHAR(MAX) = NULL,
    @PrimaryGuardianFirstName        NVARCHAR(100),
    @PrimaryGuardianMiddleName       NVARCHAR(100) = NULL,
    @PrimaryGuardianLastName         NVARCHAR(100),
    @PrimaryGuardianEmail            NVARCHAR(320) = NULL,
    @SecondaryGuardianFirstName      NVARCHAR(100) = NULL,
    @SecondaryGuardianMiddleName     NVARCHAR(100) = NULL,
    @SecondaryGuardianLastName       NVARCHAR(100) = NULL,
    @SecondaryGuardianEmail          NVARCHAR(320) = NULL,
    @PickupContactFirstName          NVARCHAR(100) = NULL,
    @PickupContactMiddleName         NVARCHAR(100) = NULL,
    @PickupContactLastName           NVARCHAR(100) = NULL,
    @PickupContactEmail              NVARCHAR(320) = NULL,
    @PickupCanPickup                 BIT = 0,
    @PickupCanDropoff                BIT = 0,
    @PickupIsEmergencyContact        BIT = 0,
    @PickupNotes                     NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @NowUTC DATETIME2(0) = SYSUTCDATETIME();
    DECLARE @ProviderID INT;
    DECLARE @SiteName NVARCHAR(200);

    DECLARE @HouseholdRolePrimaryGuardianCodeValueID INT;
    DECLARE @HouseholdRoleSecondaryGuardianCodeValueID INT;
    DECLARE @HouseholdRolePickupContactCodeValueID INT;

    DECLARE @HouseholdID INT;
    DECLARE @PrimaryGuardianPersonID INT;
    DECLARE @SecondaryGuardianPersonID INT = NULL;
    DECLARE @PickupContactPersonID INT = NULL;
    DECLARE @ChildID INT;
    DECLARE @ChildEnrollmentID INT;
    DECLARE @PrimaryRelationshipID INT;
    DECLARE @SecondaryRelationshipID INT = NULL;
    DECLARE @HouseholdDisplayName NVARCHAR(200);

    IF NULLIF(LTRIM(RTRIM(@ChildFirstName)), N'') IS NULL
        THROW 51000, 'Child first name is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@ChildLastName)), N'') IS NULL
        THROW 51001, 'Child last name is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@PrimaryGuardianFirstName)), N'') IS NULL
        THROW 51002, 'Primary guardian first name is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@PrimaryGuardianLastName)), N'') IS NULL
        THROW 51003, 'Primary guardian last name is required.', 1;

    SELECT
        @ProviderID = s.ProviderID,
        @SiteName = s.SiteName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.SiteID = @SiteID
      AND sua.IsActive = 1
      AND sua.EffectiveStartUTC <= @NowUTC
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= @NowUTC);

    IF @ProviderID IS NULL
        THROW 51004, 'The current provider user is not assigned to the requested site.', 1;

    SELECT @HouseholdRolePrimaryGuardianCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue = N'PRIMARY_GUARDIAN'
      AND cv.IsActive = 1;

    SELECT @HouseholdRoleSecondaryGuardianCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue = N'SECONDARY_GUARDIAN'
      AND cv.IsActive = 1;

    SELECT @HouseholdRolePickupContactCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue = N'AUTHORIZED_PICKUP_CONTACT'
      AND cv.IsActive = 1;

    IF @HouseholdRolePrimaryGuardianCodeValueID IS NULL
        THROW 51005, 'HouseholdRole PRIMARY_GUARDIAN code is missing from ref.CodeValue.', 1;

    IF @HouseholdRoleSecondaryGuardianCodeValueID IS NULL
        THROW 51006, 'HouseholdRole SECONDARY_GUARDIAN code is missing from ref.CodeValue.', 1;

    IF @HouseholdRolePickupContactCodeValueID IS NULL
        THROW 51007, 'HouseholdRole AUTHORIZED_PICKUP_CONTACT code is missing from ref.CodeValue.', 1;

    SET @HouseholdDisplayName =
        LEFT(
            CONCAT(
                LTRIM(RTRIM(@PrimaryGuardianLastName)),
                N' / ',
                LTRIM(RTRIM(@ChildLastName)),
                N' household'
            ),
            200
        );

    BEGIN TRANSACTION;

    INSERT INTO party.Person
    (
        FirstName,
        MiddleName,
        LastName,
        PrimaryEmail,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        LTRIM(RTRIM(@PrimaryGuardianFirstName)),
        NULLIF(LTRIM(RTRIM(@PrimaryGuardianMiddleName)), N''),
        LTRIM(RTRIM(@PrimaryGuardianLastName)),
        NULLIF(LTRIM(RTRIM(@PrimaryGuardianEmail)), N''),
        1,
        0,
        @PortalUserID
    );

    SET @PrimaryGuardianPersonID = SCOPE_IDENTITY();

    INSERT INTO party.Household
    (
        ProviderID,
        HouseholdDisplayName,
        BillingNotes,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ProviderID,
        @HouseholdDisplayName,
        NULL,
        1,
        0,
        @PortalUserID
    );

    SET @HouseholdID = SCOPE_IDENTITY();

    INSERT INTO party.HouseholdPerson
    (
        HouseholdID,
        PersonID,
        HouseholdRoleCodeValueID,
        IsPrimaryContact,
        EffectiveStartUTC,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @HouseholdID,
        @PrimaryGuardianPersonID,
        @HouseholdRolePrimaryGuardianCodeValueID,
        1,
        @NowUTC,
        1,
        0,
        @PortalUserID
    );

    IF NULLIF(LTRIM(RTRIM(@SecondaryGuardianFirstName)), N'') IS NOT NULL
       AND NULLIF(LTRIM(RTRIM(@SecondaryGuardianLastName)), N'') IS NOT NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName,
            MiddleName,
            LastName,
            PrimaryEmail,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@SecondaryGuardianFirstName)),
            NULLIF(LTRIM(RTRIM(@SecondaryGuardianMiddleName)), N''),
            LTRIM(RTRIM(@SecondaryGuardianLastName)),
            NULLIF(LTRIM(RTRIM(@SecondaryGuardianEmail)), N''),
            1,
            0,
            @PortalUserID
        );

        SET @SecondaryGuardianPersonID = SCOPE_IDENTITY();

        INSERT INTO party.HouseholdPerson
        (
            HouseholdID,
            PersonID,
            HouseholdRoleCodeValueID,
            IsPrimaryContact,
            EffectiveStartUTC,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @HouseholdID,
            @SecondaryGuardianPersonID,
            @HouseholdRoleSecondaryGuardianCodeValueID,
            0,
            @NowUTC,
            1,
            0,
            @PortalUserID
        );
    END;

    INSERT INTO child.Child
    (
        SiteID,
        FirstName,
        MiddleName,
        LastName,
        DateOfBirth,
        SpecialDietNotes,
        SpecialNeedsNotes,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        LTRIM(RTRIM(@ChildFirstName)),
        NULLIF(LTRIM(RTRIM(@ChildMiddleName)), N''),
        LTRIM(RTRIM(@ChildLastName)),
        @DateOfBirth,
        NULLIF(@SpecialDietNotes, N''),
        NULLIF(@SpecialNeedsNotes, N''),
        1,
        0,
        @PortalUserID
    );

    SET @ChildID = SCOPE_IDENTITY();

    INSERT INTO child.ChildHousehold
    (
        ChildID,
        HouseholdID,
        IsPrimaryHousehold,
        EffectiveStartUTC,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ChildID,
        @HouseholdID,
        1,
        @NowUTC,
        1,
        0,
        @PortalUserID
    );

    INSERT INTO child.ChildEnrollment
    (
        ChildID,
        SiteID,
        EnrollmentStartDate,
        ScheduleSummary,
        FinancialArrangementNotes,
        EnrollmentStatusCode,
        IsPrimaryEnrollment,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ChildID,
        @SiteID,
        @EnrollmentStartDate,
        NULLIF(@ScheduleSummary, N''),
        NULLIF(@FinancialArrangementNotes, N''),
        N'ACTIVE',
        1,
        1,
        0,
        @PortalUserID
    );

    SET @ChildEnrollmentID = SCOPE_IDENTITY();

    INSERT INTO child.ChildPersonRelationship
    (
        ChildID,
        PersonID,
        RelationshipTypeCode,
        HasPortalAccess,
        CanReceiveAlerts,
        CanSignPermissions,
        IsPrimaryGuardian,
        EffectiveStartDate,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ChildID,
        @PrimaryGuardianPersonID,
        N'GUARDIAN',
        CASE WHEN NULLIF(LTRIM(RTRIM(@PrimaryGuardianEmail)), N'') IS NULL THEN 0 ELSE 1 END,
        1,
        1,
        1,
        @EnrollmentStartDate,
        1,
        0,
        @PortalUserID
    );

    SET @PrimaryRelationshipID = SCOPE_IDENTITY();

    IF @SecondaryGuardianPersonID IS NOT NULL
    BEGIN
        INSERT INTO child.ChildPersonRelationship
        (
            ChildID,
            PersonID,
            RelationshipTypeCode,
            HasPortalAccess,
            CanReceiveAlerts,
            CanSignPermissions,
            IsPrimaryGuardian,
            EffectiveStartDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @SecondaryGuardianPersonID,
            N'GUARDIAN',
            CASE WHEN NULLIF(LTRIM(RTRIM(@SecondaryGuardianEmail)), N'') IS NULL THEN 0 ELSE 1 END,
            1,
            1,
            0,
            @EnrollmentStartDate,
            1,
            0,
            @PortalUserID
        );

        SET @SecondaryRelationshipID = SCOPE_IDENTITY();
    END;

    IF NULLIF(LTRIM(RTRIM(@PickupContactFirstName)), N'') IS NOT NULL
       AND NULLIF(LTRIM(RTRIM(@PickupContactLastName)), N'') IS NOT NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName,
            MiddleName,
            LastName,
            PrimaryEmail,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@PickupContactFirstName)),
            NULLIF(LTRIM(RTRIM(@PickupContactMiddleName)), N''),
            LTRIM(RTRIM(@PickupContactLastName)),
            NULLIF(LTRIM(RTRIM(@PickupContactEmail)), N''),
            1,
            0,
            @PortalUserID
        );

        SET @PickupContactPersonID = SCOPE_IDENTITY();

        INSERT INTO party.HouseholdPerson
        (
            HouseholdID,
            PersonID,
            HouseholdRoleCodeValueID,
            IsPrimaryContact,
            EffectiveStartUTC,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @HouseholdID,
            @PickupContactPersonID,
            @HouseholdRolePickupContactCodeValueID,
            0,
            @NowUTC,
            1,
            0,
            @PortalUserID
        );

        INSERT INTO child.PickupDropoffAuthorization
        (
            ChildID,
            PersonID,
            CanPickup,
            CanDropoff,
            IsEmergencyContact,
            Notes,
            EffectiveStartDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @PickupContactPersonID,
            @PickupCanPickup,
            @PickupCanDropoff,
            @PickupIsEmergencyContact,
            NULLIF(@PickupNotes, N''),
            @EnrollmentStartDate,
            1,
            0,
            @PortalUserID
        );
    END;

    COMMIT TRANSACTION;

    SELECT
        ChildID = @ChildID,
        SiteID = @SiteID,
        ChildDisplayName = CONCAT(@ChildFirstName, N' ', @ChildLastName),
        SiteName = @SiteName,
        HouseholdID = @HouseholdID,
        HouseholdDisplayName = @HouseholdDisplayName,
        ChildEnrollmentID = @ChildEnrollmentID,
        PrimaryRelationshipID = @PrimaryRelationshipID,
        SecondaryRelationshipID = @SecondaryRelationshipID;
END;
GO
