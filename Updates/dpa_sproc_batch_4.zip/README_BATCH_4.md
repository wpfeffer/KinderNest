DPA stored procedure batch 4 of 4

Theme:
Image security/data-access subsystem plus licensing summary.

Included procedures:
1. lic.usp_AdminLicensing_GetSummary
2. image.usp_ImageAsset_Create
3. image.usp_ImageAsset_ListForSite
4. image.usp_ImageAsset_ListForGuardian
5. image.usp_ImageAsset_GetAccessEnvelope
6. image.usp_ImageAsset_SoftDelete
7. image.usp_SiteImageKey_GetActive
8. image.usp_SiteImageKey_Upsert
9. image.usp_ImageStorageProvisioningTarget_ListByPortalUser
10. image.usp_ImageStorageContext_GetBySite

All procedures are CREATE OR ALTER and fit the data-aware, non-destructive migration rule.
