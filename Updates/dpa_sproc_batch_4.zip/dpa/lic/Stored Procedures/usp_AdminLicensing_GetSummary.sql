CREATE OR ALTER PROCEDURE lic.usp_AdminLicensing_GetSummary
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    SELECT
        OpenFindings =
        (
            SELECT COUNT(1)
            FROM rpt.vwOpenComplianceFindings ocf
        ),
        EvidenceAwaitingReview =
        (
            SELECT COUNT(1)
            FROM lic.RequirementEvidence re
            WHERE re.IsDeleted = 0
              AND re.IsActive = 1
              AND (
                    re.IsCurrent = 0
                    OR UPPER(re.EvidenceStatusCode) IN (N'PENDING', N'REVIEW', N'NEEDS_REVIEW', N'REJECTED')
                  )
        ),
        ActiveVariances =
        (
            SELECT COUNT(1)
            FROM lic.LicenseVariance lv
            WHERE lv.IsDeleted = 0
              AND lv.IsActive = 1
              AND lv.EffectiveStartDate <= @Today
              AND (lv.EffectiveEndDate IS NULL OR lv.EffectiveEndDate >= @Today)
        );

    SELECT TOP (25)
        SiteName = s.SiteName,
        RequirementTitle = COALESCE(rc.RequirementTitle, ocf.FindingTitle),
        StatusText = CASE
            WHEN UPPER(ocf.FindingSeverityCode) IN (N'CRITICAL', N'HIGH') THEN N'Critical'
            WHEN ocf.CorrectiveActionDueDate IS NOT NULL AND ocf.CorrectiveActionDueDate < @Today THEN N'Warning'
            ELSE N'Healthy'
        END,
        StatusCssClass = CASE
            WHEN UPPER(ocf.FindingSeverityCode) IN (N'CRITICAL', N'HIGH') THEN N'critical'
            WHEN ocf.CorrectiveActionDueDate IS NOT NULL AND ocf.CorrectiveActionDueDate < @Today THEN N'warning'
            ELSE N'healthy'
        END,
        DueDate = ocf.CorrectiveActionDueDate
    FROM rpt.vwOpenComplianceFindings ocf
    INNER JOIN party.Site s
        ON s.SiteID = ocf.SiteID
    LEFT JOIN lic.RequirementCatalog rc
        ON rc.RequirementID = ocf.RequirementID
    ORDER BY
        CASE WHEN ocf.CorrectiveActionDueDate IS NULL THEN 1 ELSE 0 END,
        ocf.CorrectiveActionDueDate,
        s.SiteName,
        COALESCE(rc.RequirementTitle, ocf.FindingTitle);
END;
GO
