CREATE OR ALTER PROCEDURE image.usp_SiteImageKey_GetActive
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
        sik.SiteImageKeyID,
        sik.SiteID,
        sik.KeyVersion,
        sik.WrapAlgorithmCode,
        sik.WrappedKeyCiphertext,
        sik.WrappedKeyNonce,
        sik.WrappedKeyTag,
        sik.IsPrimary,
        sik.IsActive,
        sik.CreatedUTC
    FROM image.SiteImageKey sik
    WHERE sik.SiteID = @SiteID
      AND sik.IsDeleted = 0
      AND sik.IsActive = 1
      AND sik.IsPrimary = 1
    ORDER BY sik.KeyVersion DESC, sik.SiteImageKeyID DESC;
END;
GO
