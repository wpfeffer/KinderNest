CREATE OR ALTER PROCEDURE image.usp_ImageAsset_SoftDelete
    @ImageAssetID     INT,
    @DeletedByUserID  INT,
    @DeletedReason    NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE image.ImageAsset
       SET IsDeleted = 1,
           IsActive = 0,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE ImageAssetID = @ImageAssetID
       AND IsDeleted = 0;

    UPDATE image.ImageAssetSubject
       SET IsDeleted = 1,
           IsActive = 0,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE ImageAssetID = @ImageAssetID
       AND IsDeleted = 0;

    SELECT @@ROWCOUNT AS AffectedRowCount;
END;
GO
