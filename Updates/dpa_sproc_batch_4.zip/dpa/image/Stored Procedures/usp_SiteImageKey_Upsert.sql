CREATE OR ALTER PROCEDURE image.usp_SiteImageKey_Upsert
    @SiteID                 INT,
    @KeyVersion             INT,
    @WrapAlgorithmCode      NVARCHAR(50) = N'AES-256-GCM',
    @WrappedKeyCiphertext   VARBINARY(512),
    @WrappedKeyNonce        VARBINARY(32),
    @WrappedKeyTag          VARBINARY(32),
    @PortalUserID           INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    UPDATE image.SiteImageKey
       SET IsPrimary = 0,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @PortalUserID
     WHERE SiteID = @SiteID
       AND IsDeleted = 0
       AND IsActive = 1
       AND IsPrimary = 1
       AND KeyVersion <> @KeyVersion;

    IF EXISTS
    (
        SELECT 1
        FROM image.SiteImageKey
        WHERE SiteID = @SiteID
          AND KeyVersion = @KeyVersion
    )
    BEGIN
        UPDATE image.SiteImageKey
           SET WrapAlgorithmCode = @WrapAlgorithmCode,
               WrappedKeyCiphertext = @WrappedKeyCiphertext,
               WrappedKeyNonce = @WrappedKeyNonce,
               WrappedKeyTag = @WrappedKeyTag,
               IsPrimary = 1,
               IsActive = 1,
               IsDeleted = 0,
               DeletedUTC = NULL,
               DeletedByUserID = NULL,
               DeletedReason = NULL,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @PortalUserID
         WHERE SiteID = @SiteID
           AND KeyVersion = @KeyVersion;
    END
    ELSE
    BEGIN
        INSERT INTO image.SiteImageKey
        (
            SiteID,
            KeyVersion,
            WrapAlgorithmCode,
            WrappedKeyCiphertext,
            WrappedKeyNonce,
            WrappedKeyTag,
            IsPrimary,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @KeyVersion,
            @WrapAlgorithmCode,
            @WrappedKeyCiphertext,
            @WrappedKeyNonce,
            @WrappedKeyTag,
            1,
            1,
            0,
            @PortalUserID
        );
    END;

    COMMIT TRANSACTION;

    EXEC image.usp_SiteImageKey_GetActive @SiteID = @SiteID;
END;
GO
