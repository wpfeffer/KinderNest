using System.Data;
using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class SqlAuthenticationAuditWriter : IAuthenticationAuditWriter
{
    private const string WriteAuthenticationEventProcedureName = "audit.usp_WriteAuthenticationEvent";

    private readonly ILogger<SqlAuthenticationAuditWriter> _logger;
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly DpaAuthOptions _options;

    public SqlAuthenticationAuditWriter(
        ILogger<SqlAuthenticationAuditWriter> logger,
        ISqlConnectionFactory connectionFactory,
        IOptions<DpaAuthOptions> options)
    {
        _logger = logger;
        _connectionFactory = connectionFactory;
        _options = options.Value;
    }

    public async Task WriteAsync(
        string eventTypeCode,
        string resultCode,
        int? portalUserId,
        int? portalCredentialId,
        long? loginSessionId,
        string? userNameAttempted,
        string? failureReason,
        string? remoteAddress,
        string? userAgent,
        string? notes,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = WriteAuthenticationEventProcedureName;
            command.Parameters.Add(new SqlParameter("@AuthenticationEventTypeCode", SqlDbType.NVarChar, 100) { Value = eventTypeCode });
            command.Parameters.Add(new SqlParameter("@AuthenticationResultCode", SqlDbType.NVarChar, 100) { Value = resultCode });
            command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = (object?)portalUserId ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@PortalCredentialID", SqlDbType.Int) { Value = (object?)portalCredentialId ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@LoginSessionID", SqlDbType.BigInt) { Value = (object?)loginSessionId ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@UserNameAttempted", SqlDbType.NVarChar, 320) { Value = (object?)userNameAttempted ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@FailureReason", SqlDbType.NVarChar, -1) { Value = (object?)failureReason ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = DBNull.Value });
            command.Parameters.Add(new SqlParameter("@RemoteAddress", SqlDbType.NVarChar, 100) { Value = (object?)remoteAddress ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@UserAgent", SqlDbType.NVarChar, -1) { Value = (object?)userAgent ?? DBNull.Value });
            command.Parameters.Add(new SqlParameter("@CorrelationID", SqlDbType.UniqueIdentifier) { Value = DBNull.Value });
            command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, -1) { Value = (object?)notes ?? DBNull.Value });

            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Authentication audit write failed. EventType={EventTypeCode}, ResultCode={ResultCode}", eventTypeCode, resultCode);
        }
    }
}
