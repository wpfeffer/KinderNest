using System.Security.Cryptography;
using System.Data;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class SqlDpaUserStore : IDpaUserStore
{
    private const string FindUserProcedureName = "sec.usp_PortalUserAuthentication_GetByNormalizedUserName";
    private const string SessionIsActiveProcedureName = "sec.usp_LoginSession_IsActive";
    private const string SessionCreateProcedureName = "sec.usp_LoginSession_Create";
    private const string RecordSuccessfulLoginProcedureName = "sec.usp_PortalUser_RecordSuccessfulLogin";
    private const string RecordFailedLoginProcedureName = "sec.usp_PortalCredential_RecordFailedLogin";
    private const string RevokeSessionProcedureName = "sec.usp_LoginSession_Revoke";
    private const string CheckSiteAccessProcedureName = "sec.usp_PortalUser_Access_CheckSite";
    private const string CheckChildAccessProcedureName = "sec.usp_PortalUser_Access_CheckChild";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IAuthenticationAuditWriter _auditWriter;
    private readonly DpaAuthOptions _options;
    private readonly ILogger<SqlDpaUserStore> _logger;

    public SqlDpaUserStore(
        ISqlConnectionFactory connectionFactory,
        IAuthenticationAuditWriter auditWriter,
        IOptions<DpaAuthOptions> options,
        ILogger<SqlDpaUserStore> logger)
    {
        _connectionFactory = connectionFactory;
        _auditWriter = auditWriter;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<AuthenticatedPortalUser?> FindByNormalizedUserNameAsync(string normalizedUserName, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FindUserProcedureName;
        command.Parameters.Add(new SqlParameter("@NormalizedUserName", SqlDbType.NVarChar, 320) { Value = normalizedUserName });

        AuthenticatedPortalUser? user = null;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        if (await reader.ReadAsync(cancellationToken))
        {
            user = new AuthenticatedPortalUser
            {
                PortalUserId = reader.GetInt32(reader.GetOrdinal("PortalUserID")),
                PersonId = reader.GetInt32(reader.GetOrdinal("PersonID")),
                UserName = reader.GetString(reader.GetOrdinal("UserName")),
                NormalizedUserName = reader.GetString(reader.GetOrdinal("NormalizedUserName")),
                AccountStatusCode = reader.GetString(reader.GetOrdinal("AccountStatusCode")),
                MfaEnabled = reader.GetBoolean(reader.GetOrdinal("MFAEnabled")),
                DisplayName = BuildDisplayName(reader.GetString(reader.GetOrdinal("FirstName")), reader.GetString(reader.GetOrdinal("LastName"))),
                Credential = reader.IsDBNull(reader.GetOrdinal("PortalCredentialID"))
                    ? null
                    : new DpaCredentialRecord
                    {
                        PortalCredentialId = reader.GetInt32(reader.GetOrdinal("PortalCredentialID")),
                        PasswordHash = reader.GetString(reader.GetOrdinal("PasswordHash")),
                        CredentialTypeCode = reader.IsDBNull(reader.GetOrdinal("CredentialTypeCode")) ? null : reader.GetString(reader.GetOrdinal("CredentialTypeCode")),
                        CredentialStatusCode = reader.IsDBNull(reader.GetOrdinal("CredentialStatusCode")) ? null : reader.GetString(reader.GetOrdinal("CredentialStatusCode")),
                        MustChangePassword = reader.GetBoolean(reader.GetOrdinal("MustChangePassword")),
                        FailedAttemptCount = reader.GetInt32(reader.GetOrdinal("FailedAttemptCount")),
                        LockoutEndUtc = reader.IsDBNull(reader.GetOrdinal("LockoutEndUTC")) ? null : new DateTimeOffset(DateTime.SpecifyKind(reader.GetDateTime(reader.GetOrdinal("LockoutEndUTC")), DateTimeKind.Utc)),
                        IsActive = reader.GetBoolean(reader.GetOrdinal("CredentialIsActive")),
                        IsDeleted = reader.GetBoolean(reader.GetOrdinal("CredentialIsDeleted"))
                    }
            };
        }

        if (user is null)
        {
            return null;
        }

        if (await reader.NextResultAsync(cancellationToken))
        {
            var roles = new List<string>();
            while (await reader.ReadAsync(cancellationToken))
            {
                roles.Add(reader.GetString(reader.GetOrdinal("RoleCode")));
            }
            user.RoleCodes = roles;
        }

        if (await reader.NextResultAsync(cancellationToken))
        {
            var siteIds = new List<int>();
            while (await reader.ReadAsync(cancellationToken))
            {
                siteIds.Add(reader.GetInt32(reader.GetOrdinal("SiteID")));
            }
            user.SiteIds = siteIds;
        }

        if (await reader.NextResultAsync(cancellationToken))
        {
            var childIds = new List<int>();
            while (await reader.ReadAsync(cancellationToken))
            {
                childIds.Add(reader.GetInt32(reader.GetOrdinal("ChildID")));
            }
            user.GuardianChildIds = childIds;
        }

        return user;
    }

    public async Task<bool> IsSessionActiveAsync(long loginSessionId, int portalUserId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SessionIsActiveProcedureName;
        command.Parameters.Add(new SqlParameter("@LoginSessionID", SqlDbType.BigInt) { Value = loginSessionId });
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    public async Task<long> CreateLoginSessionAsync(AuthenticatedPortalUser user, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);

        var tokenHash = CreateRandomTokenHash();
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SessionCreateProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = user.PortalUserId });
        command.Parameters.Add(new SqlParameter("@PortalCredentialID", SqlDbType.Int) { Value = (object?)user.Credential?.PortalCredentialId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@RefreshTokenHash", SqlDbType.VarBinary, tokenHash.Length) { Value = tokenHash });
        command.Parameters.Add(new SqlParameter("@RefreshTokenExpiresUTC", SqlDbType.DateTime2) { Value = DateTime.UtcNow.AddMinutes(_options.CookieSlidingExpirationMinutes) });
        command.Parameters.Add(new SqlParameter("@RemoteAddress", SqlDbType.NVarChar, 100) { Value = (object?)remoteAddress ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@UserAgent", SqlDbType.NVarChar, -1) { Value = (object?)userAgent ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = user.PortalUserId });

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return Convert.ToInt64(result);
    }

    public async Task RecordSuccessfulLoginAsync(AuthenticatedPortalUser user, long loginSessionId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = RecordSuccessfulLoginProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = user.PortalUserId });
        command.Parameters.Add(new SqlParameter("@PortalCredentialID", SqlDbType.Int) { Value = (object?)user.Credential?.PortalCredentialId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@ModifiedByUserID", SqlDbType.Int) { Value = user.PortalUserId });

        await command.ExecuteNonQueryAsync(cancellationToken);

        await _auditWriter.WriteAsync(
            eventTypeCode: "LOGIN_SUCCESS",
            resultCode: _options.AuthenticationResultSuccessCode,
            portalUserId: user.PortalUserId,
            portalCredentialId: user.Credential?.PortalCredentialId,
            loginSessionId: loginSessionId,
            userNameAttempted: user.UserName,
            failureReason: null,
            remoteAddress: remoteAddress,
            userAgent: userAgent,
            notes: "Login session created.",
            cancellationToken: cancellationToken);
    }

    public async Task RecordFailedLoginAsync(AuthenticatedPortalUser? user, string? userNameAttempted, string? failureReason, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        int? portalUserId = user?.PortalUserId;
        int? portalCredentialId = user?.Credential?.PortalCredentialId;
        var resultCode = _options.AuthenticationResultFailureCode;
        string? notes = null;

        if (user?.Credential is not null)
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = RecordFailedLoginProcedureName;
            command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = user.PortalUserId });
            command.Parameters.Add(new SqlParameter("@PortalCredentialID", SqlDbType.Int) { Value = user.Credential.PortalCredentialId });
            command.Parameters.Add(new SqlParameter("@LockoutThreshold", SqlDbType.Int) { Value = _options.LockoutThreshold });
            command.Parameters.Add(new SqlParameter("@LockoutDurationMinutes", SqlDbType.Int) { Value = _options.LockoutDurationMinutes });
            command.Parameters.Add(new SqlParameter("@ModifiedByUserID", SqlDbType.Int) { Value = user.PortalUserId });

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (await reader.ReadAsync(cancellationToken))
            {
                var failedCount = reader.GetInt32(reader.GetOrdinal("FailedAttemptCount"));
                var lockoutTriggered = reader.GetBoolean(reader.GetOrdinal("LockoutTriggered"));
                notes = $"FailedAttemptCount={failedCount}";
                if (lockoutTriggered)
                {
                    resultCode = _options.AuthenticationResultBlockedCode;
                }
            }
        }

        await _auditWriter.WriteAsync(
            eventTypeCode: "LOGIN_FAILED",
            resultCode: resultCode,
            portalUserId: portalUserId,
            portalCredentialId: portalCredentialId,
            loginSessionId: null,
            userNameAttempted: userNameAttempted,
            failureReason: failureReason,
            remoteAddress: remoteAddress,
            userAgent: userAgent,
            notes: notes,
            cancellationToken: cancellationToken);
    }

    public async Task RevokeSessionAsync(long loginSessionId, int portalUserId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = RevokeSessionProcedureName;
        command.Parameters.Add(new SqlParameter("@LoginSessionID", SqlDbType.BigInt) { Value = loginSessionId });
        command.Parameters.Add(new SqlParameter("@RevokedByUserID", SqlDbType.Int) { Value = portalUserId });
        command.Parameters.Add(new SqlParameter("@RevocationReason", SqlDbType.NVarChar, -1) { Value = "User signed out." });
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<bool> CanAccessSiteAsync(int portalUserId, int siteId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = CheckSiteAccessProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    public async Task<bool> CanAccessChildAsync(int portalUserId, int childId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = CheckChildAccessProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });
        command.Parameters.Add(new SqlParameter("@ChildID", SqlDbType.Int) { Value = childId });

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    private static string BuildDisplayName(string firstName, string lastName)
        => string.Join(' ', new[] { firstName, lastName }.Where(part => !string.IsNullOrWhiteSpace(part)));

    private static byte[] CreateRandomTokenHash()
    {
        Span<byte> rawToken = stackalloc byte[32];
        RandomNumberGenerator.Fill(rawToken);
        return SHA256.HashData(rawToken);
    }
}
