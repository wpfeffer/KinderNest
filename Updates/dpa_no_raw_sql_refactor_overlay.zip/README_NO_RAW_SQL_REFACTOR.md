# No Raw SQL Refactor Overlay

This overlay removes the currently identified ad hoc SQL from the live application code and replaces it with stored procedure calls.

## C# files replaced
- `DaycareProviderAssistant/Auth/Services/SqlDpaUserStore.cs`
- `DaycareProviderAssistant/Auth/Services/SqlAuthenticationAuditWriter.cs`
- `DaycareProviderAssistant/Auth/Services/AdminBootstrapService.cs`
- `DaycareProviderAssistant/Provider/Services/ProviderPortalService.cs`
- `DaycareProviderAssistant/Images/Services/EncryptedImageService.cs`

## New stored procedures added
### sec
- `usp_PortalUserAuthentication_GetByNormalizedUserName.sql`
- `usp_LoginSession_IsActive.sql`
- `usp_LoginSession_Create.sql`
- `usp_PortalUser_RecordSuccessfulLogin.sql`
- `usp_PortalCredential_RecordFailedLogin.sql`
- `usp_PortalUser_Access_CheckSite.sql`
- `usp_PortalUser_Access_CheckChild.sql`

### party
- `usp_BootstrapAdmin_CanBootstrap.sql`
- `usp_PortalUserAssignedSite_List.sql`
- `usp_SiteImageSubjectAdult_List.sql`

### child
- `usp_GuardianAccessibleChild_List.sql`
- `usp_GuardianAccess_CheckSite.sql`
- `usp_SiteImageSubjectChild_List.sql`

## Important review points
- `SqlDpaUserStore.RevokeSessionAsync()` now relies on `sec.usp_LoginSession_Revoke`, which already writes the logout audit event.
- `SqlAuthenticationAuditWriter` now delegates directly to `audit.usp_WriteAuthenticationEvent`.
- Shared provider site listing now goes through `party.usp_PortalUserAssignedSite_List`.
- This overlay targets the current live code paths, not the historical `Updates/` snapshots.

## Patch stubs included
- `patches/dpa.sqlproj.patch`
- `patches/master_install.sql.patch`
