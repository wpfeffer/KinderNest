CREATE OR ALTER PROCEDURE child.usp_GuardianAccess_CheckSite
    @PersonID INT,
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT HasAccess =
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM child.ChildPersonRelationship cpr
                INNER JOIN child.Child c
                    ON c.ChildID = cpr.ChildID
                   AND c.IsDeleted = 0
                   AND c.IsActive = 1
                WHERE cpr.PersonID = @PersonID
                  AND c.SiteID = @SiteID
                  AND cpr.HasPortalAccess = 1
                  AND cpr.IsDeleted = 0
                  AND cpr.IsActive = 1
                  AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
                  AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
            )
            THEN 1 ELSE 0 END AS INT
        );
END;
GO
