CREATE OR ALTER PROCEDURE sec.usp_PortalUser_Access_CheckSite
    @PortalUserID INT,
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT HasAccess =
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM party.SiteUserAssignment sua
                WHERE sua.PortalUserID = @PortalUserID
                  AND sua.SiteID = @SiteID
                  AND sua.IsActive = 1
                  AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
                  AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
            )
            THEN 1 ELSE 0 END AS INT
        );
END;
GO
