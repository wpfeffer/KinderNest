CREATE OR ALTER PROCEDURE sec.usp_PortalCredential_RecordFailedLogin
    @PortalUserID INT,
    @PortalCredentialID INT,
    @LockoutThreshold INT = 5,
    @LockoutDurationMinutes INT = 15,
    @ModifiedByUserID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LockedStatusCodeValueID INT;
    DECLARE @NewFailedAttemptCount INT;
    DECLARE @LockoutTriggered BIT = 0;

    SELECT @LockedStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    BEGIN TRANSACTION;

    UPDATE sec.PortalCredential
       SET FailedAttemptCount = FailedAttemptCount + 1,
           LastFailedAttemptUTC = SYSUTCDATETIME(),
           LockoutStartUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN SYSUTCDATETIME() ELSE LockoutStartUTC END,
           LockoutEndUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN DATEADD(MINUTE, @LockoutDurationMinutes, SYSUTCDATETIME()) ELSE LockoutEndUTC END,
           CredentialStatusCodeValueID = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold AND @LockedStatusCodeValueID IS NOT NULL THEN @LockedStatusCodeValueID ELSE CredentialStatusCodeValueID END,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = COALESCE(@ModifiedByUserID, @PortalUserID)
     WHERE PortalCredentialID = @PortalCredentialID;

    SELECT
        @NewFailedAttemptCount = pc.FailedAttemptCount,
        @LockoutTriggered = CASE WHEN pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME() THEN 1 ELSE 0 END
    FROM sec.PortalCredential pc
    WHERE pc.PortalCredentialID = @PortalCredentialID;

    COMMIT TRANSACTION;

    SELECT
        FailedAttemptCount = COALESCE(@NewFailedAttemptCount, 0),
        LockoutTriggered = @LockoutTriggered;
END;
GO
