CREATE OR ALTER PROCEDURE sec.usp_PortalUser_RecordSuccessfulLogin
    @PortalUserID INT,
    @PortalCredentialID INT = NULL,
    @ModifiedByUserID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ActiveStatusCodeValueID INT;

    SELECT @ActiveStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'ACTIVE'
      AND cv.IsActive = 1;

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET LastLoginUTC = SYSUTCDATETIME(),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = COALESCE(@ModifiedByUserID, @PortalUserID)
     WHERE PortalUserID = @PortalUserID;

    IF @PortalCredentialID IS NOT NULL
    BEGIN
        UPDATE sec.PortalCredential
           SET CredentialStatusCodeValueID = COALESCE(@ActiveStatusCodeValueID, CredentialStatusCodeValueID),
               FailedAttemptCount = 0,
               LastFailedAttemptUTC = NULL,
               LockoutStartUTC = NULL,
               LockoutEndUTC = NULL,
               LastSuccessfulLoginUTC = SYSUTCDATETIME(),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = COALESCE(@ModifiedByUserID, @PortalUserID)
         WHERE PortalCredentialID = @PortalCredentialID;
    END;

    COMMIT TRANSACTION;

    SELECT 1 AS SucceededFlag;
END;
GO
