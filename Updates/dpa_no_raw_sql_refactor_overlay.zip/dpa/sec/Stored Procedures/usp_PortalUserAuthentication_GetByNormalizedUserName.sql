CREATE OR ALTER PROCEDURE sec.usp_PortalUserAuthentication_GetByNormalizedUserName
    @NormalizedUserName NVARCHAR(320)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PersonID INT;

    SELECT TOP (1)
        @PortalUserID = u.PortalUserID,
        @PersonID = u.PersonID
    FROM party.PortalUser u
    INNER JOIN party.Person p
        ON p.PersonID = u.PersonID
    WHERE u.NormalizedUserName = @NormalizedUserName
      AND u.IsActive = 1
      AND u.IsDeleted = 0
      AND p.IsActive = 1
      AND p.IsDeleted = 0;

    SELECT TOP (1)
        u.PortalUserID,
        u.PersonID,
        u.UserName,
        u.NormalizedUserName,
        u.AccountStatusCode,
        u.MFAEnabled,
        p.FirstName,
        p.LastName,
        c.PortalCredentialID,
        c.PasswordHash,
        typeCv.CodeValue AS CredentialTypeCode,
        statusCv.CodeValue AS CredentialStatusCode,
        c.MustChangePassword,
        c.FailedAttemptCount,
        c.LockoutEndUTC,
        c.IsActive AS CredentialIsActive,
        c.IsDeleted AS CredentialIsDeleted
    FROM party.PortalUser u
    INNER JOIN party.Person p ON p.PersonID = u.PersonID
    LEFT JOIN sec.PortalCredential c ON c.PortalUserID = u.PortalUserID AND c.IsPrimary = 1 AND c.IsDeleted = 0
    LEFT JOIN ref.CodeValue typeCv ON typeCv.CodeValueID = c.CredentialTypeCodeValueID
    LEFT JOIN ref.CodeValue statusCv ON statusCv.CodeValueID = c.CredentialStatusCodeValueID
    WHERE u.PortalUserID = @PortalUserID
      AND u.IsActive = 1
      AND u.IsDeleted = 0
      AND p.IsActive = 1
      AND p.IsDeleted = 0;

    SELECT DISTINCT r.RoleCode
    FROM party.PortalUserRole pur
    INNER JOIN ref.Role r ON r.RoleID = pur.RoleID
    WHERE pur.PortalUserID = @PortalUserID
      AND pur.IsActive = 1
      AND r.IsActive = 1
      AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
      AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME());

    SELECT DISTINCT sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
      AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME());

    SELECT DISTINCT cpr.ChildID
    FROM child.ChildPersonRelationship cpr
    WHERE cpr.PersonID = @PersonID
      AND cpr.HasPortalAccess = 1
      AND cpr.IsActive = 1
      AND cpr.IsDeleted = 0
      AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
      AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date));
END;
GO
