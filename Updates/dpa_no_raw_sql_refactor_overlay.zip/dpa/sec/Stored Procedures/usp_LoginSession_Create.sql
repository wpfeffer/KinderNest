CREATE OR ALTER PROCEDURE sec.usp_LoginSession_Create
    @PortalUserID INT,
    @PortalCredentialID INT = NULL,
    @RefreshTokenHash VARBINARY(64),
    @RefreshTokenExpiresUTC DATETIME2(0),
    @RemoteAddress NVARCHAR(100) = NULL,
    @UserAgent NVARCHAR(MAX) = NULL,
    @CreatedByUserID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SessionStatusCodeValueID INT;

    SELECT @SessionStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'LoginSessionStatus'
      AND cv.CodeValue = N'ACTIVE'
      AND cv.IsActive = 1;

    IF @SessionStatusCodeValueID IS NULL
    BEGIN
        THROW 50460, 'Active login session status code was not found.', 1;
    END;

    INSERT INTO sec.LoginSession
    (
        PortalUserID,
        PortalCredentialID,
        SessionStatusCodeValueID,
        RefreshTokenHash,
        RefreshTokenExpiresUTC,
        RemoteAddress,
        UserAgent,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @PortalCredentialID,
        @SessionStatusCodeValueID,
        @RefreshTokenHash,
        @RefreshTokenExpiresUTC,
        @RemoteAddress,
        @UserAgent,
        @CreatedByUserID
    );

    SELECT CAST(SCOPE_IDENTITY() AS BIGINT) AS LoginSessionID;
END;
GO
