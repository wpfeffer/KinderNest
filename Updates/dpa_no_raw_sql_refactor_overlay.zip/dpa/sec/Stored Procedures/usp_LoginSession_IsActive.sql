CREATE OR ALTER PROCEDURE sec.usp_LoginSession_IsActive
    @LoginSessionID BIGINT,
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT IsActive =
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM sec.LoginSession ls
                WHERE ls.LoginSessionID = @LoginSessionID
                  AND ls.PortalUserID = @PortalUserID
                  AND ls.RevokedUTC IS NULL
                  AND ls.RefreshTokenExpiresUTC >= SYSUTCDATETIME()
            )
            THEN 1 ELSE 0 END AS INT
        );
END;
GO
