CREATE OR ALTER PROCEDURE sec.usp_PortalUser_Access_CheckChild
    @PortalUserID INT,
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT HasAccess =
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM child.Child c
                WHERE c.ChildID = @ChildID
                  AND c.IsActive = 1
                  AND c.IsDeleted = 0
                  AND EXISTS
                  (
                      SELECT 1
                      FROM party.SiteUserAssignment sua
                      WHERE sua.PortalUserID = @PortalUserID
                        AND sua.SiteID = c.SiteID
                        AND sua.IsActive = 1
                        AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
                        AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
                  )
            )
            OR EXISTS
            (
                SELECT 1
                FROM party.PortalUser pu
                INNER JOIN child.ChildPersonRelationship cpr ON cpr.PersonID = pu.PersonID
                WHERE pu.PortalUserID = @PortalUserID
                  AND cpr.ChildID = @ChildID
                  AND cpr.IsActive = 1
                  AND cpr.IsDeleted = 0
                  AND cpr.HasPortalAccess = 1
                  AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
                  AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
            )
            THEN 1 ELSE 0 END AS INT
        );
END;
GO
