CREATE OR ALTER PROCEDURE party.usp_PortalUserAssignedSite_List
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT DISTINCT
        s.SiteID,
        s.SiteName,
        pr.ProviderName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
       AND pr.IsActive = 1
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
      AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ORDER BY pr.ProviderName, s.SiteName;
END;
GO
