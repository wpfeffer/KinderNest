CREATE OR ALTER PROCEDURE party.usp_BootstrapAdmin_CanBootstrap
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        CanBootstrap = CAST(
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM party.PortalUser pu
                INNER JOIN party.PortalUserRole pur
                    ON pur.PortalUserID = pu.PortalUserID
                INNER JOIN ref.Role r
                    ON r.RoleID = pur.RoleID
                WHERE pu.IsDeleted = 0
                  AND pu.IsActive = 1
                  AND pur.IsActive = 1
                  AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
                  AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC > SYSUTCDATETIME())
                  AND r.IsActive = 1
                  AND r.RoleCode IN (N'PLATFORM_ADMIN', N'COMPLIANCE_ADMIN', N'DATABASE_ADMIN', N'SUPPORT_ADMIN')
            )
            THEN 0 ELSE 1 END AS BIT
        );
END;
GO
