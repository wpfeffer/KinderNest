using DaycareProviderAssistant.Admin.Services;
using DaycareProviderAssistant.Auditing;
using DaycareProviderAssistant.Auth.Endpoints;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Components;
using DaycareProviderAssistant.Portal.Services;

namespace DaycareProviderAssistant;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddRazorComponents()
            .AddInteractiveServerComponents();

        builder.Services.AddDpaAuditCore();
        builder.Services.AddDpaAuthentication(builder.Configuration);
        builder.Services.AddScoped<PortalBrandingService>();
        builder.Services.AddScoped<PortalNavigationService>();
        builder.Services.AddScoped<IAdminDashboardService, AdminDashboardService>();
        builder.Services.AddScoped<IAdminProviderApprovalService, AdminProviderApprovalService>();

        var app = builder.Build();

        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
        app.UseHttpsRedirection();
        app.UseAntiforgery();
        app.UseAuthentication();
        app.UseAuthorization();

        app.MapStaticAssets();
        app.MapDpaAuthEndpoints();
        app.MapRazorComponents<App>()
            .AddInteractiveServerRenderMode();

        app.Run();
    }
}
