using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminProviderApprovalService : IAdminProviderApprovalService
{
    private const string PendingListProcedure = "party.usp_AdminPendingProvider_List";
    private const string ApproveProcedure = "party.usp_ProviderOwner_Approve";
    private const string RejectProcedure = "party.usp_ProviderOwner_Reject";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminProviderApprovalService> _logger;

    public AdminProviderApprovalService(
        ISqlConnectionFactory connectionFactory,
        ILogger<AdminProviderApprovalService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<PendingProviderApprovalListItemDto>> ListPendingAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<PendingProviderApprovalListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = PendingListProcedure;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new PendingProviderApprovalListItemDto
                {
                    PortalUserId = GetInt32(reader, "PortalUserID"),
                    ProviderId = GetNullableInt32(reader, "ProviderID"),
                    SiteId = GetNullableInt32(reader, "SiteID"),
                    SubmittedUtc = GetDateTime(reader, "SubmittedUTC"),
                    RegistrantDisplayName = GetString(reader, "RegistrantDisplayName"),
                    UserName = GetString(reader, "UserName"),
                    PrimaryEmail = GetString(reader, "PrimaryEmail"),
                    ProviderName = GetString(reader, "ProviderName"),
                    BusinessEmail = GetNullableString(reader, "BusinessEmail"),
                    SiteName = GetString(reader, "SiteName"),
                    LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                    LicenseClassCode = GetString(reader, "LicenseClassCode"),
                    LicenseClassName = GetString(reader, "LicenseClassName"),
                    AccountStatusCode = GetString(reader, "AccountStatusCode")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Pending provider approval list failed while executing {ProcedureName}.", PendingListProcedure);
            throw;
        }

        return results;
    }

    public Task<AdminActionOutcomeDto> ApproveAsync(
        int portalUserId,
        int approvedByUserId,
        string? reasonText,
        CancellationToken cancellationToken = default)
        => ExecuteActionAsync(ApproveProcedure, portalUserId, approvedByUserId, reasonText, "Provider registration approved.", cancellationToken);

    public Task<AdminActionOutcomeDto> RejectAsync(
        int portalUserId,
        int rejectedByUserId,
        string? reasonText,
        CancellationToken cancellationToken = default)
        => ExecuteActionAsync(RejectProcedure, portalUserId, rejectedByUserId, reasonText, "Provider registration rejected.", cancellationToken);

    private async Task<AdminActionOutcomeDto> ExecuteActionAsync(
        string procedureName,
        int portalUserId,
        int actingUserId,
        string? reasonText,
        string defaultMessage,
        CancellationToken cancellationToken)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = procedureName;

        AddParameter(command, "@PortalUserID", SqlDbType.Int, portalUserId);
        if (string.Equals(procedureName, ApproveProcedure, StringComparison.OrdinalIgnoreCase))
        {
            AddParameter(command, "@ApprovedByUserID", SqlDbType.Int, actingUserId);
        }
        else
        {
            AddParameter(command, "@RejectedByUserID", SqlDbType.Int, actingUserId);
        }

        AddNullableParameter(command, "@ReasonText", SqlDbType.NVarChar, -1, string.IsNullOrWhiteSpace(reasonText) ? null : reasonText.Trim());
        AddParameter(command, "@CorrelationID", SqlDbType.UniqueIdentifier, Guid.NewGuid());

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (await reader.ReadAsync(cancellationToken))
            {
                return new AdminActionOutcomeDto
                {
                    Succeeded = true,
                    Message = GetNullableString(reader, "StatusMessage") ?? defaultMessage,
                    PortalUserId = GetInt32(reader, "PortalUserID"),
                    AccountStatusCode = GetNullableString(reader, "AccountStatusCode"),
                    ModifiedUtc = GetNullableDateTime(reader, "ModifiedUTC")
                };
            }

            return new AdminActionOutcomeDto
            {
                Succeeded = true,
                Message = defaultMessage,
                PortalUserId = portalUserId
            };
        }
        catch (SqlException ex)
        {
            _logger.LogWarning(ex, "Provider approval action {ProcedureName} failed for PortalUserID {PortalUserID}.", procedureName, portalUserId);

            return new AdminActionOutcomeDto
            {
                Succeeded = false,
                Message = string.IsNullOrWhiteSpace(ex.Message) ? "The approval action could not be completed." : ex.Message,
                PortalUserId = portalUserId
            };
        }
    }

    private static void AddParameter(SqlCommand command, string name, SqlDbType sqlDbType, object value)
    {
        var parameter = command.Parameters.Add(name, sqlDbType);
        parameter.Value = value;
    }

    private static void AddNullableParameter(SqlCommand command, string name, SqlDbType sqlDbType, int size, string? value)
    {
        var parameter = command.Parameters.Add(name, sqlDbType, size);
        parameter.Value = string.IsNullOrWhiteSpace(value) ? DBNull.Value : value;
    }

    private static int GetInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
    }

    private static int? GetNullableInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    private static string GetString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static DateTime GetDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? DateTime.MinValue : reader.GetDateTime(ordinal);
    }

    private static DateTime? GetNullableDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);
    }
}
