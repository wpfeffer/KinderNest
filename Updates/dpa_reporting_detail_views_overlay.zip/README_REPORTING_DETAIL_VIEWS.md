# Bullet 3 Overlay: Reporting / Detail Views

This overlay contains only the reporting/detail views layer for provider-family reads.

## Included views
- `dpa/rpt/Views/vwProviderHouseholdSummary.sql`
- `dpa/rpt/Views/vwProviderHouseholdChildDetail.sql`
- `dpa/rpt/Views/vwProviderHouseholdPersonDetail.sql`
- `dpa/rpt/Views/vwProviderHouseholdPickupAuthorizationDetail.sql`
- `dpa/rpt/Views/vwProviderFamilyDetail.sql`

## Dependencies
This overlay assumes bullet 1 has already been applied:
- `party.Household`
- `party.HouseholdPerson`
- `child.ChildHousehold`

It also reads existing committed-truth tables already present in the project:
- `party.Person`
- `party.Provider`
- `party.Site`
- `party.Address`
- `child.Child`
- `child.ChildEnrollment`
- `child.PickupDropoffAuthorization`
- `ref.CodeValue`

## Design notes
- These are read models only. They are not write targets.
- Code/role interpretation comes from `ref.CodeValue`.
- The views are intended to support provider portal family list/detail screens and related lookup/report queries.
- `vwProviderFamilyDetail` is intentionally flattened for UI convenience. The more focused views are the safer building blocks for stored procedures and portal queries.

## Patch notes
Patch stubs are included for:
- `dpa/dpa.sqlproj`
- `dpa/Install/master_install.sql`

No GitHub push was performed for this package.
