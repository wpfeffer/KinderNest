CREATE VIEW rpt.vwProviderHouseholdPickupAuthorizationDetail
AS
SELECT
    chh.HouseholdID,
    h.ProviderID,
    pda.PickupDropoffAuthorizationID,
    pda.ChildID,
    CONCAT(ch.FirstName, N' ', ch.LastName) AS ChildDisplayName,
    pda.PersonID,
    CONCAT(p.FirstName, N' ', p.LastName) AS AuthorizedPersonDisplayName,
    p.PrimaryEmail,
    pda.CanPickup,
    pda.CanDropoff,
    pda.IsEmergencyContact,
    pda.Notes,
    pda.EffectiveStartDate,
    pda.EffectiveEndDate,
    pda.IsActive,
    pda.IsDeleted,
    pda.CreatedUTC,
    pda.ModifiedUTC
FROM child.PickupDropoffAuthorization pda
INNER JOIN child.Child ch
    ON ch.ChildID = pda.ChildID
   AND ch.IsDeleted = 0
INNER JOIN child.ChildHousehold chh
    ON chh.ChildID = pda.ChildID
   AND chh.IsDeleted = 0
   AND chh.IsActive = 1
   AND (chh.EffectiveStartUTC IS NULL OR chh.EffectiveStartUTC <= SYSUTCDATETIME())
   AND (chh.EffectiveEndUTC IS NULL OR chh.EffectiveEndUTC >= SYSUTCDATETIME())
INNER JOIN party.Household h
    ON h.HouseholdID = chh.HouseholdID
   AND h.IsDeleted = 0
INNER JOIN party.Person p
    ON p.PersonID = pda.PersonID
   AND p.IsDeleted = 0
WHERE pda.IsDeleted = 0;
GO
