CREATE VIEW rpt.vwProviderHouseholdChildDetail
AS
SELECT
    chh.ChildHouseholdID,
    chh.HouseholdID,
    h.ProviderID,
    ch.ChildID,
    ch.SiteID,
    s.SiteName,
    CONCAT(ch.FirstName, N' ', ch.LastName) AS ChildDisplayName,
    ch.FirstName,
    ch.MiddleName,
    ch.LastName,
    ch.DateOfBirth,
    ch.SpecialDietNotes,
    ch.SpecialNeedsNotes,
    ch.ChildAddressID,
    ca.AddressLine1 AS ChildAddressLine1,
    ca.AddressLine2 AS ChildAddressLine2,
    ca.City AS ChildCity,
    ca.StateProvinceCode AS ChildStateProvinceCode,
    ca.PostalCode AS ChildPostalCode,
    ce.ChildEnrollmentID,
    ce.EnrollmentStartDate,
    ce.EnrollmentEndDate,
    ce.ScheduleSummary,
    ce.FinancialArrangementNotes,
    ce.EnrollmentStatusCode,
    chh.IsPrimaryHousehold,
    chh.IsActive AS ChildHouseholdIsActive,
    chh.IsDeleted AS ChildHouseholdIsDeleted,
    ch.CreatedUTC,
    ch.ModifiedUTC
FROM child.ChildHousehold chh
INNER JOIN party.Household h
    ON h.HouseholdID = chh.HouseholdID
   AND h.IsDeleted = 0
INNER JOIN child.Child ch
    ON ch.ChildID = chh.ChildID
   AND ch.IsDeleted = 0
INNER JOIN party.Site s
    ON s.SiteID = ch.SiteID
   AND s.IsDeleted = 0
LEFT JOIN party.Address ca
    ON ca.AddressID = ch.ChildAddressID
   AND ca.IsDeleted = 0
   AND ca.IsActive = 1
LEFT JOIN child.ChildEnrollment ce
    ON ce.ChildID = ch.ChildID
   AND ce.IsDeleted = 0
   AND ce.IsActive = 1
   AND ce.IsPrimaryEnrollment = 1
WHERE chh.IsDeleted = 0;
GO
