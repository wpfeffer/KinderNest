CREATE VIEW rpt.vwProviderHouseholdPersonDetail
AS
SELECT
    hp.HouseholdPersonID,
    hp.HouseholdID,
    h.ProviderID,
    hp.PersonID,
    CONCAT(p.FirstName, N' ', p.LastName) AS PersonDisplayName,
    p.FirstName,
    p.MiddleName,
    p.LastName,
    p.DateOfBirth,
    p.PrimaryEmail,
    p.PrimaryPhoneNumberID,
    p.PrimaryAddressID,
    p.Notes AS PersonNotes,
    hp.HouseholdRoleCodeValueID,
    cv.CodeDomain AS HouseholdRoleCodeDomain,
    cv.CodeValue AS HouseholdRoleCode,
    cv.CodeName AS HouseholdRoleCodeName,
    hp.IsPrimaryContact,
    hp.EffectiveStartUTC,
    hp.EffectiveEndUTC,
    hp.IsActive AS HouseholdPersonIsActive,
    hp.IsDeleted AS HouseholdPersonIsDeleted,
    p.IsActive AS PersonIsActive,
    p.IsDeleted AS PersonIsDeleted,
    p.CreatedUTC,
    p.ModifiedUTC
FROM party.HouseholdPerson hp
INNER JOIN party.Household h
    ON h.HouseholdID = hp.HouseholdID
   AND h.IsDeleted = 0
INNER JOIN party.Person p
    ON p.PersonID = hp.PersonID
   AND p.IsDeleted = 0
INNER JOIN ref.CodeValue cv
    ON cv.CodeValueID = hp.HouseholdRoleCodeValueID
WHERE hp.IsDeleted = 0;
GO
