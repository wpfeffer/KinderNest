DPA stored procedure batch 3 of 4

Theme:
Admin portal dashboard, approval queue, provider/site/user management, audit trail, and security summary.

Included procedures:
1. ops.usp_AdminDashboard_GetSummary
2. party.usp_AdminPendingProvider_List
3. party.usp_AdminProvider_List
4. party.usp_AdminProvider_GetDetail
5. party.usp_AdminSite_List
6. party.usp_AdminSite_GetDetail
7. party.usp_AdminPortalUser_List
8. party.usp_AdminPortalUser_GetDetail
9. audit.usp_AdminAuditTrail_List
10. ops.usp_AdminSecurity_GetSummary

All procedures are CREATE OR ALTER and align with the data-aware, non-destructive migration rule.
