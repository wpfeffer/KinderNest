CREATE OR ALTER PROCEDURE audit.usp_AdminAuditTrail_List
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (100)
        al.AuditLogID,
        al.EventUTC,
        ActionTitle = CONCAT(al.SchemaName, N'.', al.TableName, N' • ', al.ActionTypeCode),
        ActorDisplay = COALESCE(NULLIF(LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))), N''), actor.UserName, N'System'),
        EntityDisplay = CONCAT(al.TableName, N' #', al.RecordPrimaryKeyValue),
        ScopeDisplay = COALESCE(s.SiteName, CASE WHEN al.SiteID IS NOT NULL THEN CONCAT(N'Site #', al.SiteID) ELSE N'Global' END),
        al.ReasonText,
        al.SucceededFlag
    FROM audit.AuditLog al
    LEFT JOIN party.PortalUser actor
        ON actor.PortalUserID = al.ChangedByUserID
    LEFT JOIN party.Person p
        ON p.PersonID = actor.PersonID
    LEFT JOIN party.Site s
        ON s.SiteID = al.SiteID
    ORDER BY al.EventUTC DESC, al.AuditLogID DESC;
END;
GO
