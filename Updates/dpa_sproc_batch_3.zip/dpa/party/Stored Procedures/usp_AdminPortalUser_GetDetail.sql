CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_GetDetail
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH CredentialSnapshot AS
    (
        SELECT
            c.PortalUserID,
            c.LockoutEndUTC,
            ROW_NUMBER() OVER (PARTITION BY c.PortalUserID ORDER BY c.IsPrimary DESC, c.PortalCredentialID DESC) AS rn
        FROM sec.PortalCredential c
        WHERE c.IsDeleted = 0
    ),
    SessionSnapshot AS
    (
        SELECT
            ls.PortalUserID,
            MAX(ls.SessionStartedUTC) AS LastLoginUTC
        FROM sec.LoginSession ls
        GROUP BY ls.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        pu.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE
            WHEN cs.LockoutEndUTC IS NOT NULL
             AND cs.LockoutEndUTC >= SYSUTCDATETIME() THEN CAST(1 AS bit)
            ELSE CAST(0 AS bit)
        END AS IsLocked,
        cs.LockoutEndUTC,
        ss.LastLoginUTC,
        pu.IsActive,
        pu.RejectionReason
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN CredentialSnapshot cs
        ON cs.PortalUserID = pu.PortalUserID
       AND cs.rn = 1
    LEFT JOIN SessionSnapshot ss
        ON ss.PortalUserID = pu.PortalUserID
    WHERE pu.PortalUserID = @PortalUserID
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0;

    SELECT
        r.RoleCode,
        r.RoleName,
        pur.EffectiveStartUTC,
        pur.EffectiveEndUTC,
        pur.IsActive
    FROM party.PortalUserRole pur
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
    WHERE pur.PortalUserID = @PortalUserID
    ORDER BY pur.EffectiveStartUTC DESC, r.RoleCode;

    SELECT
        sua.SiteID,
        s.SiteName,
        pr.ProviderName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
    WHERE sua.PortalUserID = @PortalUserID
      AND s.IsDeleted = 0
      AND pr.IsDeleted = 0
    ORDER BY sua.EffectiveStartUTC DESC, s.SiteName;

    SELECT TOP (10)
        ls.LoginSessionID,
        statusCv.CodeValue AS SessionStatusCode,
        ls.SessionStartedUTC AS StartedUTC,
        ls.LastSeenUTC,
        ls.RevokedUTC,
        ls.RemoteAddress,
        ls.UserAgent
    FROM sec.LoginSession ls
    LEFT JOIN ref.CodeValue statusCv
        ON statusCv.CodeValueID = ls.SessionStatusCodeValueID
    WHERE ls.PortalUserID = @PortalUserID
    ORDER BY ls.SessionStartedUTC DESC, ls.LoginSessionID DESC;
END;
GO
