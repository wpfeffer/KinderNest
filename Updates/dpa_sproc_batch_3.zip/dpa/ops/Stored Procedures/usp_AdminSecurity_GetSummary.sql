CREATE OR ALTER PROCEDURE ops.usp_AdminSecurity_GetSummary
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @FailureResultCodeValueID INT;
    DECLARE @BlockedResultCodeValueID INT;
    DECLARE @LockedCredentialStatusCodeValueID INT;

    SELECT @FailureResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'FAILURE'
      AND cv.IsActive = 1;

    SELECT @BlockedResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'BLOCKED'
      AND cv.IsActive = 1;

    SELECT @LockedCredentialStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    SELECT
        FailedLoginsToday =
        (
            SELECT COUNT(1)
            FROM audit.AuthenticationEvent ae
            WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
              AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
        ),
        LockedAccounts =
        (
            SELECT COUNT(1)
            FROM sec.PortalCredential pc
            WHERE pc.IsActive = 1
              AND pc.IsDeleted = 0
              AND (
                    (@LockedCredentialStatusCodeValueID IS NOT NULL AND pc.CredentialStatusCodeValueID = @LockedCredentialStatusCodeValueID)
                    OR (pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME())
                  )
        ),
        OpenBreakGlassEvents =
        (
            SELECT COUNT(1)
            FROM audit.BreakGlassEvent bge
            WHERE bge.CompletedUTC IS NULL OR UPPER(bge.CompletionStatusCode) = N'OPEN'
        ),
        ActiveSessions =
        (
            SELECT COUNT(1)
            FROM sec.LoginSession ls
            WHERE ls.RevokedUTC IS NULL
              AND ls.RefreshTokenExpiresUTC >= SYSUTCDATETIME()
        );

    SELECT TOP (20)
        EventUTC,
        Title,
        Detail,
        StatusText,
        StatusCssClass
    FROM
    (
        SELECT
            EventUTC = ae.EventUTC,
            Title = CASE
                WHEN ar.CodeValue = N'BLOCKED' THEN N'Blocked login attempt'
                ELSE N'Failed login attempt'
            END,
            Detail = CONCAT(COALESCE(ae.UserNameAttempted, pu.UserName, N'Unknown user'), N' from ', COALESCE(ae.RemoteAddress, N'unknown IP')),
            StatusText = CASE WHEN ar.CodeValue = N'BLOCKED' THEN N'High' ELSE N'Warning' END,
            StatusCssClass = CASE WHEN ar.CodeValue = N'BLOCKED' THEN N'high' ELSE N'warning' END
        FROM audit.AuthenticationEvent ae
        LEFT JOIN ref.CodeValue ar
            ON ar.CodeValueID = ae.AuthenticationResultCodeValueID
        LEFT JOIN party.PortalUser pu
            ON pu.PortalUserID = ae.PortalUserID
        WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
          AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)

        UNION ALL

        SELECT
            EventUTC = ls.RevokedUTC,
            Title = N'Session revoked',
            Detail = CONCAT(COALESCE(pu.UserName, N'Unknown user'), N' • ', COALESCE(ls.RemoteAddress, N'unknown IP')),
            StatusText = N'Info',
            StatusCssClass = N'info'
        FROM sec.LoginSession ls
        LEFT JOIN party.PortalUser pu
            ON pu.PortalUserID = ls.PortalUserID
        WHERE ls.RevokedUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())

        UNION ALL

        SELECT
            EventUTC = bge.EventUTC,
            Title = N'Break-glass access opened',
            Detail = COALESCE(bge.ReasonText, CONCAT(N'Break-glass event #', bge.BreakGlassEventID)),
            StatusText = N'High',
            StatusCssClass = N'high'
        FROM audit.BreakGlassEvent bge
        WHERE bge.CompletedUTC IS NULL OR UPPER(bge.CompletionStatusCode) = N'OPEN'
    ) security_events
    ORDER BY EventUTC DESC;
END;
GO
