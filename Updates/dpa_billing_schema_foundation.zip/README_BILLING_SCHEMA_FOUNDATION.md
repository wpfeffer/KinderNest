This overlay creates the foundational billing schema for Daycare Provider Assistant.

Scope covered:
- platform billing of providers
- provider billing of families
- processor account references
- subscription/plan catalog
- provider usage metering foundation
- provider invoices and invoice lines
- family billing accounts
- family rates, charge staging, invoices, and invoice lines
- shared payment-method-token and payment records
- billing reference-code seed data

Important:
- this is schema foundation, not a completed billing engine
- it does not yet include billing UI, invoice generation procedures, payment orchestration, webhooks, or settlement reconciliation
- all status/type columns are INT foreign keys to ref.CodeValue
- all tables are additive new objects and respect the non-destructive/data-aware direction
