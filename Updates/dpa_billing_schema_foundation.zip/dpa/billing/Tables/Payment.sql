CREATE TABLE billing.Payment
(
    PaymentID                             INT IDENTITY(1,1)         NOT NULL,
    PaymentScopeCodeValueID               INT                       NOT NULL,
    PaymentStatusCodeValueID              INT                       NOT NULL,
    BillingProviderAccountID              INT                       NOT NULL,
    ProviderID                            INT                       NULL,
    FamilyBillingAccountID                INT                       NULL,
    ProviderInvoiceID                     INT                       NULL,
    FamilyInvoiceID                       INT                       NULL,
    PaymentMethodTokenID                  INT                       NULL,
    ExternalTransactionReference          NVARCHAR(200)             NULL,
    PaymentUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_Payment_PaymentUTC DEFAULT (SYSUTCDATETIME()),
    Amount                                DECIMAL(18,2)             NOT NULL,
    CurrencyCode                          NCHAR(3)                  NOT NULL CONSTRAINT DF_Payment_CurrencyCode DEFAULT (N'USD'),
    ProcessorFeeAmount                    DECIMAL(18,2)             NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_Payment_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_Payment_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_Payment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_Payment PRIMARY KEY CLUSTERED (PaymentID),
    CONSTRAINT FK_Payment_PaymentScopeCodeValue FOREIGN KEY (PaymentScopeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_Payment_PaymentStatusCodeValue FOREIGN KEY (PaymentStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_Payment_BillingProviderAccount FOREIGN KEY (BillingProviderAccountID) REFERENCES billing.BillingProviderAccount (BillingProviderAccountID),
    CONSTRAINT FK_Payment_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_Payment_FamilyBillingAccount FOREIGN KEY (FamilyBillingAccountID) REFERENCES billing.FamilyBillingAccount (FamilyBillingAccountID),
    CONSTRAINT FK_Payment_ProviderInvoice FOREIGN KEY (ProviderInvoiceID) REFERENCES billing.ProviderInvoice (ProviderInvoiceID),
    CONSTRAINT FK_Payment_FamilyInvoice FOREIGN KEY (FamilyInvoiceID) REFERENCES billing.FamilyInvoice (FamilyInvoiceID),
    CONSTRAINT FK_Payment_PaymentMethodToken FOREIGN KEY (PaymentMethodTokenID) REFERENCES billing.PaymentMethodToken (PaymentMethodTokenID),
    CONSTRAINT CK_Payment_Amount_Positive CHECK (Amount >= 0),
    CONSTRAINT CK_Payment_ProcessorFeeAmount_NonNegative CHECK (ProcessorFeeAmount IS NULL OR ProcessorFeeAmount >= 0),
    CONSTRAINT CK_Payment_OneOwner CHECK (
        (CASE WHEN ProviderID IS NULL THEN 0 ELSE 1 END) +
        (CASE WHEN FamilyBillingAccountID IS NULL THEN 0 ELSE 1 END) = 1
    )
);
GO
CREATE INDEX IX_Payment_ProviderID ON billing.Payment (ProviderID, PaymentUTC DESC) WHERE ProviderID IS NOT NULL;
GO
CREATE INDEX IX_Payment_FamilyBillingAccountID ON billing.Payment (FamilyBillingAccountID, PaymentUTC DESC) WHERE FamilyBillingAccountID IS NOT NULL;
GO
CREATE INDEX IX_Payment_PaymentStatusCodeValueID ON billing.Payment (PaymentStatusCodeValueID);
GO
