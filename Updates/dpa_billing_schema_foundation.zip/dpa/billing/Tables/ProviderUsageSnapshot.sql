CREATE TABLE billing.ProviderUsageSnapshot
(
    ProviderUsageSnapshotID               INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NOT NULL,
    SiteID                                INT                       NULL,
    ProviderSubscriptionID                INT                       NULL,
    UsageMetricTypeCodeValueID            INT                       NOT NULL,
    MeasurementStartUTC                   DATETIME2(0)              NOT NULL,
    MeasurementEndUTC                     DATETIME2(0)              NOT NULL,
    QuantityDecimal                       DECIMAL(18,4)             NOT NULL CONSTRAINT DF_ProviderUsageSnapshot_QuantityDecimal DEFAULT (0.0000),
    ByteCount                             BIGINT                    NULL,
    SourceProcedureName                   NVARCHAR(200)             NULL,
    IsBilled                              BIT                       NOT NULL CONSTRAINT DF_ProviderUsageSnapshot_IsBilled DEFAULT (0),
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderUsageSnapshot_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderUsageSnapshot_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderUsageSnapshot_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderUsageSnapshot PRIMARY KEY CLUSTERED (ProviderUsageSnapshotID),
    CONSTRAINT FK_ProviderUsageSnapshot_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_ProviderUsageSnapshot_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_ProviderUsageSnapshot_ProviderSubscription FOREIGN KEY (ProviderSubscriptionID) REFERENCES billing.ProviderSubscription (ProviderSubscriptionID),
    CONSTRAINT FK_ProviderUsageSnapshot_UsageMetricTypeCodeValue FOREIGN KEY (UsageMetricTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_ProviderUsageSnapshot_QuantityDecimal_NonNegative CHECK (QuantityDecimal >= 0),
    CONSTRAINT CK_ProviderUsageSnapshot_ByteCount_NonNegative CHECK (ByteCount IS NULL OR ByteCount >= 0),
    CONSTRAINT CK_ProviderUsageSnapshot_PeriodOrder CHECK (MeasurementEndUTC >= MeasurementStartUTC)
);
GO
CREATE INDEX IX_ProviderUsageSnapshot_ProviderID_Period ON billing.ProviderUsageSnapshot (ProviderID, MeasurementStartUTC, MeasurementEndUTC);
GO
CREATE INDEX IX_ProviderUsageSnapshot_SiteID ON billing.ProviderUsageSnapshot (SiteID) WHERE SiteID IS NOT NULL;
GO
CREATE INDEX IX_ProviderUsageSnapshot_UsageMetricTypeCodeValueID ON billing.ProviderUsageSnapshot (UsageMetricTypeCodeValueID);
GO
