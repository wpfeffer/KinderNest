CREATE TABLE billing.ProviderInvoiceLine
(
    ProviderInvoiceLineID                 INT IDENTITY(1,1)         NOT NULL,
    ProviderInvoiceID                     INT                       NOT NULL,
    LineTypeCodeValueID                   INT                       NOT NULL,
    Description                           NVARCHAR(500)             NOT NULL,
    QuantityDecimal                       DECIMAL(18,4)             NOT NULL CONSTRAINT DF_ProviderInvoiceLine_QuantityDecimal DEFAULT (1.0000),
    UnitPriceAmount                       DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoiceLine_UnitPriceAmount DEFAULT (0.00),
    LineAmount                            DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoiceLine_LineAmount DEFAULT (0.00),
    ProviderUsageSnapshotID               INT                       NULL,
    RelatedSiteID                         INT                       NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderInvoiceLine_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderInvoiceLine_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderInvoiceLine_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderInvoiceLine PRIMARY KEY CLUSTERED (ProviderInvoiceLineID),
    CONSTRAINT FK_ProviderInvoiceLine_ProviderInvoice FOREIGN KEY (ProviderInvoiceID) REFERENCES billing.ProviderInvoice (ProviderInvoiceID),
    CONSTRAINT FK_ProviderInvoiceLine_LineTypeCodeValue FOREIGN KEY (LineTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_ProviderInvoiceLine_ProviderUsageSnapshot FOREIGN KEY (ProviderUsageSnapshotID) REFERENCES billing.ProviderUsageSnapshot (ProviderUsageSnapshotID),
    CONSTRAINT FK_ProviderInvoiceLine_RelatedSite FOREIGN KEY (RelatedSiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT CK_ProviderInvoiceLine_QuantityDecimal_NonNegative CHECK (QuantityDecimal >= 0),
    CONSTRAINT CK_ProviderInvoiceLine_UnitPriceAmount_NonNegative CHECK (UnitPriceAmount >= 0),
    CONSTRAINT CK_ProviderInvoiceLine_LineAmount_NonNegative CHECK (LineAmount >= 0)
);
GO
CREATE INDEX IX_ProviderInvoiceLine_ProviderInvoiceID ON billing.ProviderInvoiceLine (ProviderInvoiceID);
GO
CREATE INDEX IX_ProviderInvoiceLine_LineTypeCodeValueID ON billing.ProviderInvoiceLine (LineTypeCodeValueID);
GO
