CREATE TABLE billing.PaymentMethodToken
(
    PaymentMethodTokenID                  INT IDENTITY(1,1)         NOT NULL,
    BillingProviderAccountID              INT                       NOT NULL,
    ProviderID                            INT                       NULL,
    FamilyBillingAccountID                INT                       NULL,
    PaymentMethodTypeCodeValueID          INT                       NOT NULL,
    ExternalCustomerReference             NVARCHAR(200)             NULL,
    ExternalPaymentMethodReference        NVARCHAR(200)             NOT NULL,
    DisplayLabel                          NVARCHAR(200)             NOT NULL,
    MaskedDetails                         NVARCHAR(100)             NULL,
    IsDefault                             BIT                       NOT NULL CONSTRAINT DF_PaymentMethodToken_IsDefault DEFAULT (0),
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_PaymentMethodToken_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_PaymentMethodToken_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_PaymentMethodToken_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_PaymentMethodToken PRIMARY KEY CLUSTERED (PaymentMethodTokenID),
    CONSTRAINT FK_PaymentMethodToken_BillingProviderAccount FOREIGN KEY (BillingProviderAccountID) REFERENCES billing.BillingProviderAccount (BillingProviderAccountID),
    CONSTRAINT FK_PaymentMethodToken_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_PaymentMethodToken_FamilyBillingAccount FOREIGN KEY (FamilyBillingAccountID) REFERENCES billing.FamilyBillingAccount (FamilyBillingAccountID),
    CONSTRAINT FK_PaymentMethodToken_PaymentMethodTypeCodeValue FOREIGN KEY (PaymentMethodTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_PaymentMethodToken_OneOwner CHECK (
        (CASE WHEN ProviderID IS NULL THEN 0 ELSE 1 END) +
        (CASE WHEN FamilyBillingAccountID IS NULL THEN 0 ELSE 1 END) = 1
    )
);
GO
CREATE INDEX IX_PaymentMethodToken_ProviderID ON billing.PaymentMethodToken (ProviderID) WHERE ProviderID IS NOT NULL;
GO
CREATE INDEX IX_PaymentMethodToken_FamilyBillingAccountID ON billing.PaymentMethodToken (FamilyBillingAccountID) WHERE FamilyBillingAccountID IS NOT NULL;
GO
