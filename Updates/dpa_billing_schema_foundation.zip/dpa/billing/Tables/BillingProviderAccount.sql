CREATE TABLE billing.BillingProviderAccount
(
    BillingProviderAccountID              INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NULL,
    AccountUseTypeCodeValueID             INT                       NOT NULL,
    ProcessorTypeCodeValueID              INT                       NOT NULL,
    DisplayName                           NVARCHAR(200)             NOT NULL,
    MerchantAccountReference              NVARCHAR(200)             NULL,
    ExternalAccountReference              NVARCHAR(200)             NULL,
    ApiCredentialReference                NVARCHAR(500)             NULL,
    WebhookSecretReference                NVARCHAR(500)             NULL,
    SettlementCurrencyCode                NCHAR(3)                  NOT NULL CONSTRAINT DF_BillingProviderAccount_SettlementCurrencyCode DEFAULT (N'USD'),
    IsPrimary                             BIT                       NOT NULL CONSTRAINT DF_BillingProviderAccount_IsPrimary DEFAULT (0),
    EffectiveStartUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_BillingProviderAccount_EffectiveStartUTC DEFAULT (SYSUTCDATETIME()),
    EffectiveEndUTC                       DATETIME2(0)              NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_BillingProviderAccount_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_BillingProviderAccount_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_BillingProviderAccount_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_BillingProviderAccount PRIMARY KEY CLUSTERED (BillingProviderAccountID),
    CONSTRAINT FK_BillingProviderAccount_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_BillingProviderAccount_AccountUseTypeCodeValue FOREIGN KEY (AccountUseTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_BillingProviderAccount_ProcessorTypeCodeValue FOREIGN KEY (ProcessorTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID)
);
GO
CREATE INDEX IX_BillingProviderAccount_ProviderID ON billing.BillingProviderAccount (ProviderID) WHERE ProviderID IS NOT NULL;
GO
CREATE INDEX IX_BillingProviderAccount_AccountUseTypeCodeValueID ON billing.BillingProviderAccount (AccountUseTypeCodeValueID);
GO
CREATE INDEX IX_BillingProviderAccount_ProcessorTypeCodeValueID ON billing.BillingProviderAccount (ProcessorTypeCodeValueID);
GO
