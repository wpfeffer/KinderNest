CREATE TABLE billing.FamilyCharge
(
    FamilyChargeID                        INT IDENTITY(1,1)         NOT NULL,
    FamilyBillingAccountID                INT                       NOT NULL,
    ChildID                               INT                       NULL,
    ChargeTypeCodeValueID                 INT                       NOT NULL,
    ChargeStatusCodeValueID               INT                       NOT NULL,
    ServiceDate                           DATE                      NOT NULL,
    Description                           NVARCHAR(500)             NOT NULL,
    QuantityDecimal                       DECIMAL(18,4)             NOT NULL CONSTRAINT DF_FamilyCharge_QuantityDecimal DEFAULT (1.0000),
    UnitPriceAmount                       DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyCharge_UnitPriceAmount DEFAULT (0.00),
    ChargeAmount                          DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyCharge_ChargeAmount DEFAULT (0.00),
    TaxAmount                             DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyCharge_TaxAmount DEFAULT (0.00),
    DiscountAmount                        DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyCharge_DiscountAmount DEFAULT (0.00),
    FamilyInvoiceLineID                   INT                       NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_FamilyCharge_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_FamilyCharge_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyCharge_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_FamilyCharge PRIMARY KEY CLUSTERED (FamilyChargeID),
    CONSTRAINT FK_FamilyCharge_FamilyBillingAccount FOREIGN KEY (FamilyBillingAccountID) REFERENCES billing.FamilyBillingAccount (FamilyBillingAccountID),
    CONSTRAINT FK_FamilyCharge_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_FamilyCharge_ChargeTypeCodeValue FOREIGN KEY (ChargeTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_FamilyCharge_ChargeStatusCodeValue FOREIGN KEY (ChargeStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_FamilyCharge_QuantityDecimal_NonNegative CHECK (QuantityDecimal >= 0),
    CONSTRAINT CK_FamilyCharge_UnitPriceAmount_NonNegative CHECK (UnitPriceAmount >= 0),
    CONSTRAINT CK_FamilyCharge_ChargeAmount_NonNegative CHECK (ChargeAmount >= 0),
    CONSTRAINT CK_FamilyCharge_TaxAmount_NonNegative CHECK (TaxAmount >= 0),
    CONSTRAINT CK_FamilyCharge_DiscountAmount_NonNegative CHECK (DiscountAmount >= 0)
);
GO
CREATE INDEX IX_FamilyCharge_FamilyBillingAccountID_ServiceDate ON billing.FamilyCharge (FamilyBillingAccountID, ServiceDate DESC);
GO
CREATE INDEX IX_FamilyCharge_ChildID ON billing.FamilyCharge (ChildID) WHERE ChildID IS NOT NULL;
GO
CREATE INDEX IX_FamilyCharge_ChargeStatusCodeValueID ON billing.FamilyCharge (ChargeStatusCodeValueID);
GO
