CREATE TABLE billing.ProviderRateSchedule
(
    ProviderRateScheduleID                INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NOT NULL,
    SiteID                                INT                       NULL,
    RateName                              NVARCHAR(200)             NOT NULL,
    RateTypeCodeValueID                   INT                       NOT NULL,
    BillingFrequencyCodeValueID           INT                       NULL,
    StandardAmount                        DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderRateSchedule_StandardAmount DEFAULT (0.00),
    StandardQuantityDecimal               DECIMAL(18,4)             NOT NULL CONSTRAINT DF_ProviderRateSchedule_StandardQuantityDecimal DEFAULT (1.0000),
    AppliesPerChild                       BIT                       NOT NULL CONSTRAINT DF_ProviderRateSchedule_AppliesPerChild DEFAULT (1),
    TaxableFlag                           BIT                       NOT NULL CONSTRAINT DF_ProviderRateSchedule_TaxableFlag DEFAULT (0),
    EffectiveStartDate                    DATE                      NOT NULL,
    EffectiveEndDate                      DATE                      NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderRateSchedule_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderRateSchedule_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderRateSchedule_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderRateSchedule PRIMARY KEY CLUSTERED (ProviderRateScheduleID),
    CONSTRAINT FK_ProviderRateSchedule_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_ProviderRateSchedule_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_ProviderRateSchedule_RateTypeCodeValue FOREIGN KEY (RateTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_ProviderRateSchedule_BillingFrequencyCodeValue FOREIGN KEY (BillingFrequencyCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_ProviderRateSchedule_StandardAmount_NonNegative CHECK (StandardAmount >= 0),
    CONSTRAINT CK_ProviderRateSchedule_StandardQuantityDecimal_NonNegative CHECK (StandardQuantityDecimal > 0),
    CONSTRAINT CK_ProviderRateSchedule_DateOrder CHECK (EffectiveEndDate IS NULL OR EffectiveEndDate >= EffectiveStartDate)
);
GO
CREATE INDEX IX_ProviderRateSchedule_ProviderID ON billing.ProviderRateSchedule (ProviderID, EffectiveStartDate);
GO
CREATE INDEX IX_ProviderRateSchedule_SiteID ON billing.ProviderRateSchedule (SiteID) WHERE SiteID IS NOT NULL;
GO
