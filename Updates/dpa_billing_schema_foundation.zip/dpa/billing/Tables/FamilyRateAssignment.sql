CREATE TABLE billing.FamilyRateAssignment
(
    FamilyRateAssignmentID                INT IDENTITY(1,1)         NOT NULL,
    FamilyBillingAccountID                INT                       NOT NULL,
    ChildID                               INT                       NULL,
    ProviderRateScheduleID                INT                       NOT NULL,
    OverrideAmount                        DECIMAL(18,2)             NULL,
    EffectiveStartDate                    DATE                      NOT NULL,
    EffectiveEndDate                      DATE                      NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_FamilyRateAssignment_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_FamilyRateAssignment_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyRateAssignment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_FamilyRateAssignment PRIMARY KEY CLUSTERED (FamilyRateAssignmentID),
    CONSTRAINT FK_FamilyRateAssignment_FamilyBillingAccount FOREIGN KEY (FamilyBillingAccountID) REFERENCES billing.FamilyBillingAccount (FamilyBillingAccountID),
    CONSTRAINT FK_FamilyRateAssignment_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_FamilyRateAssignment_ProviderRateSchedule FOREIGN KEY (ProviderRateScheduleID) REFERENCES billing.ProviderRateSchedule (ProviderRateScheduleID),
    CONSTRAINT CK_FamilyRateAssignment_OverrideAmount_NonNegative CHECK (OverrideAmount IS NULL OR OverrideAmount >= 0),
    CONSTRAINT CK_FamilyRateAssignment_DateOrder CHECK (EffectiveEndDate IS NULL OR EffectiveEndDate >= EffectiveStartDate)
);
GO
CREATE INDEX IX_FamilyRateAssignment_FamilyBillingAccountID ON billing.FamilyRateAssignment (FamilyBillingAccountID);
GO
CREATE INDEX IX_FamilyRateAssignment_ChildID ON billing.FamilyRateAssignment (ChildID) WHERE ChildID IS NOT NULL;
GO
