CREATE TABLE billing.FamilyBillingAccount
(
    FamilyBillingAccountID                INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NOT NULL,
    HouseholdID                           INT                       NOT NULL,
    SiteID                                INT                       NULL,
    AccountStatusCodeValueID              INT                       NOT NULL,
    BillingFrequencyCodeValueID           INT                       NOT NULL,
    BillingDayOfMonth                     TINYINT                   NULL,
    PrimaryBillingContactPersonID         INT                       NULL,
    BillingEmail                          NVARCHAR(320)             NULL,
    CurrentBalanceAmount                  DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyBillingAccount_CurrentBalanceAmount DEFAULT (0.00),
    CreditLimitAmount                     DECIMAL(18,2)             NULL,
    LateFeeGraceDays                      INT                       NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_FamilyBillingAccount_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_FamilyBillingAccount_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyBillingAccount_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_FamilyBillingAccount PRIMARY KEY CLUSTERED (FamilyBillingAccountID),
    CONSTRAINT FK_FamilyBillingAccount_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_FamilyBillingAccount_Household FOREIGN KEY (HouseholdID) REFERENCES party.Household (HouseholdID),
    CONSTRAINT FK_FamilyBillingAccount_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_FamilyBillingAccount_AccountStatusCodeValue FOREIGN KEY (AccountStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_FamilyBillingAccount_BillingFrequencyCodeValue FOREIGN KEY (BillingFrequencyCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_FamilyBillingAccount_PrimaryBillingContactPerson FOREIGN KEY (PrimaryBillingContactPersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT CK_FamilyBillingAccount_BillingDayOfMonth_Valid CHECK (BillingDayOfMonth IS NULL OR BillingDayOfMonth BETWEEN 1 AND 31),
    CONSTRAINT CK_FamilyBillingAccount_CurrentBalanceAmount_NonNegative CHECK (CurrentBalanceAmount >= 0),
    CONSTRAINT CK_FamilyBillingAccount_CreditLimitAmount_NonNegative CHECK (CreditLimitAmount IS NULL OR CreditLimitAmount >= 0),
    CONSTRAINT CK_FamilyBillingAccount_LateFeeGraceDays_NonNegative CHECK (LateFeeGraceDays IS NULL OR LateFeeGraceDays >= 0)
);
GO
CREATE UNIQUE INDEX UX_FamilyBillingAccount_Household_Active
    ON billing.FamilyBillingAccount (HouseholdID)
    WHERE IsDeleted = 0 AND IsActive = 1;
GO
CREATE INDEX IX_FamilyBillingAccount_ProviderID ON billing.FamilyBillingAccount (ProviderID);
GO
CREATE INDEX IX_FamilyBillingAccount_AccountStatusCodeValueID ON billing.FamilyBillingAccount (AccountStatusCodeValueID);
GO
