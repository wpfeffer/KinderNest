CREATE TABLE billing.FamilyInvoiceLine
(
    FamilyInvoiceLineID                   INT IDENTITY(1,1)         NOT NULL,
    FamilyInvoiceID                       INT                       NOT NULL,
    FamilyChargeID                        INT                       NULL,
    LineTypeCodeValueID                   INT                       NOT NULL,
    Description                           NVARCHAR(500)             NOT NULL,
    QuantityDecimal                       DECIMAL(18,4)             NOT NULL CONSTRAINT DF_FamilyInvoiceLine_QuantityDecimal DEFAULT (1.0000),
    UnitPriceAmount                       DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoiceLine_UnitPriceAmount DEFAULT (0.00),
    LineAmount                            DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoiceLine_LineAmount DEFAULT (0.00),
    RelatedChildID                        INT                       NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_FamilyInvoiceLine_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_FamilyInvoiceLine_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyInvoiceLine_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_FamilyInvoiceLine PRIMARY KEY CLUSTERED (FamilyInvoiceLineID),
    CONSTRAINT FK_FamilyInvoiceLine_FamilyInvoice FOREIGN KEY (FamilyInvoiceID) REFERENCES billing.FamilyInvoice (FamilyInvoiceID),
    CONSTRAINT FK_FamilyInvoiceLine_FamilyCharge FOREIGN KEY (FamilyChargeID) REFERENCES billing.FamilyCharge (FamilyChargeID),
    CONSTRAINT FK_FamilyInvoiceLine_LineTypeCodeValue FOREIGN KEY (LineTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_FamilyInvoiceLine_RelatedChild FOREIGN KEY (RelatedChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT CK_FamilyInvoiceLine_QuantityDecimal_NonNegative CHECK (QuantityDecimal >= 0),
    CONSTRAINT CK_FamilyInvoiceLine_UnitPriceAmount_NonNegative CHECK (UnitPriceAmount >= 0),
    CONSTRAINT CK_FamilyInvoiceLine_LineAmount_NonNegative CHECK (LineAmount >= 0)
);
GO
CREATE INDEX IX_FamilyInvoiceLine_FamilyInvoiceID ON billing.FamilyInvoiceLine (FamilyInvoiceID);
GO
CREATE INDEX IX_FamilyInvoiceLine_LineTypeCodeValueID ON billing.FamilyInvoiceLine (LineTypeCodeValueID);
GO
