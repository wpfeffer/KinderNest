CREATE TABLE billing.ProviderInvoice
(
    ProviderInvoiceID                     INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NOT NULL,
    ProviderSubscriptionID                INT                       NULL,
    BillingProviderAccountID              INT                       NULL,
    InvoiceStatusCodeValueID              INT                       NOT NULL,
    InvoiceNumber                         NVARCHAR(50)              NOT NULL,
    BillingPeriodStartUTC                 DATETIME2(0)              NOT NULL,
    BillingPeriodEndUTC                   DATETIME2(0)              NOT NULL,
    IssuedUTC                             DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderInvoice_IssuedUTC DEFAULT (SYSUTCDATETIME()),
    DueUTC                                DATETIME2(0)              NULL,
    SubtotalAmount                        DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoice_SubtotalAmount DEFAULT (0.00),
    TaxAmount                             DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoice_TaxAmount DEFAULT (0.00),
    TotalAmount                           DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoice_TotalAmount DEFAULT (0.00),
    BalanceAmount                         DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderInvoice_BalanceAmount DEFAULT (0.00),
    PaidUTC                               DATETIME2(0)              NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderInvoice_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderInvoice_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderInvoice_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderInvoice PRIMARY KEY CLUSTERED (ProviderInvoiceID),
    CONSTRAINT UQ_ProviderInvoice_InvoiceNumber UNIQUE (InvoiceNumber),
    CONSTRAINT FK_ProviderInvoice_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_ProviderInvoice_ProviderSubscription FOREIGN KEY (ProviderSubscriptionID) REFERENCES billing.ProviderSubscription (ProviderSubscriptionID),
    CONSTRAINT FK_ProviderInvoice_BillingProviderAccount FOREIGN KEY (BillingProviderAccountID) REFERENCES billing.BillingProviderAccount (BillingProviderAccountID),
    CONSTRAINT FK_ProviderInvoice_InvoiceStatusCodeValue FOREIGN KEY (InvoiceStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_ProviderInvoice_PeriodOrder CHECK (BillingPeriodEndUTC >= BillingPeriodStartUTC),
    CONSTRAINT CK_ProviderInvoice_SubtotalAmount_NonNegative CHECK (SubtotalAmount >= 0),
    CONSTRAINT CK_ProviderInvoice_TaxAmount_NonNegative CHECK (TaxAmount >= 0),
    CONSTRAINT CK_ProviderInvoice_TotalAmount_NonNegative CHECK (TotalAmount >= 0),
    CONSTRAINT CK_ProviderInvoice_BalanceAmount_NonNegative CHECK (BalanceAmount >= 0)
);
GO
CREATE INDEX IX_ProviderInvoice_ProviderID ON billing.ProviderInvoice (ProviderID, IssuedUTC DESC);
GO
CREATE INDEX IX_ProviderInvoice_InvoiceStatusCodeValueID ON billing.ProviderInvoice (InvoiceStatusCodeValueID);
GO
