CREATE TABLE billing.FamilyInvoice
(
    FamilyInvoiceID                       INT IDENTITY(1,1)         NOT NULL,
    FamilyBillingAccountID                INT                       NOT NULL,
    InvoiceStatusCodeValueID              INT                       NOT NULL,
    InvoiceNumber                         NVARCHAR(50)              NOT NULL,
    BillingPeriodStartUTC                 DATETIME2(0)              NOT NULL,
    BillingPeriodEndUTC                   DATETIME2(0)              NOT NULL,
    IssuedUTC                             DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyInvoice_IssuedUTC DEFAULT (SYSUTCDATETIME()),
    DueUTC                                DATETIME2(0)              NULL,
    SentUTC                               DATETIME2(0)              NULL,
    SubtotalAmount                        DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoice_SubtotalAmount DEFAULT (0.00),
    TaxAmount                             DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoice_TaxAmount DEFAULT (0.00),
    TotalAmount                           DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoice_TotalAmount DEFAULT (0.00),
    BalanceAmount                         DECIMAL(18,2)             NOT NULL CONSTRAINT DF_FamilyInvoice_BalanceAmount DEFAULT (0.00),
    PaidUTC                               DATETIME2(0)              NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_FamilyInvoice_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_FamilyInvoice_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_FamilyInvoice_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_FamilyInvoice PRIMARY KEY CLUSTERED (FamilyInvoiceID),
    CONSTRAINT UQ_FamilyInvoice_InvoiceNumber UNIQUE (InvoiceNumber),
    CONSTRAINT FK_FamilyInvoice_FamilyBillingAccount FOREIGN KEY (FamilyBillingAccountID) REFERENCES billing.FamilyBillingAccount (FamilyBillingAccountID),
    CONSTRAINT FK_FamilyInvoice_InvoiceStatusCodeValue FOREIGN KEY (InvoiceStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_FamilyInvoice_PeriodOrder CHECK (BillingPeriodEndUTC >= BillingPeriodStartUTC),
    CONSTRAINT CK_FamilyInvoice_SubtotalAmount_NonNegative CHECK (SubtotalAmount >= 0),
    CONSTRAINT CK_FamilyInvoice_TaxAmount_NonNegative CHECK (TaxAmount >= 0),
    CONSTRAINT CK_FamilyInvoice_TotalAmount_NonNegative CHECK (TotalAmount >= 0),
    CONSTRAINT CK_FamilyInvoice_BalanceAmount_NonNegative CHECK (BalanceAmount >= 0)
);
GO
CREATE INDEX IX_FamilyInvoice_FamilyBillingAccountID ON billing.FamilyInvoice (FamilyBillingAccountID, IssuedUTC DESC);
GO
CREATE INDEX IX_FamilyInvoice_InvoiceStatusCodeValueID ON billing.FamilyInvoice (InvoiceStatusCodeValueID);
GO
