CREATE TABLE billing.ProviderSubscription
(
    ProviderSubscriptionID                INT IDENTITY(1,1)         NOT NULL,
    ProviderID                            INT                       NOT NULL,
    ProviderPlanID                        INT                       NOT NULL,
    BillingProviderAccountID              INT                       NULL,
    SubscriptionStatusCodeValueID         INT                       NOT NULL,
    SubscriptionStartUTC                  DATETIME2(0)              NOT NULL,
    SubscriptionEndUTC                    DATETIME2(0)              NULL,
    NextBillingDateUTC                    DATETIME2(0)              NULL,
    AutoRenewEnabled                      BIT                       NOT NULL CONSTRAINT DF_ProviderSubscription_AutoRenewEnabled DEFAULT (0),
    BillingContactPersonID                INT                       NULL,
    Notes                                 NVARCHAR(1000)            NULL,
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderSubscription_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderSubscription_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderSubscription_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderSubscription PRIMARY KEY CLUSTERED (ProviderSubscriptionID),
    CONSTRAINT FK_ProviderSubscription_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_ProviderSubscription_ProviderPlan FOREIGN KEY (ProviderPlanID) REFERENCES billing.ProviderPlan (ProviderPlanID),
    CONSTRAINT FK_ProviderSubscription_BillingProviderAccount FOREIGN KEY (BillingProviderAccountID) REFERENCES billing.BillingProviderAccount (BillingProviderAccountID),
    CONSTRAINT FK_ProviderSubscription_SubscriptionStatusCodeValue FOREIGN KEY (SubscriptionStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_ProviderSubscription_BillingContactPerson FOREIGN KEY (BillingContactPersonID) REFERENCES party.Person (PersonID)
);
GO
CREATE UNIQUE INDEX UX_ProviderSubscription_Provider_Active
    ON billing.ProviderSubscription (ProviderID)
    WHERE IsDeleted = 0 AND IsActive = 1;
GO
CREATE INDEX IX_ProviderSubscription_ProviderPlanID ON billing.ProviderSubscription (ProviderPlanID);
GO
CREATE INDEX IX_ProviderSubscription_SubscriptionStatusCodeValueID ON billing.ProviderSubscription (SubscriptionStatusCodeValueID);
GO
