CREATE TABLE billing.ProviderPlan
(
    ProviderPlanID                         INT IDENTITY(1,1)         NOT NULL,
    PlanCode                              NVARCHAR(100)             NOT NULL,
    PlanName                              NVARCHAR(200)             NOT NULL,
    PlanTypeCodeValueID                   INT                       NOT NULL,
    BillingFrequencyCodeValueID           INT                       NOT NULL,
    BasePriceAmount                       DECIMAL(18,2)             NOT NULL CONSTRAINT DF_ProviderPlan_BasePriceAmount DEFAULT (0.00),
    IncludedChildrenCount                 INT                       NULL,
    IncludedImageStorageBytes             BIGINT                    NULL,
    IncludedUsersCount                    INT                       NULL,
    OverageImageStoragePricePerGb         DECIMAL(18,2)             NULL,
    OverageChildPriceAmount               DECIMAL(18,2)             NULL,
    EffectiveStartUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderPlan_EffectiveStartUTC DEFAULT (SYSUTCDATETIME()),
    EffectiveEndUTC                       DATETIME2(0)              NULL,
    IsPublic                              BIT                       NOT NULL CONSTRAINT DF_ProviderPlan_IsPublic DEFAULT (1),
    IsActive                              BIT                       NOT NULL CONSTRAINT DF_ProviderPlan_IsActive DEFAULT (1),
    IsDeleted                             BIT                       NOT NULL CONSTRAINT DF_ProviderPlan_IsDeleted DEFAULT (0),
    CreatedUTC                            DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderPlan_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                       INT                       NULL,
    ModifiedUTC                           DATETIME2(0)              NULL,
    ModifiedByUserID                      INT                       NULL,
    DeletedUTC                            DATETIME2(0)              NULL,
    DeletedByUserID                       INT                       NULL,
    DeletedReason                         NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderPlan PRIMARY KEY CLUSTERED (ProviderPlanID),
    CONSTRAINT UQ_ProviderPlan_PlanCode UNIQUE (PlanCode),
    CONSTRAINT FK_ProviderPlan_PlanTypeCodeValue FOREIGN KEY (PlanTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_ProviderPlan_BillingFrequencyCodeValue FOREIGN KEY (BillingFrequencyCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT CK_ProviderPlan_BasePriceAmount_NonNegative CHECK (BasePriceAmount >= 0),
    CONSTRAINT CK_ProviderPlan_IncludedChildrenCount_NonNegative CHECK (IncludedChildrenCount IS NULL OR IncludedChildrenCount >= 0),
    CONSTRAINT CK_ProviderPlan_IncludedImageStorageBytes_NonNegative CHECK (IncludedImageStorageBytes IS NULL OR IncludedImageStorageBytes >= 0),
    CONSTRAINT CK_ProviderPlan_IncludedUsersCount_NonNegative CHECK (IncludedUsersCount IS NULL OR IncludedUsersCount >= 0),
    CONSTRAINT CK_ProviderPlan_OverageImageStoragePricePerGb_NonNegative CHECK (OverageImageStoragePricePerGb IS NULL OR OverageImageStoragePricePerGb >= 0),
    CONSTRAINT CK_ProviderPlan_OverageChildPriceAmount_NonNegative CHECK (OverageChildPriceAmount IS NULL OR OverageChildPriceAmount >= 0)
);
GO
CREATE INDEX IX_ProviderPlan_PlanTypeCodeValueID ON billing.ProviderPlan (PlanTypeCodeValueID);
GO
CREATE INDEX IX_ProviderPlan_BillingFrequencyCodeValueID ON billing.ProviderPlan (BillingFrequencyCodeValueID);
GO
