SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'BillingPlanType', N'SUBSCRIPTION', N'Subscription'),
            (N'BillingPlanType', N'ENTERPRISE', N'Enterprise'),
            (N'BillingPlanType', N'PROMOTIONAL', N'Promotional'),
            (N'BillingFrequency', N'WEEKLY', N'Weekly'),
            (N'BillingFrequency', N'MONTHLY', N'Monthly'),
            (N'BillingFrequency', N'QUARTERLY', N'Quarterly'),
            (N'BillingFrequency', N'ANNUAL', N'Annual'),
            (N'BillingFrequency', N'ONE_TIME', N'One Time'),
            (N'BillingProviderAccountUse', N'PLATFORM_PROVIDER_BILLING', N'Platform Bills Provider'),
            (N'BillingProviderAccountUse', N'PROVIDER_FAMILY_BILLING', N'Provider Bills Family'),
            (N'BillingProcessorType', N'STRIPE', N'Stripe'),
            (N'BillingProcessorType', N'PAYPAL', N'PayPal'),
            (N'BillingProcessorType', N'MANUAL', N'Manual'),
            (N'BillingProcessorType', N'EXTERNAL', N'External'),
            (N'BillingSubscriptionStatus', N'DRAFT', N'Draft'),
            (N'BillingSubscriptionStatus', N'ACTIVE', N'Active'),
            (N'BillingSubscriptionStatus', N'PAST_DUE', N'Past Due'),
            (N'BillingSubscriptionStatus', N'SUSPENDED', N'Suspended'),
            (N'BillingSubscriptionStatus', N'CANCELED', N'Canceled'),
            (N'BillingSubscriptionStatus', N'EXPIRED', N'Expired'),
            (N'InvoiceStatus', N'DRAFT', N'Draft'),
            (N'InvoiceStatus', N'ISSUED', N'Issued'),
            (N'InvoiceStatus', N'SENT', N'Sent'),
            (N'InvoiceStatus', N'PARTIALLY_PAID', N'Partially Paid'),
            (N'InvoiceStatus', N'PAID', N'Paid'),
            (N'InvoiceStatus', N'PAST_DUE', N'Past Due'),
            (N'InvoiceStatus', N'VOID', N'Void'),
            (N'InvoiceStatus', N'WRITEOFF', N'Write Off'),
            (N'InvoiceLineType', N'BASE_PLAN', N'Base Plan'),
            (N'InvoiceLineType', N'USAGE_IMAGE_STORAGE', N'Image Storage Usage'),
            (N'InvoiceLineType', N'USAGE_CHILD_COUNT', N'Child Count Usage'),
            (N'InvoiceLineType', N'CREDIT', N'Credit'),
            (N'InvoiceLineType', N'ADJUSTMENT', N'Adjustment'),
            (N'InvoiceLineType', N'TUITION', N'Tuition'),
            (N'InvoiceLineType', N'FEE', N'Fee'),
            (N'InvoiceLineType', N'TAX', N'Tax'),
            (N'InvoiceLineType', N'DISCOUNT', N'Discount'),
            (N'InvoiceLineType', N'PAYMENT', N'Payment'),
            (N'PaymentMethodType', N'CARD', N'Card'),
            (N'PaymentMethodType', N'ACH', N'ACH'),
            (N'PaymentMethodType', N'CASH', N'Cash'),
            (N'PaymentMethodType', N'CHECK', N'Check'),
            (N'PaymentMethodType', N'EXTERNAL_WALLET', N'External Wallet'),
            (N'PaymentMethodType', N'MANUAL', N'Manual'),
            (N'PaymentStatus', N'PENDING', N'Pending'),
            (N'PaymentStatus', N'AUTHORIZED', N'Authorized'),
            (N'PaymentStatus', N'SETTLED', N'Settled'),
            (N'PaymentStatus', N'FAILED', N'Failed'),
            (N'PaymentStatus', N'REFUNDED', N'Refunded'),
            (N'PaymentStatus', N'VOIDED', N'Voided'),
            (N'PaymentStatus', N'PARTIALLY_REFUNDED', N'Partially Refunded'),
            (N'PaymentScope', N'PROVIDER_PLATFORM', N'Provider Pays Platform'),
            (N'PaymentScope', N'FAMILY_PROVIDER', N'Family Pays Provider'),
            (N'FamilyBillingAccountStatus', N'ACTIVE', N'Active'),
            (N'FamilyBillingAccountStatus', N'ON_HOLD', N'On Hold'),
            (N'FamilyBillingAccountStatus', N'DELINQUENT', N'Delinquent'),
            (N'FamilyBillingAccountStatus', N'CLOSED', N'Closed'),
            (N'FamilyChargeType', N'TUITION', N'Tuition'),
            (N'FamilyChargeType', N'REGISTRATION_FEE', N'Registration Fee'),
            (N'FamilyChargeType', N'SUPPLY_FEE', N'Supply Fee'),
            (N'FamilyChargeType', N'LATE_PICKUP', N'Late Pickup'),
            (N'FamilyChargeType', N'ACTIVITY_FEE', N'Activity Fee'),
            (N'FamilyChargeType', N'MEAL_FEE', N'Meal Fee'),
            (N'FamilyChargeType', N'DISCOUNT', N'Discount'),
            (N'FamilyChargeType', N'ADJUSTMENT', N'Adjustment'),
            (N'FamilyChargeStatus', N'PENDING', N'Pending'),
            (N'FamilyChargeStatus', N'INVOICED', N'Invoiced'),
            (N'FamilyChargeStatus', N'PAID', N'Paid'),
            (N'FamilyChargeStatus', N'VOID', N'Void'),
            (N'FamilyChargeStatus', N'WRITEOFF', N'Write Off'),
            (N'UsageMetricType', N'IMAGE_STORAGE_BYTES', N'Image Storage Bytes'),
            (N'UsageMetricType', N'IMAGE_COUNT', N'Image Count'),
            (N'UsageMetricType', N'ACTIVE_CHILDREN', N'Active Children'),
            (N'UsageMetricType', N'ACTIVE_SITES', N'Active Sites'),
            (N'UsageMetricType', N'ACTIVE_USERS', N'Active Users'),
            (N'ProviderRateType', N'WEEKLY_TUITION', N'Weekly Tuition'),
            (N'ProviderRateType', N'MONTHLY_TUITION', N'Monthly Tuition'),
            (N'ProviderRateType', N'DAILY_DROPIN', N'Daily Drop-In'),
            (N'ProviderRateType', N'HOURLY_CARE', N'Hourly Care'),
            (N'ProviderRateType', N'LATE_PICKUP', N'Late Pickup'),
            (N'ProviderRateType', N'REGISTRATION_FEE', N'Registration Fee'),
            (N'ProviderRateType', N'ACTIVITY_FEE', N'Activity Fee')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue c
        WHERE c.CodeDomain = v.CodeDomain
          AND c.CodeValue = v.CodeValue
    );
END;
GO
