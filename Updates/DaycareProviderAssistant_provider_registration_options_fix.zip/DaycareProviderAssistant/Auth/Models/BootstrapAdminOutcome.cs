namespace DaycareProviderAssistant.Auth.Models;

public sealed class BootstrapAdminOutcome
{
    public bool Succeeded { get; init; }
    public bool BootstrapAvailable { get; init; }
    public int? PortalUserId { get; init; }
    public string? RoleCode { get; init; }
    public string? AccountStatusCode { get; init; }
    public string? ErrorMessage { get; init; }
    public IReadOnlyDictionary<string, List<string>> FieldErrors { get; init; }
        = new Dictionary<string, List<string>>(StringComparer.Ordinal);
}
