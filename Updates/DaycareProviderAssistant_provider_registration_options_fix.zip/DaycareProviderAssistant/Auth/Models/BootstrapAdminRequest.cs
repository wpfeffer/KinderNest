using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Auth.Models;

public sealed class BootstrapAdminRequest : IValidatableObject
{
    [Required]
    [StringLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    [StringLength(320)]
    public string PrimaryEmail { get; set; } = string.Empty;

    [Required]
    [StringLength(320, MinimumLength = 3)]
    public string UserName { get; set; } = string.Empty;

    [Required]
    [StringLength(200, MinimumLength = 12)]
    public string Password { get; set; } = string.Empty;

    [Required]
    [StringLength(200, MinimumLength = 12)]
    public string ConfirmPassword { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string RoleCode { get; set; } = "PLATFORM_ADMIN";

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!string.Equals(Password, ConfirmPassword, StringComparison.Ordinal))
        {
            yield return new ValidationResult("Password confirmation does not match.", [nameof(ConfirmPassword)]);
        }
    }
}
