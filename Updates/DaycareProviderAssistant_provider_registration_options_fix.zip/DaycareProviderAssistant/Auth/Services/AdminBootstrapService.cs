using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text.RegularExpressions;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed partial class AdminBootstrapService : IAdminBootstrapService
{
    private static readonly EmailAddressAttribute EmailValidator = new();
    private static readonly Regex MultiSpaceRegex = MultiSpaceRegexFactory();
    private static readonly HashSet<string> AllowedBootstrapRoles = new(StringComparer.OrdinalIgnoreCase)
    {
        "PLATFORM_ADMIN",
        "COMPLIANCE_ADMIN",
        "DATABASE_ADMIN",
        "SUPPORT_ADMIN"
    };

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly DpaPasswordHasher _passwordHasher;
    private readonly DpaAuthOptions _options;
    private readonly ILogger<AdminBootstrapService> _logger;

    public AdminBootstrapService(
        ISqlConnectionFactory connectionFactory,
        DpaPasswordHasher passwordHasher,
        IOptions<DpaAuthOptions> options,
        ILogger<AdminBootstrapService> logger)
    {
        _connectionFactory = connectionFactory;
        _passwordHasher = passwordHasher;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<bool> CanBootstrapAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT CASE WHEN EXISTS
            (
                SELECT 1
                FROM party.PortalUser pu
                INNER JOIN party.PortalUserRole pur
                    ON pur.PortalUserID = pu.PortalUserID
                INNER JOIN ref.Role r
                    ON r.RoleID = pur.RoleID
                WHERE pu.IsDeleted = 0
                  AND pu.IsActive = 1
                  AND pur.IsActive = 1
                  AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
                  AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC > SYSUTCDATETIME())
                  AND r.IsActive = 1
                  AND r.RoleCode IN (N'PLATFORM_ADMIN', N'COMPLIANCE_ADMIN', N'DATABASE_ADMIN', N'SUPPORT_ADMIN')
            ) THEN CAST(0 AS BIT) ELSE CAST(1 AS BIT) END;
            """;

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is bool flag && flag;
    }

    public async Task<BootstrapAdminOutcome> BootstrapAsync(
        BootstrapAdminRequest request,
        string? remoteAddress,
        string? userAgent,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var bootstrapAvailable = await CanBootstrapAsync(cancellationToken);
        if (!bootstrapAvailable)
        {
            return new BootstrapAdminOutcome
            {
                Succeeded = false,
                BootstrapAvailable = false,
                ErrorMessage = "An administrator already exists. Bootstrap setup is closed."
            };
        }

        var validationErrors = Validate(request);
        if (validationErrors.Count > 0)
        {
            return new BootstrapAdminOutcome
            {
                Succeeded = false,
                BootstrapAvailable = true,
                ErrorMessage = "Fix the highlighted fields and try again.",
                FieldErrors = validationErrors
            };
        }

        var firstName = NormalizeHumanName(request.FirstName);
        var lastName = NormalizeHumanName(request.LastName);
        var primaryEmail = NormalizeEmail(request.PrimaryEmail);
        var userName = NormalizeUserName(request.UserName);
        var normalizedUserName = userName.ToUpperInvariant();
        var roleCode = NormalizeRoleCode(request.RoleCode);
        var passwordHash = _passwordHasher.Hash(request.Password);
        var correlationId = Guid.NewGuid();

        try
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = _options.BootstrapAdminStoredProcedure;

            AddParameter(command, "@FirstName", SqlDbType.NVarChar, 100, firstName);
            AddParameter(command, "@LastName", SqlDbType.NVarChar, 100, lastName);
            AddParameter(command, "@PrimaryEmail", SqlDbType.NVarChar, 320, primaryEmail);
            AddParameter(command, "@UserName", SqlDbType.NVarChar, 320, userName);
            AddParameter(command, "@NormalizedUserName", SqlDbType.NVarChar, 320, normalizedUserName);
            AddParameter(command, "@PasswordHash", SqlDbType.NVarChar, 1000, passwordHash);
            AddParameter(command, "@HashAlgorithmCode", SqlDbType.NVarChar, 100, _options.PasswordHashAlgorithmCode);
            AddParameter(command, "@AccountStatusCode", SqlDbType.NVarChar, 50, _options.ActiveAccountStatusCode);
            AddParameter(command, "@RoleCode", SqlDbType.NVarChar, 50, roleCode);
            AddParameter(command, "@CorrelationID", SqlDbType.UniqueIdentifier, 0, correlationId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (true)
            {
                if (await reader.ReadAsync(cancellationToken) && HasColumn(reader, "PortalUserID"))
                {
                    return new BootstrapAdminOutcome
                    {
                        Succeeded = true,
                        BootstrapAvailable = true,
                        PortalUserId = GetNullableInt32(reader, "PortalUserID"),
                        RoleCode = GetNullableString(reader, "RoleCode") ?? roleCode,
                        AccountStatusCode = GetNullableString(reader, "AccountStatusCode") ?? _options.ActiveAccountStatusCode
                    };
                }

                if (!await reader.NextResultAsync(cancellationToken))
                {
                    break;
                }
            }

            return new BootstrapAdminOutcome
            {
                Succeeded = true,
                BootstrapAvailable = true,
                RoleCode = roleCode,
                AccountStatusCode = _options.ActiveAccountStatusCode
            };
        }
        catch (SqlException ex) when (ex.Number is 2601 or 2627)
        {
            return new BootstrapAdminOutcome
            {
                Succeeded = false,
                BootstrapAvailable = true,
                ErrorMessage = "That username or email is already registered.",
                FieldErrors = new Dictionary<string, List<string>>(StringComparer.Ordinal)
                {
                    [nameof(BootstrapAdminRequest.UserName)] = new() { "That username may already be in use." },
                    [nameof(BootstrapAdminRequest.PrimaryEmail)] = new() { "That email may already be in use." }
                }
            };
        }
        catch (SqlException ex)
        {
            _logger.LogWarning(ex, "Admin bootstrap failed for username {UserName}.", userName);

            var fieldErrors = new Dictionary<string, List<string>>(StringComparer.Ordinal);
            if (ex.Message.Contains("already exists", StringComparison.OrdinalIgnoreCase))
            {
                fieldErrors[nameof(BootstrapAdminRequest.UserName)] = new() { "Bootstrap is already closed because an admin account exists." };
            }
            else if (ex.Message.Contains("role", StringComparison.OrdinalIgnoreCase))
            {
                fieldErrors[nameof(BootstrapAdminRequest.RoleCode)] = new() { "That admin role is not available in the database seed data." };
            }

            return new BootstrapAdminOutcome
            {
                Succeeded = false,
                BootstrapAvailable = true,
                ErrorMessage = string.IsNullOrWhiteSpace(ex.Message)
                    ? "Bootstrap setup could not be completed."
                    : ex.Message,
                FieldErrors = fieldErrors
            };
        }
    }

    private static Dictionary<string, List<string>> Validate(BootstrapAdminRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        var errors = new Dictionary<string, List<string>>(StringComparer.Ordinal);

        static void AddError(Dictionary<string, List<string>> dict, string field, string message)
        {
            if (!dict.TryGetValue(field, out var list))
            {
                list = new List<string>();
                dict[field] = list;
            }

            list.Add(message);
        }

        if (string.IsNullOrWhiteSpace(request.FirstName))
        {
            AddError(errors, nameof(BootstrapAdminRequest.FirstName), "First name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.LastName))
        {
            AddError(errors, nameof(BootstrapAdminRequest.LastName), "Last name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.PrimaryEmail) || !EmailValidator.IsValid(request.PrimaryEmail))
        {
            AddError(errors, nameof(BootstrapAdminRequest.PrimaryEmail), "Enter a valid email address.");
        }

        var userName = request.UserName?.Trim() ?? string.Empty;
        if (userName.Length < 3)
        {
            AddError(errors, nameof(BootstrapAdminRequest.UserName), "Username must be at least 3 characters long.");
        }

        var password = request.Password ?? string.Empty;
        if (password.Length < 12)
        {
            AddError(errors, nameof(BootstrapAdminRequest.Password), "Password must be at least 12 characters long.");
        }

        if (!password.Any(char.IsUpper) || !password.Any(char.IsLower) || !password.Any(char.IsDigit) || password.All(char.IsLetterOrDigit))
        {
            AddError(errors, nameof(BootstrapAdminRequest.Password), "Password must include upper-case, lower-case, numeric, and symbol characters.");
        }

        if (!string.Equals(password, request.ConfirmPassword, StringComparison.Ordinal))
        {
            AddError(errors, nameof(BootstrapAdminRequest.ConfirmPassword), "Password confirmation does not match.");
        }

        if (!AllowedBootstrapRoles.Contains((request.RoleCode ?? string.Empty).Trim().ToUpperInvariant()))
        {
            AddError(errors, nameof(BootstrapAdminRequest.RoleCode), "Choose a valid bootstrap admin role.");
        }

        return errors;
    }

    private static string NormalizeHumanName(string? value)
    {
        var normalized = NormalizeRequiredText(value, 100);
        return TitleCaseWords(normalized);
    }

    private static string NormalizeEmail(string? value)
    {
        return NormalizeRequiredText(value, 320).ToLowerInvariant();
    }

    private static string NormalizeUserName(string? value)
    {
        return NormalizeRequiredText(value, 320);
    }

    private static string NormalizeRoleCode(string? value)
    {
        return NormalizeRequiredText(value, 50).ToUpperInvariant();
    }

    private static string NormalizeRequiredText(string? value, int maxLength)
    {
        var normalized = MultiSpaceRegex.Replace(value?.Trim() ?? string.Empty, " ");
        if (string.IsNullOrWhiteSpace(normalized))
        {
            throw new ValidationException("A required value was blank after normalization.");
        }

        return normalized.Length <= maxLength ? normalized : normalized[..maxLength];
    }

    private static string TitleCaseWords(string value)
    {
        var words = value.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        return string.Join(' ', words.Select(static word => word.Length switch
        {
            <= 1 => word.ToUpperInvariant(),
            _ => char.ToUpperInvariant(word[0]) + word[1..].ToLowerInvariant()
        }));
    }

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, int size, object value)
    {
        var parameter = command.Parameters.Add(name, dbType);
        if (size > 0)
        {
            parameter.Size = size;
        }

        parameter.Value = value;
    }

    private static bool HasColumn(SqlDataReader reader, string name)
    {
        for (var index = 0; index < reader.FieldCount; index++)
        {
            if (string.Equals(reader.GetName(index), name, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    private static int? GetNullableInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    [GeneratedRegex("\\s{2,}")]
    private static partial Regex MultiSpaceRegexFactory();
}
