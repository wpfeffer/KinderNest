using DaycareProviderAssistant.Auth.Models;

namespace DaycareProviderAssistant.Auth.Services;

public interface IAdminBootstrapService
{
    Task<bool> CanBootstrapAsync(CancellationToken cancellationToken = default);

    Task<BootstrapAdminOutcome> BootstrapAsync(
        BootstrapAdminRequest request,
        string? remoteAddress,
        string? userAgent,
        CancellationToken cancellationToken = default);
}
