using DaycareProviderAssistant.Auth.Authorization;
using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;

namespace DaycareProviderAssistant.Auth.Services;

public static class DpaAuthenticationServiceCollectionExtensions
{
    public static IServiceCollection AddDpaAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<DpaAuthOptions>()
            .Bind(configuration.GetSection(DpaAuthOptions.SectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddHttpContextAccessor();
        services.AddCascadingAuthenticationState();

        services.AddScoped<ISqlConnectionFactory, SqlConnectionFactory>();
        services.AddScoped<IDpaUserStore, SqlDpaUserStore>();
        services.AddScoped<IAuthenticationAuditWriter, SqlAuthenticationAuditWriter>();
        services.AddScoped<DpaPasswordHasher>();
        services.AddScoped<DpaClaimsPrincipalFactory>();
        services.AddScoped<DpaCurrentUserAccessor>();
        services.AddScoped<IDpaAuthenticationService, DpaAuthenticationService>();
        services.AddScoped<IAdminBootstrapService, AdminBootstrapService>();
        services.AddScoped<IProviderRegistrationService, ProviderRegistrationService>();
        services.AddScoped<IProviderRegistrationLookupService, ProviderRegistrationLookupService>();
        services.AddScoped<DpaCookieSessionValidator>();
        services.AddScoped<IAuthorizationHandler, SiteAccessAuthorizationHandler>();
        services.AddScoped<IAuthorizationHandler, ChildAccessAuthorizationHandler>();

        var options = configuration.GetSection(DpaAuthOptions.SectionName).Get<DpaAuthOptions>() ?? new DpaAuthOptions();

        services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
            .AddCookie(optionsBuilder =>
            {
                optionsBuilder.Cookie.Name = options.CookieName;
                optionsBuilder.LoginPath = options.LoginPath;
                optionsBuilder.AccessDeniedPath = options.AccessDeniedPath;
                optionsBuilder.SlidingExpiration = true;
                optionsBuilder.ExpireTimeSpan = TimeSpan.FromMinutes(options.CookieSlidingExpirationMinutes);
                optionsBuilder.EventsType = typeof(DpaCookieSessionValidator);
            });

        services.AddAuthorizationBuilder()
            .AddPolicy(DpaPolicies.AdminPortal, policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.RequireClaim(DpaClaimTypes.PortalAccess, DpaPortalValues.Admin);
            })
            .AddPolicy(DpaPolicies.ProviderPortal, policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.RequireClaim(DpaClaimTypes.PortalAccess, DpaPortalValues.Provider);
            })
            .AddPolicy(DpaPolicies.GuardianPortal, policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.RequireClaim(DpaClaimTypes.PortalAccess, DpaPortalValues.Guardian);
            });

        return services;
    }
}
