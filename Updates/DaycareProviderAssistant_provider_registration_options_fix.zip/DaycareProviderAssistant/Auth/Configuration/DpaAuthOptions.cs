using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Auth.Configuration;

public sealed class DpaAuthOptions
{
    public const string SectionName = "DpaAuth";

    [Required]
    public string ConnectionStringName { get; set; } = "DpaDatabase";

    [Required]
    public string CookieName { get; set; } = "DPA.Auth";

    [Required]
    public string LoginPath { get; set; } = "/auth/login";

    [Required]
    public string AccessDeniedPath { get; set; } = "/auth/access-denied";

    public int CookieSlidingExpirationMinutes { get; set; } = 480;
    public int LockoutThreshold { get; set; } = 5;
    public int LockoutDurationMinutes { get; set; } = 15;

    public string CredentialTypeDomain { get; set; } = "CredentialType";
    public string PasswordCredentialCode { get; set; } = "PASSWORD";

    public string CredentialStatusDomain { get; set; } = "CredentialStatus";
    public string CredentialStatusActiveCode { get; set; } = "ACTIVE";
    public string CredentialStatusLockedCode { get; set; } = "LOCKED";

    public string SessionStatusDomain { get; set; } = "LoginSessionStatus";
    public string SessionStatusActiveCode { get; set; } = "ACTIVE";
    public string SessionStatusRevokedCode { get; set; } = "REVOKED";

    public string AuthenticationEventTypeDomain { get; set; } = "AuthenticationEventType";
    public string AuthenticationResultDomain { get; set; } = "AuthenticationResult";
    public string AuthenticationResultSuccessCode { get; set; } = "SUCCESS";
    public string AuthenticationResultFailureCode { get; set; } = "FAILURE";
    public string AuthenticationResultBlockedCode { get; set; } = "BLOCKED";

    public string PendingApprovalAccountStatusCode { get; set; } = "PENDING_APPROVAL";
    public string ActiveAccountStatusCode { get; set; } = "ACTIVE";
    public string ProviderOwnerRoleCode { get; set; } = "PROVIDER_OWNER";
    public string ProviderRegistrationStoredProcedure { get; set; } = "party.usp_ProviderOwner_SelfRegister";
    public string BootstrapAdminStoredProcedure { get; set; } = "party.usp_BootstrapAdmin_CreateFirstUser";
    public string PasswordHashAlgorithmCode { get; set; } = "ASPNETCORE_IDENTITY_V3";

    public string[] AllowedAccountStatusCodes { get; set; } = ["ACTIVE"];
    public string[] AdminRoleCodes { get; set; } = ["GOD", "PLATFORM_ADMIN", "COMPLIANCE_ADMIN", "DATABASE_ADMIN"];
}
