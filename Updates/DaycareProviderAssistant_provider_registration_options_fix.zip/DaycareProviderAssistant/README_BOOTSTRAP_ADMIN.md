# Bootstrap Admin Setup

This build adds a first-run bootstrap flow for the initial admin account.

## What changed

- New page: `/auth/bootstrap-admin`
- New service: `IAdminBootstrapService`
- New database stored procedure: `party.usp_BootstrapAdmin_CreateFirstUser`
- `Install/master_install.sql` now installs the bootstrap stored procedure automatically

## How it works

- If **no admin user exists** in the database, `/auth/bootstrap-admin` allows creation of the first admin.
- Once an admin exists, bootstrap closes itself and the page stops allowing new bootstrap creation.
- The password is hashed by the app using the same ASP.NET Core Identity V3 hasher already used by the rest of the auth system.

## Why this route

Trying to create a real ASP.NET Identity V3 password hash directly inside the SQL install script is the wrong place to solve the problem.
The browser/app layer already knows how to hash passwords correctly, so the bootstrap path uses that instead of faking it in T-SQL.

## Recommended use

1. Recreate the database with `dpa/Install/master_install.sql`
2. Start the web app
3. Browse to `/auth/bootstrap-admin`
4. Create the first admin account
5. Sign in normally at `/auth/login`

