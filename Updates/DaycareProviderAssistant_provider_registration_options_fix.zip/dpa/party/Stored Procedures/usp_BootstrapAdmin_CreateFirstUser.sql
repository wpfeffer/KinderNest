CREATE OR ALTER PROCEDURE party.usp_BootstrapAdmin_CreateFirstUser
    @FirstName              NVARCHAR(100),
    @LastName               NVARCHAR(100),
    @PrimaryEmail           NVARCHAR(320),
    @UserName               NVARCHAR(320),
    @NormalizedUserName     NVARCHAR(320),
    @PasswordHash           NVARCHAR(1000),
    @HashAlgorithmCode      NVARCHAR(100),
    @AccountStatusCode      NVARCHAR(50),
    @RoleCode               NVARCHAR(50),
    @CorrelationID          UNIQUEIDENTIFIER = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PersonID INT;
    DECLARE @PortalUserRoleID INT;
    DECLARE @RoleID INT;
    DECLARE @ReasonText NVARCHAR(MAX) = N'Initial admin bootstrap.';
    DECLARE @AuthenticationEventTypeCode NVARCHAR(100) = N'PASSWORD_CHANGED';
    DECLARE @PasswordNotes NVARCHAR(4000) = N'Password established during initial admin bootstrap.';
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @NewValuesJson NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pu.IsDeleted = 0
          AND pu.IsActive = 1
          AND pur.IsActive = 1
          AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC > SYSUTCDATETIME())
          AND r.IsActive = 1
          AND r.RoleCode IN (N'PLATFORM_ADMIN', N'COMPLIANCE_ADMIN', N'DATABASE_ADMIN', N'SUPPORT_ADMIN')
    )
    BEGIN
        THROW 50600, 'An administrator already exists. Bootstrap is closed.', 1;
    END;

    SELECT @RoleID = r.RoleID
    FROM ref.Role r
    WHERE r.RoleCode = @RoleCode
      AND r.IsActive = 1;

    IF @RoleID IS NULL
    BEGIN
        THROW 50601, 'The requested admin role was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'AccountStatus'
          AND cv.CodeValue = @AccountStatusCode
          AND cv.IsActive = 1
    )
    BEGIN
        THROW 50602, 'The requested account status code was not found.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.NormalizedUserName = @NormalizedUserName
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50603, 'That username is already registered.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.Person p
        WHERE UPPER(ISNULL(p.PrimaryEmail, N'')) = UPPER(@PrimaryEmail)
          AND p.IsDeleted = 0
    )
    BEGIN
        THROW 50604, 'That email is already registered.', 1;
    END;

    BEGIN TRANSACTION;

    INSERT INTO party.Person
    (
        FirstName,
        LastName,
        PrimaryEmail,
        IsActive,
        IsDeleted
    )
    VALUES
    (
        @FirstName,
        @LastName,
        @PrimaryEmail,
        1,
        0
    );

    SET @PersonID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUser
    (
        PersonID,
        UserName,
        NormalizedUserName,
        AccountStatusCode,
        MFAEnabled,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @PersonID,
        @UserName,
        @NormalizedUserName,
        @AccountStatusCode,
        0,
        1,
        0,
        NULL
    );

    SET @PortalUserID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUserRole
    (
        PortalUserID,
        RoleID,
        EffectiveStartUTC,
        IsActive,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @RoleID,
        SYSUTCDATETIME(),
        1,
        @PortalUserID
    );

    SET @PortalUserRoleID = SCOPE_IDENTITY();

    EXEC sec.usp_PortalCredential_SetPassword
        @PortalUserID = @PortalUserID,
        @PasswordHash = @PasswordHash,
        @HashAlgorithmCode = @HashAlgorithmCode,
        @HashVersion = 1,
        @MustChangePassword = 0,
        @ChangedByUserID = @PortalUserID,
        @AuthenticationEventTypeCode = @AuthenticationEventTypeCode,
        @SiteID = NULL,
        @CorrelationID = @CorrelationID,
        @Notes = @PasswordNotes;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PersonID);
    SELECT @NewValuesJson = (SELECT p.* FROM party.Person p WHERE p.PersonID = @PersonID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Person',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'BOOTSTRAP_ADMIN',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);
    SELECT @NewValuesJson = (SELECT pu.* FROM party.PortalUser pu WHERE pu.PortalUserID = @PortalUserID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'BOOTSTRAP_ADMIN',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserRoleID);
    SELECT @NewValuesJson = (SELECT pur.* FROM party.PortalUserRole pur WHERE pur.PortalUserRoleID = @PortalUserRoleID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUserRole',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'BOOTSTRAP_ADMIN',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    COMMIT TRANSACTION;

    SELECT
        @PortalUserID AS PortalUserID,
        @RoleCode AS RoleCode,
        @AccountStatusCode AS AccountStatusCode;
END;
GO
