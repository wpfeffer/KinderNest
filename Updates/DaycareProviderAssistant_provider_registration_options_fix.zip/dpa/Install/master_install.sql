:setvar DatabaseName dpa

IF DB_ID(N'$(DatabaseName)') IS NOT NULL
BEGIN
    ALTER DATABASE [$(DatabaseName)] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [$(DatabaseName)];
END;
GO
CREATE DATABASE [$(DatabaseName)];
GO
USE [$(DatabaseName)];
GO
:r "..\CreateSchemas.sql"
GO
:r "..\ref\Tables\CodeValue.sql"
GO
:r "..\ref\Tables\MedicalProviderType.sql"
GO
:r "..\ref\Tables\Role.sql"
GO
:r "..\ref\Tables\SeedBatch.sql"
GO
:r "..\ref\Tables\TimeZone.sql"
GO
:r "..\party\Tables\Address.sql"
GO
:r "..\party\Tables\PhoneNumber.sql"
GO
:r "..\party\Tables\Person.sql"
GO
:r "..\doc\Tables\DocumentType.sql"
GO
:r "..\doc\Tables\Document.sql"
GO
:r "..\doc\Tables\EntityDocument.sql"
GO
:r "..\party\Tables\Hospital.sql"
GO
:r "..\party\Tables\MedicalProvider.sql"
GO
:r "..\lic\Tables\LicenseClass.sql"
GO
:r "..\lic\Tables\RequirementCatalog.sql"
GO
:r "..\party\Tables\PortalUser.sql"
GO
:r "..\party\Tables\Provider.sql"
GO
:r "..\comm\Tables\EmailOutbox.sql"
GO
:r "..\comm\Tables\NotificationTemplate.sql"
GO
:r "..\lic\Tables\CapacityRuleSet.sql"
GO
:r "..\audit\Tables\BreakGlassEvent.sql"
GO
:r "..\party\Tables\PortalUserRole.sql"
GO
:r "..\ref\Tables\SeedBatchExecution.sql"
GO
:r "..\party\Tables\Site.sql"
GO
:r "..\sec\Tables\SiteImageKey.sql"
GO
:r "..\child\Tables\Child.sql"
GO
:r "..\lic\Tables\ComplianceReview.sql"
GO
:r "..\lic\Tables\LicenseVariance.sql"
GO
:r "..\ops\Tables\CaregiverPresence.sql"
GO
:r "..\ops\Tables\CountedNonEnrollmentChild.sql"
GO
:r "..\ops\Tables\DrillLog.sql"
GO
:r "..\ops\Tables\EmergencyPlan.sql"
GO
:r "..\ops\Tables\SafetyInspection.sql"
GO
:r "..\ops\Tables\StaffAssignment.sql"
GO
:r "..\party\Tables\LicensorAssignment.sql"
GO
:r "..\party\Tables\SiteUserAssignment.sql"
GO
:r "..\audit\Tables\AccessLog.sql"
GO
:r "..\audit\Tables\AuditLog.sql"
GO
:r "..\audit\Tables\DataExportLog.sql"
GO
:r "..\audit\Tables\RecoveryRequest.sql"
GO
:r "..\child\Tables\ChildAllergyPlan.sql"
GO
:r "..\child\Tables\ChildAttendance.sql"
GO
:r "..\child\Tables\ChildEnrollment.sql"
GO
:r "..\child\Tables\ChildMedicalProfile.sql"
GO
:r "..\child\Tables\ChildPersonRelationship.sql"
GO
:r "..\child\Tables\MedicationPermission.sql"
GO
:r "..\child\Tables\PickupDropoffAuthorization.sql"
GO
:r "..\comm\Tables\Conversation.sql"
GO
:r "..\doc\Tables\ConsentRecord.sql"
GO
:r "..\doc\Tables\ImageAsset.sql"
GO
:r "..\doc\Tables\ImageAssetSubject.sql"
GO
:r "..\lic\Tables\RequirementEvidence.sql"
GO
:r "..\lic\Tables\RequirementStatus.sql"
GO
:r "..\ops\Tables\IncidentReport.sql"
GO
:r "..\lic\Tables\ComplianceFinding.sql"
GO
:r "..\ops\Tables\BackgroundStudyRecord.sql"
GO
:r "..\ops\Tables\TrainingCompletion.sql"
GO
:r "..\audit\Tables\RecoveryApproval.sql"
GO
:r "..\audit\Tables\RecoveryExecution.sql"
GO
:r "..\child\Tables\GuardianInvitation.sql"
GO
:r "..\audit\Tables\NotificationLog.sql"
GO
:r "..\comm\Tables\AdminConversationMetadata.sql"
GO
:r "..\comm\Tables\ConversationParticipant.sql"
GO
:r "..\comm\Tables\ConversationParticipantAudit.sql"
GO
:r "..\comm\Tables\Message.sql"
GO
:r "..\lic\Tables\FindingResolution.sql"
GO
:r "..\child\Tables\GuardianEmailIdentity.sql"
GO
:r "..\comm\Tables\MessageAttachment.sql"
GO
:r "..\comm\Tables\MessageReadReceipt.sql"
GO
:r "..\child\Tables\GuardianEmailChangeRequest.sql"
GO
:r "..\child\Tables\GuardianEmailClaimAttempt.sql"
GO
:r "..\sec\Tables\PortalCredential.sql"
GO
:r "..\sec\Tables\LoginSession.sql"
GO
:r "..\audit\Tables\AuthenticationEvent.sql"
GO
:r "..\sec\Tables\PasswordResetRequest.sql"
GO
:r "..\sec\Tables\MfaFactor.sql"
GO
:r "..\sec\Tables\PortalCredentialHistory.sql"
GO
:r "..\sec\Functions\fn_GetSessionPortalUserID.sql"
GO
:r "..\sec\Functions\fn_GetSessionSiteID.sql"
GO
:r "..\child\Functions\fn_CalculateAgeInDays.sql"
GO
:r "..\lic\Functions\fn_GetFamilyAgeBandCode.sql"
GO
:r "..\lic\Functions\fn_GetNextFamilyAgeBandTransitionDate.sql"
GO
:r "..\sec\Functions\fn_HasRoleCode.sql"
GO
:r "..\sec\Functions\fn_UserAssignedToSite.sql"
GO
:r "..\sec\Functions\fn_UserLinkedToChild.sql"
GO
:r "..\sec\Functions\fn_UserCanAccessChildDetail.sql"
GO
:r "..\sec\Functions\fn_UserCanAccessSiteAggregate.sql"
GO
:r "..\lic\Functions\fn_GetSiteChildCountSnapshot.sql"
GO
:r "..\lic\Functions\fn_ValidateFamilyCareCapacity.sql"
GO
:r "..\ref\Views\vwCodeDomains.sql"
GO
:r "..\rpt\Views\vwActiveChildEnrollmentSummary.sql"
GO
:r "..\rpt\Views\vwGuardianAccessSummary.sql"
GO
:r "..\rpt\Views\vwDocumentStatus.sql"
GO
:r "..\rpt\Views\vwProviderCapacityStatus.sql"
GO
:r "..\rpt\Views\vwLicensorAggregateChildCounts.sql"
GO
:r "..\rpt\Views\vwCapacityInputsByDate.sql"
GO
:r "..\rpt\Views\vwCodeUsageValidation.sql"
GO
:r "..\rpt\Views\vwSecureChildAccess.sql"
GO
:r "..\rpt\Views\vwSecureSiteAggregateAccess.sql"
GO
:r "..\rpt\Views\vwOpenComplianceFindings.sql"
GO
:r "..\audit\Stored Procedures\usp_WriteAuditLog.sql"
GO
:r "..\audit\Stored Procedures\usp_WriteAuthenticationEvent.sql"
GO
:r "..\party\Stored Procedures\usp_Address_FindCanonical.sql"
GO
:r "..\party\Stored Procedures\usp_BootstrapAdmin_CreateFirstUser.sql"
GO
:r "..\party\Stored Procedures\usp_PhoneNumber_FindCanonical.sql"
GO
:r "..\sec\Stored Procedures\usp_AssertRowVersionMatch.sql"
GO
:r "..\ref\Stored Procedures\usp_SeedBatch_Start.sql"
GO
:r "..\ref\Stored Procedures\usp_SeedBatch_Complete.sql"
GO
:r "..\ref\Stored Procedures\usp_TimeZone_ListActive.sql"
GO
:r "..\lic\Stored Procedures\usp_LicenseClass_ListActive.sql"
GO
:r "..\party\Stored Procedures\usp_ProviderOwner_SelfRegister.sql"
GO
:r "..\ops\Stored Procedures\usp_AdminDashboard_GetSummary.sql"
GO
:r "..\party\Stored Procedures\usp_AdminPendingProvider_List.sql"
GO
:r "..\party\Stored Procedures\usp_ProviderOwner_Approve.sql"
GO
:r "..\party\Stored Procedures\usp_ProviderOwner_Reject.sql"
GO
:r "..\party\Stored Procedures\usp_AdminPortalUser_List.sql"
GO
:r "..\party\Stored Procedures\usp_AdminPortalUser_GetDetail.sql"
GO
:r "..\party\Stored Procedures\usp_AdminProvider_List.sql"
GO
:r "..\party\Stored Procedures\usp_AdminProvider_GetDetail.sql"
GO
:r "..\party\Stored Procedures\usp_AdminSite_List.sql"
GO
:r "..\party\Stored Procedures\usp_AdminSite_GetDetail.sql"
GO
:r "..\comm\Stored Procedures\usp_Message_MarkRead.sql"
GO
:r "..\child\Stored Procedures\usp_ChildMedicalProfile_GetByChildID.sql"
GO
:r "..\child\Stored Procedures\usp_ChildAllergyPlan_GetByChildID.sql"
GO
:r "..\child\Stored Procedures\usp_MedicationPermission_GetByChildID.sql"
GO
:r "..\child\Stored Procedures\usp_GuardianEmailClaimAttempt_Insert.sql"
GO
:r "..\doc\Stored Procedures\usp_ImageAsset_Create.sql"
GO
:r "..\doc\Stored Procedures\usp_ImageAsset_ListForSite.sql"
GO
:r "..\doc\Stored Procedures\usp_ImageAsset_ListForGuardian.sql"
GO
:r "..\doc\Stored Procedures\usp_ImageAsset_GetAccessEnvelope.sql"
GO
:r "..\doc\Stored Procedures\usp_ImageAsset_SoftDelete.sql"
GO
:r "..\lic\Stored Procedures\usp_CapacitySnapshot_Get.sql"
GO
:r "..\lic\Stored Procedures\usp_CapacityForecast_Get.sql"
GO
:r "..\sec\Stored Procedures\usp_PortalCredential_SetPassword.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginFailure_Record.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginSuccess_Record.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginSession_Revoke.sql"
GO
:r "..\sec\Stored Procedures\usp_PasswordResetRequest_Create.sql"
GO
:r "..\sec\Stored Procedures\usp_PasswordResetRequest_Consume.sql"
GO
:r "..\sec\Stored Procedures\usp_SiteImageKey_GetActive.sql"
GO
:r "..\sec\Stored Procedures\usp_SiteImageKey_Upsert.sql"
GO
:r "..\PostDeploy\SeedData.sql"
GO
