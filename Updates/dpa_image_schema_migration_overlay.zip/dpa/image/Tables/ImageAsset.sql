
CREATE TABLE image.ImageAsset
(
    ImageAssetID                   INT IDENTITY(1,1)         NOT NULL,
    SiteID                         INT                       NOT NULL,
    ImageCategoryCode              NVARCHAR(50)              NOT NULL,
    VisibilityScopeCode            NVARCHAR(50)              NOT NULL CONSTRAINT DF_image_ImageAsset_VisibilityScopeCode DEFAULT (N'SITE_STAFF'),
    OriginalFileName               NVARCHAR(255)             NOT NULL,
    OriginalContentType            NVARCHAR(100)             NOT NULL,
    OriginalLengthBytes            BIGINT                    NOT NULL,
    EncryptedFileRelativePath      NVARCHAR(500)             NOT NULL,
    EncryptedFileLengthBytes       BIGINT                    NOT NULL,
    EncryptionAlgorithmCode        NVARCHAR(50)              NOT NULL CONSTRAINT DF_image_ImageAsset_EncryptionAlgorithmCode DEFAULT (N'AES-256-GCM'),
    SiteKeyVersion                 INT                       NOT NULL,
    ImageNonce                     VARBINARY(32)             NOT NULL,
    ImageSha256Hex                 NVARCHAR(64)              NULL,
    ThumbnailContentType           NVARCHAR(100)             NULL,
    ThumbnailLengthBytes           BIGINT                    NULL,
    EncryptedThumbnailRelativePath NVARCHAR(500)             NULL,
    EncryptedThumbnailLengthBytes  BIGINT                    NULL,
    ThumbnailNonce                 VARBINARY(32)             NULL,
    ThumbnailSha256Hex             NVARCHAR(64)              NULL,
    PixelWidth                     INT                       NULL,
    PixelHeight                    INT                       NULL,
    Caption                        NVARCHAR(500)             NULL,
    TakenUTC                       DATETIME2(0)              NULL,
    UploadedByPortalUserID         INT                       NOT NULL,
    IsActive                       BIT                       NOT NULL CONSTRAINT DF_image_ImageAsset_IsActive DEFAULT (1),
    IsDeleted                      BIT                       NOT NULL CONSTRAINT DF_image_ImageAsset_IsDeleted DEFAULT (0),
    CreatedUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_image_ImageAsset_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                INT                       NOT NULL,
    ModifiedUTC                    DATETIME2(0)              NULL,
    ModifiedByUserID               INT                       NULL,
    DeletedUTC                     DATETIME2(0)              NULL,
    DeletedByUserID                INT                       NULL,
    DeletedReason                  NVARCHAR(500)             NULL,
    CONSTRAINT PK_image_ImageAsset PRIMARY KEY CLUSTERED (ImageAssetID),
    CONSTRAINT FK_image_ImageAsset_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_image_ImageAsset_SiteImageKey FOREIGN KEY (SiteID, SiteKeyVersion) REFERENCES image.SiteImageKey (SiteID, KeyVersion),
    CONSTRAINT FK_image_ImageAsset_UploadedByPortalUser FOREIGN KEY (UploadedByPortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT CK_image_ImageAsset_ThumbnailMetadata CHECK
    (
        (EncryptedThumbnailRelativePath IS NULL AND ThumbnailNonce IS NULL)
        OR
        (EncryptedThumbnailRelativePath IS NOT NULL AND ThumbnailNonce IS NOT NULL)
    )
);
GO
CREATE INDEX IX_image_ImageAsset_SiteID
    ON image.ImageAsset (SiteID, IsDeleted, IsActive, CreatedUTC DESC);
GO
CREATE INDEX IX_image_ImageAsset_Category
    ON image.ImageAsset (ImageCategoryCode, VisibilityScopeCode, IsDeleted, IsActive, SiteID);
GO
CREATE INDEX IX_image_ImageAsset_UploadedByPortalUser
    ON image.ImageAsset (UploadedByPortalUserID, CreatedUTC DESC);
GO
