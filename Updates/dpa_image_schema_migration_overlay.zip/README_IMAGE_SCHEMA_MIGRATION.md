# Image Schema Migration Overlay

This overlay does two things:

1. fixes the immediate runtime gap where the current live database install does not create the image procedures that `EncryptedImageService` expects
2. moves image-only database objects into a dedicated `image` schema

## Included C# change
- `DaycareProviderAssistant/Images/Services/EncryptedImageService.cs`
  - switches image procedure names from `doc.*` and `sec.*` to `image.*`

## New database objects
### Tables
- `image.SiteImageKey`
- `image.ImageAsset`
- `image.ImageAssetSubject`

### Stored procedures
- `image.usp_SiteImageKey_GetActive`
- `image.usp_SiteImageKey_Upsert`
- `image.usp_ImageAsset_Create`
- `image.usp_ImageAsset_ListForSite`
- `image.usp_ImageAsset_ListForGuardian`
- `image.usp_ImageAsset_GetAccessEnvelope`
- `image.usp_ImageAsset_SoftDelete`

## Also required in your repo
You still need to update:
- `dpa/CreateSchemas.sql` to create the `image` schema
- `dpa/dpa.sqlproj` to include these new files
- `dpa/Install/master_install.sql` to execute these new files

Patch stub files for those are included in `patches/`.
