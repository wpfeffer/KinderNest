This is an overlay patch for the current GitHub version of DaycareProviderAssistant.

Files fixed:
- DpaAuthOptions.cs
- Provider/Children.razor
- Provider/Documents.razor
- Provider/Messages.razor
- Guardian/Children.razor
- Guardian/Consents.razor
- Guardian/Messages.razor
- Guardian/Profile.razor

Why:
- Restores DpaAuthOptions properties referenced by AdminBootstrapService
- Renames Razor component backing properties that matched their component class names and caused CS0542-style compile failures

Apply by copying these files over the matching paths in the repo, then rebuild.
