# Image Upload System + Automatic Folder Provisioning Overlay

This overlay finishes the backend side of the encrypted image upload subsystem and adds automatic filesystem provisioning.

## What it does
- Moves image-only database objects into a dedicated `image` schema
- Updates `EncryptedImageService` to call `image.*` stored procedures
- Adds missing image tables and procedures to the database layer
- Adds automatic folder provisioning so provider/site folders are created by code
- Creates folders both:
  - when a provider approval succeeds, as a best-effort provisioning step
  - and again when the provider opens the encrypted photos workspace, as a safety net
- Keeps lazy folder creation on actual upload writes so no manual folder creation is needed later

## Filesystem layout
Encrypted files are written under:

`<StorageRoot>/providers/{ProviderID}/sites/{SiteID}/{CATEGORY}/{yyyy}/{MM}/{random}.bin`

Example:

`App_Data/EncryptedImages/providers/12/sites/34/CHILD_DIARY/2026/04/abc123.bin`

## Key code changes
- `EncryptedImageFileStore` now has `EnsureSiteStorageAsync`
- `ImageStorageProvisioningService` provisions provider/site directories from stored procedure results
- `AdminProviderApprovalService` calls the provisioning service after successful approval
- `EncryptedImageService` also provisions as a safety net before image operations

## Important note
The current repo already has the provider photos page, guardian photos page, image endpoints, and browser-side JS wiring. This overlay focuses on the backend completion and automatic directory provisioning you asked for.
