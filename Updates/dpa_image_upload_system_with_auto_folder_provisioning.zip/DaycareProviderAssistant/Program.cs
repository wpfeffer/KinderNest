using DaycareProviderAssistant.Admin.Services;
using DaycareProviderAssistant.Auditing;
using DaycareProviderAssistant.Auth.Endpoints;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Components;
using DaycareProviderAssistant.Guardian.Services;
using DaycareProviderAssistant.Images.Configuration;
using DaycareProviderAssistant.Images.Endpoints;
using DaycareProviderAssistant.Images.Services;
using DaycareProviderAssistant.Portal.Services;
using DaycareProviderAssistant.Provider.Services;

namespace DaycareProviderAssistant;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddRazorComponents()
            .AddInteractiveServerComponents();

        builder.Services.AddDpaAuditCore();
        builder.Services.AddDpaAuthentication(builder.Configuration);
        builder.Services.Configure<ImageStorageOptions>(builder.Configuration.GetSection(ImageStorageOptions.SectionName));
        builder.Services.AddSingleton<SiteImageKeyProtector>();
        builder.Services.AddScoped<IEncryptedImageFileStore, EncryptedImageFileStore>();
        builder.Services.AddScoped<IImageStorageProvisioningService, ImageStorageProvisioningService>();
        builder.Services.AddScoped<IEncryptedImageService, EncryptedImageService>();
        builder.Services.AddScoped<PortalBrandingService>();
        builder.Services.AddScoped<PortalNavigationService>();
        builder.Services.AddScoped<IAdminDashboardService, AdminDashboardService>();
        builder.Services.AddScoped<IAdminProviderApprovalService, AdminProviderApprovalService>();
        builder.Services.AddScoped<IAdminUserService, AdminUserService>();
        builder.Services.AddScoped<IAdminProviderService, AdminProviderService>();
        builder.Services.AddScoped<IAdminSiteService, AdminSiteService>();
        builder.Services.AddScoped<IAdminOperationsService, AdminOperationsService>();
        builder.Services.AddScoped<IProviderPortalService, ProviderPortalService>();
        builder.Services.AddScoped<IGuardianPortalService, GuardianPortalService>();

        var app = builder.Build();

        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
        app.UseHttpsRedirection();
        app.UseAntiforgery();
        app.UseAuthentication();
        app.UseAuthorization();

        app.MapStaticAssets();
        app.MapDpaAuthEndpoints();
        app.MapDpaImageEndpoints();
        app.MapRazorComponents<App>()
            .AddInteractiveServerRenderMode();

        app.Run();
    }
}
