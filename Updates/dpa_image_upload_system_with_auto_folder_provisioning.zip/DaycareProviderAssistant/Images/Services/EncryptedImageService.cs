using System.Data;
using System.Text.Json;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Images.Configuration;
using DaycareProviderAssistant.Images.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using static DaycareProviderAssistant.Images.Services.ImageDataReaderHelpers;

namespace DaycareProviderAssistant.Images.Services;

public sealed class EncryptedImageService : IEncryptedImageService
{
    private const string AssignedSiteListProcedureName = "party.usp_PortalUserAssignedSite_List";
    private const string GuardianAccessibleChildListProcedureName = "child.usp_GuardianAccessibleChild_List";
    private const string SiteImageChildSubjectListProcedureName = "child.usp_SiteImageSubjectChild_List";
    private const string SiteImageAdultSubjectListProcedureName = "party.usp_SiteImageSubjectAdult_List";
    private const string GuardianSiteAccessCheckProcedureName = "child.usp_GuardianAccess_CheckSite";
    private const string StorageContextGetBySiteProcedureName = "image.usp_ImageStorageContext_GetBySite";
    private const string SiteKeyGetProcedureName = "image.usp_SiteImageKey_GetActive";
    private const string SiteKeyUpsertProcedureName = "image.usp_SiteImageKey_Upsert";
    private const string ImageCreateProcedureName = "image.usp_ImageAsset_Create";
    private const string ImageListForSiteProcedureName = "image.usp_ImageAsset_ListForSite";
    private const string ImageListForGuardianProcedureName = "image.usp_ImageAsset_ListForGuardian";
    private const string ImageEnvelopeProcedureName = "image.usp_ImageAsset_GetAccessEnvelope";
    private const string ImageSoftDeleteProcedureName = "image.usp_ImageAsset_SoftDelete";

    private static readonly JsonSerializerOptions SubjectSerializerOptions = new(JsonSerializerDefaults.Web);

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IDpaUserStore _userStore;
    private readonly IEncryptedImageFileStore _fileStore;
    private readonly IImageStorageProvisioningService _storageProvisioningService;
    private readonly SiteImageKeyProtector _keyProtector;
    private readonly ImageStorageOptions _options;
    private readonly ILogger<EncryptedImageService> _logger;

    public EncryptedImageService(
        ISqlConnectionFactory connectionFactory,
        IDpaUserStore userStore,
        IEncryptedImageFileStore fileStore,
        IImageStorageProvisioningService storageProvisioningService,
        SiteImageKeyProtector keyProtector,
        IOptions<ImageStorageOptions> options,
        ILogger<EncryptedImageService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _userStore = userStore ?? throw new ArgumentNullException(nameof(userStore));
        _fileStore = fileStore ?? throw new ArgumentNullException(nameof(fileStore));
        _storageProvisioningService = storageProvisioningService ?? throw new ArgumentNullException(nameof(storageProvisioningService));
        _keyProtector = keyProtector ?? throw new ArgumentNullException(nameof(keyProtector));
        _options = options.Value;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<ProviderImageSiteOptionDto>> GetAccessibleProviderSitesAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        await _storageProvisioningService.EnsureFoldersForPortalUserAsync(portalUserId, cancellationToken);

        var sites = new List<ProviderImageSiteOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = AssignedSiteListProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            sites.Add(new ProviderImageSiteOptionDto
            {
                SiteId = GetInt32(reader, "SiteID"),
                SiteName = GetString(reader, "SiteName"),
                ProviderName = GetString(reader, "ProviderName")
            });
        }

        return sites;
    }

    public async Task<ProviderSiteImageWorkspaceDto?> GetProviderWorkspaceAsync(int portalUserId, int siteId, CancellationToken cancellationToken = default)
    {
        if (!await _userStore.CanAccessSiteAsync(portalUserId, siteId, cancellationToken))
        {
            return null;
        }

        await _storageProvisioningService.EnsureFolderForSiteAsync(siteId, cancellationToken);

        var sites = await GetAccessibleProviderSitesAsync(portalUserId, cancellationToken);
        var selectedSite = sites.FirstOrDefault(site => site.SiteId == siteId);
        if (selectedSite is null)
        {
            return null;
        }

        var children = await GetSiteChildrenAsync(siteId, cancellationToken);
        var adults = await GetSiteAdultsAsync(siteId, cancellationToken);
        var galleryItems = await GetProviderGalleryAsync(siteId, cancellationToken);

        return new ProviderSiteImageWorkspaceDto
        {
            Site = selectedSite,
            Children = children,
            Adults = adults,
            GalleryItems = galleryItems
        };
    }

    public async Task<IReadOnlyList<GuardianImageChildOptionDto>> GetAccessibleGuardianChildrenAsync(int personId, CancellationToken cancellationToken = default)
    {
        var children = new List<GuardianImageChildOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = GuardianAccessibleChildListProcedureName;
        command.Parameters.Add(new SqlParameter("@PersonID", SqlDbType.Int) { Value = personId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            children.Add(new GuardianImageChildOptionDto
            {
                ChildId = GetInt32(reader, "ChildID"),
                SiteId = GetInt32(reader, "SiteID"),
                ChildName = GetString(reader, "ChildName"),
                SiteName = GetString(reader, "SiteName")
            });
        }

        return children;
    }

    public async Task<IReadOnlyList<ImageGalleryItemDto>> GetGuardianGalleryAsync(int portalUserId, int childId, CancellationToken cancellationToken = default)
    {
        if (!await _userStore.CanAccessChildAsync(portalUserId, childId, cancellationToken))
        {
            return Array.Empty<ImageGalleryItemDto>();
        }

        return await LoadGalleryItemsAsync(
            ImageListForGuardianProcedureName,
            cancellationToken,
            new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId },
            new SqlParameter("@ChildID", SqlDbType.Int) { Value = childId });
    }

    public async Task<SiteImageKeyDto> GetOrCreateSiteKeyAsync(int portalUserId, int personId, int siteId, bool createIfMissing, CancellationToken cancellationToken = default)
    {
        var hasProviderAccess = await _userStore.CanAccessSiteAsync(portalUserId, siteId, cancellationToken);
        var hasGuardianAccess = !hasProviderAccess && await CanAccessSiteThroughGuardianRelationshipAsync(personId, siteId, cancellationToken);
        if (!hasProviderAccess && !hasGuardianAccess)
        {
            throw new UnauthorizedAccessException("The current portal user is not allowed to access that site image key.");
        }

        await _storageProvisioningService.EnsureFolderForSiteAsync(siteId, cancellationToken);

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        var existingKey = await LoadSiteKeyRecordAsync(connection, siteId, cancellationToken);
        if (existingKey is not null)
        {
            var rawKey = _keyProtector.UnwrapKey(existingKey.WrappedCiphertext, existingKey.Nonce, existingKey.Tag);
            return new SiteImageKeyDto
            {
                SiteId = siteId,
                KeyVersion = existingKey.KeyVersion,
                WrapAlgorithmCode = existingKey.WrapAlgorithmCode,
                KeyBase64 = Convert.ToBase64String(rawKey)
            };
        }

        if (!createIfMissing || !hasProviderAccess)
        {
            throw new InvalidOperationException("No active image key exists for that site yet.");
        }

        var newKey = _keyProtector.CreateNewSiteKey();
        var wrapped = _keyProtector.WrapKey(newKey);

        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SiteKeyUpsertProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });
        command.Parameters.Add(new SqlParameter("@KeyVersion", SqlDbType.Int) { Value = 1 });
        command.Parameters.Add(new SqlParameter("@WrapAlgorithmCode", SqlDbType.NVarChar, 50) { Value = "AES-256-GCM" });
        command.Parameters.Add(new SqlParameter("@WrappedKeyCiphertext", SqlDbType.VarBinary, wrapped.Ciphertext.Length) { Value = wrapped.Ciphertext });
        command.Parameters.Add(new SqlParameter("@WrappedKeyNonce", SqlDbType.VarBinary, wrapped.Nonce.Length) { Value = wrapped.Nonce });
        command.Parameters.Add(new SqlParameter("@WrappedKeyTag", SqlDbType.VarBinary, wrapped.Tag.Length) { Value = wrapped.Tag });
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        await command.ExecuteNonQueryAsync(cancellationToken);

        return new SiteImageKeyDto
        {
            SiteId = siteId,
            KeyVersion = 1,
            WrapAlgorithmCode = "AES-256-GCM",
            KeyBase64 = Convert.ToBase64String(newKey)
        };
    }

    public async Task<ImageUploadResultDto> SaveEncryptedImageAsync(int portalUserId, int personId, int siteId, ImageUploadManifestDto manifest, Stream encryptedFile, Stream? encryptedThumbnail, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(manifest);
        ArgumentNullException.ThrowIfNull(encryptedFile);

        if (!await _userStore.CanAccessSiteAsync(portalUserId, siteId, cancellationToken))
        {
            throw new UnauthorizedAccessException("Only provider users assigned to the site can upload encrypted images.");
        }

        ValidateUploadManifest(manifest);

        var storageContext = await LoadStorageContextBySiteAsync(siteId, cancellationToken)
            ?? throw new InvalidOperationException("The image storage context for the requested site could not be found.");

        await _fileStore.EnsureSiteStorageAsync(storageContext.ProviderId, storageContext.SiteId, cancellationToken);

        var activeSiteKey = await GetOrCreateSiteKeyAsync(portalUserId, personId, siteId, createIfMissing: true, cancellationToken);
        if (manifest.SiteKeyVersion != activeSiteKey.KeyVersion)
        {
            throw new InvalidOperationException("The browser uploaded the image using an out-of-date site key version.");
        }

        var encryptedFileWriteResult = await _fileStore.SaveAsync(storageContext.ProviderId, siteId, manifest.ImageCategoryCode, encryptedFile, cancellationToken);
        EncryptedFileWriteResult? encryptedThumbnailWriteResult = null;
        if (encryptedThumbnail is not null)
        {
            encryptedThumbnailWriteResult = await _fileStore.SaveAsync(storageContext.ProviderId, siteId, $"{manifest.ImageCategoryCode}_THUMB", encryptedThumbnail, cancellationToken);
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ImageCreateProcedureName;

        AddParameter(command, "@SiteID", SqlDbType.Int, siteId);
        AddParameter(command, "@ImageCategoryCode", SqlDbType.NVarChar, 50, manifest.ImageCategoryCode);
        AddParameter(command, "@VisibilityScopeCode", SqlDbType.NVarChar, 50, manifest.VisibilityScopeCode);
        AddParameter(command, "@OriginalFileName", SqlDbType.NVarChar, 255, manifest.OriginalFileName);
        AddParameter(command, "@OriginalContentType", SqlDbType.NVarChar, 100, manifest.OriginalContentType);
        AddParameter(command, "@OriginalLengthBytes", SqlDbType.BigInt, manifest.OriginalLengthBytes);
        AddParameter(command, "@EncryptedFileRelativePath", SqlDbType.NVarChar, 500, encryptedFileWriteResult.RelativePath);
        AddParameter(command, "@EncryptedFileLengthBytes", SqlDbType.BigInt, encryptedFileWriteResult.LengthBytes);
        AddParameter(command, "@EncryptionAlgorithmCode", SqlDbType.NVarChar, 50, "AES-256-GCM");
        AddParameter(command, "@SiteKeyVersion", SqlDbType.Int, manifest.SiteKeyVersion);
        AddParameter(command, "@ImageNonce", SqlDbType.VarBinary, Convert.FromBase64String(manifest.ImageNonceBase64));
        AddParameter(command, "@ImageSha256Hex", SqlDbType.NVarChar, 64, encryptedFileWriteResult.Sha256Hex);
        AddNullableStringParameter(command, "@ThumbnailContentType", SqlDbType.NVarChar, 100, manifest.ThumbnailContentType);
        AddNullableLongParameter(command, "@ThumbnailLengthBytes", manifest.ThumbnailLengthBytes);
        AddNullableStringParameter(command, "@EncryptedThumbnailRelativePath", SqlDbType.NVarChar, 500, encryptedThumbnailWriteResult?.RelativePath);
        AddNullableLongParameter(command, "@EncryptedThumbnailLengthBytes", encryptedThumbnailWriteResult?.LengthBytes);
        AddNullableBytesParameter(command, "@ThumbnailNonce", manifest.ThumbnailNonceBase64 is null ? null : Convert.FromBase64String(manifest.ThumbnailNonceBase64));
        AddNullableStringParameter(command, "@ThumbnailSha256Hex", SqlDbType.NVarChar, 64, encryptedThumbnailWriteResult?.Sha256Hex);
        AddNullableIntParameter(command, "@PixelWidth", manifest.PixelWidth);
        AddNullableIntParameter(command, "@PixelHeight", manifest.PixelHeight);
        AddNullableStringParameter(command, "@Caption", SqlDbType.NVarChar, 500, manifest.Caption);
        AddNullableDateTimeParameter(command, "@TakenUTC", manifest.TakenUtc);
        AddParameter(command, "@UploadedByPortalUserID", SqlDbType.Int, portalUserId);
        AddParameter(command, "@CreatedByUserID", SqlDbType.Int, portalUserId);
        AddNullableStringParameter(command, "@SubjectLinksJson", SqlDbType.NVarChar, -1, JsonSerializer.Serialize(manifest.SubjectLinks, SubjectSerializerOptions));

        var imageAssetId = 0;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
        {
            if (await reader.ReadAsync(cancellationToken))
            {
                imageAssetId = GetInt32(reader, "ImageAssetID");
            }
        }

        if (imageAssetId <= 0)
        {
            throw new InvalidOperationException("The image upload metadata did not return a new ImageAssetID.");
        }

        return new ImageUploadResultDto
        {
            ImageAssetId = imageAssetId,
            SiteId = siteId,
            ImageCategoryCode = manifest.ImageCategoryCode
        };
    }

    public async Task<ImageBinaryEnvelopeDto?> GetImageBinaryAsync(int portalUserId, int personId, int imageAssetId, bool thumbnail, CancellationToken cancellationToken = default)
    {
        var envelope = await LoadImageAccessEnvelopeAsync(imageAssetId, cancellationToken);
        if (envelope is null || envelope.IsDeleted || !envelope.IsActive)
        {
            return null;
        }

        var canAccess = await _userStore.CanAccessSiteAsync(portalUserId, envelope.SiteId, cancellationToken);
        if (!canAccess)
        {
            if (!string.Equals(envelope.VisibilityScopeCode, "LINKED_GUARDIANS", StringComparison.OrdinalIgnoreCase)
                && !string.Equals(envelope.VisibilityScopeCode, "CHILD_GUARDIANS_ONLY", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            foreach (var childId in envelope.SubjectChildIds)
            {
                if (await _userStore.CanAccessChildAsync(portalUserId, childId, cancellationToken))
                {
                    canAccess = true;
                    break;
                }
            }
        }

        if (!canAccess)
        {
            return null;
        }

        var relativePath = thumbnail ? envelope.EncryptedThumbnailRelativePath : envelope.EncryptedFileRelativePath;
        if (string.IsNullOrWhiteSpace(relativePath))
        {
            return null;
        }

        var contentType = thumbnail ? envelope.ThumbnailContentType : envelope.OriginalContentType;
        var fileName = thumbnail ? $"thumb-{envelope.OriginalFileName}" : envelope.OriginalFileName;
        var stream = await _fileStore.OpenReadAsync(relativePath, cancellationToken);

        return new ImageBinaryEnvelopeDto
        {
            ContentStream = stream,
            ContentType = string.IsNullOrWhiteSpace(contentType) ? "application/octet-stream" : contentType,
            FileName = fileName,
            LastModifiedUtc = envelope.CreatedUtc.HasValue ? new DateTimeOffset(DateTime.SpecifyKind(envelope.CreatedUtc.Value, DateTimeKind.Utc)) : null
        };
    }

    public async Task<bool> SoftDeleteImageAsync(int portalUserId, int personId, int imageAssetId, string? reason, CancellationToken cancellationToken = default)
    {
        var envelope = await LoadImageAccessEnvelopeAsync(imageAssetId, cancellationToken);
        if (envelope is null || envelope.IsDeleted)
        {
            return false;
        }

        if (!await _userStore.CanAccessSiteAsync(portalUserId, envelope.SiteId, cancellationToken))
        {
            throw new UnauthorizedAccessException("Only provider users assigned to the image site can delete image records.");
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ImageSoftDeleteProcedureName;
        AddParameter(command, "@ImageAssetID", SqlDbType.Int, imageAssetId);
        AddParameter(command, "@DeletedByUserID", SqlDbType.Int, portalUserId);
        AddNullableStringParameter(command, "@DeletedReason", SqlDbType.NVarChar, 500, reason);

        var affectedRows = 0;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
        {
            if (await reader.ReadAsync(cancellationToken))
            {
                affectedRows = GetInt32(reader, "AffectedRowCount");
            }
        }

        return affectedRows > 0;
    }

    private async Task<IReadOnlyList<ImageGalleryItemDto>> GetProviderGalleryAsync(int siteId, CancellationToken cancellationToken)
        => await LoadGalleryItemsAsync(
            ImageListForSiteProcedureName,
            cancellationToken,
            new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

    private async Task<IReadOnlyList<ImageGalleryItemDto>> LoadGalleryItemsAsync(string procedureName, CancellationToken cancellationToken, params SqlParameter[] parameters)
    {
        var items = new List<ImageGalleryItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = procedureName;
        foreach (var parameter in parameters)
        {
            command.Parameters.Add(parameter);
        }

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            items.Add(new ImageGalleryItemDto
            {
                ImageAssetId = GetInt32(reader, "ImageAssetID"),
                SiteId = GetInt32(reader, "SiteID"),
                ImageCategoryCode = GetString(reader, "ImageCategoryCode"),
                VisibilityScopeCode = GetString(reader, "VisibilityScopeCode"),
                OriginalFileName = GetString(reader, "OriginalFileName"),
                OriginalContentType = GetString(reader, "OriginalContentType"),
                SiteKeyVersion = GetInt32(reader, "SiteKeyVersion"),
                ImageNonceBase64 = Convert.ToBase64String(GetNullableBytes(reader, "ImageNonce") ?? Array.Empty<byte>()),
                ThumbnailNonceBase64 = GetNullableBytes(reader, "ThumbnailNonce") is { Length: > 0 } thumbNonce ? Convert.ToBase64String(thumbNonce) : null,
                ThumbnailContentType = GetNullableString(reader, "ThumbnailContentType"),
                HasThumbnail = GetBoolean(reader, "HasThumbnail"),
                SubjectSummary = GetNullableString(reader, "SubjectSummary") ?? string.Empty,
                Caption = GetNullableString(reader, "Caption"),
                PixelWidth = GetNullableInt32(reader, "PixelWidth"),
                PixelHeight = GetNullableInt32(reader, "PixelHeight"),
                TakenUtc = GetNullableDateTime(reader, "TakenUTC"),
                CreatedUtc = GetNullableDateTime(reader, "CreatedUTC") ?? DateTime.UtcNow
            });
        }

        return items;
    }

    private async Task<IReadOnlyList<ImageSubjectOptionDto>> GetSiteChildrenAsync(int siteId, CancellationToken cancellationToken)
    {
        var results = new List<ImageSubjectOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SiteImageChildSubjectListProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new ImageSubjectOptionDto
            {
                Id = GetInt32(reader, "ChildID"),
                DisplayName = GetString(reader, "DisplayName"),
                Detail = GetNullableString(reader, "Detail")
            });
        }

        return results;
    }

    private async Task<IReadOnlyList<ImageSubjectOptionDto>> GetSiteAdultsAsync(int siteId, CancellationToken cancellationToken)
    {
        var results = new List<ImageSubjectOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SiteImageAdultSubjectListProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new ImageSubjectOptionDto
            {
                Id = GetInt32(reader, "PersonID"),
                DisplayName = GetString(reader, "DisplayName"),
                Detail = GetNullableString(reader, "Detail")
            });
        }

        return results;
    }

    private async Task<bool> CanAccessSiteThroughGuardianRelationshipAsync(int personId, int siteId, CancellationToken cancellationToken)
    {
        if (personId <= 0)
        {
            return false;
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = GuardianSiteAccessCheckProcedureName;
        command.Parameters.Add(new SqlParameter("@PersonID", SqlDbType.Int) { Value = personId });
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int intResult && intResult == 1;
    }

    private async Task<StorageContext?> LoadStorageContextBySiteAsync(int siteId, CancellationToken cancellationToken)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = StorageContextGetBySiteProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return new StorageContext(
            reader.GetInt32(reader.GetOrdinal("ProviderID")),
            reader.GetInt32(reader.GetOrdinal("SiteID")));
    }

    private async Task<SiteKeyRecord?> LoadSiteKeyRecordAsync(SqlConnection connection, int siteId, CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = SiteKeyGetProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        var ciphertext = GetNullableBytes(reader, "WrappedKeyCiphertext");
        var nonce = GetNullableBytes(reader, "WrappedKeyNonce");
        var tag = GetNullableBytes(reader, "WrappedKeyTag");
        if (ciphertext is null || nonce is null || tag is null)
        {
            return null;
        }

        return new SiteKeyRecord(
            KeyVersion: GetInt32(reader, "KeyVersion"),
            WrapAlgorithmCode: GetString(reader, "WrapAlgorithmCode"),
            WrappedCiphertext: ciphertext,
            Nonce: nonce,
            Tag: tag);
    }

    private async Task<ImageAssetAccessEnvelope?> LoadImageAccessEnvelopeAsync(int imageAssetId, CancellationToken cancellationToken)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ImageEnvelopeProcedureName;
        command.Parameters.Add(new SqlParameter("@ImageAssetID", SqlDbType.Int) { Value = imageAssetId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        var envelope = new ImageAssetAccessEnvelope
        {
            ImageAssetId = GetInt32(reader, "ImageAssetID"),
            SiteId = GetInt32(reader, "SiteID"),
            VisibilityScopeCode = GetString(reader, "VisibilityScopeCode"),
            OriginalFileName = GetString(reader, "OriginalFileName"),
            OriginalContentType = GetString(reader, "OriginalContentType"),
            EncryptedFileRelativePath = GetString(reader, "EncryptedFileRelativePath"),
            EncryptedThumbnailRelativePath = GetNullableString(reader, "EncryptedThumbnailRelativePath"),
            ThumbnailContentType = GetNullableString(reader, "ThumbnailContentType"),
            IsActive = GetBoolean(reader, "IsActive"),
            IsDeleted = GetBoolean(reader, "IsDeleted"),
            CreatedUtc = GetNullableDateTime(reader, "CreatedUTC")
        };

        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                var childId = GetNullableInt32(reader, "ChildID");
                if (childId.HasValue)
                {
                    envelope.SubjectChildIds.Add(childId.Value);
                }
            }
        }

        return envelope;
    }

    private void ValidateUploadManifest(ImageUploadManifestDto manifest)
    {
        if (string.IsNullOrWhiteSpace(manifest.ImageCategoryCode))
        {
            throw new InvalidOperationException("ImageCategoryCode is required.");
        }

        if (string.IsNullOrWhiteSpace(manifest.OriginalFileName))
        {
            throw new InvalidOperationException("OriginalFileName is required.");
        }

        if (string.IsNullOrWhiteSpace(manifest.OriginalContentType))
        {
            throw new InvalidOperationException("OriginalContentType is required.");
        }

        if (manifest.EncryptedFileLengthBytes <= 0 || manifest.EncryptedFileLengthBytes > _options.MaxUploadBytes)
        {
            throw new InvalidOperationException($"Encrypted file length must be between 1 and {_options.MaxUploadBytes} bytes.");
        }

        if (manifest.EncryptedThumbnailLengthBytes.HasValue && manifest.EncryptedThumbnailLengthBytes.Value > _options.MaxThumbnailBytes)
        {
            throw new InvalidOperationException($"Encrypted thumbnail length cannot exceed {_options.MaxThumbnailBytes} bytes.");
        }

        if (string.IsNullOrWhiteSpace(manifest.ImageNonceBase64))
        {
            throw new InvalidOperationException("ImageNonceBase64 is required.");
        }

        if (manifest.SiteKeyVersion <= 0)
        {
            throw new InvalidOperationException("SiteKeyVersion must be a positive integer.");
        }

        if (manifest.SubjectLinks.Count == 0)
        {
            throw new InvalidOperationException("At least one subject link is required.");
        }

        switch (manifest.ImageCategoryCode.ToUpperInvariant())
        {
            case "CHILD_HEADSHOT":
                if (manifest.SubjectLinks.Count(link => string.Equals(link.SubjectTypeCode, "CHILD", StringComparison.OrdinalIgnoreCase)) != 1)
                {
                    throw new InvalidOperationException("Child headshots require exactly one child subject.");
                }
                break;

            case "PERSON_HEADSHOT":
                if (manifest.SubjectLinks.Count(link => string.Equals(link.SubjectTypeCode, "PERSON", StringComparison.OrdinalIgnoreCase)) != 1)
                {
                    throw new InvalidOperationException("Person headshots require exactly one person subject.");
                }
                break;

            case "CHILD_DIARY":
                if (!manifest.SubjectLinks.Any(link => string.Equals(link.SubjectTypeCode, "CHILD", StringComparison.OrdinalIgnoreCase)))
                {
                    throw new InvalidOperationException("Child diary images require at least one child subject.");
                }
                break;

            default:
                throw new InvalidOperationException($"Unsupported ImageCategoryCode '{manifest.ImageCategoryCode}'.");
        }
    }

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, object value)
        => command.Parameters.Add(new SqlParameter(name, dbType) { Value = value });

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, int size, object value)
        => command.Parameters.Add(new SqlParameter(name, dbType, size) { Value = value });

    private static void AddNullableStringParameter(SqlCommand command, string name, SqlDbType dbType, int size, string? value)
        => command.Parameters.Add(new SqlParameter(name, dbType, size) { Value = string.IsNullOrWhiteSpace(value) ? DBNull.Value : value });

    private static void AddNullableLongParameter(SqlCommand command, string name, long? value)
        => command.Parameters.Add(new SqlParameter(name, SqlDbType.BigInt) { Value = value.HasValue ? value.Value : DBNull.Value });

    private static void AddNullableIntParameter(SqlCommand command, string name, int? value)
        => command.Parameters.Add(new SqlParameter(name, SqlDbType.Int) { Value = value.HasValue ? value.Value : DBNull.Value });

    private static void AddNullableDateTimeParameter(SqlCommand command, string name, DateTime? value)
        => command.Parameters.Add(new SqlParameter(name, SqlDbType.DateTime2) { Value = value.HasValue ? DateTime.SpecifyKind(value.Value, DateTimeKind.Utc) : DBNull.Value });

    private static void AddNullableBytesParameter(SqlCommand command, string name, byte[]? value)
        => command.Parameters.Add(new SqlParameter(name, SqlDbType.VarBinary, value?.Length ?? 32) { Value = value ?? (object)DBNull.Value });

    private static int? GetNullableInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    private sealed record StorageContext(int ProviderId, int SiteId);
    private sealed record SiteKeyRecord(int KeyVersion, string WrapAlgorithmCode, byte[] WrappedCiphertext, byte[] Nonce, byte[] Tag);

    private sealed class ImageAssetAccessEnvelope
    {
        public int ImageAssetId { get; init; }
        public int SiteId { get; init; }
        public string VisibilityScopeCode { get; init; } = string.Empty;
        public string OriginalFileName { get; init; } = string.Empty;
        public string OriginalContentType { get; init; } = string.Empty;
        public string EncryptedFileRelativePath { get; init; } = string.Empty;
        public string? EncryptedThumbnailRelativePath { get; init; }
        public string? ThumbnailContentType { get; init; }
        public bool IsActive { get; init; }
        public bool IsDeleted { get; init; }
        public DateTime? CreatedUtc { get; init; }
        public List<int> SubjectChildIds { get; } = new();
    }
}
