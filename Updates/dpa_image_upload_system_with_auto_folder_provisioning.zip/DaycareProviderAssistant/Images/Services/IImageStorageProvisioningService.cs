namespace DaycareProviderAssistant.Images.Services;

public interface IImageStorageProvisioningService
{
    Task EnsureFoldersForPortalUserAsync(int portalUserId, CancellationToken cancellationToken = default);
    Task EnsureFolderForSiteAsync(int siteId, CancellationToken cancellationToken = default);
}
