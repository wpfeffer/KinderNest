using System.Data;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Images.Services;

public sealed class ImageStorageProvisioningService : IImageStorageProvisioningService
{
    private const string ProvisioningTargetListProcedureName = "image.usp_ImageStorageProvisioningTarget_ListByPortalUser";
    private const string StorageContextGetBySiteProcedureName = "image.usp_ImageStorageContext_GetBySite";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IEncryptedImageFileStore _fileStore;
    private readonly ILogger<ImageStorageProvisioningService> _logger;

    public ImageStorageProvisioningService(
        ISqlConnectionFactory connectionFactory,
        IEncryptedImageFileStore fileStore,
        ILogger<ImageStorageProvisioningService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _fileStore = fileStore ?? throw new ArgumentNullException(nameof(fileStore));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task EnsureFoldersForPortalUserAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        if (portalUserId <= 0)
        {
            return;
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProvisioningTargetListProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var providerId = reader.GetInt32(reader.GetOrdinal("ProviderID"));
            var siteId = reader.GetInt32(reader.GetOrdinal("SiteID"));
            await _fileStore.EnsureSiteStorageAsync(providerId, siteId, cancellationToken);
        }
    }

    public async Task EnsureFolderForSiteAsync(int siteId, CancellationToken cancellationToken = default)
    {
        if (siteId <= 0)
        {
            return;
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = StorageContextGetBySiteProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            _logger.LogWarning("Image storage provisioning skipped because SiteID {SiteID} was not found.", siteId);
            return;
        }

        var providerId = reader.GetInt32(reader.GetOrdinal("ProviderID"));
        await _fileStore.EnsureSiteStorageAsync(providerId, siteId, cancellationToken);
    }
}
