CREATE TABLE image.SiteImageKey
(
    SiteImageKeyID                INT IDENTITY(1,1)         NOT NULL,
    SiteID                        INT                       NOT NULL,
    KeyVersion                    INT                       NOT NULL,
    WrapAlgorithmCode             NVARCHAR(50)              NOT NULL CONSTRAINT DF_image_SiteImageKey_WrapAlgorithmCode DEFAULT (N'AES-256-GCM'),
    WrappedKeyCiphertext          VARBINARY(512)            NOT NULL,
    WrappedKeyNonce               VARBINARY(32)             NOT NULL,
    WrappedKeyTag                 VARBINARY(32)             NOT NULL,
    IsPrimary                     BIT                       NOT NULL CONSTRAINT DF_image_SiteImageKey_IsPrimary DEFAULT (1),
    IsActive                      BIT                       NOT NULL CONSTRAINT DF_image_SiteImageKey_IsActive DEFAULT (1),
    IsDeleted                     BIT                       NOT NULL CONSTRAINT DF_image_SiteImageKey_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)              NOT NULL CONSTRAINT DF_image_SiteImageKey_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                       NOT NULL,
    ModifiedUTC                   DATETIME2(0)              NULL,
    ModifiedByUserID              INT                       NULL,
    DeletedUTC                    DATETIME2(0)              NULL,
    DeletedByUserID               INT                       NULL,
    DeletedReason                 NVARCHAR(500)             NULL,
    CONSTRAINT PK_image_SiteImageKey PRIMARY KEY CLUSTERED (SiteImageKeyID),
    CONSTRAINT FK_image_SiteImageKey_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT UQ_image_SiteImageKey_Site_Version UNIQUE (SiteID, KeyVersion)
);
GO
CREATE UNIQUE INDEX UX_image_SiteImageKey_PrimaryActive
    ON image.SiteImageKey (SiteID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND IsPrimary = 1;
GO
CREATE INDEX IX_image_SiteImageKey_SiteID
    ON image.SiteImageKey (SiteID, IsDeleted, IsActive, IsPrimary, KeyVersion DESC);
GO
