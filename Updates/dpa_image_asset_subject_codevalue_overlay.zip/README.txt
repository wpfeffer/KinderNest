DPA ImageAssetSubject CodeValue overlay

Purpose:
- Replace image.ImageAssetSubject.SubjectTypeCode NVARCHAR(50) with SubjectTypeCodeValueID INT.
- Add FK to ref.CodeValue(CodeValueID).
- Keep browser/API JSON unchanged: subjectTypeCode still comes from the client, and the create proc maps it to ref.CodeValue.
- Seed missing ref.CodeValue rows for CodeDomain = ImageAssetSubjectType.

Apply:
1. Unzip at repository root and allow overwrite.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\patch_image_subjecttype_seed.ps1
3. Rebuild dpa.
4. Publish dpa database project.

Existing database note:
- If your existing local DB already has image.ImageAssetSubject.SubjectTypeCode, run:
  ManualHotfix\20260424_Migrate_ImageAssetSubject_SubjectTypeCodeValueID.sql
  before or as part of deployment. This migrates existing CHILD/PERSON values to CodeValueID.

Files replaced:
- dpa/image/Tables/ImageAssetSubject.sql
- dpa/image/Stored Procedures/usp_ImageAsset_Create.sql
- dpa/image/Stored Procedures/usp_ImageAsset_GetAccessEnvelope.sql
