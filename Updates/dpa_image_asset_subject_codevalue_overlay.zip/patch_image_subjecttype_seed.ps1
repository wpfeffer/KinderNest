param(
    [string]$RepoRoot = "."
)

$seedPath = Join-Path $RepoRoot "dpa\PostDeploy\SeedData.sql"
if (-not (Test-Path $seedPath)) {
    throw "Could not find dpa\PostDeploy\SeedData.sql"
}

$content = Get-Content $seedPath -Raw

if ($content -match "ImageAssetSubjectType") {
    Write-Host "ImageAssetSubjectType seed values already present."
    exit 0
}

$needle = "(N'ProviderFamilyDraftPersonRole', N'BILLING_CONTACT', N'Billing Contact')"
$replacement = "(N'ProviderFamilyDraftPersonRole', N'BILLING_CONTACT', N'Billing Contact'),`r`n`r`n`t`t`t(N'ImageAssetSubjectType', N'CHILD', N'Child'),`r`n`t`t`t(N'ImageAssetSubjectType', N'PERSON', N'Person')"

if (-not $content.Contains($needle)) {
    throw "Could not find insertion point in SeedData.sql. Add ImageAssetSubjectType CHILD/PERSON manually."
}

$content = $content.Replace($needle, $replacement)
Set-Content -Path $seedPath -Value $content -Encoding UTF8

Write-Host "Added ImageAssetSubjectType seed values to dpa\PostDeploy\SeedData.sql."
