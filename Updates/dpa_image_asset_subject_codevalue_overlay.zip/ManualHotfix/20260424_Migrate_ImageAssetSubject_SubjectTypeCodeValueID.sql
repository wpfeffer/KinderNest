/* Manual one-time migration for existing databases.

Run this against the target database if the database already has:
    image.ImageAssetSubject.SubjectTypeCode NVARCHAR(50)

The SSDT publish may handle a brand-new database cleanly from the model file, but existing
databases need data migration from text code to CodeValueID before the text column can disappear.
*/

SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'ImageAssetSubjectType', N'CHILD', N'Child'),
            (N'ImageAssetSubjectType', N'PERSON', N'Person')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = v.CodeDomain
          AND cv.CodeValue = v.CodeValue
    );
END;

IF COL_LENGTH(N'image.ImageAssetSubject', N'SubjectTypeCodeValueID') IS NULL
BEGIN
    ALTER TABLE image.ImageAssetSubject ADD SubjectTypeCodeValueID INT NULL;
END;

IF COL_LENGTH(N'image.ImageAssetSubject', N'SubjectTypeCode') IS NOT NULL
BEGIN
    UPDATE ias
       SET SubjectTypeCodeValueID = cv.CodeValueID
    FROM image.ImageAssetSubject ias
    INNER JOIN ref.CodeValue cv
        ON cv.CodeDomain = N'ImageAssetSubjectType'
       AND cv.CodeValue = ias.SubjectTypeCode
    WHERE ias.SubjectTypeCodeValueID IS NULL;
END;

IF EXISTS
(
    SELECT 1
    FROM image.ImageAssetSubject
    WHERE SubjectTypeCodeValueID IS NULL
)
BEGIN
    THROW 52003, 'ImageAssetSubject migration failed: at least one row could not map SubjectTypeCode to ImageAssetSubjectType.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UX_image_ImageAssetSubject_UniqueTarget'
      AND object_id = OBJECT_ID(N'image.ImageAssetSubject')
)
BEGIN
    DROP INDEX UX_image_ImageAssetSubject_UniqueTarget ON image.ImageAssetSubject;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_image_ImageAssetSubject_Target'
      AND parent_object_id = OBJECT_ID(N'image.ImageAssetSubject')
)
BEGIN
    ALTER TABLE image.ImageAssetSubject DROP CONSTRAINT CK_image_ImageAssetSubject_Target;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_image_ImageAssetSubject_SubjectTypeCodeValue'
      AND parent_object_id = OBJECT_ID(N'image.ImageAssetSubject')
)
BEGIN
    ALTER TABLE image.ImageAssetSubject
        ADD CONSTRAINT FK_image_ImageAssetSubject_SubjectTypeCodeValue
        FOREIGN KEY (SubjectTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID);
END;

ALTER TABLE image.ImageAssetSubject ALTER COLUMN SubjectTypeCodeValueID INT NOT NULL;

IF COL_LENGTH(N'image.ImageAssetSubject', N'SubjectTypeCode') IS NOT NULL
BEGIN
    ALTER TABLE image.ImageAssetSubject DROP COLUMN SubjectTypeCode;
END;

ALTER TABLE image.ImageAssetSubject
    ADD CONSTRAINT CK_image_ImageAssetSubject_Target CHECK
    (
        (ChildID IS NOT NULL AND PersonID IS NULL)
        OR
        (PersonID IS NOT NULL AND ChildID IS NULL)
    );

CREATE UNIQUE INDEX UX_image_ImageAssetSubject_UniqueTarget
    ON image.ImageAssetSubject (ImageAssetID, SubjectTypeCodeValueID, ChildID, PersonID)
    WHERE IsDeleted = 0;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_image_ImageAssetSubject_SubjectTypeCodeValueID'
      AND object_id = OBJECT_ID(N'image.ImageAssetSubject')
)
BEGIN
    CREATE INDEX IX_image_ImageAssetSubject_SubjectTypeCodeValueID
        ON image.ImageAssetSubject (SubjectTypeCodeValueID);
END;

COMMIT TRANSACTION;
