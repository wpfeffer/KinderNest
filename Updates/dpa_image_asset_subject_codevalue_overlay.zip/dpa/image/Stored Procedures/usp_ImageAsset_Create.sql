CREATE PROCEDURE image.usp_ImageAsset_Create
    @SiteID                          INT,
    @ImageCategoryCode               NVARCHAR(50),
    @VisibilityScopeCode             NVARCHAR(50)       = N'SITE_STAFF',
    @OriginalFileName                NVARCHAR(255),
    @OriginalContentType             NVARCHAR(100),
    @OriginalLengthBytes             BIGINT,
    @EncryptedFileRelativePath       NVARCHAR(500),
    @EncryptedFileLengthBytes        BIGINT,
    @EncryptionAlgorithmCode         NVARCHAR(50)       = N'AES-256-GCM',
    @SiteKeyVersion                  INT,
    @ImageNonce                      VARBINARY(32),
    @ImageSha256Hex                  NVARCHAR(64)       = NULL,
    @ThumbnailContentType            NVARCHAR(100)      = NULL,
    @ThumbnailLengthBytes            BIGINT             = NULL,
    @EncryptedThumbnailRelativePath  NVARCHAR(500)      = NULL,
    @EncryptedThumbnailLengthBytes   BIGINT             = NULL,
    @ThumbnailNonce                  VARBINARY(32)      = NULL,
    @ThumbnailSha256Hex              NVARCHAR(64)       = NULL,
    @PixelWidth                      INT                = NULL,
    @PixelHeight                     INT                = NULL,
    @Caption                         NVARCHAR(500)      = NULL,
    @TakenUTC                        DATETIME2(0)       = NULL,
    @UploadedByPortalUserID          INT,
    @CreatedByUserID                 INT,
    @SubjectLinksJson                NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ImageAssetID INT;

    DECLARE @SubjectLinks TABLE
    (
        SubjectTypeCode        NVARCHAR(50) NOT NULL,
        SubjectTypeCodeValueID INT          NULL,
        ChildID                INT          NULL,
        PersonID               INT          NULL,
        IsPrimarySubject       BIT          NOT NULL,
        SortOrder              INT          NOT NULL
    );

    IF ISNULL(@SubjectLinksJson, N'') <> N''
       AND ISJSON(@SubjectLinksJson) = 1
    BEGIN
        INSERT INTO @SubjectLinks
        (
            SubjectTypeCode,
            ChildID,
            PersonID,
            IsPrimarySubject,
            SortOrder
        )
        SELECT
            UPPER(LTRIM(RTRIM(SubjectTypeCode))),
            ChildID,
            PersonID,
            ISNULL(IsPrimarySubject, 0),
            ISNULL(SortOrder, 1)
        FROM OPENJSON(@SubjectLinksJson)
        WITH
        (
            SubjectTypeCode NVARCHAR(50) '$.subjectTypeCode',
            ChildID         INT          '$.childId',
            PersonID        INT          '$.personId',
            IsPrimarySubject BIT         '$.isPrimarySubject',
            SortOrder       INT          '$.sortOrder'
        );
    END;

    UPDATE sl
       SET SubjectTypeCodeValueID = cv.CodeValueID
    FROM @SubjectLinks sl
    INNER JOIN ref.CodeValue cv
        ON cv.CodeDomain = N'ImageAssetSubjectType'
       AND cv.CodeValue = sl.SubjectTypeCode
       AND cv.IsActive = 1;

    IF EXISTS (SELECT 1 FROM @SubjectLinks WHERE SubjectTypeCodeValueID IS NULL)
    BEGIN
        THROW 52001, 'One or more image subject type codes are not valid ImageAssetSubjectType code values.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM @SubjectLinks
        WHERE (SubjectTypeCode = N'CHILD' AND (ChildID IS NULL OR PersonID IS NOT NULL))
           OR (SubjectTypeCode = N'PERSON' AND (PersonID IS NULL OR ChildID IS NOT NULL))
           OR SubjectTypeCode NOT IN (N'CHILD', N'PERSON')
    )
    BEGIN
        THROW 52002, 'Image subject links must use CHILD with ChildID or PERSON with PersonID.', 1;
    END;

    BEGIN TRANSACTION;

    INSERT INTO image.ImageAsset
    (
        SiteID,
        ImageCategoryCode,
        VisibilityScopeCode,
        OriginalFileName,
        OriginalContentType,
        OriginalLengthBytes,
        EncryptedFileRelativePath,
        EncryptedFileLengthBytes,
        EncryptionAlgorithmCode,
        SiteKeyVersion,
        ImageNonce,
        ImageSha256Hex,
        ThumbnailContentType,
        ThumbnailLengthBytes,
        EncryptedThumbnailRelativePath,
        EncryptedThumbnailLengthBytes,
        ThumbnailNonce,
        ThumbnailSha256Hex,
        PixelWidth,
        PixelHeight,
        Caption,
        TakenUTC,
        UploadedByPortalUserID,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        @ImageCategoryCode,
        @VisibilityScopeCode,
        @OriginalFileName,
        @OriginalContentType,
        @OriginalLengthBytes,
        @EncryptedFileRelativePath,
        @EncryptedFileLengthBytes,
        @EncryptionAlgorithmCode,
        @SiteKeyVersion,
        @ImageNonce,
        @ImageSha256Hex,
        @ThumbnailContentType,
        @ThumbnailLengthBytes,
        @EncryptedThumbnailRelativePath,
        @EncryptedThumbnailLengthBytes,
        @ThumbnailNonce,
        @ThumbnailSha256Hex,
        @PixelWidth,
        @PixelHeight,
        @Caption,
        @TakenUTC,
        @UploadedByPortalUserID,
        1,
        0,
        @CreatedByUserID
    );

    SET @ImageAssetID = CAST(SCOPE_IDENTITY() AS INT);

    INSERT INTO image.ImageAssetSubject
    (
        ImageAssetID,
        SubjectTypeCodeValueID,
        ChildID,
        PersonID,
        IsPrimarySubject,
        SortOrder,
        CreatedByUserID
    )
    SELECT
        @ImageAssetID,
        sl.SubjectTypeCodeValueID,
        sl.ChildID,
        sl.PersonID,
        sl.IsPrimarySubject,
        sl.SortOrder,
        @CreatedByUserID
    FROM @SubjectLinks sl;

    IF @ImageCategoryCode = N'CHILD_HEADSHOT'
    BEGIN
        UPDATE ia
           SET IsActive = 0,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
        FROM image.ImageAsset ia
        INNER JOIN image.ImageAssetSubject ias
            ON ias.ImageAssetID = ia.ImageAssetID
           AND ias.IsDeleted = 0
           AND ias.IsActive = 1
        INNER JOIN ref.CodeValue st
            ON st.CodeValueID = ias.SubjectTypeCodeValueID
           AND st.CodeDomain = N'ImageAssetSubjectType'
           AND st.CodeValue = N'CHILD'
        INNER JOIN @SubjectLinks sl
            ON sl.SubjectTypeCode = N'CHILD'
           AND sl.ChildID = ias.ChildID
        WHERE ia.SiteID = @SiteID
          AND ia.ImageAssetID <> @ImageAssetID
          AND ia.ImageCategoryCode = N'CHILD_HEADSHOT'
          AND ia.IsDeleted = 0
          AND ia.IsActive = 1;
    END;

    IF @ImageCategoryCode = N'PERSON_HEADSHOT'
    BEGIN
        UPDATE ia
           SET IsActive = 0,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
        FROM image.ImageAsset ia
        INNER JOIN image.ImageAssetSubject ias
            ON ias.ImageAssetID = ia.ImageAssetID
           AND ias.IsDeleted = 0
           AND ias.IsActive = 1
        INNER JOIN ref.CodeValue st
            ON st.CodeValueID = ias.SubjectTypeCodeValueID
           AND st.CodeDomain = N'ImageAssetSubjectType'
           AND st.CodeValue = N'PERSON'
        INNER JOIN @SubjectLinks sl
            ON sl.SubjectTypeCode = N'PERSON'
           AND sl.PersonID = ias.PersonID
        WHERE ia.SiteID = @SiteID
          AND ia.ImageAssetID <> @ImageAssetID
          AND ia.ImageCategoryCode = N'PERSON_HEADSHOT'
          AND ia.IsDeleted = 0
          AND ia.IsActive = 1;
    END;

    COMMIT TRANSACTION;

    SELECT @ImageAssetID AS ImageAssetID;
END;
GO
