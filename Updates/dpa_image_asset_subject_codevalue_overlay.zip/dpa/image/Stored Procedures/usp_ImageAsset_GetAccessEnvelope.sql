CREATE PROCEDURE image.usp_ImageAsset_GetAccessEnvelope
    @ImageAssetID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ia.ImageAssetID,
        ia.SiteID,
        ia.ImageCategoryCode,
        ia.VisibilityScopeCode,
        ia.OriginalFileName,
        ia.OriginalContentType,
        ia.OriginalLengthBytes,
        ia.EncryptedFileRelativePath,
        ia.EncryptedFileLengthBytes,
        ia.SiteKeyVersion,
        ia.ImageNonce,
        ia.ImageSha256Hex,
        ia.ThumbnailContentType,
        ia.ThumbnailLengthBytes,
        ia.EncryptedThumbnailRelativePath,
        ia.EncryptedThumbnailLengthBytes,
        ia.ThumbnailNonce,
        ia.ThumbnailSha256Hex,
        ia.Caption,
        ia.TakenUTC,
        ia.CreatedUTC,
        ia.IsActive,
        ia.IsDeleted
    FROM image.ImageAsset ia
    WHERE ia.ImageAssetID = @ImageAssetID;

    SELECT
        ias.ImageAssetSubjectID,
        ias.SubjectTypeCodeValueID,
        SubjectTypeCode = st.CodeValue,
        ias.ChildID,
        ias.PersonID,
        ias.IsPrimarySubject,
        ias.SortOrder,
        ias.IsActive,
        ias.IsDeleted
    FROM image.ImageAssetSubject ias
    INNER JOIN ref.CodeValue st
        ON st.CodeValueID = ias.SubjectTypeCodeValueID
       AND st.CodeDomain = N'ImageAssetSubjectType'
    WHERE ias.ImageAssetID = @ImageAssetID
    ORDER BY ias.SortOrder, ias.ImageAssetSubjectID;
END;
GO
