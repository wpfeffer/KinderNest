SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'AccountStatus', N'ACTIVE', N'Active'),
            (N'AccountStatus', N'PENDING_APPROVAL', N'Pending Approval'),
            (N'AccountStatus', N'REJECTED', N'Rejected'),
            (N'AccountStatus', N'DISABLED', N'Disabled')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = v.CodeDomain
          AND cv.CodeValue = v.CodeValue
    );
END;
GO

IF OBJECT_ID(N'ref.Role', N'U') IS NOT NULL
AND NOT EXISTS
(
    SELECT 1
    FROM ref.Role r
    WHERE r.RoleCode = N'PROVIDER_OWNER'
)
BEGIN
    INSERT INTO ref.Role
    (
        RoleCode,
        RoleName,
        RoleDescription,
        IsSystemRole,
        IsActive
    )
    VALUES
    (
        N'PROVIDER_OWNER',
        N'Provider Owner',
        N'Primary provider account owner.',
        1,
        1
    );
END;
GO
CREATE OR ALTER PROCEDURE ops.usp_AdminDashboard_GetSummary
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER',
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @FailureResultCodeValueID INT;
    DECLARE @BlockedResultCodeValueID INT;
    DECLARE @LockedCredentialStatusCodeValueID INT;

    SELECT @FailureResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'FAILURE'
      AND cv.IsActive = 1;

    SELECT @BlockedResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'BLOCKED'
      AND cv.IsActive = 1;

    SELECT @LockedCredentialStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    )
    SELECT
        PendingProviderApprovals =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
              AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
        ),
        ActiveProviders =
        (
            SELECT COUNT(1)
            FROM party.Provider pr
            WHERE pr.IsActive = 1
              AND pr.IsDeleted = 0
        ),
        ActiveSites =
        (
            SELECT COUNT(1)
            FROM party.Site s
            WHERE s.IsActive = 1
              AND s.IsDeleted = 0
        ),
        ActiveUsers =
        (
            SELECT COUNT(1)
            FROM party.PortalUser pu
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
        ),
        LockedAccounts =
        (
            SELECT COUNT(1)
            FROM sec.PortalCredential pc
            WHERE pc.IsActive = 1
              AND pc.IsDeleted = 0
              AND (
                    (@LockedCredentialStatusCodeValueID IS NOT NULL AND pc.CredentialStatusCodeValueID = @LockedCredentialStatusCodeValueID)
                    OR (pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME())
                  )
        ),
        FailedLoginsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuthenticationEvent ae
            WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
              AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
        ),
        RecentRegistrationsLast7Days =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsDeleted = 0
              AND pu.CreatedUTC >= DATEADD(DAY, -7, SYSUTCDATETIME())
        ),
        AuditEventsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuditLog al
            WHERE al.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
        );

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    )
    SELECT TOP (10)
        pu.PortalUserID,
        reg.ProviderID,
        reg.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        pu.UserName,
        PrimaryEmail = ISNULL(p.PrimaryEmail, N''),
        ProviderName = ISNULL(reg.ProviderName, N''),
        reg.BusinessEmail,
        SiteName = ISNULL(reg.SiteName, N''),
        reg.LicenseNumber,
        LicenseClassCode = ISNULL(reg.LicenseClassCode, N''),
        LicenseClassName = ISNULL(reg.LicenseClassName, N''),
        pu.AccountStatusCode
    FROM ProviderOwnerUsers pou
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = pou.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    OUTER APPLY
    (
        SELECT TOP (1)
            s.SiteID,
            pr.ProviderID,
            pr.ProviderName,
            pr.BusinessEmail,
            s.SiteName,
            s.LicenseNumber,
            lc.LicenseClassCode,
            lc.LicenseClassName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
        INNER JOIN party.Provider pr
            ON pr.ProviderID = s.ProviderID
           AND pr.IsDeleted = 0
        INNER JOIN lic.LicenseClass lc
            ON lc.LicenseClassID = s.LicenseClassID
        WHERE sua.PortalUserID = pu.PortalUserID
          AND sua.IsActive = 1
        ORDER BY sua.IsPrimaryProviderContact DESC,
                 sua.EffectiveStartUTC DESC,
                 sua.SiteUserAssignmentID DESC
    ) reg
    ORDER BY pu.CreatedUTC DESC,
             pu.PortalUserID DESC;

    SELECT TOP (10)
        ae.AuthenticationEventID,
        ae.EventUTC,
        UserNameAttempted = COALESCE(ae.UserNameAttempted, pu.UserName, N''),
        AuthenticationEventTypeCode = et.CodeValue,
        AuthenticationResultCode = ar.CodeValue,
        ae.FailureReason,
        ae.RemoteAddress,
        SiteName = s.SiteName
    FROM audit.AuthenticationEvent ae
    LEFT JOIN party.PortalUser pu
        ON pu.PortalUserID = ae.PortalUserID
    LEFT JOIN ref.CodeValue et
        ON et.CodeValueID = ae.AuthenticationEventTypeCodeValueID
    LEFT JOIN ref.CodeValue ar
        ON ar.CodeValueID = ae.AuthenticationResultCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = ae.SiteID
    WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
      AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
    ORDER BY ae.EventUTC DESC,
             ae.AuthenticationEventID DESC;

    SELECT TOP (10)
        al.AuditLogID,
        al.EventUTC,
        al.SchemaName,
        al.TableName,
        al.ActionTypeCode,
        ActorUserName = actor.UserName,
        al.RecordPrimaryKeyValue,
        al.ReasonText,
        al.SucceededFlag
    FROM audit.AuditLog al
    LEFT JOIN party.PortalUser actor
        ON actor.PortalUserID = al.ChangedByUserID
    ORDER BY al.EventUTC DESC,
             al.AuditLogID DESC;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminPendingProvider_List
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER',
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pu.PortalUserID,
        reg.ProviderID,
        reg.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        pu.UserName,
        PrimaryEmail = ISNULL(p.PrimaryEmail, N''),
        ProviderName = ISNULL(reg.ProviderName, N''),
        reg.BusinessEmail,
        SiteName = ISNULL(reg.SiteName, N''),
        reg.LicenseNumber,
        LicenseClassCode = ISNULL(reg.LicenseClassCode, N''),
        LicenseClassName = ISNULL(reg.LicenseClassName, N''),
        pu.AccountStatusCode
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    INNER JOIN party.PortalUserRole pur
        ON pur.PortalUserID = pu.PortalUserID
       AND pur.IsActive = 1
       AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
       AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
       AND r.RoleCode = @ProviderOwnerRoleCode
       AND r.IsActive = 1
    OUTER APPLY
    (
        SELECT TOP (1)
            s.SiteID,
            pr.ProviderID,
            pr.ProviderName,
            pr.BusinessEmail,
            s.SiteName,
            s.LicenseNumber,
            lc.LicenseClassCode,
            lc.LicenseClassName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
        INNER JOIN party.Provider pr
            ON pr.ProviderID = s.ProviderID
           AND pr.IsDeleted = 0
        INNER JOIN lic.LicenseClass lc
            ON lc.LicenseClassID = s.LicenseClassID
        WHERE sua.PortalUserID = pu.PortalUserID
          AND sua.IsActive = 1
        ORDER BY sua.IsPrimaryProviderContact DESC,
                 sua.EffectiveStartUTC DESC,
                 sua.SiteUserAssignmentID DESC
    ) reg
    WHERE pu.IsActive = 1
      AND pu.IsDeleted = 0
      AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
    ORDER BY pu.CreatedUTC DESC,
             pu.PortalUserID DESC;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Approve
    @PortalUserID INT,
    @ApprovedByUserID INT,
    @ReasonText NVARCHAR(MAX) = NULL,
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ApprovedAccountStatusCode NVARCHAR(50) = N'ACTIVE',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration approved.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = COALESCE(NULLIF(LTRIM(RTRIM(@ReasonText)), N''), N'Provider registration approved from admin portal.');

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50700, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50701, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @ApprovedAccountStatusCode,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ApprovedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50702, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'APPROVE_PROVIDER_REGISTRATION',
        @ChangedByUserID = @ApprovedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @ApprovedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Reject
    @PortalUserID INT,
    @RejectedByUserID INT,
    @ReasonText NVARCHAR(MAX) = NULL,
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @RejectedAccountStatusCode NVARCHAR(50) = N'REJECTED',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration rejected.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = COALESCE(NULLIF(LTRIM(RTRIM(@ReasonText)), N''), N'Provider registration rejected from admin portal.');

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50710, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50711, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @RejectedAccountStatusCode,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @RejectedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50712, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'REJECT_PROVIDER_REGISTRATION',
        @ChangedByUserID = @RejectedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @RejectedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO
