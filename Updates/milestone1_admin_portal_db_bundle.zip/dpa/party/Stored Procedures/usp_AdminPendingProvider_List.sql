CREATE OR ALTER PROCEDURE party.usp_AdminPendingProvider_List
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER',
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pu.PortalUserID,
        reg.ProviderID,
        reg.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        pu.UserName,
        PrimaryEmail = ISNULL(p.PrimaryEmail, N''),
        ProviderName = ISNULL(reg.ProviderName, N''),
        reg.BusinessEmail,
        SiteName = ISNULL(reg.SiteName, N''),
        reg.LicenseNumber,
        LicenseClassCode = ISNULL(reg.LicenseClassCode, N''),
        LicenseClassName = ISNULL(reg.LicenseClassName, N''),
        pu.AccountStatusCode
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    INNER JOIN party.PortalUserRole pur
        ON pur.PortalUserID = pu.PortalUserID
       AND pur.IsActive = 1
       AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
       AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
       AND r.RoleCode = @ProviderOwnerRoleCode
       AND r.IsActive = 1
    OUTER APPLY
    (
        SELECT TOP (1)
            s.SiteID,
            pr.ProviderID,
            pr.ProviderName,
            pr.BusinessEmail,
            s.SiteName,
            s.LicenseNumber,
            lc.LicenseClassCode,
            lc.LicenseClassName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
        INNER JOIN party.Provider pr
            ON pr.ProviderID = s.ProviderID
           AND pr.IsDeleted = 0
        INNER JOIN lic.LicenseClass lc
            ON lc.LicenseClassID = s.LicenseClassID
        WHERE sua.PortalUserID = pu.PortalUserID
          AND sua.IsActive = 1
        ORDER BY sua.IsPrimaryProviderContact DESC,
                 sua.EffectiveStartUTC DESC,
                 sua.SiteUserAssignmentID DESC
    ) reg
    WHERE pu.IsActive = 1
      AND pu.IsDeleted = 0
      AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
    ORDER BY pu.CreatedUTC DESC,
             pu.PortalUserID DESC;
END;
GO
