SET NOCOUNT ON;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH CredentialSnapshot AS
    (
        SELECT
            c.PortalUserID,
            c.LockoutEndUTC,
            ROW_NUMBER() OVER (PARTITION BY c.PortalUserID ORDER BY c.IsPrimary DESC, c.PortalCredentialID DESC) AS rn
        FROM sec.PortalCredential c
        WHERE c.IsDeleted = 0
    ),
    SessionSnapshot AS
    (
        SELECT
            ls.PortalUserID,
            MAX(ls.StartedUTC) AS LastLoginUTC
        FROM sec.LoginSession ls
        GROUP BY ls.PortalUserID
    ),
    RoleSnapshot AS
    (
        SELECT
            pur.PortalUserID,
            STRING_AGG(r.RoleCode, N', ') WITHIN GROUP (ORDER BY r.RoleCode) AS RoleCodes
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND pur.EffectiveEndUTC IS NULL
          AND r.IsActive = 1
        GROUP BY pur.PortalUserID
    ),
    SiteSnapshot AS
    (
        SELECT
            sua.PortalUserID,
            COUNT(DISTINCT sua.SiteID) AS SiteCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE WHEN cs.LockoutEndUTC IS NOT NULL AND cs.LockoutEndUTC >= SYSUTCDATETIME() THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsLocked,
        cs.LockoutEndUTC,
        ss.LastLoginUTC,
        ISNULL(rs.RoleCodes, N'') AS RoleCodes,
        ISNULL(si.SiteCount, 0) AS SiteCount,
        pu.IsActive
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN CredentialSnapshot cs
        ON cs.PortalUserID = pu.PortalUserID
       AND cs.rn = 1
    LEFT JOIN SessionSnapshot ss
        ON ss.PortalUserID = pu.PortalUserID
    LEFT JOIN RoleSnapshot rs
        ON rs.PortalUserID = pu.PortalUserID
    LEFT JOIN SiteSnapshot si
        ON si.PortalUserID = pu.PortalUserID
    WHERE pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY CONCAT(p.FirstName, N' ', p.LastName), pu.UserName;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_GetDetail
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH CredentialSnapshot AS
    (
        SELECT
            c.PortalUserID,
            c.LockoutEndUTC,
            ROW_NUMBER() OVER (PARTITION BY c.PortalUserID ORDER BY c.IsPrimary DESC, c.PortalCredentialID DESC) AS rn
        FROM sec.PortalCredential c
        WHERE c.IsDeleted = 0
    ),
    SessionSnapshot AS
    (
        SELECT
            ls.PortalUserID,
            MAX(ls.StartedUTC) AS LastLoginUTC
        FROM sec.LoginSession ls
        GROUP BY ls.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        pu.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE WHEN cs.LockoutEndUTC IS NOT NULL AND cs.LockoutEndUTC >= SYSUTCDATETIME() THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsLocked,
        cs.LockoutEndUTC,
        ss.LastLoginUTC,
        pu.IsActive,
        pu.RejectionReason
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN CredentialSnapshot cs
        ON cs.PortalUserID = pu.PortalUserID
       AND cs.rn = 1
    LEFT JOIN SessionSnapshot ss
        ON ss.PortalUserID = pu.PortalUserID
    WHERE pu.PortalUserID = @PortalUserID
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0;

    SELECT
        r.RoleCode,
        r.RoleName,
        pur.EffectiveStartUTC,
        pur.EffectiveEndUTC,
        pur.IsActive
    FROM party.PortalUserRole pur
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
    WHERE pur.PortalUserID = @PortalUserID
    ORDER BY pur.EffectiveStartUTC DESC, r.RoleCode;

    SELECT
        sua.SiteID,
        s.SiteName,
        pr.ProviderName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
    WHERE sua.PortalUserID = @PortalUserID
      AND s.IsDeleted = 0
      AND pr.IsDeleted = 0
    ORDER BY sua.EffectiveStartUTC DESC, s.SiteName;

    SELECT TOP (10)
        ls.LoginSessionID,
        ls.SessionStatusCode,
        ls.StartedUTC,
        ls.LastSeenUTC,
        ls.RevokedUTC,
        ls.RemoteAddress,
        ls.UserAgent
    FROM sec.LoginSession ls
    WHERE ls.PortalUserID = @PortalUserID
    ORDER BY ls.StartedUTC DESC, ls.LoginSessionID DESC;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminProvider_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH SiteCounts AS
    (
        SELECT
            s.ProviderID,
            COUNT(*) AS SiteCount
        FROM party.Site s
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    ),
    OwnerSnapshot AS
    (
        SELECT
            s.ProviderID,
            MIN(CONCAT(p.FirstName, N' ', p.LastName)) AS OwnerDisplayName
        FROM party.Site s
        INNER JOIN party.SiteUserAssignment sua
            ON sua.SiteID = s.SiteID
           AND sua.IsActive = 1
           AND sua.EffectiveEndUTC IS NULL
           AND sua.IsPrimaryProviderContact = 1
        INNER JOIN party.PortalUser pu
            ON pu.PortalUserID = sua.PortalUserID
           AND pu.IsDeleted = 0
        INNER JOIN party.Person p
            ON p.PersonID = pu.PersonID
           AND p.IsDeleted = 0
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    )
    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        pr.BusinessEmail,
        os.OwnerDisplayName,
        ISNULL(sc.SiteCount, 0) AS SiteCount,
        pr.IsActive
    FROM party.Provider pr
    LEFT JOIN SiteCounts sc
        ON sc.ProviderID = pr.ProviderID
    LEFT JOIN OwnerSnapshot os
        ON os.ProviderID = pr.ProviderID
    WHERE pr.IsDeleted = 0
    ORDER BY pr.ProviderName;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminProvider_GetDetail
    @ProviderID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        pr.BusinessEmail,
        CONCAT(lp.FirstName, N' ', lp.LastName) AS LicenseHolderDisplayName,
        pr.IsActive
    FROM party.Provider pr
    LEFT JOIN party.Person lp
        ON lp.PersonID = pr.LicenseHolderPersonID
    WHERE pr.ProviderID = @ProviderID
      AND pr.IsDeleted = 0;

    ;WITH RoleSnapshot AS
    (
        SELECT
            pur.PortalUserID,
            STRING_AGG(r.RoleCode, N', ') WITHIN GROUP (ORDER BY r.RoleCode) AS RoleCodes
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND pur.EffectiveEndUTC IS NULL
          AND r.IsActive = 1
        GROUP BY pur.PortalUserID
    )
    SELECT DISTINCT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        ISNULL(rs.RoleCodes, N'') AS RoleCodes,
        sua.IsPrimaryProviderContact,
        pu.IsActive
    FROM party.Site s
    INNER JOIN party.SiteUserAssignment sua
        ON sua.SiteID = s.SiteID
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN RoleSnapshot rs
        ON rs.PortalUserID = pu.PortalUserID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY DisplayName, pu.UserName;

    ;WITH AssignmentCounts AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS AssignedUserCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        ISNULL(ac.AssignedUserCount, 0) AS AssignedUserCount,
        s.IsActive
    FROM party.Site s
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN AssignmentCounts ac
        ON ac.SiteID = s.SiteID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
    ORDER BY s.SiteName;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminSite_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH AssignmentCounts AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS AssignedUserCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.SiteName,
        s.ProviderID,
        pr.ProviderName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        tz.TimeZoneCode,
        ISNULL(ac.AssignedUserCount, 0) AS AssignedUserCount,
        s.IsActive
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN AssignmentCounts ac
        ON ac.SiteID = s.SiteID
    WHERE s.IsDeleted = 0
    ORDER BY pr.ProviderName, s.SiteName;
END;
GO

CREATE OR ALTER PROCEDURE party.usp_AdminSite_GetDetail
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        s.SiteID,
        s.ProviderID,
        pr.ProviderName,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        s.IsActive
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    WHERE s.SiteID = @SiteID
      AND s.IsDeleted = 0;

    SELECT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    WHERE sua.SiteID = @SiteID
    ORDER BY sua.EffectiveStartUTC DESC, DisplayName;
END;
GO
