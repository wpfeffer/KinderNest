CREATE OR ALTER PROCEDURE party.usp_AdminSite_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH AssignmentCounts AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS AssignedUserCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.SiteName,
        s.ProviderID,
        pr.ProviderName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        tz.TimeZoneCode,
        ISNULL(ac.AssignedUserCount, 0) AS AssignedUserCount,
        s.IsActive
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN AssignmentCounts ac
        ON ac.SiteID = s.SiteID
    WHERE s.IsDeleted = 0
    ORDER BY pr.ProviderName, s.SiteName;
END;
GO
