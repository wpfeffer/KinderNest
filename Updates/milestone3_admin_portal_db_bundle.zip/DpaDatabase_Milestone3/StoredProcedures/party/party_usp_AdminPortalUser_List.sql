CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH CredentialSnapshot AS
    (
        SELECT
            c.PortalUserID,
            c.LockoutEndUTC,
            ROW_NUMBER() OVER (PARTITION BY c.PortalUserID ORDER BY c.IsPrimary DESC, c.PortalCredentialID DESC) AS rn
        FROM sec.PortalCredential c
        WHERE c.IsDeleted = 0
    ),
    SessionSnapshot AS
    (
        SELECT
            ls.PortalUserID,
            MAX(ls.StartedUTC) AS LastLoginUTC
        FROM sec.LoginSession ls
        GROUP BY ls.PortalUserID
    ),
    RoleSnapshot AS
    (
        SELECT
            pur.PortalUserID,
            STRING_AGG(r.RoleCode, N', ') WITHIN GROUP (ORDER BY r.RoleCode) AS RoleCodes
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND pur.EffectiveEndUTC IS NULL
          AND r.IsActive = 1
        GROUP BY pur.PortalUserID
    ),
    SiteSnapshot AS
    (
        SELECT
            sua.PortalUserID,
            COUNT(DISTINCT sua.SiteID) AS SiteCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE WHEN cs.LockoutEndUTC IS NOT NULL AND cs.LockoutEndUTC >= SYSUTCDATETIME() THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsLocked,
        cs.LockoutEndUTC,
        ss.LastLoginUTC,
        ISNULL(rs.RoleCodes, N'') AS RoleCodes,
        ISNULL(si.SiteCount, 0) AS SiteCount,
        pu.IsActive
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN CredentialSnapshot cs
        ON cs.PortalUserID = pu.PortalUserID
       AND cs.rn = 1
    LEFT JOIN SessionSnapshot ss
        ON ss.PortalUserID = pu.PortalUserID
    LEFT JOIN RoleSnapshot rs
        ON rs.PortalUserID = pu.PortalUserID
    LEFT JOIN SiteSnapshot si
        ON si.PortalUserID = pu.PortalUserID
    WHERE pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY CONCAT(p.FirstName, N' ', p.LastName), pu.UserName;
END;
GO
