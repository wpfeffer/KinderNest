CREATE OR ALTER PROCEDURE party.usp_AdminProvider_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH SiteCounts AS
    (
        SELECT
            s.ProviderID,
            COUNT(*) AS SiteCount
        FROM party.Site s
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    ),
    OwnerSnapshot AS
    (
        SELECT
            s.ProviderID,
            MIN(CONCAT(p.FirstName, N' ', p.LastName)) AS OwnerDisplayName
        FROM party.Site s
        INNER JOIN party.SiteUserAssignment sua
            ON sua.SiteID = s.SiteID
           AND sua.IsActive = 1
           AND sua.EffectiveEndUTC IS NULL
           AND sua.IsPrimaryProviderContact = 1
        INNER JOIN party.PortalUser pu
            ON pu.PortalUserID = sua.PortalUserID
           AND pu.IsDeleted = 0
        INNER JOIN party.Person p
            ON p.PersonID = pu.PersonID
           AND p.IsDeleted = 0
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    )
    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        pr.BusinessEmail,
        os.OwnerDisplayName,
        ISNULL(sc.SiteCount, 0) AS SiteCount,
        pr.IsActive
    FROM party.Provider pr
    LEFT JOIN SiteCounts sc
        ON sc.ProviderID = pr.ProviderID
    LEFT JOIN OwnerSnapshot os
        ON os.ProviderID = pr.ProviderID
    WHERE pr.IsDeleted = 0
    ORDER BY pr.ProviderName;
END;
GO
