param(
    [string]$RepoRoot = "."
)

$jsPath = Join-Path $RepoRoot "DaycareProviderAssistant\wwwroot\js\dpa-images.js"
$razorPath = Join-Path $RepoRoot "DaycareProviderAssistant\Components\Pages\Provider\Photos.razor"

if (-not (Test-Path $jsPath)) {
    throw "Could not find dpa-images.js at $jsPath"
}

$js = Get-Content $jsPath -Raw

# Critical syntax fix: the current file has an unquoted template literal body, which prevents the ES module from loading.
$js = $js.Replace(
    "throw new Error(payload?.error || The encrypted upload failed with HTTP .);",
    "throw new Error(payload?.error || ``The encrypted upload failed with HTTP `${response.status}.``);"
)

# Repair common mojibake left by prior patching.
$js = $js.Replace("in-browserâ€¦", "in-browser...")
$js = $js.Replace("galleryâ€¦", "gallery...")

# Make missing controls visible in the console instead of silently returning.
$js = $js.Replace(
    "if (!form || !button || !status) {`r`n        return;`r`n    }",
    "if (!form || !button || !status) {`r`n        console.warn('Encrypted upload controls were not found.', { form: !!form, button: !!button, status: !!status });`r`n        return;`r`n    }`r`n`r`n    status.textContent = 'Ready. No plaintext leaves the browser.';"
)
$js = $js.Replace(
    "if (!form || !button || !status) {`n        return;`n    }",
    "if (!form || !button || !status) {`n        console.warn('Encrypted upload controls were not found.', { form: !!form, button: !!button, status: !!status });`n        return;`n    }`n`n    status.textContent = 'Ready. No plaintext leaves the browser.';"
)

Set-Content -Path $jsPath -Value $js -Encoding UTF8

# Optional but helpful: bust the browser cache for the imported ES module.
if (Test-Path $razorPath) {
    $razor = Get-Content $razorPath -Raw
    $razor = $razor.Replace('"import", "/js/dpa-images.js"', '"import", "/js/dpa-images.js?v=20260424-fix1"')
    Set-Content -Path $razorPath -Value $razor -Encoding UTF8
}

Write-Host "Fixed dpa-images.js syntax error and added cache-busted import."
