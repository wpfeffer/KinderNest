DPA fix Encrypt and Upload JavaScript overlay

Problem:
The current DaycareProviderAssistant/wwwroot/js/dpa-images.js contains invalid JavaScript:

    throw new Error(payload?.error || The encrypted upload failed with HTTP .);

Because dpa-images.js is imported as an ES module, this syntax error prevents the module from loading. The click handler never wires up, so the Encrypt and upload button appears to do nothing.

Apply:
1. Unzip this archive at the repository root.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\apply_fix_encrypt_upload_js.ps1
3. Rebuild/run the app.
4. Hard refresh /provider/photos.
5. Open DevTools Console. The dpa-images.js syntax error should be gone.

This patch also changes Photos.razor to import /js/dpa-images.js?v=20260424-fix1 so the browser does not keep using the broken cached module.
