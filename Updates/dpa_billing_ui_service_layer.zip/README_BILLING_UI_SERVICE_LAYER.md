This overlay adds the billing UI + service layer for admin, provider, and guardian portals.

Included database changes:
- billing.usp_AdminBillingDashboard_GetSummary
- billing.usp_ProviderBillingDashboard_GetSummary
- billing.usp_GuardianBillingDashboard_GetSummary

Included C# changes:
- billing models
- admin/provider/guardian billing services + interfaces
- admin/provider/guardian billing pages
- Program.cs registration patch
- PortalNavigationService patch

What this layer does:
- admin can see billing counts, provider subscriptions, and recent provider invoices
- provider can see subscription/plan details, provider invoices, rate schedules, and family billing accounts
- guardian can see family billing accounts, invoices, and payment history

What it does not do yet:
- edit/create forms for rates, accounts, invoices, or payments
- webhook orchestration for external processors
- invoice PDF generation
- payment capture UI
