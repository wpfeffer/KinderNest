using System.Data;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Billing.Models;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Portal.Services.PortalDataReaderHelpers;

namespace DaycareProviderAssistant.Billing.Services;

public sealed class GuardianBillingService : IGuardianBillingService
{
    private const string ProcedureName = "billing.usp_GuardianBillingDashboard_GetSummary";
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<GuardianBillingService> _logger;

    public GuardianBillingService(ISqlConnectionFactory connectionFactory, ILogger<GuardianBillingService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<GuardianBillingDashboardDto> GetDashboardAsync(int personId, CancellationToken cancellationToken = default)
    {
        var counts = new GuardianBillingCountsDto();
        var accounts = new List<GuardianBillingAccountItemDto>();
        var invoices = new List<GuardianInvoiceItemDto>();
        var payments = new List<GuardianPaymentItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;
        command.Parameters.Add(new SqlParameter("@PersonID", SqlDbType.Int) { Value = personId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                counts = new GuardianBillingCountsDto
                {
                    HouseholdCount = GetInt32(reader, "HouseholdCount"),
                    ActiveFamilyBillingAccounts = GetInt32(reader, "ActiveFamilyBillingAccounts"),
                    OpenInvoices = GetInt32(reader, "OpenInvoices"),
                    OutstandingBalanceAmount = GetDecimal(reader, "OutstandingBalanceAmount")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    accounts.Add(new GuardianBillingAccountItemDto
                    {
                        FamilyBillingAccountId = GetInt32(reader, "FamilyBillingAccountID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        HouseholdId = GetInt32(reader, "HouseholdID"),
                        HouseholdDisplayName = GetString(reader, "HouseholdDisplayName"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SiteName = GetNullableString(reader, "SiteName"),
                        AccountStatusCode = GetString(reader, "AccountStatusCode"),
                        AccountStatusName = GetString(reader, "AccountStatusName"),
                        BillingFrequencyCode = GetString(reader, "BillingFrequencyCode"),
                        BillingFrequencyName = GetString(reader, "BillingFrequencyName"),
                        BillingDayOfMonth = GetNullableByte(reader, "BillingDayOfMonth"),
                        BillingEmail = GetNullableString(reader, "BillingEmail"),
                        CurrentBalanceAmount = GetDecimal(reader, "CurrentBalanceAmount")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    invoices.Add(new GuardianInvoiceItemDto
                    {
                        FamilyInvoiceId = GetInt32(reader, "FamilyInvoiceID"),
                        FamilyBillingAccountId = GetInt32(reader, "FamilyBillingAccountID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        HouseholdDisplayName = GetString(reader, "HouseholdDisplayName"),
                        InvoiceNumber = GetString(reader, "InvoiceNumber"),
                        InvoiceStatusCode = GetString(reader, "InvoiceStatusCode"),
                        InvoiceStatusName = GetString(reader, "InvoiceStatusName"),
                        IssuedUtc = GetDateTime(reader, "IssuedUTC"),
                        DueUtc = GetNullableDateTime(reader, "DueUTC"),
                        TotalAmount = GetDecimal(reader, "TotalAmount"),
                        BalanceAmount = GetDecimal(reader, "BalanceAmount")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    payments.Add(new GuardianPaymentItemDto
                    {
                        PaymentId = GetInt32(reader, "PaymentID"),
                        FamilyBillingAccountId = GetInt32(reader, "FamilyBillingAccountID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        PaymentStatusCode = GetString(reader, "PaymentStatusCode"),
                        PaymentStatusName = GetString(reader, "PaymentStatusName"),
                        PaymentUtc = GetDateTime(reader, "PaymentUTC"),
                        Amount = GetDecimal(reader, "Amount"),
                        CurrencyCode = GetString(reader, "CurrencyCode"),
                        ExternalTransactionReference = GetNullableString(reader, "ExternalTransactionReference")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Guardian billing dashboard failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return new GuardianBillingDashboardDto
        {
            Counts = counts,
            Accounts = accounts,
            Invoices = invoices,
            Payments = payments
        };
    }

    private static byte? GetNullableByte(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetByte(ordinal);
    }
}
