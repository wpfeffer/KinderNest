using DaycareProviderAssistant.Billing.Models;

namespace DaycareProviderAssistant.Billing.Services;

public interface IGuardianBillingService
{
    Task<GuardianBillingDashboardDto> GetDashboardAsync(int personId, CancellationToken cancellationToken = default);
}
