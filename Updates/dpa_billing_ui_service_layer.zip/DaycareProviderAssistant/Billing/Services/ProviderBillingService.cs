using System.Data;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Billing.Models;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Portal.Services.PortalDataReaderHelpers;

namespace DaycareProviderAssistant.Billing.Services;

public sealed class ProviderBillingService : IProviderBillingService
{
    private const string ProcedureName = "billing.usp_ProviderBillingDashboard_GetSummary";
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<ProviderBillingService> _logger;

    public ProviderBillingService(ISqlConnectionFactory connectionFactory, ILogger<ProviderBillingService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<ProviderBillingDashboardDto> GetDashboardAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var summary = new ProviderBillingSummaryDto();
        var plans = new List<ProviderPlanOptionDto>();
        var invoices = new List<ProviderInvoiceListItemDto>();
        var rateSchedules = new List<ProviderRateScheduleListItemDto>();
        var familyAccounts = new List<ProviderFamilyBillingAccountItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                summary = new ProviderBillingSummaryDto
                {
                    ProviderSubscriptionId = GetInt32(reader, "ProviderSubscriptionID"),
                    ProviderId = GetInt32(reader, "ProviderID"),
                    ProviderName = GetString(reader, "ProviderName"),
                    ProviderPlanId = GetInt32(reader, "ProviderPlanID"),
                    PlanCode = GetString(reader, "PlanCode"),
                    PlanName = GetString(reader, "PlanName"),
                    SubscriptionStatusCode = GetString(reader, "SubscriptionStatusCode"),
                    SubscriptionStatusName = GetString(reader, "SubscriptionStatusName"),
                    BillingFrequencyCode = GetString(reader, "BillingFrequencyCode"),
                    BillingFrequencyName = GetString(reader, "BillingFrequencyName"),
                    SubscriptionStartUtc = GetDateTime(reader, "SubscriptionStartUTC"),
                    SubscriptionEndUtc = GetNullableDateTime(reader, "SubscriptionEndUTC"),
                    NextBillingDateUtc = GetNullableDateTime(reader, "NextBillingDateUTC"),
                    AutoRenewEnabled = GetBoolean(reader, "AutoRenewEnabled"),
                    BasePriceAmount = GetDecimal(reader, "BasePriceAmount"),
                    IncludedChildrenCount = GetNullableInt32(reader, "IncludedChildrenCount"),
                    IncludedImageStorageBytes = GetNullableInt64(reader, "IncludedImageStorageBytes"),
                    IncludedUsersCount = GetNullableInt32(reader, "IncludedUsersCount"),
                    OverageImageStoragePricePerGb = GetNullableDecimal(reader, "OverageImageStoragePricePerGb"),
                    OverageChildPriceAmount = GetNullableDecimal(reader, "OverageChildPriceAmount"),
                    CurrentImageStorageBytes = GetInt64(reader, "CurrentImageStorageBytes"),
                    ActiveFamilyBillingAccounts = GetInt32(reader, "ActiveFamilyBillingAccounts"),
                    OpenFamilyInvoices = GetInt32(reader, "OpenFamilyInvoices"),
                    RateScheduleCount = GetInt32(reader, "RateScheduleCount")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    plans.Add(new ProviderPlanOptionDto
                    {
                        ProviderPlanId = GetInt32(reader, "ProviderPlanID"),
                        PlanCode = GetString(reader, "PlanCode"),
                        PlanName = GetString(reader, "PlanName"),
                        PlanTypeCode = GetString(reader, "PlanTypeCode"),
                        BillingFrequencyCode = GetString(reader, "BillingFrequencyCode"),
                        BasePriceAmount = GetDecimal(reader, "BasePriceAmount"),
                        IncludedChildrenCount = GetNullableInt32(reader, "IncludedChildrenCount"),
                        IncludedImageStorageBytes = GetNullableInt64(reader, "IncludedImageStorageBytes"),
                        IncludedUsersCount = GetNullableInt32(reader, "IncludedUsersCount"),
                        OverageImageStoragePricePerGb = GetNullableDecimal(reader, "OverageImageStoragePricePerGb"),
                        OverageChildPriceAmount = GetNullableDecimal(reader, "OverageChildPriceAmount"),
                        IsPublic = GetBoolean(reader, "IsPublic"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    invoices.Add(new ProviderInvoiceListItemDto
                    {
                        ProviderInvoiceId = GetInt32(reader, "ProviderInvoiceID"),
                        InvoiceNumber = GetString(reader, "InvoiceNumber"),
                        InvoiceStatusCode = GetString(reader, "InvoiceStatusCode"),
                        InvoiceStatusName = GetString(reader, "InvoiceStatusName"),
                        IssuedUtc = GetDateTime(reader, "IssuedUTC"),
                        DueUtc = GetNullableDateTime(reader, "DueUTC"),
                        TotalAmount = GetDecimal(reader, "TotalAmount"),
                        BalanceAmount = GetDecimal(reader, "BalanceAmount")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    rateSchedules.Add(new ProviderRateScheduleListItemDto
                    {
                        ProviderRateScheduleId = GetInt32(reader, "ProviderRateScheduleID"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SiteName = GetNullableString(reader, "SiteName"),
                        RateName = GetString(reader, "RateName"),
                        RateTypeCode = GetString(reader, "RateTypeCode"),
                        BillingFrequencyCode = GetNullableString(reader, "BillingFrequencyCode"),
                        StandardAmount = GetDecimal(reader, "StandardAmount"),
                        StandardQuantityDecimal = GetDecimal(reader, "StandardQuantityDecimal"),
                        AppliesPerChild = GetBoolean(reader, "AppliesPerChild"),
                        TaxableFlag = GetBoolean(reader, "TaxableFlag"),
                        EffectiveStartDate = GetDateOnly(reader, "EffectiveStartDate"),
                        EffectiveEndDate = GetNullableDateOnly(reader, "EffectiveEndDate"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    familyAccounts.Add(new ProviderFamilyBillingAccountItemDto
                    {
                        FamilyBillingAccountId = GetInt32(reader, "FamilyBillingAccountID"),
                        HouseholdId = GetInt32(reader, "HouseholdID"),
                        HouseholdDisplayName = GetString(reader, "HouseholdDisplayName"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SiteName = GetNullableString(reader, "SiteName"),
                        AccountStatusCode = GetString(reader, "AccountStatusCode"),
                        BillingFrequencyCode = GetString(reader, "BillingFrequencyCode"),
                        BillingContactDisplayName = GetNullableString(reader, "BillingContactDisplayName"),
                        BillingEmail = GetNullableString(reader, "BillingEmail"),
                        CurrentBalanceAmount = GetDecimal(reader, "CurrentBalanceAmount"),
                        OpenInvoiceCount = GetInt32(reader, "OpenInvoiceCount")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider billing dashboard failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return new ProviderBillingDashboardDto
        {
            Summary = summary,
            Plans = plans,
            Invoices = invoices,
            RateSchedules = rateSchedules,
            FamilyAccounts = familyAccounts
        };
    }

    private static long? GetNullableInt64(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt64(ordinal);
    }

    private static decimal? GetNullableDecimal(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetDecimal(ordinal);
    }
}
