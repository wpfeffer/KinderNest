using System.Data;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Billing.Models;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Portal.Services.PortalDataReaderHelpers;

namespace DaycareProviderAssistant.Billing.Services;

public sealed class AdminBillingService : IAdminBillingService
{
    private const string ProcedureName = "billing.usp_AdminBillingDashboard_GetSummary";
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminBillingService> _logger;

    public AdminBillingService(ISqlConnectionFactory connectionFactory, ILogger<AdminBillingService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<AdminBillingOverviewDto> GetOverviewAsync(CancellationToken cancellationToken = default)
    {
        var counts = new AdminBillingCountsDto();
        var subscriptions = new List<AdminProviderSubscriptionItemDto>();
        var invoices = new List<AdminProviderInvoiceItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                counts = new AdminBillingCountsDto
                {
                    ActiveProviderSubscriptions = GetInt32(reader, "ActiveProviderSubscriptions"),
                    ProvidersPastDue = GetInt32(reader, "ProvidersPastDue"),
                    OpenProviderInvoices = GetInt32(reader, "OpenProviderInvoices"),
                    FamilyBillingAccounts = GetInt32(reader, "FamilyBillingAccounts"),
                    OpenFamilyInvoices = GetInt32(reader, "OpenFamilyInvoices"),
                    PaymentsLast30Days = GetInt32(reader, "PaymentsLast30Days"),
                    ProviderPaymentsLast30DaysAmount = GetDecimal(reader, "ProviderPaymentsLast30DaysAmount"),
                    FamilyPaymentsLast30DaysAmount = GetDecimal(reader, "FamilyPaymentsLast30DaysAmount")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    subscriptions.Add(new AdminProviderSubscriptionItemDto
                    {
                        ProviderSubscriptionId = GetInt32(reader, "ProviderSubscriptionID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        PlanName = GetString(reader, "PlanName"),
                        SubscriptionStatusCode = GetString(reader, "SubscriptionStatusCode"),
                        SubscriptionStatusName = GetString(reader, "SubscriptionStatusName"),
                        SubscriptionStartUtc = GetDateTime(reader, "SubscriptionStartUTC"),
                        SubscriptionEndUtc = GetNullableDateTime(reader, "SubscriptionEndUTC"),
                        NextBillingDateUtc = GetNullableDateTime(reader, "NextBillingDateUTC"),
                        BasePriceAmount = GetDecimal(reader, "BasePriceAmount"),
                        LatestInvoiceBalanceAmount = GetDecimal(reader, "LatestInvoiceBalanceAmount")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    invoices.Add(new AdminProviderInvoiceItemDto
                    {
                        ProviderInvoiceId = GetInt32(reader, "ProviderInvoiceID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        InvoiceNumber = GetString(reader, "InvoiceNumber"),
                        InvoiceStatusCode = GetString(reader, "InvoiceStatusCode"),
                        InvoiceStatusName = GetString(reader, "InvoiceStatusName"),
                        IssuedUtc = GetDateTime(reader, "IssuedUTC"),
                        DueUtc = GetNullableDateTime(reader, "DueUTC"),
                        TotalAmount = GetDecimal(reader, "TotalAmount"),
                        BalanceAmount = GetDecimal(reader, "BalanceAmount")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin billing overview failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return new AdminBillingOverviewDto
        {
            Counts = counts,
            ProviderSubscriptions = subscriptions,
            RecentProviderInvoices = invoices
        };
    }
}
