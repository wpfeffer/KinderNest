using DaycareProviderAssistant.Billing.Models;

namespace DaycareProviderAssistant.Billing.Services;

public interface IProviderBillingService
{
    Task<ProviderBillingDashboardDto> GetDashboardAsync(int portalUserId, CancellationToken cancellationToken = default);
}
