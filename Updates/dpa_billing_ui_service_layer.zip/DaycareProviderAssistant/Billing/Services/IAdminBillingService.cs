using DaycareProviderAssistant.Billing.Models;

namespace DaycareProviderAssistant.Billing.Services;

public interface IAdminBillingService
{
    Task<AdminBillingOverviewDto> GetOverviewAsync(CancellationToken cancellationToken = default);
}
