namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderInvoiceListItemDto
{
    public int ProviderInvoiceId { get; init; }
    public string InvoiceNumber { get; init; } = string.Empty;
    public string InvoiceStatusCode { get; init; } = string.Empty;
    public string InvoiceStatusName { get; init; } = string.Empty;
    public DateTime IssuedUtc { get; init; }
    public DateTime? DueUtc { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal BalanceAmount { get; init; }
}
