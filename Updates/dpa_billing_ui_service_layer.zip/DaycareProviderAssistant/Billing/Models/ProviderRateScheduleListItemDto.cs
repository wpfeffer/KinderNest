namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderRateScheduleListItemDto
{
    public int ProviderRateScheduleId { get; init; }
    public int? SiteId { get; init; }
    public string? SiteName { get; init; }
    public string RateName { get; init; } = string.Empty;
    public string RateTypeCode { get; init; } = string.Empty;
    public string? BillingFrequencyCode { get; init; }
    public decimal StandardAmount { get; init; }
    public decimal StandardQuantityDecimal { get; init; }
    public bool AppliesPerChild { get; init; }
    public bool TaxableFlag { get; init; }
    public DateOnly EffectiveStartDate { get; init; }
    public DateOnly? EffectiveEndDate { get; init; }
    public bool IsActive { get; init; }
}
