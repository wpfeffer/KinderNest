namespace DaycareProviderAssistant.Billing.Models;

public sealed class GuardianPaymentItemDto
{
    public int PaymentId { get; init; }
    public int FamilyBillingAccountId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string PaymentStatusCode { get; init; } = string.Empty;
    public string PaymentStatusName { get; init; } = string.Empty;
    public DateTime PaymentUtc { get; init; }
    public decimal Amount { get; init; }
    public string CurrencyCode { get; init; } = string.Empty;
    public string? ExternalTransactionReference { get; init; }
}
