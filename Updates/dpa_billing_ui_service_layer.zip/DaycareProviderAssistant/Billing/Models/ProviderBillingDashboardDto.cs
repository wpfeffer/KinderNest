namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingDashboardDto
{
    public ProviderBillingSummaryDto Summary { get; init; } = new();
    public IReadOnlyList<ProviderPlanOptionDto> Plans { get; init; } = Array.Empty<ProviderPlanOptionDto>();
    public IReadOnlyList<ProviderInvoiceListItemDto> Invoices { get; init; } = Array.Empty<ProviderInvoiceListItemDto>();
    public IReadOnlyList<ProviderRateScheduleListItemDto> RateSchedules { get; init; } = Array.Empty<ProviderRateScheduleListItemDto>();
    public IReadOnlyList<ProviderFamilyBillingAccountItemDto> FamilyAccounts { get; init; } = Array.Empty<ProviderFamilyBillingAccountItemDto>();
}
