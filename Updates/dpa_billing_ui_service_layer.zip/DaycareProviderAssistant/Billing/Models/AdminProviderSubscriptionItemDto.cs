namespace DaycareProviderAssistant.Billing.Models;

public sealed class AdminProviderSubscriptionItemDto
{
    public int ProviderSubscriptionId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string PlanName { get; init; } = string.Empty;
    public string SubscriptionStatusCode { get; init; } = string.Empty;
    public string SubscriptionStatusName { get; init; } = string.Empty;
    public DateTime SubscriptionStartUtc { get; init; }
    public DateTime? SubscriptionEndUtc { get; init; }
    public DateTime? NextBillingDateUtc { get; init; }
    public decimal BasePriceAmount { get; init; }
    public decimal LatestInvoiceBalanceAmount { get; init; }
}
