namespace DaycareProviderAssistant.Billing.Models;

public sealed class AdminBillingCountsDto
{
    public int ActiveProviderSubscriptions { get; init; }
    public int ProvidersPastDue { get; init; }
    public int OpenProviderInvoices { get; init; }
    public int FamilyBillingAccounts { get; init; }
    public int OpenFamilyInvoices { get; init; }
    public int PaymentsLast30Days { get; init; }
    public decimal ProviderPaymentsLast30DaysAmount { get; init; }
    public decimal FamilyPaymentsLast30DaysAmount { get; init; }
}
