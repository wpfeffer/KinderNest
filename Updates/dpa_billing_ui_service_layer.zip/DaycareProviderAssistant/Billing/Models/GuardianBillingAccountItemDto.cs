namespace DaycareProviderAssistant.Billing.Models;

public sealed class GuardianBillingAccountItemDto
{
    public int FamilyBillingAccountId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public int HouseholdId { get; init; }
    public string HouseholdDisplayName { get; init; } = string.Empty;
    public int? SiteId { get; init; }
    public string? SiteName { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public string AccountStatusName { get; init; } = string.Empty;
    public string BillingFrequencyCode { get; init; } = string.Empty;
    public string BillingFrequencyName { get; init; } = string.Empty;
    public byte? BillingDayOfMonth { get; init; }
    public string? BillingEmail { get; init; }
    public decimal CurrentBalanceAmount { get; init; }
}
