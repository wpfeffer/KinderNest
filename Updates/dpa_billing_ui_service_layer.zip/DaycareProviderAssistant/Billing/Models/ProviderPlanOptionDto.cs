namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderPlanOptionDto
{
    public int ProviderPlanId { get; init; }
    public string PlanCode { get; init; } = string.Empty;
    public string PlanName { get; init; } = string.Empty;
    public string PlanTypeCode { get; init; } = string.Empty;
    public string BillingFrequencyCode { get; init; } = string.Empty;
    public decimal BasePriceAmount { get; init; }
    public int? IncludedChildrenCount { get; init; }
    public long? IncludedImageStorageBytes { get; init; }
    public int? IncludedUsersCount { get; init; }
    public decimal? OverageImageStoragePricePerGb { get; init; }
    public decimal? OverageChildPriceAmount { get; init; }
    public bool IsPublic { get; init; }
    public bool IsActive { get; init; }
}
