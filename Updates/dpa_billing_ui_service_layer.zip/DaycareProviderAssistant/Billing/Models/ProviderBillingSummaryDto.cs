namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingSummaryDto
{
    public int ProviderSubscriptionId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public int ProviderPlanId { get; init; }
    public string PlanCode { get; init; } = string.Empty;
    public string PlanName { get; init; } = string.Empty;
    public string SubscriptionStatusCode { get; init; } = string.Empty;
    public string SubscriptionStatusName { get; init; } = string.Empty;
    public string BillingFrequencyCode { get; init; } = string.Empty;
    public string BillingFrequencyName { get; init; } = string.Empty;
    public DateTime SubscriptionStartUtc { get; init; }
    public DateTime? SubscriptionEndUtc { get; init; }
    public DateTime? NextBillingDateUtc { get; init; }
    public bool AutoRenewEnabled { get; init; }
    public decimal BasePriceAmount { get; init; }
    public int? IncludedChildrenCount { get; init; }
    public long? IncludedImageStorageBytes { get; init; }
    public int? IncludedUsersCount { get; init; }
    public decimal? OverageImageStoragePricePerGb { get; init; }
    public decimal? OverageChildPriceAmount { get; init; }
    public long CurrentImageStorageBytes { get; init; }
    public int ActiveFamilyBillingAccounts { get; init; }
    public int OpenFamilyInvoices { get; init; }
    public int RateScheduleCount { get; init; }
}
