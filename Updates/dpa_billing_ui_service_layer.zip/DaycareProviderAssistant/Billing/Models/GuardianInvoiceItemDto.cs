namespace DaycareProviderAssistant.Billing.Models;

public sealed class GuardianInvoiceItemDto
{
    public int FamilyInvoiceId { get; init; }
    public int FamilyBillingAccountId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string HouseholdDisplayName { get; init; } = string.Empty;
    public string InvoiceNumber { get; init; } = string.Empty;
    public string InvoiceStatusCode { get; init; } = string.Empty;
    public string InvoiceStatusName { get; init; } = string.Empty;
    public DateTime IssuedUtc { get; init; }
    public DateTime? DueUtc { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal BalanceAmount { get; init; }
}
