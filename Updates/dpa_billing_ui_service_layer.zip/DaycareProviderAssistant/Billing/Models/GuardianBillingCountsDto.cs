namespace DaycareProviderAssistant.Billing.Models;

public sealed class GuardianBillingCountsDto
{
    public int HouseholdCount { get; init; }
    public int ActiveFamilyBillingAccounts { get; init; }
    public int OpenInvoices { get; init; }
    public decimal OutstandingBalanceAmount { get; init; }
}
