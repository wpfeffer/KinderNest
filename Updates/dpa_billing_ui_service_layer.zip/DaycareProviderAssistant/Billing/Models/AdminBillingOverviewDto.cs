namespace DaycareProviderAssistant.Billing.Models;

public sealed class AdminBillingOverviewDto
{
    public AdminBillingCountsDto Counts { get; init; } = new();
    public IReadOnlyList<AdminProviderSubscriptionItemDto> ProviderSubscriptions { get; init; } = Array.Empty<AdminProviderSubscriptionItemDto>();
    public IReadOnlyList<AdminProviderInvoiceItemDto> RecentProviderInvoices { get; init; } = Array.Empty<AdminProviderInvoiceItemDto>();
}
