namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderFamilyBillingAccountItemDto
{
    public int FamilyBillingAccountId { get; init; }
    public int HouseholdId { get; init; }
    public string HouseholdDisplayName { get; init; } = string.Empty;
    public int? SiteId { get; init; }
    public string? SiteName { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public string BillingFrequencyCode { get; init; } = string.Empty;
    public string? BillingContactDisplayName { get; init; }
    public string? BillingEmail { get; init; }
    public decimal CurrentBalanceAmount { get; init; }
    public int OpenInvoiceCount { get; init; }
}
