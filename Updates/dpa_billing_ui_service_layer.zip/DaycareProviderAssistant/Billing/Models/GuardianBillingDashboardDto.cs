namespace DaycareProviderAssistant.Billing.Models;

public sealed class GuardianBillingDashboardDto
{
    public GuardianBillingCountsDto Counts { get; init; } = new();
    public IReadOnlyList<GuardianBillingAccountItemDto> Accounts { get; init; } = Array.Empty<GuardianBillingAccountItemDto>();
    public IReadOnlyList<GuardianInvoiceItemDto> Invoices { get; init; } = Array.Empty<GuardianInvoiceItemDto>();
    public IReadOnlyList<GuardianPaymentItemDto> Payments { get; init; } = Array.Empty<GuardianPaymentItemDto>();
}
