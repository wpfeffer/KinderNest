CREATE OR ALTER PROCEDURE billing.usp_AdminBillingDashboard_GetSummary
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PaidInvoiceStatusCodeValueID INT;
    DECLARE @VoidInvoiceStatusCodeValueID INT;
    DECLARE @WriteoffInvoiceStatusCodeValueID INT;
    DECLARE @PastDueSubscriptionStatusCodeValueID INT;
    DECLARE @SettledPaymentStatusCodeValueID INT;
    DECLARE @ProviderPlatformScopeCodeValueID INT;
    DECLARE @FamilyProviderScopeCodeValueID INT;

    SELECT @PaidInvoiceStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceStatus'
      AND cv.CodeValue = N'PAID';

    SELECT @VoidInvoiceStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceStatus'
      AND cv.CodeValue = N'VOID';

    SELECT @WriteoffInvoiceStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceStatus'
      AND cv.CodeValue = N'WRITEOFF';

    SELECT @PastDueSubscriptionStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'BillingSubscriptionStatus'
      AND cv.CodeValue = N'PAST_DUE';

    SELECT @SettledPaymentStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PaymentStatus'
      AND cv.CodeValue = N'SETTLED';

    SELECT @ProviderPlatformScopeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PaymentScope'
      AND cv.CodeValue = N'PROVIDER_PLATFORM';

    SELECT @FamilyProviderScopeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PaymentScope'
      AND cv.CodeValue = N'FAMILY_PROVIDER';

    SELECT
        ActiveProviderSubscriptions =
        (
            SELECT COUNT(1)
            FROM billing.ProviderSubscription ps
            WHERE ps.IsDeleted = 0
              AND ps.IsActive = 1
        ),
        ProvidersPastDue =
        (
            SELECT COUNT(1)
            FROM billing.ProviderSubscription ps
            WHERE ps.IsDeleted = 0
              AND ps.IsActive = 1
              AND ps.SubscriptionStatusCodeValueID = @PastDueSubscriptionStatusCodeValueID
        ),
        OpenProviderInvoices =
        (
            SELECT COUNT(1)
            FROM billing.ProviderInvoice pi
            WHERE pi.IsDeleted = 0
              AND pi.IsActive = 1
              AND pi.InvoiceStatusCodeValueID NOT IN (@PaidInvoiceStatusCodeValueID, @VoidInvoiceStatusCodeValueID, @WriteoffInvoiceStatusCodeValueID)
              AND pi.BalanceAmount > 0
        ),
        FamilyBillingAccounts =
        (
            SELECT COUNT(1)
            FROM billing.FamilyBillingAccount fba
            WHERE fba.IsDeleted = 0
              AND fba.IsActive = 1
        ),
        OpenFamilyInvoices =
        (
            SELECT COUNT(1)
            FROM billing.FamilyInvoice fi
            WHERE fi.IsDeleted = 0
              AND fi.IsActive = 1
              AND fi.InvoiceStatusCodeValueID NOT IN (@PaidInvoiceStatusCodeValueID, @VoidInvoiceStatusCodeValueID, @WriteoffInvoiceStatusCodeValueID)
              AND fi.BalanceAmount > 0
        ),
        PaymentsLast30Days =
        (
            SELECT COUNT(1)
            FROM billing.Payment p
            WHERE p.IsDeleted = 0
              AND p.IsActive = 1
              AND p.PaymentStatusCodeValueID = @SettledPaymentStatusCodeValueID
              AND p.PaymentUTC >= DATEADD(DAY, -30, SYSUTCDATETIME())
        ),
        ProviderPaymentsLast30DaysAmount =
        (
            SELECT ISNULL(SUM(p.Amount), 0.00)
            FROM billing.Payment p
            WHERE p.IsDeleted = 0
              AND p.IsActive = 1
              AND p.PaymentStatusCodeValueID = @SettledPaymentStatusCodeValueID
              AND p.PaymentScopeCodeValueID = @ProviderPlatformScopeCodeValueID
              AND p.PaymentUTC >= DATEADD(DAY, -30, SYSUTCDATETIME())
        ),
        FamilyPaymentsLast30DaysAmount =
        (
            SELECT ISNULL(SUM(p.Amount), 0.00)
            FROM billing.Payment p
            WHERE p.IsDeleted = 0
              AND p.IsActive = 1
              AND p.PaymentStatusCodeValueID = @SettledPaymentStatusCodeValueID
              AND p.PaymentScopeCodeValueID = @FamilyProviderScopeCodeValueID
              AND p.PaymentUTC >= DATEADD(DAY, -30, SYSUTCDATETIME())
        );

    SELECT TOP (25)
        ps.ProviderSubscriptionID,
        ps.ProviderID,
        pr.ProviderName,
        pp.PlanName,
        SubscriptionStatusCode = ss.CodeValue,
        SubscriptionStatusName = ss.CodeName,
        ps.SubscriptionStartUTC,
        ps.SubscriptionEndUTC,
        ps.NextBillingDateUTC,
        pp.BasePriceAmount,
        LatestInvoiceBalanceAmount =
            ISNULL(
                (
                    SELECT TOP (1) pi.BalanceAmount
                    FROM billing.ProviderInvoice pi
                    WHERE pi.ProviderID = ps.ProviderID
                      AND pi.IsDeleted = 0
                    ORDER BY pi.IssuedUTC DESC, pi.ProviderInvoiceID DESC
                ),
                0.00
            )
    FROM billing.ProviderSubscription ps
    INNER JOIN party.Provider pr
        ON pr.ProviderID = ps.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN billing.ProviderPlan pp
        ON pp.ProviderPlanID = ps.ProviderPlanID
       AND pp.IsDeleted = 0
    INNER JOIN ref.CodeValue ss
        ON ss.CodeValueID = ps.SubscriptionStatusCodeValueID
    WHERE ps.IsDeleted = 0
      AND ps.IsActive = 1
    ORDER BY pr.ProviderName, ps.ProviderSubscriptionID DESC;

    SELECT TOP (25)
        pi.ProviderInvoiceID,
        pi.ProviderID,
        pr.ProviderName,
        pi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue,
        InvoiceStatusName = ist.CodeName,
        pi.IssuedUTC,
        pi.DueUTC,
        pi.TotalAmount,
        pi.BalanceAmount
    FROM billing.ProviderInvoice pi
    INNER JOIN party.Provider pr
        ON pr.ProviderID = pi.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN ref.CodeValue ist
        ON ist.CodeValueID = pi.InvoiceStatusCodeValueID
    WHERE pi.IsDeleted = 0
      AND pi.IsActive = 1
    ORDER BY pi.IssuedUTC DESC, pi.ProviderInvoiceID DESC;
END;
GO
