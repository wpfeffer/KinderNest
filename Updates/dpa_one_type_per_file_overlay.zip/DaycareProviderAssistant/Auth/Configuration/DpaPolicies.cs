namespace DaycareProviderAssistant.Auth.Configuration;

public static class DpaPolicies
{
    public const string AdminPortal = "Dpa.AdminPortal";
    public const string ProviderPortal = "Dpa.ProviderPortal";
    public const string GuardianPortal = "Dpa.GuardianPortal";
}
