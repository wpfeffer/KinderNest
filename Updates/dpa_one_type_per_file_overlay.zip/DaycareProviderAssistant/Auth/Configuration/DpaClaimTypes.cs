namespace DaycareProviderAssistant.Auth.Configuration;

public static class DpaClaimTypes
{
    public const string PortalUserId = "dpa_portal_user_id";
    public const string PersonId = "dpa_person_id";
    public const string SessionId = "dpa_session_id";
    public const string PortalAccess = "dpa_portal_access";
    public const string DisplayName = "dpa_display_name";
}
