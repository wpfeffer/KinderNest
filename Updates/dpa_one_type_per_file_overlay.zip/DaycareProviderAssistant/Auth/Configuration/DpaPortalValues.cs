namespace DaycareProviderAssistant.Auth.Configuration;

public static class DpaPortalValues
{
    public const string Admin = "Admin";
    public const string Provider = "Provider";
    public const string Guardian = "Guardian";
}
