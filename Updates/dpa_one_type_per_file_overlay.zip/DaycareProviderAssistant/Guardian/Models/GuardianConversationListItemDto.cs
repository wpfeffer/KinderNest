namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianConversationListItemDto
{
    public int ConversationId { get; init; }
    public string Subject { get; init; } = string.Empty;
    public string CounterpartyDisplay { get; init; } = string.Empty;
    public string LatestSnippet { get; init; } = string.Empty;
    public DateTime? LatestMessageUtc { get; init; }
    public string StatusText { get; init; } = string.Empty;
    public string StatusCssClass { get; init; } = string.Empty;
    public string? SiteName { get; init; }
    public string? ChildName { get; init; }
}
