namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianChildListItemDto
{
    public int ChildId { get; init; }
    public string ChildDisplayName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
    public string RelationshipTypeCode { get; init; } = string.Empty;
    public bool IsPrimaryGuardian { get; init; }
    public string PickupStatusText { get; init; } = string.Empty;
    public string PickupStatusCssClass { get; init; } = string.Empty;
    public string DocumentStatusText { get; init; } = string.Empty;
    public string DocumentStatusCssClass { get; init; } = string.Empty;
    public string AgeGroup { get; init; } = string.Empty;
}
