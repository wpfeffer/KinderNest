namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianAlertDto
{
    public string Title { get; init; } = string.Empty;
    public string Detail { get; init; } = string.Empty;
    public string StatusText { get; init; } = string.Empty;
    public string StatusCssClass { get; init; } = string.Empty;
}
