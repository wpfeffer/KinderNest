namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianRelationshipDetailDto
{
    public int ChildId { get; init; }
    public string ChildDisplayName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
    public string RelationshipTypeCode { get; init; } = string.Empty;
    public bool HasPortalAccess { get; init; }
    public bool CanReceiveAlerts { get; init; }
    public bool CanSignPermissions { get; init; }
    public bool IsPrimaryGuardian { get; init; }
    public DateOnly EffectiveStartDate { get; init; }
    public DateOnly? EffectiveEndDate { get; init; }
}
