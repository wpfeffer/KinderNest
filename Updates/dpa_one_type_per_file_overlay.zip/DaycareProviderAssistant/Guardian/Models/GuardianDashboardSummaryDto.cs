namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianDashboardSummaryDto
{
    public int LinkedChildren { get; init; }
    public int PendingConsents { get; init; }
    public int UnreadMessages { get; init; }
    public int PickupAuthorizations { get; init; }
    public IReadOnlyList<GuardianAlertDto> Alerts { get; init; } = Array.Empty<GuardianAlertDto>();
}
