namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianConsentListItemDto
{
    public string DocumentName { get; init; } = string.Empty;
    public string ChildDisplayName { get; init; } = string.Empty;
    public string StatusText { get; init; } = string.Empty;
    public string StatusCssClass { get; init; } = string.Empty;
    public DateTime UpdatedUtc { get; init; }
    public DateOnly EffectiveDate { get; init; }
    public DateOnly? ExpirationDate { get; init; }
}
