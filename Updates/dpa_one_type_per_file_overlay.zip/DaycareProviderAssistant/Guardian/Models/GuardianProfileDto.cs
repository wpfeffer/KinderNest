namespace DaycareProviderAssistant.Guardian.Models;

public sealed class GuardianProfileDto
{
    public int PortalUserId { get; init; }
    public int PersonId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string? PrimaryEmail { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public int LinkedChildCount { get; init; }
    public int PickupAuthorizationCount { get; init; }
    public int PendingEmailChangeCount { get; init; }
    public IReadOnlyList<GuardianRelationshipDetailDto> Relationships { get; init; } = Array.Empty<GuardianRelationshipDetailDto>();
}
