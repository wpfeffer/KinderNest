namespace DaycareProviderAssistant.Auditing;

public sealed record AuditWriteResult(
    long AuditEventId,
    Guid AuditEventGuid,
    byte[] EventHash
);
