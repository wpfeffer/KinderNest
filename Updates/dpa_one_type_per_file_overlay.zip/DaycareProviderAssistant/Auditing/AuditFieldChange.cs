namespace DaycareProviderAssistant.Auditing;

public sealed record AuditFieldChange(
    string EntityName,
    string FieldName,
    string ChangeTypeCode,
    string? OldValueRedacted = null,
    string? NewValueRedacted = null,
    byte[]? OldValueHash = null,
    byte[]? NewValueHash = null,
    bool IsSensitive = false,
    string EncryptionDispositionCode = "None"
);
