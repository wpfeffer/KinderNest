namespace DaycareProviderAssistant.Auditing;

public sealed record AuditRequestContext(
    string? ActorUserId,
    string? ActorRoleCode,
    string? EffectiveRoleCode,
    string? ImpersonatedUserId,
    string? SessionId,
    Guid? CorrelationId,
    string? RequestId,
    string? ClientIpAddress,
    string? UserAgent,
    string AccessPathCode,
    string? Path,
    string? HttpMethod
);
