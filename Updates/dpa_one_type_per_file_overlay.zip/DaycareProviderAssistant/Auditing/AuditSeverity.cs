namespace DaycareProviderAssistant.Auditing;

public static class AuditSeverity
{
    public const string Trace = "Trace";
    public const string Info = "Info";
    public const string Warning = "Warning";
    public const string Error = "Error";
    public const string Critical = "Critical";
}
