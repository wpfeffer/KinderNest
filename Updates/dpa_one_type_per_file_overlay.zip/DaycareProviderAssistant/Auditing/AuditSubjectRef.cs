namespace DaycareProviderAssistant.Auditing;

public sealed record AuditSubjectRef(
    string SubjectTypeCode,
    string SubjectId,
    string? RelationshipCode = null,
    bool IsSensitive = false
);
