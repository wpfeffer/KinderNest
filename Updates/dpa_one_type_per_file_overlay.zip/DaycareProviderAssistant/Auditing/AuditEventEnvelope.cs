using System.Text.Json;

namespace DaycareProviderAssistant.Auditing;

public sealed record AuditEventEnvelope
{
    public required DateTimeOffset OccurredUtc { get; init; }
    public string CategoryCode { get; init; } = AuditCategories.System;
    public required string EventTypeCode { get; init; }
    public string OutcomeCode { get; init; } = AuditOutcomes.Success;
    public string SeverityCode { get; init; } = AuditSeverity.Info;

    public string? ActorUserId { get; init; }
    public string? ActorRoleCode { get; init; }
    public string? EffectiveRoleCode { get; init; }
    public string? ImpersonatedUserId { get; init; }

    public string? SessionId { get; init; }
    public Guid? CorrelationId { get; init; }
    public string? RequestId { get; init; }
    public string AccessPathCode { get; init; } = AuditAccessPaths.Ui;
    public string? ClientIpAddress { get; init; }
    public string? UserAgent { get; init; }

    public string? ReasonCode { get; init; }
    public string? ReasonText { get; init; }

    public bool WasEncryptedFieldMaterialized { get; init; }
    public bool WasExport { get; init; }
    public long? BreakGlassSessionId { get; init; }

    public JsonDocument? PayloadJson { get; init; }

    public IReadOnlyCollection<AuditSubjectRef> Subjects { get; init; } = Array.Empty<AuditSubjectRef>();
    public IReadOnlyCollection<AuditFieldChange> Changes { get; init; } = Array.Empty<AuditFieldChange>();
}
