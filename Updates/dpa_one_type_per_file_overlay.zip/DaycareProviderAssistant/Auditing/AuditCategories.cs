namespace DaycareProviderAssistant.Auditing;

public static class AuditCategories
{
    public const string Security = "Security";
    public const string DataAccess = "DataAccess";
    public const string DomainChange = "DomainChange";
    public const string BreakGlass = "BreakGlass";
    public const string Export = "Export";
    public const string System = "System";
}
