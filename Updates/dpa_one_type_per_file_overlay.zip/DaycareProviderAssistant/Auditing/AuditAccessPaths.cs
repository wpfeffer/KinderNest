namespace DaycareProviderAssistant.Auditing;

public static class AuditAccessPaths
{
    public const string Ui = "UI";
    public const string Api = "API";
    public const string BackgroundJob = "BackgroundJob";
    public const string DirectDb = "DirectDB";
    public const string SupportImpersonation = "SupportImpersonation";
    public const string BreakGlass = "BreakGlass";
}
