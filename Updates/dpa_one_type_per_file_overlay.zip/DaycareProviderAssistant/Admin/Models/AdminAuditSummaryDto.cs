namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminAuditSummaryDto
{
    public IReadOnlyList<AdminAuditTrailItemDto> Items { get; init; } = Array.Empty<AdminAuditTrailItemDto>();
}
