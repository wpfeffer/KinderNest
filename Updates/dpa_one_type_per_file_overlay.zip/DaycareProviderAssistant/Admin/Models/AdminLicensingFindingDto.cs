namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminLicensingFindingDto
{
    public string SiteName { get; init; } = string.Empty;
    public string RequirementTitle { get; init; } = string.Empty;
    public string StatusText { get; init; } = string.Empty;
    public string StatusCssClass { get; init; } = string.Empty;
    public DateOnly? DueDate { get; init; }
}
