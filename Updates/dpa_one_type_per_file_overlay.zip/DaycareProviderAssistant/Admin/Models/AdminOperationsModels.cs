namespace DaycareProviderAssistant.Admin.Models;

// Types from this former aggregate file have been split into individual files.
// This shim remains only to make the refactor easy to merge without requiring a file delete.
