namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminLicensingSummaryDto
{
    public int OpenFindings { get; init; }
    public int EvidenceAwaitingReview { get; init; }
    public int ActiveVariances { get; init; }
    public IReadOnlyList<AdminLicensingFindingDto> Findings { get; init; } = Array.Empty<AdminLicensingFindingDto>();
}
