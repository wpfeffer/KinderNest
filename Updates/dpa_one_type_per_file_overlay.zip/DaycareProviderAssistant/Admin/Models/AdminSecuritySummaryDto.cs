namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminSecuritySummaryDto
{
    public int FailedLoginsToday { get; init; }
    public int LockedAccounts { get; init; }
    public int OpenBreakGlassEvents { get; init; }
    public int ActiveSessions { get; init; }
    public IReadOnlyList<AdminSecurityEventDto> Events { get; init; } = Array.Empty<AdminSecurityEventDto>();
}
