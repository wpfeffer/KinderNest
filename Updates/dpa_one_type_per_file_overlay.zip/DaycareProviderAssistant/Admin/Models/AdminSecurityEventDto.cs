namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminSecurityEventDto
{
    public DateTime EventUtc { get; init; }
    public string Title { get; init; } = string.Empty;
    public string Detail { get; init; } = string.Empty;
    public string StatusText { get; init; } = string.Empty;
    public string StatusCssClass { get; init; } = string.Empty;
}
