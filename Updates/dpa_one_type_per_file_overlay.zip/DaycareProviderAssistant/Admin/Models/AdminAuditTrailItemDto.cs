namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminAuditTrailItemDto
{
    public long AuditLogId { get; init; }
    public DateTime EventUtc { get; init; }
    public string ActionTitle { get; init; } = string.Empty;
    public string ActorDisplay { get; init; } = string.Empty;
    public string EntityDisplay { get; init; } = string.Empty;
    public string ScopeDisplay { get; init; } = string.Empty;
    public string? ReasonText { get; init; }
    public bool SucceededFlag { get; init; }
}
