This overlay splits the current multi-type root files I found in the DaycareProviderAssistant project into one top-level type per file.

Files split in this pass:
- DaycareProviderAssistant/Auditing/AuditContracts.cs
- DaycareProviderAssistant/Auditing/AuditContextAccessor.cs
- DaycareProviderAssistant/Auth/Configuration/DpaClaimTypes.cs
- DaycareProviderAssistant/Guardian/Models/GuardianPortalModels.cs
- DaycareProviderAssistant/Admin/Models/AdminOperationsModels.cs

For the two aggregate model files and AuditContracts.cs, the original file is turned into a small shim with no type definitions so you do not need to delete files manually during merge.
