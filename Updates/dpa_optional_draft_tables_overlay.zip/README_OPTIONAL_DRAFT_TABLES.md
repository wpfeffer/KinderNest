# Bullet 2 Overlay: Optional Draft Tables

This overlay contains the database objects for **bullet 2** only:
optional draft tables for provider family intake.

## Files included
- `dpa/ops/Tables/ProviderFamilyIntakeDraft.sql`
- `dpa/ops/Tables/ProviderFamilyIntakeDraftPerson.sql`
- `patches/dpa.sqlproj.patch`
- `patches/master_install.sql.patch`
- `patches/SeedData.sql.patch`

## Intent
These tables are for **save draft / resume later** workflow only.
They are **not** the committed system of record.

Committed data should still land in the normalized tables:
- `party.Person`
- `child.Child`
- `child.ChildEnrollment`
- `child.ChildPersonRelationship`
- `child.PickupDropoffAuthorization`
- household grouping tables from bullet 1

## CodeValue usage
All draft code columns are modeled as `INT` foreign keys to `ref.CodeValue`:
- `DraftStatusCodeValueID`
- `DraftPersonRoleCodeValueID`

## Suggested CodeValue domains
### ProviderFamilyIntakeDraftStatus
- `DRAFT`
- `READY_FOR_REVIEW`
- `SUBMITTED`
- `APPLIED`
- `ABANDONED`
- `VOID`

### ProviderFamilyDraftPersonRole
- `PRIMARY_GUARDIAN`
- `SECONDARY_GUARDIAN`
- `PICKUP_CONTACT`
- `EMERGENCY_CONTACT`
- `BILLING_CONTACT`

## Integration notes
1. Add both new table files to `dpa.sqlproj`
2. Add both `:r` includes to `dpa/Install/master_install.sql`
3. Add the seed-code rows shown in `patches/SeedData.sql.patch`
4. Rebuild/recreate the database after applying the changes

## Notes on shape
- `ops.ProviderFamilyIntakeDraft` stores household-level, child-level, and enrollment draft fields
- `ops.ProviderFamilyIntakeDraftPerson` stores guardian/contact rows attached to the draft
- raw address and phone values stay in draft storage as text until the draft is applied to committed tables

This overlay does **not** include views or onboarding stored procedures yet.
