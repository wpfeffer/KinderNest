CREATE TABLE ops.ProviderFamilyIntakeDraftPerson
(
    ProviderFamilyIntakeDraftPersonID INT IDENTITY(1,1)       NOT NULL,
    ProviderFamilyIntakeDraftID       INT                     NOT NULL,
    DraftPersonRoleCodeValueID        INT                     NOT NULL,
    DisplaySequence                   INT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_DisplaySequence DEFAULT (1),
    FirstName                         NVARCHAR(100)           NULL,
    MiddleName                        NVARCHAR(100)           NULL,
    LastName                          NVARCHAR(100)           NULL,
    PrimaryEmail                      NVARCHAR(320)           NULL,
    PrimaryPhoneRaw                   NVARCHAR(50)            NULL,
    AddressLine1                      NVARCHAR(200)           NULL,
    AddressLine2                      NVARCHAR(200)           NULL,
    AddressCity                       NVARCHAR(100)           NULL,
    AddressRegion                     NVARCHAR(100)           NULL,
    AddressPostalCode                 NVARCHAR(30)            NULL,
    AddressCountryCode                NVARCHAR(10)            NULL,
    HasPortalAccess                   BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_HasPortalAccess DEFAULT (0),
    CanReceiveAlerts                  BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_CanReceiveAlerts DEFAULT (0),
    CanSignPermissions                BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_CanSignPermissions DEFAULT (0),
    IsPrimaryGuardian                 BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_IsPrimaryGuardian DEFAULT (0),
    CanPickup                         BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_CanPickup DEFAULT (0),
    CanDropoff                        BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_CanDropoff DEFAULT (0),
    IsEmergencyContact                BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_IsEmergencyContact DEFAULT (0),
    Notes                             NVARCHAR(MAX)           NULL,
    IsActive                          BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_IsActive DEFAULT (1),
    IsDeleted                         BIT                     NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_IsDeleted DEFAULT (0),
    CreatedUTC                        DATETIME2(0)            NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraftPerson_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                   INT                     NULL,
    ModifiedUTC                       DATETIME2(0)            NULL,
    ModifiedByUserID                  INT                     NULL,
    DeletedUTC                        DATETIME2(0)            NULL,
    DeletedByUserID                   INT                     NULL,
    DeletedReason                     NVARCHAR(500)           NULL,
    CONSTRAINT PK_ProviderFamilyIntakeDraftPerson PRIMARY KEY CLUSTERED (ProviderFamilyIntakeDraftPersonID),
    CONSTRAINT FK_ProviderFamilyIntakeDraftPerson_Draft FOREIGN KEY (ProviderFamilyIntakeDraftID) REFERENCES ops.ProviderFamilyIntakeDraft (ProviderFamilyIntakeDraftID),
    CONSTRAINT FK_ProviderFamilyIntakeDraftPerson_DraftPersonRoleCodeValue FOREIGN KEY (DraftPersonRoleCodeValueID) REFERENCES ref.CodeValue (CodeValueID)
);
GO
CREATE INDEX IX_ProviderFamilyIntakeDraftPerson_Draft
    ON ops.ProviderFamilyIntakeDraftPerson (ProviderFamilyIntakeDraftID, DraftPersonRoleCodeValueID, IsDeleted, IsActive, DisplaySequence);
GO
