CREATE TABLE ops.ProviderFamilyIntakeDraft
(
    ProviderFamilyIntakeDraftID     INT IDENTITY(1,1)         NOT NULL,
    ProviderID                      INT                       NOT NULL,
    SiteID                          INT                       NOT NULL,
    DraftStatusCodeValueID          INT                       NOT NULL,
    HouseholdDisplayName            NVARCHAR(200)             NULL,
    ChildFirstName                  NVARCHAR(100)             NULL,
    ChildMiddleName                 NVARCHAR(100)             NULL,
    ChildLastName                   NVARCHAR(100)             NULL,
    ChildDateOfBirth                DATE                      NULL,
    EnrollmentStartDate             DATE                      NULL,
    PrimaryAddressLine1             NVARCHAR(200)             NULL,
    PrimaryAddressLine2             NVARCHAR(200)             NULL,
    PrimaryAddressCity              NVARCHAR(100)             NULL,
    PrimaryAddressRegion            NVARCHAR(100)             NULL,
    PrimaryAddressPostalCode        NVARCHAR(30)              NULL,
    PrimaryAddressCountryCode       NVARCHAR(10)              NULL,
    ScheduleSummary                 NVARCHAR(MAX)             NULL,
    FinancialArrangementNotes       NVARCHAR(MAX)             NULL,
    SpecialDietNotes                NVARCHAR(MAX)             NULL,
    SpecialNeedsNotes               NVARCHAR(MAX)             NULL,
    DraftNotes                      NVARCHAR(MAX)             NULL,
    LastViewedUTC                   DATETIME2(0)              NULL,
    SubmittedUTC                    DATETIME2(0)              NULL,
    AppliedUTC                      DATETIME2(0)              NULL,
    IsActive                        BIT                       NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraft_IsActive DEFAULT (1),
    IsDeleted                       BIT                       NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraft_IsDeleted DEFAULT (0),
    CreatedUTC                      DATETIME2(0)              NOT NULL CONSTRAINT DF_ProviderFamilyIntakeDraft_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                 INT                       NULL,
    ModifiedUTC                     DATETIME2(0)              NULL,
    ModifiedByUserID                INT                       NULL,
    DeletedUTC                      DATETIME2(0)              NULL,
    DeletedByUserID                 INT                       NULL,
    DeletedReason                   NVARCHAR(500)             NULL,
    CONSTRAINT PK_ProviderFamilyIntakeDraft PRIMARY KEY CLUSTERED (ProviderFamilyIntakeDraftID),
    CONSTRAINT FK_ProviderFamilyIntakeDraft_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_ProviderFamilyIntakeDraft_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_ProviderFamilyIntakeDraft_DraftStatusCodeValue FOREIGN KEY (DraftStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID)
);
GO
CREATE INDEX IX_ProviderFamilyIntakeDraft_Provider_Site_Status
    ON ops.ProviderFamilyIntakeDraft (ProviderID, SiteID, DraftStatusCodeValueID, IsDeleted, IsActive);
GO
CREATE INDEX IX_ProviderFamilyIntakeDraft_Site
    ON ops.ProviderFamilyIntakeDraft (SiteID, IsDeleted, IsActive);
GO
