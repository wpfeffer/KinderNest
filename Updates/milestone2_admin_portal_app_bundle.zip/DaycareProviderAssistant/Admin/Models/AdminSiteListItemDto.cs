namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminSiteListItemDto
{
    public int SiteId { get; init; }
    public int ProviderId { get; init; }
    public string SiteName { get; init; } = string.Empty;
    public string ProviderName { get; init; } = string.Empty;
    public string LicenseClassCode { get; init; } = string.Empty;
    public string LicenseClassName { get; init; } = string.Empty;
    public string TimeZoneCode { get; init; } = string.Empty;
    public string TimeZoneDisplayName { get; init; } = string.Empty;
    public string? LicenseNumber { get; init; }
    public string? PrimaryContactUserName { get; init; }
    public int ActiveUserCount { get; init; }
    public bool IsActive { get; init; }
    public DateTime CreatedUtc { get; init; }
}
