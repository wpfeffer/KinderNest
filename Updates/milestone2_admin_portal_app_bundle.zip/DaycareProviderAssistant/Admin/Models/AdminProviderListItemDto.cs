namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminProviderListItemDto
{
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string LegalEntityName { get; init; } = string.Empty;
    public string? LicenseHolderDisplayName { get; init; }
    public string? BusinessEmail { get; init; }
    public string? PrimaryContactUserName { get; init; }
    public int SiteCount { get; init; }
    public int ActiveSiteCount { get; init; }
    public bool IsActive { get; init; }
    public DateTime CreatedUtc { get; init; }
}
