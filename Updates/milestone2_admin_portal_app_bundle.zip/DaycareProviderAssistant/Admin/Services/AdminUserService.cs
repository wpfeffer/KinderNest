using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminUserService : IAdminUserService
{
    private const string ProcedureName = "party.usp_AdminPortalUser_List";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminUserService> _logger;

    public AdminUserService(
        ISqlConnectionFactory connectionFactory,
        ILogger<AdminUserService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminPortalUserListItemDto>> GetUsersAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminPortalUserListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminPortalUserListItemDto
                {
                    PortalUserId = GetInt32(reader, "PortalUserID"),
                    DisplayName = GetString(reader, "DisplayName"),
                    UserName = GetString(reader, "UserName"),
                    PrimaryEmail = GetNullableString(reader, "PrimaryEmail"),
                    AccountStatusCode = GetString(reader, "AccountStatusCode"),
                    MfaEnabled = GetBoolean(reader, "MFAEnabled"),
                    IsLocked = GetBoolean(reader, "IsLocked"),
                    LockoutEndUtc = GetNullableDateTime(reader, "LockoutEndUTC"),
                    LastLoginUtc = GetNullableDateTime(reader, "LastLoginUTC"),
                    RoleCodes = GetNullableString(reader, "RoleCodes") ?? string.Empty,
                    SiteCount = GetInt32(reader, "SiteCount"),
                    IsActive = GetBoolean(reader, "IsActive")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin user list failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return results;
    }

    private static int GetInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
    }

    private static string GetString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static bool GetBoolean(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return !reader.IsDBNull(ordinal) && reader.GetBoolean(ordinal);
    }

    private static DateTime? GetNullableDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);
    }
}
