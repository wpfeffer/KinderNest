using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminProviderService : IAdminProviderService
{
    private const string ProcedureName = "party.usp_AdminProvider_List";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminProviderService> _logger;

    public AdminProviderService(
        ISqlConnectionFactory connectionFactory,
        ILogger<AdminProviderService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminProviderListItemDto>> GetProvidersAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminProviderListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminProviderListItemDto
                {
                    ProviderId = GetInt32(reader, "ProviderID"),
                    ProviderName = GetString(reader, "ProviderName"),
                    LegalEntityName = GetString(reader, "LegalEntityName"),
                    LicenseHolderDisplayName = GetNullableString(reader, "LicenseHolderDisplayName"),
                    BusinessEmail = GetNullableString(reader, "BusinessEmail"),
                    PrimaryContactUserName = GetNullableString(reader, "PrimaryContactUserName"),
                    SiteCount = GetInt32(reader, "SiteCount"),
                    ActiveSiteCount = GetInt32(reader, "ActiveSiteCount"),
                    IsActive = GetBoolean(reader, "IsActive"),
                    CreatedUtc = GetDateTime(reader, "CreatedUTC")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin provider list failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return results;
    }

    private static int GetInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
    }

    private static string GetString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static bool GetBoolean(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return !reader.IsDBNull(ordinal) && reader.GetBoolean(ordinal);
    }

    private static DateTime GetDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? DateTime.MinValue : reader.GetDateTime(ordinal);
    }
}
