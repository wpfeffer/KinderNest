using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminSiteService
{
    Task<IReadOnlyList<AdminSiteListItemDto>> GetSitesAsync(CancellationToken cancellationToken = default);
}
