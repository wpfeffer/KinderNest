using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminSiteService : IAdminSiteService
{
    private const string ProcedureName = "party.usp_AdminSite_List";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminSiteService> _logger;

    public AdminSiteService(
        ISqlConnectionFactory connectionFactory,
        ILogger<AdminSiteService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminSiteListItemDto>> GetSitesAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminSiteListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminSiteListItemDto
                {
                    SiteId = GetInt32(reader, "SiteID"),
                    ProviderId = GetInt32(reader, "ProviderID"),
                    SiteName = GetString(reader, "SiteName"),
                    ProviderName = GetString(reader, "ProviderName"),
                    LicenseClassCode = GetString(reader, "LicenseClassCode"),
                    LicenseClassName = GetString(reader, "LicenseClassName"),
                    TimeZoneCode = GetString(reader, "TimeZoneCode"),
                    TimeZoneDisplayName = GetString(reader, "TimeZoneDisplayName"),
                    LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                    PrimaryContactUserName = GetNullableString(reader, "PrimaryContactUserName"),
                    ActiveUserCount = GetInt32(reader, "ActiveUserCount"),
                    IsActive = GetBoolean(reader, "IsActive"),
                    CreatedUtc = GetDateTime(reader, "CreatedUTC")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin site list failed while executing {ProcedureName}.", ProcedureName);
            throw;
        }

        return results;
    }

    private static int GetInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
    }

    private static string GetString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static bool GetBoolean(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return !reader.IsDBNull(ordinal) && reader.GetBoolean(ordinal);
    }

    private static DateTime GetDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? DateTime.MinValue : reader.GetDateTime(ordinal);
    }
}
