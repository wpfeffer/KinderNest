using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminUserService
{
    Task<IReadOnlyList<AdminPortalUserListItemDto>> GetUsersAsync(CancellationToken cancellationToken = default);
}
