Hotfix for provider family onboarding antiforgery failure. Adds `@rendermode InteractiveServer`, `FormName`, and `<AntiforgeryToken />` to FamiliesNew.razor.
