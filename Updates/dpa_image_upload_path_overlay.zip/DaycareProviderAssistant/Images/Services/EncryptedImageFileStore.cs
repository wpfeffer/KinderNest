using System.Security.Cryptography;
using DaycareProviderAssistant.Images.Configuration;
using DaycareProviderAssistant.Images.Models;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Images.Services;

public sealed class EncryptedImageFileStore : IEncryptedImageFileStore
{
    private readonly IWebHostEnvironment _environment;
    private readonly ImageStorageOptions _options;

    public EncryptedImageFileStore(IWebHostEnvironment environment, IOptions<ImageStorageOptions> options)
    {
        _environment = environment ?? throw new ArgumentNullException(nameof(environment));
        _options = options.Value;
    }

    public Task EnsureSiteStorageAsync(int providerId, int siteId, CancellationToken cancellationToken = default)
    {
        if (providerId <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(providerId), "ProviderID must be a positive integer.");
        }

        if (siteId <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(siteId), "SiteID must be a positive integer.");
        }

        cancellationToken.ThrowIfCancellationRequested();

        var rootPath = GetStorageRootPath();
        Directory.CreateDirectory(rootPath);
        Directory.CreateDirectory(Path.Combine(rootPath, providerId.ToString(), siteId.ToString()));

        return Task.CompletedTask;
    }

    public async Task<EncryptedFileWriteResult> SaveAsync(int providerId, int siteId, string originalFileName, Stream encryptedContent, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(encryptedContent);

        await EnsureSiteStorageAsync(providerId, siteId, cancellationToken);

        var now = DateTime.UtcNow;
        var rootPath = GetStorageRootPath();
        var safeExtension = GetSafeExtension(originalFileName);

        var relativeDirectory = Path.Combine(
            providerId.ToString(),
            siteId.ToString(),
            now.Year.ToString("0000"),
            now.Month.ToString(),
            now.Day.ToString());

        var absoluteDirectory = Path.Combine(rootPath, relativeDirectory);
        Directory.CreateDirectory(absoluteDirectory);

        var storedFileName = $"{Guid.NewGuid():N}{safeExtension}";
        var absolutePath = Path.Combine(absoluteDirectory, storedFileName);
        var relativePath = Path.Combine(relativeDirectory, storedFileName).Replace('\\', '/');

        long totalBytes = 0;
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        await using var output = new FileStream(absolutePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 64, useAsync: true);

        var buffer = new byte[1024 * 64];
        int bytesRead;
        while ((bytesRead = await encryptedContent.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken)) > 0)
        {
            hash.AppendData(buffer, 0, bytesRead);
            await output.WriteAsync(buffer.AsMemory(0, bytesRead), cancellationToken);
            totalBytes += bytesRead;
        }

        var sha256Hex = Convert.ToHexString(hash.GetHashAndReset());

        return new EncryptedFileWriteResult
        {
            RelativePath = relativePath,
            LengthBytes = totalBytes,
            Sha256Hex = sha256Hex
        };
    }

    public Task<Stream> OpenReadAsync(string relativePath, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(relativePath);

        var rootPath = GetStorageRootPath();
        var normalizedPath = relativePath.Replace('/', Path.DirectorySeparatorChar);
        var absolutePath = Path.GetFullPath(Path.Combine(rootPath, normalizedPath));

        if (!absolutePath.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("The requested image path was outside the configured storage root.");
        }

        cancellationToken.ThrowIfCancellationRequested();

        Stream stream = new FileStream(absolutePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 64, useAsync: true);
        return Task.FromResult(stream);
    }

    private string GetStorageRootPath()
    {
        var configuredRoot = _options.StorageRootPath?.Trim();
        if (string.IsNullOrWhiteSpace(configuredRoot))
        {
            configuredRoot = "images";
        }

        return Path.IsPathRooted(configuredRoot)
            ? Path.GetFullPath(configuredRoot)
            : Path.GetFullPath(Path.Combine(_environment.ContentRootPath, configuredRoot));
    }

    private static string GetSafeExtension(string? originalFileName)
    {
        var extension = Path.GetExtension(originalFileName ?? string.Empty).ToLowerInvariant();

        return extension switch
        {
            ".jpg" => ".jpg",
            ".jpeg" => ".jpeg",
            ".png" => ".png",
            ".webp" => ".webp",
            _ => ".bin"
        };
    }
}
