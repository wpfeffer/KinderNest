using DaycareProviderAssistant.Images.Models;

namespace DaycareProviderAssistant.Images.Services;

public interface IEncryptedImageFileStore
{
    Task EnsureSiteStorageAsync(int providerId, int siteId, CancellationToken cancellationToken = default);
    Task<EncryptedFileWriteResult> SaveAsync(int providerId, int siteId, string originalFileName, Stream encryptedContent, CancellationToken cancellationToken = default);
    Task<Stream> OpenReadAsync(string relativePath, CancellationToken cancellationToken = default);
}
