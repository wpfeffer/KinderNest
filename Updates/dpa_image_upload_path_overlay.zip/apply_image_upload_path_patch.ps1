param(
    [string]$RepoRoot = "."
)

$servicePath = Join-Path $RepoRoot "DaycareProviderAssistant\Images\Services\EncryptedImageService.cs"
$appSettingsPath = Join-Path $RepoRoot "DaycareProviderAssistant\appsettings.json"
$jsPath = Join-Path $RepoRoot "DaycareProviderAssistant\wwwroot\js\dpa-images.js"

if (-not (Test-Path $servicePath)) {
    throw "Could not find EncryptedImageService.cs at $servicePath"
}

$content = Get-Content $servicePath -Raw
$content = $content.Replace(
    '_fileStore.SaveAsync(storageContext.ProviderId, siteId, manifest.ImageCategoryCode, encryptedFile, cancellationToken)',
    '_fileStore.SaveAsync(storageContext.ProviderId, siteId, manifest.OriginalFileName, encryptedFile, cancellationToken)'
)
$content = $content.Replace(
    '_fileStore.SaveAsync(storageContext.ProviderId, siteId, $"{manifest.ImageCategoryCode}_THUMB", encryptedThumbnail, cancellationToken)',
    '_fileStore.SaveAsync(storageContext.ProviderId, siteId, $"thumb-{manifest.OriginalFileName}", encryptedThumbnail, cancellationToken)'
)
Set-Content -Path $servicePath -Value $content -Encoding UTF8

if (Test-Path $appSettingsPath) {
    $settings = Get-Content $appSettingsPath -Raw
    $settings = $settings.Replace('"StorageRootPath": "App_Data/EncryptedImages"', '"StorageRootPath": "images"')
    Set-Content -Path $appSettingsPath -Value $settings -Encoding UTF8
}

if (Test-Path $jsPath) {
    $js = Get-Content $jsPath -Raw

    $js = $js.Replace(
        "if (!form || !button || !status) {" + [Environment]::NewLine + "        return;" + [Environment]::NewLine + "    }",
        "if (!form || !button || !status) {" + [Environment]::NewLine + "        console.warn('Encrypted upload controls were not found.', { form: !!form, button: !!button, status: !!status });" + [Environment]::NewLine + "        return;" + [Environment]::NewLine + "    }" + [Environment]::NewLine + [Environment]::NewLine + "    status.textContent = 'Ready. No plaintext leaves the browser.';"
    )

    $js = $js.Replace(
        "button.addEventListener('click', async () => {",
        "button.addEventListener('click', async event => {" + [Environment]::NewLine + "        event.preventDefault();" + [Environment]::NewLine + "        event.stopPropagation();"
    )

    $js = $js.Replace(
        "const siteId = Number(form.querySelector('input[name=""siteId""]').value || '0');",
        "const siteId = Number(form.querySelector('input[name=""siteId""]')?.value || '0');"
    )

    $js = $js.Replace(
        "const file = fileInput?.files?.[0];" + [Environment]::NewLine + "        if (!siteId || !file) {",
        "const file = fileInput?.files?.[0];" + [Environment]::NewLine + [Environment]::NewLine + "        if (!window.crypto?.subtle) {" + [Environment]::NewLine + "            status.textContent = 'Browser crypto is unavailable. Use HTTPS or localhost.';" + [Environment]::NewLine + "            return;" + [Environment]::NewLine + "        }" + [Environment]::NewLine + [Environment]::NewLine + "        if (!siteId || !file) {"
    )

    $js = $js.Replace(
        "formData.append('encryptedFile', encryptedOriginal.blob, `${file.name}.bin`);",
        "formData.append('encryptedFile', encryptedOriginal.blob, file.name);"
    )

    $js = $js.Replace(
        "formData.append('encryptedThumbnail', encryptedThumbnail.blob, `${file.name}.thumb.bin`);",
        "formData.append('encryptedThumbnail', encryptedThumbnail.blob, `thumb-${file.name}`);"
    )

    $js = $js.Replace(
        "throw new Error(payload?.error || 'The encrypted upload failed.');",
        "throw new Error(payload?.error || `The encrypted upload failed with HTTP ${response.status}.`);"
    )

    $js = $js.Replace(
        "status.textContent = error?.message || 'The encrypted upload failed.';",
        "console.error('Encrypted image upload failed.', error);" + [Environment]::NewLine + "            status.textContent = error?.message || 'The encrypted upload failed.';"
    )

    Set-Content -Path $jsPath -Value $js -Encoding UTF8
}

Write-Host "Patched encrypted image upload path, file naming, appsettings, and browser-side status diagnostics."
