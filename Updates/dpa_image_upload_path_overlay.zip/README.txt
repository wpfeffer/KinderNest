DPA image upload path overlay

Purpose:
- Store encrypted images under ./images/{ProviderID}/{SiteID}/{year}/{month number}/{day number}/{guid}.{file extension}
- Automatically create missing provider/site/date folders during upload.
- Preserve the original file extension when storing encrypted payloads.
- Patch the browser upload script so the Encrypt and Upload button updates status and logs failures to the console.

How to apply:
1. Unzip at the repository root and allow overwrite.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\apply_image_upload_path_patch.ps1
3. Rebuild and debug.
4. Hard-refresh the browser so /js/dpa-images.js reloads.

Files overwritten:
- DaycareProviderAssistant/Images/Services/IEncryptedImageFileStore.cs
- DaycareProviderAssistant/Images/Services/EncryptedImageFileStore.cs

Files patched by script:
- DaycareProviderAssistant/Images/Services/EncryptedImageService.cs
- DaycareProviderAssistant/appsettings.json
- DaycareProviderAssistant/wwwroot/js/dpa-images.js
