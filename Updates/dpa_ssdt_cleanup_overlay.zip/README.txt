DPA SSDT cleanup overlay

What this overlay includes
- SSDT-safe replacements for the table files still using IF OBJECT_ID / IF NOT EXISTS wrappers
- A clean replacement for dpa/billing/Stored Procedures/usp_FamilyInvoice_GetDetail.sql
- A PowerShell script that converts leading CREATE OR ALTER PROCEDURE/VIEW/FUNCTION to plain CREATE

How to apply
1. Unzip this archive at the repository root and allow overwrite.
2. From the repository root run:
   powershell -ExecutionPolicy Bypass -File .\apply_ssdt_normalize_create_or_alter.ps1
3. Rebuild the dpa project.

Notes
- This overlay targets the exact failure pattern shown in your latest build log.
- The script only normalizes leading CREATE OR ALTER statements; it does not touch tables.
