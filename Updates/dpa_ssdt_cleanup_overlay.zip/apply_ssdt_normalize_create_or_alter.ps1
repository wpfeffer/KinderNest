param(
    [string]$RepoRoot = "."
)

$targets = @(
    "dpa\sec\Stored Procedures",
    "dpa\child\Stored Procedures",
    "dpa\doc\Stored Procedures",
    "dpa\ops\Stored Procedures",
    "dpa\comm\Stored Procedures",
    "dpa\party\Stored Procedures",
    "dpa\image\Stored Procedures",
    "dpa\billing\Stored Procedures",
    "dpa\audit\Stored Procedures",
    "dpa\ref\Stored Procedures",
    "dpa\lic\Stored Procedures",
    "dpa\rpt\Views"
)

foreach ($target in $targets) {
    $full = Join-Path $RepoRoot $target
    if (-not (Test-Path $full)) { continue }

    Get-ChildItem -Path $full -Filter *.sql -Recurse | ForEach-Object {
        $content = Get-Content $_.FullName -Raw
        $updated = $content `
            -replace '^\s*CREATE\s+OR\s+ALTER\s+PROCEDURE\b', 'CREATE PROCEDURE' `
            -replace '^\s*CREATE\s+OR\s+ALTER\s+VIEW\b', 'CREATE VIEW' `
            -replace '^\s*CREATE\s+OR\s+ALTER\s+FUNCTION\b', 'CREATE FUNCTION'

        if ($updated -ne $content) {
            Set-Content -Path $_.FullName -Value $updated -Encoding UTF8
            Write-Host "Normalized: $($_.FullName)"
        }
    }
}

Write-Host "Done."
