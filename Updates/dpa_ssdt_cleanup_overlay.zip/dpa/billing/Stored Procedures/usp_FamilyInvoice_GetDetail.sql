CREATE PROCEDURE billing.usp_FamilyInvoice_GetDetail
    @FamilyInvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH PaymentRollup AS
    (
        SELECT
            p.FamilyInvoiceID,
            SuccessfulPaymentAmount = SUM(CASE WHEN pst.CodeValue IN (N'SUCCEEDED', N'SETTLED', N'PAID') THEN p.Amount ELSE 0 END),
            PaymentCount = COUNT_BIG(*)
        FROM billing.Payment p
        INNER JOIN ref.CodeValue pst ON pst.CodeValueID = p.PaymentStatusCodeValueID
        WHERE p.FamilyInvoiceID = @FamilyInvoiceID
          AND p.IsDeleted = 0
        GROUP BY p.FamilyInvoiceID
    )
    SELECT
        fi.FamilyInvoiceID,
        fi.FamilyBillingAccountID,
        fba.ProviderID,
        pr.ProviderName,
        fba.HouseholdID,
        h.HouseholdDisplayName,
        fi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue,
        InvoiceStatusName = ist.CodeName,
        fi.BillingPeriodStartUTC,
        fi.BillingPeriodEndUTC,
        fi.IssuedUTC,
        fi.DueUTC,
        fi.SentUTC,
        fi.SubtotalAmount,
        fi.TaxAmount,
        fi.TotalAmount,
        fi.BalanceAmount,
        PaidAmount = ISNULL(pru.SuccessfulPaymentAmount, 0.00),
        PaymentCount = CONVERT(INT, ISNULL(pru.PaymentCount, 0)),
        ReconciliationStatusCode = CASE
            WHEN fi.BalanceAmount <= 0 THEN N'RECONCILED'
            WHEN ISNULL(pru.SuccessfulPaymentAmount, 0.00) > 0 THEN N'PARTIAL'
            ELSE N'OPEN'
        END,
        fi.PaidUTC,
        fi.Notes
    FROM billing.FamilyInvoice fi
    INNER JOIN billing.FamilyBillingAccount fba ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID AND fba.IsDeleted = 0
    INNER JOIN party.Provider pr ON pr.ProviderID = fba.ProviderID AND pr.IsDeleted = 0
    INNER JOIN party.Household h ON h.HouseholdID = fba.HouseholdID AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = fi.InvoiceStatusCodeValueID
    LEFT JOIN PaymentRollup pru ON pru.FamilyInvoiceID = fi.FamilyInvoiceID
    WHERE fi.FamilyInvoiceID = @FamilyInvoiceID
      AND fi.IsDeleted = 0;

    SELECT
        fil.FamilyInvoiceLineID,
        LineTypeCode = lt.CodeValue,
        LineTypeName = lt.CodeName,
        fil.Description,
        fil.QuantityDecimal,
        fil.UnitPriceAmount,
        fil.LineAmount,
        fil.FamilyChargeID,
        fil.RelatedChildID,
        ChildDisplayName = CASE WHEN ch.ChildID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))) END,
        ChargeStatusCode = cst.CodeValue,
        ChargeStatusName = cst.CodeName,
        fc.ServiceDate,
        fc.ChildAttendanceID
    FROM billing.FamilyInvoiceLine fil
    INNER JOIN ref.CodeValue lt ON lt.CodeValueID = fil.LineTypeCodeValueID
    LEFT JOIN billing.FamilyCharge fc ON fc.FamilyChargeID = fil.FamilyChargeID AND fc.IsDeleted = 0
    LEFT JOIN ref.CodeValue cst ON cst.CodeValueID = fc.ChargeStatusCodeValueID
    LEFT JOIN child.Child ch ON ch.ChildID = fil.RelatedChildID AND ch.IsDeleted = 0
    WHERE fil.FamilyInvoiceID = @FamilyInvoiceID
      AND fil.IsDeleted = 0
    ORDER BY fil.FamilyInvoiceLineID;

    SELECT
        fc.FamilyChargeID,
        fc.FamilyBillingAccountID,
        fc.ChildID,
        ChildDisplayName = CASE WHEN ch.ChildID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))) END,
        ChargeTypeCode = cty.CodeValue,
        ChargeTypeName = cty.CodeName,
        ChargeStatusCode = cst.CodeValue,
        ChargeStatusName = cst.CodeName,
        fc.ServiceDate,
        fc.Description,
        fc.QuantityDecimal,
        fc.UnitPriceAmount,
        fc.ChargeAmount,
        fc.TaxAmount,
        fc.DiscountAmount,
        fc.FamilyInvoiceLineID,
        fc.ChildAttendanceID,
        fc.Notes
    FROM billing.FamilyCharge fc
    INNER JOIN billing.FamilyInvoiceLine fil ON fil.FamilyChargeID = fc.FamilyChargeID AND fil.IsDeleted = 0
    INNER JOIN ref.CodeValue cty ON cty.CodeValueID = fc.ChargeTypeCodeValueID
    INNER JOIN ref.CodeValue cst ON cst.CodeValueID = fc.ChargeStatusCodeValueID
    LEFT JOIN child.Child ch ON ch.ChildID = fc.ChildID AND ch.IsDeleted = 0
    WHERE fil.FamilyInvoiceID = @FamilyInvoiceID
      AND fc.IsDeleted = 0
    ORDER BY fc.ServiceDate DESC, fc.FamilyChargeID DESC;

    SELECT
        ca.ChildAttendanceID,
        ca.ChildID,
        ChildDisplayName = LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))),
        ca.SiteID,
        s.SiteName,
        ca.AttendanceDateLocal,
        ca.StartDateTimeUTC,
        ca.EndDateTimeUTC,
        MinutesAttended = DATEDIFF(MINUTE, ca.StartDateTimeUTC, ca.EndDateTimeUTC),
        ca.CorrectionReason,
        ca.Notes
    FROM child.ChildAttendance ca
    INNER JOIN child.Child ch ON ch.ChildID = ca.ChildID AND ch.IsDeleted = 0
    INNER JOIN party.Site s ON s.SiteID = ca.SiteID AND s.IsDeleted = 0
    WHERE ca.ChildAttendanceID IN
    (
        SELECT DISTINCT fc.ChildAttendanceID
        FROM billing.FamilyCharge fc
        INNER JOIN billing.FamilyInvoiceLine fil ON fil.FamilyChargeID = fc.FamilyChargeID AND fil.IsDeleted = 0
        WHERE fil.FamilyInvoiceID = @FamilyInvoiceID
          AND fc.ChildAttendanceID IS NOT NULL
          AND fc.IsDeleted = 0
    )
      AND ca.IsDeleted = 0
    ORDER BY ca.AttendanceDateLocal DESC, ca.ChildAttendanceID DESC;

    SELECT
        p.PaymentID,
        PaymentStatusCode = pst.CodeValue,
        PaymentStatusName = pst.CodeName,
        PaymentScopeCode = psc.CodeValue,
        p.PaymentUTC,
        p.Amount,
        p.CurrencyCode,
        p.ProcessorFeeAmount,
        p.ExternalTransactionReference
    FROM billing.Payment p
    INNER JOIN ref.CodeValue pst ON pst.CodeValueID = p.PaymentStatusCodeValueID
    INNER JOIN ref.CodeValue psc ON psc.CodeValueID = p.PaymentScopeCodeValueID
    WHERE p.FamilyInvoiceID = @FamilyInvoiceID
      AND p.IsDeleted = 0
    ORDER BY p.PaymentUTC DESC, p.PaymentID DESC;
END;
GO
