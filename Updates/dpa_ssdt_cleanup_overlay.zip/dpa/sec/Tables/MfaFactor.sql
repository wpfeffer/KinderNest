CREATE TABLE sec.MfaFactor
(
    MfaFactorID                    INT IDENTITY(1,1)         NOT NULL,
    PortalUserID                   INT                       NOT NULL,
    MfaFactorTypeCodeValueID       INT                       NOT NULL,
    PhoneNumberID                  INT                       NULL,
    SecretEncrypted                VARBINARY(MAX)            NULL,
    EmailAddress                   NVARCHAR(320)             NULL,
    IsPrimary                      BIT                       NOT NULL CONSTRAINT DF_MfaFactor_IsPrimary DEFAULT (0),
    IsActive                       BIT                       NOT NULL CONSTRAINT DF_MfaFactor_IsActive DEFAULT (1),
    IsDeleted                      BIT                       NOT NULL CONSTRAINT DF_MfaFactor_IsDeleted DEFAULT (0),
    VerifiedUTC                    DATETIME2(0)              NULL,
    CreatedUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_MfaFactor_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                INT                       NULL,
    ModifiedUTC                    DATETIME2(0)              NULL,
    ModifiedByUserID               INT                       NULL,
    DeletedUTC                     DATETIME2(0)              NULL,
    DeletedByUserID                INT                       NULL,
    DeletedReason                  NVARCHAR(500)             NULL,
    RowVer                         ROWVERSION                NOT NULL,
    CONSTRAINT PK_MfaFactor PRIMARY KEY CLUSTERED (MfaFactorID),
    CONSTRAINT FK_MfaFactor_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_MfaFactor_MfaFactorTypeCodeValue FOREIGN KEY (MfaFactorTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
    CONSTRAINT FK_MfaFactor_PhoneNumber FOREIGN KEY (PhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
    CONSTRAINT FK_MfaFactor_CreatedByUser FOREIGN KEY (CreatedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_MfaFactor_ModifiedByUser FOREIGN KEY (ModifiedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_MfaFactor_DeletedByUser FOREIGN KEY (DeletedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT CK_MfaFactor_Channel CHECK ((PhoneNumberID IS NOT NULL) OR (EmailAddress IS NOT NULL) OR (SecretEncrypted IS NOT NULL))
);
GO
CREATE UNIQUE INDEX UX_MfaFactor_PortalUser_PrimaryActive ON sec.MfaFactor (PortalUserID) WHERE IsDeleted = 0 AND IsActive = 1 AND IsPrimary = 1;
GO
CREATE INDEX IX_MfaFactor_MfaFactorTypeCodeValueID ON sec.MfaFactor (MfaFactorTypeCodeValueID);
GO
CREATE INDEX IX_MfaFactor_PhoneNumberID ON sec.MfaFactor (PhoneNumberID) WHERE PhoneNumberID IS NOT NULL;
GO
CREATE INDEX IX_MfaFactor_CreatedByUserID ON sec.MfaFactor (CreatedByUserID) WHERE CreatedByUserID IS NOT NULL;
GO
CREATE INDEX IX_MfaFactor_ModifiedByUserID ON sec.MfaFactor (ModifiedByUserID) WHERE ModifiedByUserID IS NOT NULL;
GO
CREATE INDEX IX_MfaFactor_DeletedByUserID ON sec.MfaFactor (DeletedByUserID) WHERE DeletedByUserID IS NOT NULL;
GO
