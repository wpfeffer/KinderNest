# DPA portal page wiring

This build adds a shared Blazor portal shell and wires routed pages for the admin, provider, and guardian areas.

## New folders
- Portal/Models
- Portal/Services
- Components/Portal
- Components/Pages/Admin
- Components/Pages/Provider
- Components/Pages/Guardian

## Shared shell
- Components/Portal/PortalShell.razor
- Components/Portal/PortalStatCard.razor
- Components/Portal/PortalSection.razor
- Components/Portal/PortalStatusPill.razor

## Branding
Provider and guardian shells are prepared for branding through appsettings.json using the PortalBranding section.
This is a starter implementation and can later be replaced with database-backed theme loading.

## Routes added
- /admin
- /admin/users
- /admin/sites
- /admin/security
- /admin/licensing
- /admin/audit
- /provider
- /provider/children
- /provider/attendance
- /provider/documents
- /provider/messages
- /guardian
- /guardian/children
- /guardian/consents
- /guardian/messages
- /guardian/profile
