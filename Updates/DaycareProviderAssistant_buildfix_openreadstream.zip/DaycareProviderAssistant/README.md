# Provider signup UI fixes

Replace these files in your project:

- `Components/Pages/Home.razor`
- `Auth/Models/ProviderRegistrationRequest.cs`
- `Auth/Models/ProviderRegistrationOutcome.cs`
- `Auth/Services/ProviderRegistrationService.cs`
- `Components/Pages/Auth/RegisterProvider.razor`
- `Components/Pages/Auth/RegisterProvider.razor.css`

What this changes:

- Adds a visible **Register as a provider** action on the homepage.
- Converts provider registration from a raw POST form to a Blazor `EditForm`.
- Keeps form values after submission errors.
- Shows field-level validation messages.
- Adds red invalid-field outlines.
- Returns field-specific errors from the registration service for duplicate usernames/emails and validation failures.
