namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminPortalUserSessionDto
{
    public long LoginSessionId { get; init; }
    public string SessionStatusCode { get; init; } = string.Empty;
    public DateTime? StartedUtc { get; init; }
    public DateTime? LastSeenUtc { get; init; }
    public DateTime? RevokedUtc { get; init; }
    public string? RemoteAddress { get; init; }
    public string? UserAgent { get; init; }
}
