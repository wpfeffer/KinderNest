namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminSiteDetailDto
{
    public int SiteId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
    public string? LicenseNumber { get; init; }
    public string LicenseClassCode { get; init; } = string.Empty;
    public string LicenseClassName { get; init; } = string.Empty;
    public string TimeZoneCode { get; init; } = string.Empty;
    public string TimeZoneDisplayName { get; init; } = string.Empty;
    public bool IsActive { get; init; }
    public IReadOnlyList<AdminSiteUserAssignmentDto> Assignments { get; init; } = Array.Empty<AdminSiteUserAssignmentDto>();
}
