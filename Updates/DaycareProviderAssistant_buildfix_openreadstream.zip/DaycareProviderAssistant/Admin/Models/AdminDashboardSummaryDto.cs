namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminDashboardSummaryDto
{
    public AdminDashboardCountsDto Counts { get; init; } = new();
    public IReadOnlyList<RecentProviderRegistrationDto> RecentRegistrations { get; init; } = Array.Empty<RecentProviderRegistrationDto>();
    public IReadOnlyList<RecentFailedLoginDto> RecentFailedLogins { get; init; } = Array.Empty<RecentFailedLoginDto>();
    public IReadOnlyList<RecentAuditEventDto> RecentAuditEvents { get; init; } = Array.Empty<RecentAuditEventDto>();
}
