namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminProviderOwnerDto
{
    public int PortalUserId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string? PrimaryEmail { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public string RoleCodes { get; init; } = string.Empty;
    public bool IsPrimaryProviderContact { get; init; }
    public bool IsActive { get; init; }
}
