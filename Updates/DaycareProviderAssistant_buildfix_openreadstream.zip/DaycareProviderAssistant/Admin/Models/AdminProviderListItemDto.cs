namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminProviderListItemDto
{
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string? LegalEntityName { get; init; }
    public string? BusinessEmail { get; init; }
    public string? OwnerDisplayName { get; init; }
    public int SiteCount { get; init; }
    public bool IsActive { get; init; }
}
