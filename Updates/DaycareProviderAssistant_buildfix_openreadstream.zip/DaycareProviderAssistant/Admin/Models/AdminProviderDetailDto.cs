namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminProviderDetailDto
{
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string? LegalEntityName { get; init; }
    public string? BusinessEmail { get; init; }
    public string? LicenseHolderDisplayName { get; init; }
    public bool IsActive { get; init; }
    public IReadOnlyList<AdminProviderOwnerDto> Owners { get; init; } = Array.Empty<AdminProviderOwnerDto>();
    public IReadOnlyList<AdminProviderSiteDto> Sites { get; init; } = Array.Empty<AdminProviderSiteDto>();
}
