namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminPortalUserDetailDto
{
    public int PortalUserId { get; init; }
    public int PersonId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string? PrimaryEmail { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public bool MfaEnabled { get; init; }
    public bool IsLocked { get; init; }
    public DateTime? LockoutEndUtc { get; init; }
    public DateTime? LastLoginUtc { get; init; }
    public bool IsActive { get; init; }
    public string? RejectionReason { get; init; }
    public IReadOnlyList<AdminPortalUserRoleDto> Roles { get; init; } = Array.Empty<AdminPortalUserRoleDto>();
    public IReadOnlyList<AdminPortalUserSiteAssignmentDto> SiteAssignments { get; init; } = Array.Empty<AdminPortalUserSiteAssignmentDto>();
    public IReadOnlyList<AdminPortalUserSessionDto> RecentSessions { get; init; } = Array.Empty<AdminPortalUserSessionDto>();
}
