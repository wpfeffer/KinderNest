namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminSiteUserAssignmentDto
{
    public int PortalUserId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string AssignmentTypeCode { get; init; } = string.Empty;
    public bool IsPrimaryProviderContact { get; init; }
    public DateTime? EffectiveStartUtc { get; init; }
    public DateTime? EffectiveEndUtc { get; init; }
    public bool IsActive { get; init; }
}
