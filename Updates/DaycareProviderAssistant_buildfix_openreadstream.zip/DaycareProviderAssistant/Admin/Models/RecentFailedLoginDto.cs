namespace DaycareProviderAssistant.Admin.Models;

public sealed class RecentFailedLoginDto
{
    public long AuthenticationEventId { get; init; }
    public DateTime EventUtc { get; init; }
    public string UserNameAttempted { get; init; } = string.Empty;
    public string AuthenticationEventTypeCode { get; init; } = string.Empty;
    public string AuthenticationResultCode { get; init; } = string.Empty;
    public string? FailureReason { get; init; }
    public string? RemoteAddress { get; init; }
    public string? SiteName { get; init; }
}
