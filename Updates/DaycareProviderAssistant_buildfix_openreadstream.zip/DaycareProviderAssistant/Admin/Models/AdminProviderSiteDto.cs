namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminProviderSiteDto
{
    public int SiteId { get; init; }
    public string SiteName { get; init; } = string.Empty;
    public string? LicenseNumber { get; init; }
    public string LicenseClassCode { get; init; } = string.Empty;
    public string LicenseClassName { get; init; } = string.Empty;
    public string TimeZoneCode { get; init; } = string.Empty;
    public string TimeZoneDisplayName { get; init; } = string.Empty;
    public int AssignedUserCount { get; init; }
    public bool IsActive { get; init; }
}
