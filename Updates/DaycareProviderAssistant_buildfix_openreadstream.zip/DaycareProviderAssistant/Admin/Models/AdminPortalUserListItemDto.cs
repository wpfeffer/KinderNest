namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminPortalUserListItemDto
{
    public int PortalUserId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string? PrimaryEmail { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public bool MfaEnabled { get; init; }
    public bool IsLocked { get; init; }
    public DateTime? LockoutEndUtc { get; init; }
    public DateTime? LastLoginUtc { get; init; }
    public string RoleCodes { get; init; } = string.Empty;
    public int SiteCount { get; init; }
    public bool IsActive { get; init; }
}
