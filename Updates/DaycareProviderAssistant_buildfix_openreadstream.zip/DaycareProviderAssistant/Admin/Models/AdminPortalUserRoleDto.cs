namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminPortalUserRoleDto
{
    public string RoleCode { get; init; } = string.Empty;
    public string RoleName { get; init; } = string.Empty;
    public DateTime? EffectiveStartUtc { get; init; }
    public DateTime? EffectiveEndUtc { get; init; }
    public bool IsActive { get; init; }
}
