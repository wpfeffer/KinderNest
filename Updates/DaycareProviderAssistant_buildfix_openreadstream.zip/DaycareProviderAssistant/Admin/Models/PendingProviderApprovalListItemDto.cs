namespace DaycareProviderAssistant.Admin.Models;

public sealed class PendingProviderApprovalListItemDto
{
    public int PortalUserId { get; init; }
    public int? ProviderId { get; init; }
    public int? SiteId { get; init; }
    public DateTime SubmittedUtc { get; init; }
    public string RegistrantDisplayName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string PrimaryEmail { get; init; } = string.Empty;
    public string ProviderName { get; init; } = string.Empty;
    public string? BusinessEmail { get; init; }
    public string SiteName { get; init; } = string.Empty;
    public string? LicenseNumber { get; init; }
    public string LicenseClassCode { get; init; } = string.Empty;
    public string LicenseClassName { get; init; } = string.Empty;
    public string AccountStatusCode { get; init; } = string.Empty;
}
