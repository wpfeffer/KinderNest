namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminActionOutcomeDto
{
    public bool Succeeded { get; init; }
    public string Message { get; init; } = string.Empty;
    public int PortalUserId { get; init; }
    public string? AccountStatusCode { get; init; }
    public DateTime? ModifiedUtc { get; init; }
}
