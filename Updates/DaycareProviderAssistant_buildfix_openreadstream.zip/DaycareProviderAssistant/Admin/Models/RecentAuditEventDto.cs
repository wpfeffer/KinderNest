namespace DaycareProviderAssistant.Admin.Models;

public sealed class RecentAuditEventDto
{
    public long AuditLogId { get; init; }
    public DateTime EventUtc { get; init; }
    public string SchemaName { get; init; } = string.Empty;
    public string TableName { get; init; } = string.Empty;
    public string ActionTypeCode { get; init; } = string.Empty;
    public string? ActorUserName { get; init; }
    public string RecordPrimaryKeyValue { get; init; } = string.Empty;
    public string? ReasonText { get; init; }
    public bool SucceededFlag { get; init; }
}
