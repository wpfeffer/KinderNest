namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminPortalUserSiteAssignmentDto
{
    public int SiteId { get; init; }
    public string SiteName { get; init; } = string.Empty;
    public string ProviderName { get; init; } = string.Empty;
    public string AssignmentTypeCode { get; init; } = string.Empty;
    public bool IsPrimaryProviderContact { get; init; }
    public DateTime? EffectiveStartUtc { get; init; }
    public DateTime? EffectiveEndUtc { get; init; }
    public bool IsActive { get; init; }
}
