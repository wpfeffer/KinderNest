Milestone 1 admin portal application bundle

Included:
- live admin dashboard service + page wiring
- pending provider approvals page
- admin services and DTOs
- Program.cs service registration
- admin navigation update

Routes added/updated:
- /admin
- /admin/dashboard
- /admin/approvals/providers

This bundle assumes the matching database stored procedures exist:
- ops.usp_AdminDashboard_GetSummary
- party.usp_AdminPendingProvider_List
- party.usp_ProviderOwner_Approve
- party.usp_ProviderOwner_Reject
