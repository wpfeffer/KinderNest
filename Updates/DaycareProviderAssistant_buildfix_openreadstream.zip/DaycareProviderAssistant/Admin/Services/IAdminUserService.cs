using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminUserService
{
    Task<IReadOnlyList<AdminPortalUserListItemDto>> GetUsersAsync(CancellationToken cancellationToken = default);
    Task<AdminPortalUserDetailDto?> GetUserDetailAsync(int portalUserId, CancellationToken cancellationToken = default);
}
