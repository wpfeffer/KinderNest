using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminProviderApprovalService
{
    Task<IReadOnlyList<PendingProviderApprovalListItemDto>> ListPendingAsync(CancellationToken cancellationToken = default);

    Task<AdminActionOutcomeDto> ApproveAsync(
        int portalUserId,
        int approvedByUserId,
        string? reasonText,
        CancellationToken cancellationToken = default);

    Task<AdminActionOutcomeDto> RejectAsync(
        int portalUserId,
        int rejectedByUserId,
        string? reasonText,
        CancellationToken cancellationToken = default);
}
