using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Admin.Services.AdminDataReaderHelpers;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminSiteService : IAdminSiteService
{
    private const string ListProcedureName = "party.usp_AdminSite_List";
    private const string DetailProcedureName = "party.usp_AdminSite_GetDetail";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminSiteService> _logger;

    public AdminSiteService(ISqlConnectionFactory connectionFactory, ILogger<AdminSiteService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminSiteListItemDto>> GetSitesAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminSiteListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ListProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminSiteListItemDto
                {
                    SiteId = GetInt32(reader, "SiteID"),
                    SiteName = GetString(reader, "SiteName"),
                    ProviderId = GetInt32(reader, "ProviderID"),
                    ProviderName = GetString(reader, "ProviderName"),
                    LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                    LicenseClassCode = GetString(reader, "LicenseClassCode"),
                    TimeZoneCode = GetString(reader, "TimeZoneCode"),
                    AssignedUserCount = GetInt32(reader, "AssignedUserCount"),
                    IsActive = GetBoolean(reader, "IsActive")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin site list failed while executing {ProcedureName}.", ListProcedureName);
            throw;
        }

        return results;
    }

    public async Task<AdminSiteDetailDto?> GetSiteDetailAsync(int siteId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = DetailProcedureName;
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = siteId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            var detail = new AdminSiteDetailDto
            {
                SiteId = GetInt32(reader, "SiteID"),
                ProviderId = GetInt32(reader, "ProviderID"),
                ProviderName = GetString(reader, "ProviderName"),
                SiteName = GetString(reader, "SiteName"),
                LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                LicenseClassCode = GetString(reader, "LicenseClassCode"),
                LicenseClassName = GetString(reader, "LicenseClassName"),
                TimeZoneCode = GetString(reader, "TimeZoneCode"),
                TimeZoneDisplayName = GetString(reader, "TimeZoneDisplayName"),
                IsActive = GetBoolean(reader, "IsActive")
            };

            var assignments = new List<AdminSiteUserAssignmentDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    assignments.Add(new AdminSiteUserAssignmentDto
                    {
                        PortalUserId = GetInt32(reader, "PortalUserID"),
                        DisplayName = GetString(reader, "DisplayName"),
                        UserName = GetString(reader, "UserName"),
                        AssignmentTypeCode = GetString(reader, "AssignmentTypeCode"),
                        IsPrimaryProviderContact = GetBoolean(reader, "IsPrimaryProviderContact"),
                        EffectiveStartUtc = GetNullableDateTime(reader, "EffectiveStartUTC"),
                        EffectiveEndUtc = GetNullableDateTime(reader, "EffectiveEndUTC"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            return new AdminSiteDetailDto
            {
                SiteId = detail.SiteId,
                ProviderId = detail.ProviderId,
                ProviderName = detail.ProviderName,
                SiteName = detail.SiteName,
                LicenseNumber = detail.LicenseNumber,
                LicenseClassCode = detail.LicenseClassCode,
                LicenseClassName = detail.LicenseClassName,
                TimeZoneCode = detail.TimeZoneCode,
                TimeZoneDisplayName = detail.TimeZoneDisplayName,
                IsActive = detail.IsActive,
                Assignments = assignments
            };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin site detail failed while executing {ProcedureName} for SiteID {SiteID}.", DetailProcedureName, siteId);
            throw;
        }
    }
}
