using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminProviderService
{
    Task<IReadOnlyList<AdminProviderListItemDto>> GetProvidersAsync(CancellationToken cancellationToken = default);
    Task<AdminProviderDetailDto?> GetProviderDetailAsync(int providerId, CancellationToken cancellationToken = default);
}
