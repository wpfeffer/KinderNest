using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Admin.Services.AdminDataReaderHelpers;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminProviderService : IAdminProviderService
{
    private const string ListProcedureName = "party.usp_AdminProvider_List";
    private const string DetailProcedureName = "party.usp_AdminProvider_GetDetail";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminProviderService> _logger;

    public AdminProviderService(ISqlConnectionFactory connectionFactory, ILogger<AdminProviderService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminProviderListItemDto>> GetProvidersAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminProviderListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ListProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminProviderListItemDto
                {
                    ProviderId = GetInt32(reader, "ProviderID"),
                    ProviderName = GetString(reader, "ProviderName"),
                    LegalEntityName = GetNullableString(reader, "LegalEntityName"),
                    BusinessEmail = GetNullableString(reader, "BusinessEmail"),
                    OwnerDisplayName = GetNullableString(reader, "OwnerDisplayName"),
                    SiteCount = GetInt32(reader, "SiteCount"),
                    IsActive = GetBoolean(reader, "IsActive")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin provider list failed while executing {ProcedureName}.", ListProcedureName);
            throw;
        }

        return results;
    }

    public async Task<AdminProviderDetailDto?> GetProviderDetailAsync(int providerId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = DetailProcedureName;
        command.Parameters.Add(new SqlParameter("@ProviderID", SqlDbType.Int) { Value = providerId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            var detail = new AdminProviderDetailDto
            {
                ProviderId = GetInt32(reader, "ProviderID"),
                ProviderName = GetString(reader, "ProviderName"),
                LegalEntityName = GetNullableString(reader, "LegalEntityName"),
                BusinessEmail = GetNullableString(reader, "BusinessEmail"),
                LicenseHolderDisplayName = GetNullableString(reader, "LicenseHolderDisplayName"),
                IsActive = GetBoolean(reader, "IsActive")
            };

            var owners = new List<AdminProviderOwnerDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    owners.Add(new AdminProviderOwnerDto
                    {
                        PortalUserId = GetInt32(reader, "PortalUserID"),
                        DisplayName = GetString(reader, "DisplayName"),
                        UserName = GetString(reader, "UserName"),
                        PrimaryEmail = GetNullableString(reader, "PrimaryEmail"),
                        AccountStatusCode = GetString(reader, "AccountStatusCode"),
                        RoleCodes = GetNullableString(reader, "RoleCodes") ?? string.Empty,
                        IsPrimaryProviderContact = GetBoolean(reader, "IsPrimaryProviderContact"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            var sites = new List<AdminProviderSiteDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    sites.Add(new AdminProviderSiteDto
                    {
                        SiteId = GetInt32(reader, "SiteID"),
                        SiteName = GetString(reader, "SiteName"),
                        LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                        LicenseClassCode = GetString(reader, "LicenseClassCode"),
                        LicenseClassName = GetString(reader, "LicenseClassName"),
                        TimeZoneCode = GetString(reader, "TimeZoneCode"),
                        TimeZoneDisplayName = GetString(reader, "TimeZoneDisplayName"),
                        AssignedUserCount = GetInt32(reader, "AssignedUserCount"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            return new AdminProviderDetailDto
            {
                ProviderId = detail.ProviderId,
                ProviderName = detail.ProviderName,
                LegalEntityName = detail.LegalEntityName,
                BusinessEmail = detail.BusinessEmail,
                LicenseHolderDisplayName = detail.LicenseHolderDisplayName,
                IsActive = detail.IsActive,
                Owners = owners,
                Sites = sites
            };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin provider detail failed while executing {ProcedureName} for ProviderID {ProviderID}.", DetailProcedureName, providerId);
            throw;
        }
    }
}
