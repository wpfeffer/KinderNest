using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Admin.Services.AdminDataReaderHelpers;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminUserService : IAdminUserService
{
    private const string ListProcedureName = "party.usp_AdminPortalUser_List";
    private const string DetailProcedureName = "party.usp_AdminPortalUser_GetDetail";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminUserService> _logger;

    public AdminUserService(ISqlConnectionFactory connectionFactory, ILogger<AdminUserService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IReadOnlyList<AdminPortalUserListItemDto>> GetUsersAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<AdminPortalUserListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ListProcedureName;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new AdminPortalUserListItemDto
                {
                    PortalUserId = GetInt32(reader, "PortalUserID"),
                    DisplayName = GetString(reader, "DisplayName"),
                    UserName = GetString(reader, "UserName"),
                    PrimaryEmail = GetNullableString(reader, "PrimaryEmail"),
                    AccountStatusCode = GetString(reader, "AccountStatusCode"),
                    MfaEnabled = GetBoolean(reader, "MFAEnabled"),
                    IsLocked = GetBoolean(reader, "IsLocked"),
                    LockoutEndUtc = GetNullableDateTime(reader, "LockoutEndUTC"),
                    LastLoginUtc = GetNullableDateTime(reader, "LastLoginUTC"),
                    RoleCodes = GetNullableString(reader, "RoleCodes") ?? string.Empty,
                    SiteCount = GetInt32(reader, "SiteCount"),
                    IsActive = GetBoolean(reader, "IsActive")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin user list failed while executing {ProcedureName}.", ListProcedureName);
            throw;
        }

        return results;
    }

    public async Task<AdminPortalUserDetailDto?> GetUserDetailAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = DetailProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            var portalUserIdValue = GetInt32(reader, "PortalUserID");
            var personId = GetInt32(reader, "PersonID");
            var displayName = GetString(reader, "DisplayName");
            var userName = GetString(reader, "UserName");
            var primaryEmail = GetNullableString(reader, "PrimaryEmail");
            var accountStatusCode = GetString(reader, "AccountStatusCode");
            var mfaEnabled = GetBoolean(reader, "MFAEnabled");
            var isLocked = GetBoolean(reader, "IsLocked");
            var lockoutEndUtc = GetNullableDateTime(reader, "LockoutEndUTC");
            var lastLoginUtc = GetNullableDateTime(reader, "LastLoginUTC");
            var isActive = GetBoolean(reader, "IsActive");
            var rejectionReason = GetNullableString(reader, "RejectionReason");

            var roles = new List<AdminPortalUserRoleDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    roles.Add(new AdminPortalUserRoleDto
                    {
                        RoleCode = GetString(reader, "RoleCode"),
                        RoleName = GetString(reader, "RoleName"),
                        EffectiveStartUtc = GetNullableDateTime(reader, "EffectiveStartUTC"),
                        EffectiveEndUtc = GetNullableDateTime(reader, "EffectiveEndUTC"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            var assignments = new List<AdminPortalUserSiteAssignmentDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    assignments.Add(new AdminPortalUserSiteAssignmentDto
                    {
                        SiteId = GetInt32(reader, "SiteID"),
                        SiteName = GetString(reader, "SiteName"),
                        ProviderName = GetString(reader, "ProviderName"),
                        AssignmentTypeCode = GetString(reader, "AssignmentTypeCode"),
                        IsPrimaryProviderContact = GetBoolean(reader, "IsPrimaryProviderContact"),
                        EffectiveStartUtc = GetNullableDateTime(reader, "EffectiveStartUTC"),
                        EffectiveEndUtc = GetNullableDateTime(reader, "EffectiveEndUTC"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            var sessions = new List<AdminPortalUserSessionDto>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    sessions.Add(new AdminPortalUserSessionDto
                    {
                        LoginSessionId = GetInt64(reader, "LoginSessionID"),
                        SessionStatusCode = GetString(reader, "SessionStatusCode"),
                        StartedUtc = GetNullableDateTime(reader, "StartedUTC"),
                        LastSeenUtc = GetNullableDateTime(reader, "LastSeenUTC"),
                        RevokedUtc = GetNullableDateTime(reader, "RevokedUTC"),
                        RemoteAddress = GetNullableString(reader, "RemoteAddress"),
                        UserAgent = GetNullableString(reader, "UserAgent")
                    });
                }
            }

            return new AdminPortalUserDetailDto
            {
                PortalUserId = portalUserIdValue,
                PersonId = personId,
                DisplayName = displayName,
                UserName = userName,
                PrimaryEmail = primaryEmail,
                AccountStatusCode = accountStatusCode,
                MfaEnabled = mfaEnabled,
                IsLocked = isLocked,
                LockoutEndUtc = lockoutEndUtc,
                LastLoginUtc = lastLoginUtc,
                IsActive = isActive,
                RejectionReason = rejectionReason,
                Roles = roles,
                SiteAssignments = assignments,
                RecentSessions = sessions
            };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin user detail failed while executing {ProcedureName} for PortalUserID {PortalUserID}.", DetailProcedureName, portalUserId);
            throw;
        }
    }
}
