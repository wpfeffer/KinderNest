using DaycareProviderAssistant.Admin.Models;

namespace DaycareProviderAssistant.Admin.Services;

public interface IAdminDashboardService
{
    Task<AdminDashboardSummaryDto> GetSummaryAsync(CancellationToken cancellationToken = default);
}
