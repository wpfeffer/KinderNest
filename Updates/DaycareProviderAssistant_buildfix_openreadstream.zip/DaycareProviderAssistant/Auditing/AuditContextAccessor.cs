using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace DaycareProviderAssistant.Auditing;

public sealed record AuditRequestContext(
    string? ActorUserId,
    string? ActorRoleCode,
    string? EffectiveRoleCode,
    string? ImpersonatedUserId,
    string? SessionId,
    Guid? CorrelationId,
    string? RequestId,
    string? ClientIpAddress,
    string? UserAgent,
    string AccessPathCode,
    string? Path,
    string? HttpMethod
);

public sealed class AuditContextAccessor
{
    private const string CorrelationHeaderName = "X-Correlation-ID";
    private const string SessionHeaderName = "X-Session-ID";
    private readonly IHttpContextAccessor _httpContextAccessor;

    public AuditContextAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public AuditRequestContext GetCurrent(string defaultAccessPathCode = AuditAccessPaths.Ui)
    {
        var httpContext = _httpContextAccessor.HttpContext;

        if (httpContext is null)
        {
            return new AuditRequestContext(
                ActorUserId: null,
                ActorRoleCode: null,
                EffectiveRoleCode: null,
                ImpersonatedUserId: null,
                SessionId: null,
                CorrelationId: null,
                RequestId: null,
                ClientIpAddress: null,
                UserAgent: null,
                AccessPathCode: defaultAccessPathCode,
                Path: null,
                HttpMethod: null);
        }

        var user = httpContext.User;
        var request = httpContext.Request;

        return new AuditRequestContext(
            ActorUserId: GetUserId(user),
            ActorRoleCode: GetPrimaryRole(user),
            EffectiveRoleCode: GetClaimValue(user, "effective_role") ?? GetPrimaryRole(user),
            ImpersonatedUserId: GetClaimValue(user, "impersonated_user_id"),
            SessionId: GetFirstHeaderValue(request, SessionHeaderName) ?? httpContext.TraceIdentifier,
            CorrelationId: TryGetCorrelationId(request),
            RequestId: httpContext.TraceIdentifier,
            ClientIpAddress: httpContext.Connection.RemoteIpAddress?.ToString(),
            UserAgent: GetFirstHeaderValue(request, HeaderNames.UserAgent),
            AccessPathCode: ResolveAccessPath(request, defaultAccessPathCode),
            Path: request.Path.HasValue ? request.Path.Value : null,
            HttpMethod: request.Method);
    }

    private static string? GetUserId(ClaimsPrincipal user)
    {
        return GetClaimValue(user, ClaimTypes.NameIdentifier)
            ?? GetClaimValue(user, "sub")
            ?? GetClaimValue(user, "user_id");
    }

    private static string? GetPrimaryRole(ClaimsPrincipal user)
    {
        return user.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value
            ?? GetClaimValue(user, "role");
    }

    private static string? GetClaimValue(ClaimsPrincipal user, string claimType)
    {
        return user.Claims.FirstOrDefault(c => c.Type == claimType)?.Value;
    }

    private static Guid? TryGetCorrelationId(HttpRequest request)
    {
        var headerValue = GetFirstHeaderValue(request, CorrelationHeaderName);
        return Guid.TryParse(headerValue, out var correlationId)
            ? correlationId
            : null;
    }

    private static string? GetFirstHeaderValue(HttpRequest request, string headerName)
    {
        return request.Headers.TryGetValue(headerName, out var value)
            ? value.FirstOrDefault()
            : null;
    }

    private static string ResolveAccessPath(HttpRequest request, string defaultAccessPathCode)
    {
        if (request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
        {
            return AuditAccessPaths.Api;
        }

        return defaultAccessPathCode;
    }

    private static class HeaderNames
    {
        public const string UserAgent = "User-Agent";
    }
}
