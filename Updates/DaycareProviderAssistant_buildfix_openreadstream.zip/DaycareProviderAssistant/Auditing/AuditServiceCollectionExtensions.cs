using Microsoft.Extensions.DependencyInjection;

namespace DaycareProviderAssistant.Auditing;

public static class AuditServiceCollectionExtensions
{
    public static IServiceCollection AddDpaAuditCore ( this IServiceCollection services )
    {
        ArgumentNullException.ThrowIfNull ( services );

        services.AddHttpContextAccessor ( );
        services.AddScoped<AuditContextAccessor> ( );
        services.AddSingleton<AuditHasher> ( );

        return services;
    }
}