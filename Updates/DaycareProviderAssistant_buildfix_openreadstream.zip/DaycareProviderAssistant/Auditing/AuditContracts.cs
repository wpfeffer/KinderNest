using System.Text.Json;

namespace DaycareProviderAssistant.Auditing;

public static class AuditCategories
{
    public const string Security = "Security";
    public const string DataAccess = "DataAccess";
    public const string DomainChange = "DomainChange";
    public const string BreakGlass = "BreakGlass";
    public const string Export = "Export";
    public const string System = "System";
}

public static class AuditOutcomes
{
    public const string Success = "Success";
    public const string Denied = "Denied";
    public const string Failed = "Failed";
}

public static class AuditAccessPaths
{
    public const string Ui = "UI";
    public const string Api = "API";
    public const string BackgroundJob = "BackgroundJob";
    public const string DirectDb = "DirectDB";
    public const string SupportImpersonation = "SupportImpersonation";
    public const string BreakGlass = "BreakGlass";
}

public static class AuditSeverity
{
    public const string Trace = "Trace";
    public const string Info = "Info";
    public const string Warning = "Warning";
    public const string Error = "Error";
    public const string Critical = "Critical";
}

public sealed record AuditSubjectRef(
    string SubjectTypeCode,
    string SubjectId,
    string? RelationshipCode = null,
    bool IsSensitive = false
);

public sealed record AuditFieldChange(
    string EntityName,
    string FieldName,
    string ChangeTypeCode,
    string? OldValueRedacted = null,
    string? NewValueRedacted = null,
    byte[]? OldValueHash = null,
    byte[]? NewValueHash = null,
    bool IsSensitive = false,
    string EncryptionDispositionCode = "None"
);

public sealed record AuditEventEnvelope
{
    public required DateTimeOffset OccurredUtc { get; init; }
    public string CategoryCode { get; init; } = AuditCategories.System;
    public required string EventTypeCode { get; init; }
    public string OutcomeCode { get; init; } = AuditOutcomes.Success;
    public string SeverityCode { get; init; } = AuditSeverity.Info;

    public string? ActorUserId { get; init; }
    public string? ActorRoleCode { get; init; }
    public string? EffectiveRoleCode { get; init; }
    public string? ImpersonatedUserId { get; init; }

    public string? SessionId { get; init; }
    public Guid? CorrelationId { get; init; }
    public string? RequestId { get; init; }
    public string AccessPathCode { get; init; } = AuditAccessPaths.Ui;
    public string? ClientIpAddress { get; init; }
    public string? UserAgent { get; init; }

    public string? ReasonCode { get; init; }
    public string? ReasonText { get; init; }

    public bool WasEncryptedFieldMaterialized { get; init; }
    public bool WasExport { get; init; }
    public long? BreakGlassSessionId { get; init; }

    public JsonDocument? PayloadJson { get; init; }

    public IReadOnlyCollection<AuditSubjectRef> Subjects { get; init; } = Array.Empty<AuditSubjectRef>();
    public IReadOnlyCollection<AuditFieldChange> Changes { get; init; } = Array.Empty<AuditFieldChange>();
}

public sealed record AuditWriteResult(
    long AuditEventId,
    Guid AuditEventGuid,
    byte[] EventHash
);
