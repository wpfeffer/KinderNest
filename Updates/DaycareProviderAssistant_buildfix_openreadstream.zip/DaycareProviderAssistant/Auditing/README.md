# DPA Auditing Core

These files are the **core C# contracts and helpers** for the auditing subsystem.

## Files

- `AuditContracts.cs`
- `IAuditWriter.cs`
- `AuditContextAccessor.cs`
- `AuditHasher.cs`
- `AuditServiceCollectionExtensions.cs`

## Where to put them

If your app is currently a single web project, place them under:

```text
/Auditing
```

Example:

```text
DaycareProviderAssistant/
├── Auditing/
│   ├── AuditContracts.cs
│   ├── IAuditWriter.cs
│   ├── AuditContextAccessor.cs
│   ├── AuditHasher.cs
│   └── AuditServiceCollectionExtensions.cs
├── Components/
├── Data/
├── Services/
└── Program.cs
```

## Program.cs

Register the helpers in `Program.cs`:

```csharp
using DaycareProviderAssistant.Auditing;

builder.Services.AddAuditCore();
```

## Important

This package does **not** include the real `SqlAuditWriter` yet.
You will still need to add a concrete implementation of `IAuditWriter` that writes to your database.

That is intentional.
These files are the stable core, so you can wire the contracts and helpers now without locking yourself into a half-baked persistence layer.

## Notes

- Namespace is `DaycareProviderAssistant.Auditing`
- If your project root namespace is different, update the namespace declarations.
- `AuditContextAccessor` expects ASP.NET Core and `IHttpContextAccessor`.
- `AuditHasher` gives you a deterministic SHA-256 hash of the audit envelope plus the previous event hash.
