namespace DaycareProviderAssistant.Auditing;

public interface IAuditWriter
{
    Task<AuditWriteResult> WriteAsync(
        AuditEventEnvelope envelope,
        CancellationToken cancellationToken = default);
}
