using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DaycareProviderAssistant.Auditing;

public sealed class AuditHasher
{
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNamingPolicy = null,
        WriteIndented = false
    };

    public byte[] ComputeEventHash(AuditEventEnvelope envelope, byte[]? previousEventHash = null)
    {
        ArgumentNullException.ThrowIfNull(envelope);

        var canonicalPayload = CreateCanonicalPayload(envelope, previousEventHash);
        var bytes = Encoding.UTF8.GetBytes(canonicalPayload);

        using var sha256 = SHA256.Create();
        return sha256.ComputeHash(bytes);
    }

    public byte[] ComputeValueHash(string? value)
    {
        using var sha256 = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(value ?? string.Empty);
        return sha256.ComputeHash(bytes);
    }

    private static string CreateCanonicalPayload(AuditEventEnvelope envelope, byte[]? previousEventHash)
    {
        var payload = new
        {
            envelope.OccurredUtc,
            envelope.CategoryCode,
            envelope.EventTypeCode,
            envelope.OutcomeCode,
            envelope.SeverityCode,
            envelope.ActorUserId,
            envelope.ActorRoleCode,
            envelope.EffectiveRoleCode,
            envelope.ImpersonatedUserId,
            envelope.SessionId,
            envelope.CorrelationId,
            envelope.RequestId,
            envelope.AccessPathCode,
            envelope.ClientIpAddress,
            envelope.UserAgent,
            envelope.ReasonCode,
            envelope.ReasonText,
            envelope.WasEncryptedFieldMaterialized,
            envelope.WasExport,
            envelope.BreakGlassSessionId,
            PayloadJson = envelope.PayloadJson?.RootElement.GetRawText(),
            Subjects = envelope.Subjects
                .Select(subject => new
                {
                    subject.SubjectTypeCode,
                    subject.SubjectId,
                    subject.RelationshipCode,
                    subject.IsSensitive
                })
                .ToArray(),
            Changes = envelope.Changes
                .Select(change => new
                {
                    change.EntityName,
                    change.FieldName,
                    change.ChangeTypeCode,
                    change.OldValueRedacted,
                    change.NewValueRedacted,
                    OldValueHash = change.OldValueHash is null ? null : Convert.ToHexString(change.OldValueHash),
                    NewValueHash = change.NewValueHash is null ? null : Convert.ToHexString(change.NewValueHash),
                    change.IsSensitive,
                    change.EncryptionDispositionCode
                })
                .ToArray(),
            PreviousEventHash = previousEventHash is null ? null : Convert.ToHexString(previousEventHash)
        };

        return JsonSerializer.Serialize(payload, SerializerOptions);
    }
}
