using DaycareProviderAssistant.Portal.Models;

namespace DaycareProviderAssistant.Portal.Services;

public sealed class PortalNavigationService
{
    public IReadOnlyList<PortalNavItem> GetAdminNavigation() =>
    [
        new("Dashboard", "/admin", "📊", true),
        new("Provider Approvals", "/admin/approvals/providers", "✅"),
        new("Users", "/admin/users", "👥"),
        new("Providers", "/admin/providers", "🪪"),
        new("Sites", "/admin/sites", "🏢"),
        new("Security", "/admin/security", "🔐"),
        new("Licensing", "/admin/licensing", "📋"),
        new("Audit", "/admin/audit", "🧾")
    ];

    public IReadOnlyList<PortalNavItem> GetProviderNavigation() =>
    [
        new("Dashboard", "/provider", "🏠", true),
        new("Children", "/provider/children", "🧒"),
        new("Attendance", "/provider/attendance", "⏱️"),
        new("Documents", "/provider/documents", "📄"),
        new("Photos", "/provider/photos", "🖼️"),
        new("Messages", "/provider/messages", "💬")
    ];

    public IReadOnlyList<PortalNavItem> GetGuardianNavigation() =>
    [
        new("Dashboard", "/guardian", "🏠", true),
        new("My Children", "/guardian/children", "🪁"),
        new("Consents", "/guardian/consents", "✍️"),
        new("Photos", "/guardian/photos", "🖼️"),
        new("Messages", "/guardian/messages", "💌"),
        new("Profile", "/guardian/profile", "🪪")
    ];
}
