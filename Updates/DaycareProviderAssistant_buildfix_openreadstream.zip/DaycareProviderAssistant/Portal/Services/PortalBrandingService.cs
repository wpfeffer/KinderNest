using DaycareProviderAssistant.Portal.Models;
using Microsoft.Extensions.Configuration;

namespace DaycareProviderAssistant.Portal.Services;

public sealed class PortalBrandingService
{
    private readonly IConfiguration _configuration;

    public PortalBrandingService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public PortalTheme GetTheme(string portalKey)
    {
        var section = _configuration.GetSection($"PortalBranding:{portalKey}");

        return new PortalTheme(
            portalKey,
            Get(section, "DisplayName", GetDefault(portalKey).DisplayName),
            Get(section, "Eyebrow", GetDefault(portalKey).Eyebrow),
            Get(section, "AccentColor", GetDefault(portalKey).AccentColor),
            Get(section, "AccentSoftColor", GetDefault(portalKey).AccentSoftColor),
            Get(section, "SurfaceTint", GetDefault(portalKey).SurfaceTint),
            Get(section, "SidebarStart", GetDefault(portalKey).SidebarStart),
            Get(section, "SidebarEnd", GetDefault(portalKey).SidebarEnd),
            section["HeaderImageUrl"],
            Get(section, "HeaderTitle", GetDefault(portalKey).HeaderTitle),
            Get(section, "HeaderSummary", GetDefault(portalKey).HeaderSummary));
    }

    private static string Get(IConfigurationSection section, string key, string fallback)
        => string.IsNullOrWhiteSpace(section[key]) ? fallback : section[key]!;

    private static PortalTheme GetDefault(string portalKey)
        => portalKey.ToLowerInvariant() switch
        {
            "admin" => new PortalTheme(
                "admin",
                "Admin Portal",
                "Daycare Provider Assistant",
                "#7c3aed",
                "#ede9fe",
                "#faf5ff",
                "#111827",
                "#0f172a",
                null,
                "System command deck",
                "Monitor providers, auth health, licensing posture, and sensitive activity from one place."),
            "provider" => new PortalTheme(
                "provider",
                "Provider Portal",
                "Daycare Provider Assistant",
                "#0f766e",
                "#ccfbf1",
                "#f0fdfa",
                "#115e59",
                "#134e4a",
                null,
                "Provider operations hub",
                "Manage children, attendance, documents, and daily work from one consistent shell."),
            _ => new PortalTheme(
                "guardian",
                "Guardian Portal",
                "Daycare Provider Assistant",
                "#1d4ed8",
                "#dbeafe",
                "#eff6ff",
                "#1e3a8a",
                "#1d4ed8",
                null,
                "Family connection center",
                "See child updates, review documents, and manage family-side tasks without spelunking through menus.")
        };
}
