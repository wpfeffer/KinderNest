namespace DaycareProviderAssistant.Portal.Models;

public sealed record PortalTheme(
    string PortalKey,
    string DisplayName,
    string Eyebrow,
    string AccentColor,
    string AccentSoftColor,
    string SurfaceTint,
    string SidebarStart,
    string SidebarEnd,
    string? HeaderImageUrl,
    string HeaderTitle,
    string HeaderSummary);
