namespace DaycareProviderAssistant.Portal.Models;

public sealed record PortalNavItem(string Label, string Href, string Icon, bool ExactMatch = false);
