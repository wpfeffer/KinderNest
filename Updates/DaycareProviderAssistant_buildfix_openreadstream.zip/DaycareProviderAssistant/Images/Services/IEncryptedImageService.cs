using DaycareProviderAssistant.Images.Models;

namespace DaycareProviderAssistant.Images.Services;

public interface IEncryptedImageService
{
    Task<IReadOnlyList<ProviderImageSiteOptionDto>> GetAccessibleProviderSitesAsync(int portalUserId, CancellationToken cancellationToken = default);
    Task<ProviderSiteImageWorkspaceDto?> GetProviderWorkspaceAsync(int portalUserId, int siteId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<GuardianImageChildOptionDto>> GetAccessibleGuardianChildrenAsync(int personId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ImageGalleryItemDto>> GetGuardianGalleryAsync(int portalUserId, int childId, CancellationToken cancellationToken = default);
    Task<SiteImageKeyDto> GetOrCreateSiteKeyAsync(int portalUserId, int personId, int siteId, bool createIfMissing, CancellationToken cancellationToken = default);
    Task<ImageUploadResultDto> SaveEncryptedImageAsync(int portalUserId, int personId, int siteId, ImageUploadManifestDto manifest, Stream encryptedFile, Stream? encryptedThumbnail, CancellationToken cancellationToken = default);
    Task<ImageBinaryEnvelopeDto?> GetImageBinaryAsync(int portalUserId, int personId, int imageAssetId, bool thumbnail, CancellationToken cancellationToken = default);
    Task<bool> SoftDeleteImageAsync(int portalUserId, int personId, int imageAssetId, string? reason, CancellationToken cancellationToken = default);
}
