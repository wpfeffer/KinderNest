using DaycareProviderAssistant.Images.Models;

namespace DaycareProviderAssistant.Images.Services;

public interface IEncryptedImageFileStore
{
    Task<EncryptedFileWriteResult> SaveAsync(int siteId, string categoryCode, Stream encryptedContent, CancellationToken cancellationToken = default);
    Task<Stream> OpenReadAsync(string relativePath, CancellationToken cancellationToken = default);
}
