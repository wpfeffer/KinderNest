using System.Security.Cryptography;
using DaycareProviderAssistant.Images.Configuration;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Images.Services;

public sealed class SiteImageKeyProtector
{
    private readonly byte[] _masterKey;

    public SiteImageKeyProtector(IOptions<ImageStorageOptions> options)
    {
        var configuredValue = options.Value.MasterKeyBase64?.Trim();
        if (string.IsNullOrWhiteSpace(configuredValue))
        {
            throw new InvalidOperationException("DpaImages:MasterKeyBase64 is required before encrypted image support can run.");
        }

        try
        {
            _masterKey = Convert.FromBase64String(configuredValue);
        }
        catch (FormatException ex)
        {
            throw new InvalidOperationException("DpaImages:MasterKeyBase64 must be valid base64.", ex);
        }

        if (_masterKey.Length != 32)
        {
            throw new InvalidOperationException("DpaImages:MasterKeyBase64 must decode to exactly 32 bytes.");
        }
    }

    public byte[] CreateNewSiteKey() => RandomNumberGenerator.GetBytes(32);

    public (byte[] Ciphertext, byte[] Nonce, byte[] Tag) WrapKey(byte[] rawSiteKey)
    {
        ArgumentNullException.ThrowIfNull(rawSiteKey);

        var nonce = RandomNumberGenerator.GetBytes(12);
        var ciphertext = new byte[rawSiteKey.Length];
        var tag = new byte[16];

        using var aes = new AesGcm(_masterKey, 16);
        aes.Encrypt(nonce, rawSiteKey, ciphertext, tag);

        return (ciphertext, nonce, tag);
    }

    public byte[] UnwrapKey(byte[] wrappedCiphertext, byte[] nonce, byte[] tag)
    {
        ArgumentNullException.ThrowIfNull(wrappedCiphertext);
        ArgumentNullException.ThrowIfNull(nonce);
        ArgumentNullException.ThrowIfNull(tag);

        var plaintext = new byte[wrappedCiphertext.Length];
        using var aes = new AesGcm(_masterKey, 16);
        aes.Decrypt(nonce, wrappedCiphertext, tag, plaintext);
        return plaintext;
    }
}
