using System.Text.Json;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Images.Models;
using DaycareProviderAssistant.Images.Services;

namespace DaycareProviderAssistant.Images.Endpoints;

public static class ImageEndpointMapper
{
    public static IEndpointRouteBuilder MapDpaImageEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/images")
            .RequireAuthorization();

        group.MapGet("/sites/{siteId:int}/key", async (
            int siteId,
            bool ensure,
            DpaCurrentUserAccessor currentUser,
            IEncryptedImageService imageService,
            HttpResponse response,
            CancellationToken cancellationToken) =>
        {
            if (currentUser.PortalUserId is null)
            {
                return Results.Unauthorized();
            }

            try
            {
                response.Headers.CacheControl = "no-store";
                var siteKey = await imageService.GetOrCreateSiteKeyAsync(
                    currentUser.PortalUserId.Value,
                    currentUser.PersonId ?? 0,
                    siteId,
                    ensure,
                    cancellationToken);
                return Results.Json(siteKey);
            }
            catch (UnauthorizedAccessException)
            {
                return Results.Forbid();
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(new { error = ex.Message });
            }
        });

        group.MapPost("/sites/{siteId:int}/upload", async (
            int siteId,
            HttpRequest request,
            DpaCurrentUserAccessor currentUser,
            IEncryptedImageService imageService,
            CancellationToken cancellationToken) =>
        {
            if (currentUser.PortalUserId is null)
            {
                return Results.Unauthorized();
            }

            var form = await request.ReadFormAsync(cancellationToken);
            var manifestJson = form["manifest"].ToString();
            if (string.IsNullOrWhiteSpace(manifestJson))
            {
                return Results.BadRequest(new { error = "The upload manifest was missing." });
            }

            ImageUploadManifestDto? manifest;
            try
            {
                manifest = JsonSerializer.Deserialize<ImageUploadManifestDto>(manifestJson, new JsonSerializerOptions(JsonSerializerDefaults.Web)
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (JsonException ex)
            {
                return Results.BadRequest(new { error = $"The upload manifest JSON was invalid: {ex.Message}" });
            }

            if (manifest is null)
            {
                return Results.BadRequest(new { error = "The upload manifest JSON was invalid." });
            }

            var encryptedFile = form.Files.GetFile("encryptedFile");
            if (encryptedFile is null)
            {
                return Results.BadRequest(new { error = "The encryptedFile payload was missing." });
            }

            var encryptedThumbnail = form.Files.GetFile("encryptedThumbnail");

            try
            {
                await using var encryptedFileStream = encryptedFile.OpenReadStream();
                Stream? encryptedThumbnailStream = null;
                try
                {
                    encryptedThumbnailStream = encryptedThumbnail?.OpenReadStream();

                    var result = await imageService.SaveEncryptedImageAsync(
                        currentUser.PortalUserId.Value,
                        currentUser.PersonId ?? 0,
                        siteId,
                        manifest,
                        encryptedFileStream,
                        encryptedThumbnailStream,
                        cancellationToken);

                    return Results.Json(result);
                }
                finally
                {
                    if (encryptedThumbnailStream is IAsyncDisposable asyncDisposable)
                    {
                        await asyncDisposable.DisposeAsync();
                    }
                    else
                    {
                        encryptedThumbnailStream?.Dispose();
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                return Results.Forbid();
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(new { error = ex.Message });
            }
        }).DisableAntiforgery();

        group.MapGet("/{imageAssetId:int}/binary", async (
            int imageAssetId,
            bool thumbnail,
            DpaCurrentUserAccessor currentUser,
            IEncryptedImageService imageService,
            CancellationToken cancellationToken) =>
        {
            if (currentUser.PortalUserId is null)
            {
                return Results.Unauthorized();
            }

            var result = await imageService.GetImageBinaryAsync(
                currentUser.PortalUserId.Value,
                currentUser.PersonId ?? 0,
                imageAssetId,
                thumbnail,
                cancellationToken);

            if (result is null)
            {
                return Results.NotFound();
            }

            return Results.File(result.ContentStream, "application/octet-stream", fileDownloadName: result.FileName, lastModified: result.LastModifiedUtc, enableRangeProcessing: false);
        });

        group.MapDelete("/{imageAssetId:int}", async (
            int imageAssetId,
            string? reason,
            DpaCurrentUserAccessor currentUser,
            IEncryptedImageService imageService,
            CancellationToken cancellationToken) =>
        {
            if (currentUser.PortalUserId is null)
            {
                return Results.Unauthorized();
            }

            try
            {
                var deleted = await imageService.SoftDeleteImageAsync(
                    currentUser.PortalUserId.Value,
                    currentUser.PersonId ?? 0,
                    imageAssetId,
                    reason,
                    cancellationToken);
                return deleted ? Results.NoContent() : Results.NotFound();
            }
            catch (UnauthorizedAccessException)
            {
                return Results.Forbid();
            }
        }).DisableAntiforgery();

        return app;
    }
}
