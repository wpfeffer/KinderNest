namespace DaycareProviderAssistant.Images.Configuration;

public sealed class ImageStorageOptions
{
    public const string SectionName = "DpaImages";

    public string StorageRootPath { get; set; } = "App_Data/EncryptedImages";
    public string MasterKeyBase64 { get; set; } = string.Empty;
    public int MaxUploadBytes { get; set; } = 10 * 1024 * 1024;
    public int MaxThumbnailBytes { get; set; } = 2 * 1024 * 1024;
    public int DefaultThumbnailMaxEdge { get; set; } = 512;
}
