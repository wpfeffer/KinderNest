namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageUploadResultDto
{
    public int ImageAssetId { get; init; }
    public int SiteId { get; init; }
    public string ImageCategoryCode { get; init; } = string.Empty;
}
