namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageSubjectLinkDto
{
    public string SubjectTypeCode { get; init; } = string.Empty;
    public int? ChildId { get; init; }
    public int? PersonId { get; init; }
    public bool IsPrimarySubject { get; init; }
    public int SortOrder { get; init; }
}
