namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageUploadManifestDto
{
    public string ImageCategoryCode { get; init; } = string.Empty;
    public string VisibilityScopeCode { get; init; } = "SITE_STAFF";
    public string OriginalFileName { get; init; } = string.Empty;
    public string OriginalContentType { get; init; } = string.Empty;
    public long OriginalLengthBytes { get; init; }
    public long EncryptedFileLengthBytes { get; init; }
    public int SiteKeyVersion { get; init; }
    public string ImageNonceBase64 { get; init; } = string.Empty;
    public string? ThumbnailContentType { get; init; }
    public long? ThumbnailLengthBytes { get; init; }
    public long? EncryptedThumbnailLengthBytes { get; init; }
    public string? ThumbnailNonceBase64 { get; init; }
    public int? PixelWidth { get; init; }
    public int? PixelHeight { get; init; }
    public string? Caption { get; init; }
    public DateTime? TakenUtc { get; init; }
    public IReadOnlyList<ImageSubjectLinkDto> SubjectLinks { get; init; } = Array.Empty<ImageSubjectLinkDto>();
}
