namespace DaycareProviderAssistant.Images.Models;

public sealed class ProviderSiteImageWorkspaceDto
{
    public required ProviderImageSiteOptionDto Site { get; init; }
    public IReadOnlyList<ImageSubjectOptionDto> Children { get; init; } = Array.Empty<ImageSubjectOptionDto>();
    public IReadOnlyList<ImageSubjectOptionDto> Adults { get; init; } = Array.Empty<ImageSubjectOptionDto>();
    public IReadOnlyList<ImageGalleryItemDto> GalleryItems { get; init; } = Array.Empty<ImageGalleryItemDto>();
}
