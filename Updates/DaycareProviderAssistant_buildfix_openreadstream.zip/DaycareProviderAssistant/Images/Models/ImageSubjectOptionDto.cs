namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageSubjectOptionDto
{
    public int Id { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string? Detail { get; init; }
}
