namespace DaycareProviderAssistant.Images.Models;

public sealed class GuardianImageChildOptionDto
{
    public int ChildId { get; init; }
    public int SiteId { get; init; }
    public string ChildName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
}
