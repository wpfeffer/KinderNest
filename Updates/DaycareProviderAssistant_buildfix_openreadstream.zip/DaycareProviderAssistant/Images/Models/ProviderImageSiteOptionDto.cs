namespace DaycareProviderAssistant.Images.Models;

public sealed class ProviderImageSiteOptionDto
{
    public int SiteId { get; init; }
    public string SiteName { get; init; } = string.Empty;
    public string ProviderName { get; init; } = string.Empty;
}
