namespace DaycareProviderAssistant.Images.Models;

public sealed class SiteImageKeyDto
{
    public int SiteId { get; init; }
    public int KeyVersion { get; init; }
    public string WrapAlgorithmCode { get; init; } = string.Empty;
    public string KeyBase64 { get; init; } = string.Empty;
}
