namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageGalleryItemDto
{
    public int ImageAssetId { get; init; }
    public int SiteId { get; init; }
    public string ImageCategoryCode { get; init; } = string.Empty;
    public string VisibilityScopeCode { get; init; } = string.Empty;
    public string OriginalFileName { get; init; } = string.Empty;
    public string OriginalContentType { get; init; } = string.Empty;
    public int SiteKeyVersion { get; init; }
    public string ImageNonceBase64 { get; init; } = string.Empty;
    public string? ThumbnailNonceBase64 { get; init; }
    public string? ThumbnailContentType { get; init; }
    public bool HasThumbnail { get; init; }
    public string SubjectSummary { get; init; } = string.Empty;
    public string? Caption { get; init; }
    public int? PixelWidth { get; init; }
    public int? PixelHeight { get; init; }
    public DateTime? TakenUtc { get; init; }
    public DateTime CreatedUtc { get; init; }
}
