namespace DaycareProviderAssistant.Images.Models;

public sealed class ImageBinaryEnvelopeDto
{
    public required Stream ContentStream { get; init; }
    public required string ContentType { get; init; }
    public required string FileName { get; init; }
    public DateTimeOffset? LastModifiedUtc { get; init; }
}
