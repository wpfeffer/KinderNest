namespace DaycareProviderAssistant.Images.Models;

public sealed class EncryptedFileWriteResult
{
    public string RelativePath { get; init; } = string.Empty;
    public long LengthBytes { get; init; }
    public string Sha256Hex { get; init; } = string.Empty;
}
