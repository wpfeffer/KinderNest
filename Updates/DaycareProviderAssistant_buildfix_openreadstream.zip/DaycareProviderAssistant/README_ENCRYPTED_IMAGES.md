# Encrypted Images

This module adds end-to-end client-side image encryption for:

- child headshots
- parent / guardian / pickup-dropoff headshots
- child diary / scrapbook images

## What this implementation does

- normalizes images in the browser to strip EXIF-style metadata
- creates thumbnails in the browser
- encrypts original + thumbnail in the browser with AES-GCM through Web Crypto
- stores only ciphertext files on the server file system
- stores image metadata and subject links in SQL Server
- uses one site-scoped image key per site, wrapped at rest in SQL Server with an application master key

## Important caveat

The browser is the only place the image bytes are decrypted.
However, the server can unwrap the site key in order to provision it to an authorized browser session.
That means this is **client-side encryption with browser-only plaintext decryption**, not a zero-knowledge design.

If you later want true zero-knowledge access, the next step is per-user or per-device wrapping for the site key instead of a server-unwrapped site key.

## Required configuration

Set `DpaImages:MasterKeyBase64` to a 32-byte base64 value before using the feature.
Do not reuse a fake sample value in production.

Example PowerShell to generate one:

```powershell
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Minimum 0 -Maximum 256 }))
```

Store the encrypted image files outside `wwwroot`.
The default configured path is `App_Data/EncryptedImages` under the app content root.
