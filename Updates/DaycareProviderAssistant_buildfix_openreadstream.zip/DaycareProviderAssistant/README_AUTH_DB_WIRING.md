# DPA Authentication and Authorization Wiring

This scaffold replaces the in-memory auth store with SQL-backed services.

## What it expects in the database

The app now reads from these tables at sign-in time:

- `party.PortalUser`
- `party.Person`
- `party.PortalUserRole`
- `party.SiteUserAssignment`
- `child.ChildPersonRelationship`
- `ref.Role`
- `ref.CodeValue`
- `sec.PortalCredential`
- `sec.LoginSession`
- `audit.AuthenticationEvent`

If the `sec.*` auth tables and `audit.AuthenticationEvent` aren't present yet, sign-in won't succeed.

## What is real now

- cookie authentication
- SQL-backed credential lookup
- SQL-backed role loading
- SQL-backed site assignment loading
- SQL-backed guardian relationship loading
- SQL-backed login session creation
- SQL-backed session revocation
- SQL-backed authentication event writes
- policy-based portal protection for `/admin`, `/provider`, and `/guardian`
- resource authorization handlers for site access and child access

## What to configure

Set the `ConnectionStrings:DpaDatabase` connection string in `appsettings.Development.json`.

Example:

```json
{
  "ConnectionStrings": {
    "DpaDatabase": "Server=WayneDesktop\\SQL2025;Database=dpa;Trusted_Connection=True;Encrypt=False;TrustServerCertificate=True"
  }
}
```

## Notes

- Password verification uses ASP.NET Core's `PasswordHasher` format.
- Login and logout endpoints are mapped in `Auth/Endpoints/AuthEndpointMapper.cs`.
- The scaffold keeps cookies lean and uses database checks for session validation and resource authorization.
