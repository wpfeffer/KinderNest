const keyCache = new Map();

export async function initializeProviderWorkspace(root, options) {
    if (!root) {
        return;
    }

    wireCategoryToggle(root);
    wireUpload(root, options);
    wireGallery(root, options, true);
    await hydrateThumbnails(root, options);
}

export async function initializeGuardianWorkspace(root, options) {
    if (!root) {
        return;
    }

    wireGallery(root, options, false);
    await hydrateThumbnails(root, options);
}

function wireCategoryToggle(root) {
    const select = root.querySelector('[data-role="image-category-select"]');
    if (!select) {
        return;
    }

    const applyMode = () => {
        const currentValue = select.value;
        root.querySelectorAll('.encrypted-upload-mode').forEach(section => {
            section.hidden = section.dataset.mode !== modeForCategory(currentValue);
        });
    };

    select.addEventListener('change', applyMode);
    applyMode();
}

function modeForCategory(categoryCode) {
    switch (categoryCode) {
        case 'PERSON_HEADSHOT':
            return 'person-headshot';
        case 'CHILD_DIARY':
            return 'child-diary';
        default:
            return 'child-headshot';
    }
}

function wireUpload(root, options) {
    const form = root.querySelector('[data-role="provider-image-upload-form"]');
    const button = root.querySelector('[data-role="encrypted-upload-button"]');
    const status = root.querySelector('[data-role="encrypted-upload-status"]');
    if (!form || !button || !status) {
        return;
    }

    button.addEventListener('click', async () => {
        const siteId = Number(form.querySelector('input[name="siteId"]').value || '0');
        const fileInput = form.querySelector('input[name="sourceImage"]');
        const file = fileInput?.files?.[0];
        if (!siteId || !file) {
            status.textContent = 'Pick a site and an image first.';
            return;
        }

        if (file.size > options.maxUploadBytes) {
            status.textContent = `That file is larger than the configured ${options.maxUploadBytes} byte limit.`;
            return;
        }

        status.textContent = 'Normalizing image, building thumbnail, and encrypting in-browser…';
        button.disabled = true;

        try {
            const siteKey = await getSiteKey(siteId, options.keyUrlTemplate, true);
            const normalized = await normalizeImage(file);
            const thumbnail = await createThumbnail(normalized.blob, options.thumbnailMaxEdge || 512);
            const encryptedOriginal = await encryptBlob(normalized.blob, siteKey.cryptoKey);
            const encryptedThumbnail = await encryptBlob(thumbnail.blob, siteKey.cryptoKey);
            const subjectLinks = buildSubjectLinks(form, form.querySelector('[name="imageCategoryCode"]').value);
            if (!subjectLinks.length) {
                throw new Error('Select at least one subject for the uploaded image.');
            }

            const manifest = {
                imageCategoryCode: form.querySelector('[name="imageCategoryCode"]').value,
                visibilityScopeCode: form.querySelector('[name="visibilityScopeCode"]').value,
                originalFileName: file.name,
                originalContentType: normalized.blob.type || file.type || 'application/octet-stream',
                originalLengthBytes: normalized.blob.size,
                encryptedFileLengthBytes: encryptedOriginal.blob.size,
                siteKeyVersion: siteKey.keyVersion,
                imageNonceBase64: encryptedOriginal.ivBase64,
                thumbnailContentType: thumbnail.blob.type || 'image/jpeg',
                thumbnailLengthBytes: thumbnail.blob.size,
                encryptedThumbnailLengthBytes: encryptedThumbnail.blob.size,
                thumbnailNonceBase64: encryptedThumbnail.ivBase64,
                pixelWidth: normalized.width,
                pixelHeight: normalized.height,
                caption: form.querySelector('[name="caption"]').value || null,
                takenUtc: file.lastModified ? new Date(file.lastModified).toISOString() : null,
                subjectLinks
            };

            const formData = new FormData();
            formData.append('manifest', JSON.stringify(manifest));
            formData.append('encryptedFile', encryptedOriginal.blob, `${file.name}.bin`);
            formData.append('encryptedThumbnail', encryptedThumbnail.blob, `${file.name}.thumb.bin`);

            const uploadUrl = options.uploadUrlTemplate.replace('__SITE_ID__', String(siteId));
            const response = await fetch(uploadUrl, {
                method: 'POST',
                credentials: 'include',
                body: formData
            });

            if (!response.ok) {
                const payload = await safeReadJson(response);
                throw new Error(payload?.error || 'The encrypted upload failed.');
            }

            status.textContent = 'Upload complete. Reloading gallery…';
            window.location.reload();
        } catch (error) {
            status.textContent = error?.message || 'The encrypted upload failed.';
        } finally {
            button.disabled = false;
        }
    });
}

function buildSubjectLinks(form, categoryCode) {
    if (categoryCode === 'CHILD_HEADSHOT') {
        const childId = Number(form.querySelector('[name="childHeadshotChildId"]').value || '0');
        return childId ? [{ subjectTypeCode: 'CHILD', childId, personId: null, isPrimarySubject: true, sortOrder: 1 }] : [];
    }

    if (categoryCode === 'PERSON_HEADSHOT') {
        const personId = Number(form.querySelector('[name="personHeadshotPersonId"]').value || '0');
        const links = [];
        if (personId) {
            links.push({ subjectTypeCode: 'PERSON', childId: null, personId, isPrimarySubject: true, sortOrder: 1 });
        }

        let sortOrder = 2;
        form.querySelectorAll('input[name="adultLinkedChildIds"]:checked').forEach(box => {
            const childId = Number(box.value || '0');
            if (childId) {
                links.push({ subjectTypeCode: 'CHILD', childId, personId: null, isPrimarySubject: false, sortOrder });
                sortOrder += 1;
            }
        });

        return links;
    }

    const links = [];
    let sortOrder = 1;
    form.querySelectorAll('input[name="diaryChildIds"]:checked').forEach(box => {
        const childId = Number(box.value || '0');
        if (childId) {
            links.push({ subjectTypeCode: 'CHILD', childId, personId: null, isPrimarySubject: sortOrder === 1, sortOrder });
            sortOrder += 1;
        }
    });

    return links;
}

function wireGallery(root, options, allowDelete) {
    root.querySelectorAll('[data-role="image-view-button"]').forEach(button => {
        button.addEventListener('click', async () => {
            const card = button.closest('.encrypted-image-card');
            await openImageModal(card, options);
        });
    });

    root.querySelectorAll('[data-role="image-download-button"]').forEach(button => {
        button.addEventListener('click', async () => {
            const card = button.closest('.encrypted-image-card');
            await downloadDecryptedImage(card, options);
        });
    });

    if (!allowDelete) {
        return;
    }

    root.querySelectorAll('[data-role="image-delete-button"]').forEach(button => {
        button.addEventListener('click', async () => {
            const card = button.closest('.encrypted-image-card');
            const imageId = card?.dataset.imageId;
            if (!imageId) {
                return;
            }

            const confirmed = window.confirm('Soft delete this image row? The ciphertext file is retained for audit/history until you build a purge job.');
            if (!confirmed) {
                return;
            }

            const deleteUrl = options.deleteUrlTemplate.replace('__IMAGE_ID__', imageId);
            const response = await fetch(deleteUrl, {
                method: 'DELETE',
                credentials: 'include'
            });

            if (!response.ok && response.status !== 204) {
                const payload = await safeReadJson(response);
                window.alert(payload?.error || 'Delete failed.');
                return;
            }

            window.location.reload();
        });
    });
}

async function hydrateThumbnails(root, options) {
    const cards = Array.from(root.querySelectorAll('.encrypted-image-card'));
    for (const card of cards) {
        const thumbContainer = card.querySelector('[data-role="encrypted-thumb"]');
        if (!thumbContainer) {
            continue;
        }

        try {
            const blob = await fetchAndDecrypt(card, true, options);
            if (!blob) {
                thumbContainer.textContent = 'No thumbnail';
                continue;
            }

            const url = URL.createObjectURL(blob);
            const image = document.createElement('img');
            image.src = url;
            image.alt = card.dataset.originalFileName || 'Encrypted image';
            image.loading = 'lazy';
            image.addEventListener('load', () => setTimeout(() => URL.revokeObjectURL(url), 1000));
            thumbContainer.replaceChildren(image);
        } catch {
            thumbContainer.textContent = 'Preview locked';
        }
    }
}

async function openImageModal(card, options) {
    if (!card) {
        return;
    }

    const blob = await fetchAndDecrypt(card, false, options);
    if (!blob) {
        window.alert('That image could not be decrypted.');
        return;
    }

    const modal = ensureModal();
    const imageUrl = URL.createObjectURL(blob);
    modal.image.src = imageUrl;
    modal.image.alt = card.dataset.originalFileName || 'Decrypted image';
    modal.caption.textContent = card.dataset.originalFileName || 'Decrypted image';
    modal.shell.hidden = false;

    const closeModal = () => {
        modal.shell.hidden = true;
        modal.image.removeAttribute('src');
        URL.revokeObjectURL(imageUrl);
    };

    modal.closeElements.forEach(element => {
        element.onclick = closeModal;
    });
}

async function downloadDecryptedImage(card, options) {
    if (!card) {
        return;
    }

    const blob = await fetchAndDecrypt(card, false, options);
    if (!blob) {
        window.alert('That image could not be decrypted.');
        return;
    }

    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = card.dataset.originalFileName || 'image';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

async function fetchAndDecrypt(card, useThumbnail, options) {
    const siteId = Number(card.dataset.siteId || '0');
    const imageUrl = useThumbnail && card.dataset.thumbUrl ? card.dataset.thumbUrl : card.dataset.imageUrl;
    const nonceBase64 = useThumbnail && card.dataset.thumbNonce ? card.dataset.thumbNonce : card.dataset.imageNonce;
    const contentType = useThumbnail && card.dataset.thumbContentType ? card.dataset.thumbContentType : card.dataset.originalContentType;
    if (!siteId || !imageUrl || !nonceBase64) {
        return null;
    }

    const siteKey = await getSiteKey(siteId, options.keyUrlTemplate, false);
    const response = await fetch(imageUrl, { credentials: 'include' });
    if (!response.ok) {
        throw new Error('The encrypted image fetch failed.');
    }

    const encryptedBytes = await response.arrayBuffer();
    const decryptedBytes = await crypto.subtle.decrypt(
        {
            name: 'AES-GCM',
            iv: base64ToBytes(nonceBase64)
        },
        siteKey.cryptoKey,
        encryptedBytes);

    return new Blob([decryptedBytes], { type: contentType || 'application/octet-stream' });
}

async function getSiteKey(siteId, keyUrlTemplate, ensure) {
    const cacheKey = `${siteId}:${ensure ? 'ensure' : 'read'}`;
    if (keyCache.has(cacheKey)) {
        return keyCache.get(cacheKey);
    }

    const url = keyUrlTemplate.replace('__SITE_ID__', String(siteId)) + (keyUrlTemplate.includes('?') ? `&ensure=${ensure}` : `?ensure=${ensure}`);
    const response = await fetch(url, { credentials: 'include' });
    if (!response.ok) {
        const payload = await safeReadJson(response);
        throw new Error(payload?.error || 'The site image key was unavailable.');
    }

    const payload = await response.json();
    const rawKeyBytes = base64ToBytes(payload.keyBase64);
    const cryptoKey = await crypto.subtle.importKey('raw', rawKeyBytes, 'AES-GCM', false, ['encrypt', 'decrypt']);
    const siteKey = {
        siteId: payload.siteId,
        keyVersion: payload.keyVersion,
        cryptoKey
    };

    keyCache.set(cacheKey, siteKey);
    return siteKey;
}

async function normalizeImage(file) {
    const bitmap = await createImageBitmap(file);
    const canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const context = canvas.getContext('2d');
    context.drawImage(bitmap, 0, 0, bitmap.width, bitmap.height);
    bitmap.close();

    const contentType = selectContentType(file.type);
    const blob = await canvasToBlob(canvas, contentType, 0.92);
    return { blob, width: canvas.width, height: canvas.height };
}

async function createThumbnail(blob, maxEdge) {
    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    context.drawImage(bitmap, 0, 0, width, height);
    bitmap.close();

    const blobResult = await canvasToBlob(canvas, selectContentType(blob.type), 0.85);
    return { blob: blobResult, width, height };
}

async function encryptBlob(blob, cryptoKey) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plaintext = await blob.arrayBuffer();
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cryptoKey, plaintext);
    return {
        ivBase64: bytesToBase64(iv),
        blob: new Blob([ciphertext], { type: 'application/octet-stream' })
    };
}

function selectContentType(contentType) {
    if (contentType === 'image/png' || contentType === 'image/webp') {
        return contentType;
    }

    return 'image/jpeg';
}

function canvasToBlob(canvas, contentType, quality) {
    return new Promise((resolve, reject) => {
        canvas.toBlob(blob => {
            if (!blob) {
                reject(new Error('The browser could not encode the image blob.'));
                return;
            }

            resolve(blob);
        }, contentType, quality);
    });
}

function bytesToBase64(bytes) {
    let binary = '';
    const input = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    input.forEach(byte => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
}

function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
}

async function safeReadJson(response) {
    try {
        return await response.json();
    } catch {
        return null;
    }
}

function ensureModal() {
    let shell = document.getElementById('encrypted-image-modal');
    if (shell) {
        return {
            shell,
            image: shell.querySelector('img'),
            caption: shell.querySelector('[data-role="caption"]'),
            closeElements: Array.from(shell.querySelectorAll('[data-role="close"]'))
        };
    }

    shell = document.createElement('div');
    shell.id = 'encrypted-image-modal';
    shell.className = 'encrypted-modal-shell';
    shell.hidden = true;
    shell.innerHTML = `
        <div class="encrypted-modal-backdrop" data-role="close"></div>
        <div class="encrypted-modal-card">
            <button type="button" class="encrypted-modal-close" data-role="close">Close</button>
            <img alt="Decrypted image preview" />
            <div class="encrypted-modal-caption" data-role="caption"></div>
        </div>`;
    document.body.appendChild(shell);

    return {
        shell,
        image: shell.querySelector('img'),
        caption: shell.querySelector('[data-role="caption"]'),
        closeElements: Array.from(shell.querySelectorAll('[data-role="close"]'))
    };
}
