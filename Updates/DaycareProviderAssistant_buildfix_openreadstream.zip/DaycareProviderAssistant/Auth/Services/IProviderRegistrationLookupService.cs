using DaycareProviderAssistant.Auth.Models;

namespace DaycareProviderAssistant.Auth.Services;

public interface IProviderRegistrationLookupService
{
    Task<ProviderRegistrationFormOptions> GetFormOptionsAsync(CancellationToken cancellationToken = default);
}
