using System.Data;
using System.ComponentModel.DataAnnotations;
using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed partial class ProviderRegistrationService : IProviderRegistrationService
{
    private static readonly EmailAddressAttribute EmailValidator = new();
    private static readonly Regex MultiSpaceRegex = MultiSpaceRegexFactory();

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly DpaPasswordHasher _passwordHasher;
    private readonly DpaAuthOptions _options;
    private readonly ILogger<ProviderRegistrationService> _logger;

    public ProviderRegistrationService(
        ISqlConnectionFactory connectionFactory,
        DpaPasswordHasher passwordHasher,
        IOptions<DpaAuthOptions> options,
        ILogger<ProviderRegistrationService> logger)
    {
        _connectionFactory = connectionFactory;
        _passwordHasher = passwordHasher;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<ProviderRegistrationOutcome> RegisterProviderOwnerAsync(
        ProviderRegistrationRequest request,
        string? remoteAddress,
        string? userAgent,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var validationErrors = Validate(request);
        if (validationErrors.Count > 0)
        {
            return new ProviderRegistrationOutcome
            {
                Succeeded = false,
                ErrorMessage = "Fix the highlighted fields and try again.",
                FieldErrors = validationErrors
            };
        }

        var firstName = NormalizeHumanName(request.FirstName);
        var lastName = NormalizeHumanName(request.LastName);
        var primaryEmail = NormalizeEmail(request.PrimaryEmail);
        var userName = NormalizeUserName(request.UserName);
        var normalizedUserName = userName.ToUpperInvariant();
        var providerName = NormalizeRequiredText(request.ProviderName, 200);
        var legalEntityName = NormalizeOptionalText(request.LegalEntityName, 200) ?? providerName;
        var businessEmail = NormalizeOptionalEmail(request.BusinessEmail) ?? primaryEmail;
        var siteName = NormalizeRequiredText(request.SiteName, 200);
        var licenseNumber = NormalizeOptionalText(request.LicenseNumber, 100);
        var licenseClassCode = NormalizeRequiredText(request.LicenseClassCode, 10).ToUpperInvariant();
        var timeZoneCode = NormalizeRequiredText(request.TimeZoneCode, 100);
        var passwordHash = _passwordHasher.Hash(request.Password);
        var correlationId = Guid.NewGuid();

        try
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = _options.ProviderRegistrationStoredProcedure;

            AddParameter(command, "@FirstName", SqlDbType.NVarChar, 100, firstName);
            AddParameter(command, "@LastName", SqlDbType.NVarChar, 100, lastName);
            AddParameter(command, "@PrimaryEmail", SqlDbType.NVarChar, 320, primaryEmail);
            AddParameter(command, "@UserName", SqlDbType.NVarChar, 320, userName);
            AddParameter(command, "@NormalizedUserName", SqlDbType.NVarChar, 320, normalizedUserName);
            AddParameter(command, "@ProviderName", SqlDbType.NVarChar, 200, providerName);
            AddParameter(command, "@LegalEntityName", SqlDbType.NVarChar, 200, legalEntityName);
            AddParameter(command, "@BusinessEmail", SqlDbType.NVarChar, 320, businessEmail);
            AddParameter(command, "@SiteName", SqlDbType.NVarChar, 200, siteName);
            AddNullableParameter(command, "@LicenseNumber", SqlDbType.NVarChar, 100, licenseNumber);
            AddParameter(command, "@LicenseClassCode", SqlDbType.NVarChar, 10, licenseClassCode);
            AddParameter(command, "@TimeZoneCode", SqlDbType.NVarChar, 100, timeZoneCode);
            AddParameter(command, "@PasswordHash", SqlDbType.NVarChar, 1000, passwordHash);
            AddParameter(command, "@HashAlgorithmCode", SqlDbType.NVarChar, 100, _options.PasswordHashAlgorithmCode);
            AddParameter(command, "@ProviderOwnerRoleCode", SqlDbType.NVarChar, 50, _options.ProviderOwnerRoleCode);
            AddParameter(command, "@PendingApprovalAccountStatusCode", SqlDbType.NVarChar, 50, _options.PendingApprovalAccountStatusCode);
            AddNullableParameter(command, "@RemoteAddress", SqlDbType.NVarChar, 64, NormalizeOptionalText(remoteAddress, 64));
            AddNullableParameter(command, "@UserAgent", SqlDbType.NVarChar, 512, NormalizeOptionalText(userAgent, 512));
            AddParameter(command, "@CorrelationID", SqlDbType.UniqueIdentifier, 0, correlationId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            while (true)
            {
                if (await reader.ReadAsync(cancellationToken) && HasColumn(reader, "PortalUserID"))
                {
                    return new ProviderRegistrationOutcome
                    {
                        Succeeded = true,
                        PortalUserId = GetNullableInt32(reader, "PortalUserID"),
                        ProviderId = GetNullableInt32(reader, "ProviderID"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        AccountStatusCode = GetNullableString(reader, "AccountStatusCode") ?? _options.PendingApprovalAccountStatusCode
                    };
                }

                if (!await reader.NextResultAsync(cancellationToken))
                {
                    break;
                }
            }

            return new ProviderRegistrationOutcome
            {
                Succeeded = true,
                AccountStatusCode = _options.PendingApprovalAccountStatusCode
            };
        }
        catch (SqlException ex) when (ex.Number is 2601 or 2627)
        {
            return new ProviderRegistrationOutcome
            {
                Succeeded = false,
                ErrorMessage = "That username or email is already registered.",
                FieldErrors = new Dictionary<string, List<string>>(StringComparer.Ordinal)
                {
                    [nameof(ProviderRegistrationRequest.UserName)] = new() { "That username may already be in use." },
                    [nameof(ProviderRegistrationRequest.PrimaryEmail)] = new() { "That email may already be in use." }
                }
            };
        }
        catch (SqlException ex)
        {
            _logger.LogWarning(ex, "Provider self-registration failed for username {UserName}.", userName);

            var fieldErrors = new Dictionary<string, List<string>>(StringComparer.Ordinal);

            if (ex.Message.Contains("License class code was not found", StringComparison.OrdinalIgnoreCase))
            {
                fieldErrors[nameof(ProviderRegistrationRequest.LicenseClassCode)] = new() { "The selected license class is not available in the database seed data." };
            }
            else if (ex.Message.Contains("Time zone code was not found", StringComparison.OrdinalIgnoreCase))
            {
                fieldErrors[nameof(ProviderRegistrationRequest.TimeZoneCode)] = new() { "The selected time zone is not available in the database seed data." };
            }
            else if (ex.Message.Contains("Provider owner role was not found", StringComparison.OrdinalIgnoreCase))
            {
                fieldErrors[nameof(ProviderRegistrationRequest.ProviderName)] = new() { "Provider registration reference data is incomplete. The provider-owner role is missing." };
            }

            return new ProviderRegistrationOutcome
            {
                Succeeded = false,
                ErrorMessage = string.IsNullOrWhiteSpace(ex.Message)
                    ? "Registration could not be submitted."
                    : ex.Message,
                FieldErrors = fieldErrors
            };
        }
    }

    private static Dictionary<string, List<string>> Validate(ProviderRegistrationRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        var errors = new Dictionary<string, List<string>>(StringComparer.Ordinal);

        static void AddError(Dictionary<string, List<string>> dict, string field, string message)
        {
            if (!dict.TryGetValue(field, out var list))
            {
                list = new List<string>();
                dict[field] = list;
            }

            list.Add(message);
        }

        if (string.IsNullOrWhiteSpace(request.FirstName))
        {
            AddError(errors, nameof(request.FirstName), "First name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.LastName))
        {
            AddError(errors, nameof(request.LastName), "Last name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.PrimaryEmail))
        {
            AddError(errors, nameof(request.PrimaryEmail), "Primary email is required.");
        }
        else if (!EmailValidator.IsValid(request.PrimaryEmail))
        {
            AddError(errors, nameof(request.PrimaryEmail), "Enter a valid primary email address.");
        }

        if (string.IsNullOrWhiteSpace(request.UserName))
        {
            AddError(errors, nameof(request.UserName), "Username is required.");
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            AddError(errors, nameof(request.Password), "Password is required.");
        }
        else
        {
            if (request.Password.Length < 12)
            {
                AddError(errors, nameof(request.Password), "Choose a password that is at least 12 characters long.");
            }

            if (!request.Password.Any(char.IsLetter) || !request.Password.Any(char.IsDigit))
            {
                AddError(errors, nameof(request.Password), "Choose a password that includes at least one letter and one number.");
            }
        }

        if (string.IsNullOrWhiteSpace(request.ConfirmPassword))
        {
            AddError(errors, nameof(request.ConfirmPassword), "Confirm password is required.");
        }
        else if (!string.Equals(request.Password, request.ConfirmPassword, StringComparison.Ordinal))
        {
            AddError(errors, nameof(request.ConfirmPassword), "The password and confirmation password do not match.");
        }

        if (string.IsNullOrWhiteSpace(request.ProviderName))
        {
            AddError(errors, nameof(request.ProviderName), "Provider name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.SiteName))
        {
            AddError(errors, nameof(request.SiteName), "Site name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.LicenseClassCode))
        {
            AddError(errors, nameof(request.LicenseClassCode), "License class code is required.");
        }

        if (string.IsNullOrWhiteSpace(request.TimeZoneCode))
        {
            AddError(errors, nameof(request.TimeZoneCode), "Time zone code is required.");
        }

        if (!string.IsNullOrWhiteSpace(request.BusinessEmail) && !EmailValidator.IsValid(request.BusinessEmail))
        {
            AddError(errors, nameof(request.BusinessEmail), "Enter a valid business email address or leave it blank.");
        }

        if (!request.TermsAccepted)
        {
            AddError(errors, nameof(request.TermsAccepted), "You must accept the registration terms before continuing.");
        }

        return errors;
    }

    private static int? GetNullableInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    private static bool HasColumn(SqlDataReader reader, string columnName)
    {
        for (var i = 0; i < reader.FieldCount; i++)
        {
            if (string.Equals(reader.GetName(i), columnName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static string NormalizeHumanName(string value)
        => NormalizeRequiredText(value, 100);

    private static string NormalizeEmail(string value)
        => NormalizeRequiredText(value, 320).Trim();

    private static string? NormalizeOptionalEmail(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : NormalizeOptionalText(value, 320)?.Trim();

    private static string NormalizeUserName(string value)
        => NormalizeRequiredText(value, 320);

    private static string NormalizeRequiredText(string value, int maxLength)
    {
        var normalized = NormalizeOptionalText(value, maxLength);
        if (string.IsNullOrWhiteSpace(normalized))
        {
            throw new InvalidOperationException("A required registration value normalized to null or empty.");
        }

        return normalized;
    }

    private static string? NormalizeOptionalText(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var normalized = MultiSpaceRegex.Replace(value.Trim(), " ");
        return normalized.Length <= maxLength ? normalized : normalized[..maxLength];
    }

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, int size, object value)
    {
        var parameter = command.Parameters.Add(name, dbType);
        if (size > 0)
        {
            parameter.Size = size;
        }

        parameter.Value = value;
    }

    private static void AddNullableParameter(SqlCommand command, string name, SqlDbType dbType, int size, object? value)
    {
        var parameter = command.Parameters.Add(name, dbType);
        if (size > 0)
        {
            parameter.Size = size;
        }

        parameter.Value = value ?? DBNull.Value;
    }

    [GeneratedRegex(@"\s+")]
    private static partial Regex MultiSpaceRegexFactory();
}
