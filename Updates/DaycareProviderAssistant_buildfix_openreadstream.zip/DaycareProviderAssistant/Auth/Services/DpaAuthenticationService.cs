using System.Security.Claims;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class DpaAuthenticationService : IDpaAuthenticationService
{
    private readonly IDpaUserStore _userStore;
    private readonly DpaPasswordHasher _passwordHasher;
    private readonly DpaClaimsPrincipalFactory _claimsPrincipalFactory;
    private readonly DpaAuthOptions _options;

    public DpaAuthenticationService(
        IDpaUserStore userStore,
        DpaPasswordHasher passwordHasher,
        DpaClaimsPrincipalFactory claimsPrincipalFactory,
        IOptions<DpaAuthOptions> options)
    {
        _userStore = userStore;
        _passwordHasher = passwordHasher;
        _claimsPrincipalFactory = claimsPrincipalFactory;
        _options = options.Value;
    }

    public async Task<LoginOutcome> PasswordSignInAsync(string userName, string password, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
        {
            return new LoginOutcome { Succeeded = false, ErrorMessage = "Enter both a username and password." };
        }

        var normalizedUserName = userName.Trim().ToUpperInvariant();
        var user = await _userStore.FindByNormalizedUserNameAsync(normalizedUserName, cancellationToken);
        if (user is null)
        {
            await _userStore.RecordFailedLoginAsync(null, userName, "Unknown username.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "Sign-in failed." };
        }

        if (!_options.AllowedAccountStatusCodes.Contains(user.AccountStatusCode, StringComparer.OrdinalIgnoreCase))
        {
            await _userStore.RecordFailedLoginAsync(user, userName, $"Account status '{user.AccountStatusCode}' is not allowed.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "This account is not allowed to sign in." };
        }

        if (user.Credential is null)
        {
            await _userStore.RecordFailedLoginAsync(user, userName, "No active primary credential exists for the account.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "This account is missing a credential record." };
        }

        if (!user.Credential.IsActive || user.Credential.IsDeleted)
        {
            await _userStore.RecordFailedLoginAsync(user, userName, "Credential is inactive.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "This credential is inactive." };
        }

        if (!string.Equals(user.Credential.CredentialTypeCode, _options.PasswordCredentialCode, StringComparison.OrdinalIgnoreCase))
        {
            await _userStore.RecordFailedLoginAsync(user, userName, "Primary credential is not password-based.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "This account is not configured for password sign-in." };
        }

        if (user.Credential.LockoutEndUtc.HasValue && user.Credential.LockoutEndUtc.Value > DateTimeOffset.UtcNow)
        {
            await _userStore.RecordFailedLoginAsync(user, userName, "Credential is locked out.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "This account is temporarily locked." };
        }

        var passwordResult = _passwordHasher.Verify(user.Credential.PasswordHash, password);
        if (passwordResult == PasswordVerificationResult.Failed)
        {
            await _userStore.RecordFailedLoginAsync(user, userName, "Password verification failed.", remoteAddress, userAgent, cancellationToken);
            return new LoginOutcome { Succeeded = false, ErrorMessage = "Sign-in failed." };
        }

        var loginSessionId = await _userStore.CreateLoginSessionAsync(user, remoteAddress, userAgent, cancellationToken);
        await _userStore.RecordSuccessfulLoginAsync(user, loginSessionId, remoteAddress, userAgent, cancellationToken);
        var principal = _claimsPrincipalFactory.CreatePrincipal(user, loginSessionId);
        var properties = new AuthenticationProperties
        {
            IsPersistent = true,
            IssuedUtc = DateTimeOffset.UtcNow,
            ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(_options.CookieSlidingExpirationMinutes),
            AllowRefresh = true,
            RedirectUri = "/"
        };

        return new LoginOutcome
        {
            Succeeded = true,
            Principal = principal,
            Properties = properties
        };
    }

    public async Task SignOutAsync(ClaimsPrincipal principal, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        if (!TryGetClaimValue(principal, DpaClaimTypes.PortalUserId, out var portalUserIdText)
            || !int.TryParse(portalUserIdText, out var portalUserId)
            || !TryGetClaimValue(principal, DpaClaimTypes.SessionId, out var sessionIdText)
            || !long.TryParse(sessionIdText, out var loginSessionId))
        {
            return;
        }

        await _userStore.RevokeSessionAsync(loginSessionId, portalUserId, remoteAddress, userAgent, cancellationToken);
    }

    private static bool TryGetClaimValue(ClaimsPrincipal principal, string claimType, out string? value)
    {
        value = principal.Claims.FirstOrDefault(claim => claim.Type == claimType)?.Value;
        return !string.IsNullOrWhiteSpace(value);
    }
}
