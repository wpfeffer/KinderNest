using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly IConfiguration _configuration;
    private readonly DpaAuthOptions _options;

    public SqlConnectionFactory(IConfiguration configuration, IOptions<DpaAuthOptions> options)
    {
        _configuration = configuration;
        _options = options.Value;
    }

    public async Task<SqlConnection> OpenConnectionAsync(CancellationToken cancellationToken = default)
    {
        var connectionString = _configuration.GetConnectionString(_options.ConnectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException($"Connection string '{_options.ConnectionStringName}' is not configured.");
        }

        var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        return connection;
    }
}
