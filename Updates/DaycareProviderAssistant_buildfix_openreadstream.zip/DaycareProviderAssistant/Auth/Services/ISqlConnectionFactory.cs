using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Auth.Services;

public interface ISqlConnectionFactory
{
    Task<SqlConnection> OpenConnectionAsync(CancellationToken cancellationToken = default);
}
