namespace DaycareProviderAssistant.Auth.Services;

public interface IAuthenticationAuditWriter
{
    Task WriteAsync(
        string eventTypeCode,
        string resultCode,
        int? portalUserId,
        int? portalCredentialId,
        long? loginSessionId,
        string? userNameAttempted,
        string? failureReason,
        string? remoteAddress,
        string? userAgent,
        string? notes,
        CancellationToken cancellationToken = default);
}
