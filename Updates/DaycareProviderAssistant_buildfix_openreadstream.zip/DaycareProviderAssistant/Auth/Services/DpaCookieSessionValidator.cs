using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class DpaCookieSessionValidator : CookieAuthenticationEvents
{
    private readonly IDpaUserStore _userStore;

    public DpaCookieSessionValidator(IDpaUserStore userStore)
    {
        _userStore = userStore;
    }

    public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
    {
        var portalUserIdText = context.Principal?.FindFirst(DpaClaimTypes.PortalUserId)?.Value;
        var sessionIdText = context.Principal?.FindFirst(DpaClaimTypes.SessionId)?.Value;

        if (!int.TryParse(portalUserIdText, out var portalUserId) || !long.TryParse(sessionIdText, out var loginSessionId))
        {
            context.RejectPrincipal();
            await context.HttpContext.SignOutAsync();
            return;
        }

        if (!await _userStore.IsSessionActiveAsync(loginSessionId, portalUserId, context.HttpContext.RequestAborted))
        {
            context.RejectPrincipal();
            await context.HttpContext.SignOutAsync();
        }
    }
}
