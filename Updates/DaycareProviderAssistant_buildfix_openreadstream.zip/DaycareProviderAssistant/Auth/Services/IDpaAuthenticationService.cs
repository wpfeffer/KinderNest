using System.Security.Claims;
using DaycareProviderAssistant.Auth.Models;

namespace DaycareProviderAssistant.Auth.Services;

public interface IDpaAuthenticationService
{
    Task<LoginOutcome> PasswordSignInAsync(string userName, string password, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
    Task SignOutAsync(ClaimsPrincipal principal, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
}
