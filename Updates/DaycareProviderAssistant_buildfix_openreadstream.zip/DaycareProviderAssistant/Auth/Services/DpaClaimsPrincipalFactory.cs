using System.Security.Claims;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class DpaClaimsPrincipalFactory
{
    private readonly DpaAuthOptions _options;

    public DpaClaimsPrincipalFactory(Microsoft.Extensions.Options.IOptions<DpaAuthOptions> options)
    {
        _options = options.Value;
    }

    public ClaimsPrincipal CreatePrincipal(AuthenticatedPortalUser user, long loginSessionId)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.PortalUserId.ToString()),
            new(ClaimTypes.Name, user.UserName),
            new(DpaClaimTypes.PortalUserId, user.PortalUserId.ToString()),
            new(DpaClaimTypes.PersonId, user.PersonId.ToString()),
            new(DpaClaimTypes.SessionId, loginSessionId.ToString()),
            new(DpaClaimTypes.DisplayName, user.DisplayName)
        };

        foreach (var roleCode in user.RoleCodes.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            claims.Add(new Claim(ClaimTypes.Role, roleCode));
        }

        if (user.RoleCodes.Any(role => _options.AdminRoleCodes.Contains(role, StringComparer.OrdinalIgnoreCase)))
        {
            claims.Add(new Claim(DpaClaimTypes.PortalAccess, DpaPortalValues.Admin));
        }

        if (user.HasProviderPortalAccess)
        {
            claims.Add(new Claim(DpaClaimTypes.PortalAccess, DpaPortalValues.Provider));
        }

        if (user.HasGuardianPortalAccess)
        {
            claims.Add(new Claim(DpaClaimTypes.PortalAccess, DpaPortalValues.Guardian));
        }

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        return new ClaimsPrincipal(identity);
    }
}
