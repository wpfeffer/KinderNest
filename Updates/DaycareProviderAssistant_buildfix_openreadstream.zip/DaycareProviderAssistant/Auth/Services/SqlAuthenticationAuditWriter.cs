using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class SqlAuthenticationAuditWriter : IAuthenticationAuditWriter
{
    private readonly ILogger<SqlAuthenticationAuditWriter> _logger;
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly DpaAuthOptions _options;

    public SqlAuthenticationAuditWriter(
        ILogger<SqlAuthenticationAuditWriter> logger,
        ISqlConnectionFactory connectionFactory,
        IOptions<DpaAuthOptions> options)
    {
        _logger = logger;
        _connectionFactory = connectionFactory;
        _options = options.Value;
    }

    public async Task WriteAsync(
        string eventTypeCode,
        string resultCode,
        int? portalUserId,
        int? portalCredentialId,
        long? loginSessionId,
        string? userNameAttempted,
        string? failureReason,
        string? remoteAddress,
        string? userAgent,
        string? notes,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            var eventTypeId = await LookupCodeValueIdAsync(connection, _options.AuthenticationEventTypeDomain, eventTypeCode, cancellationToken);
            var resultId = await LookupCodeValueIdAsync(connection, _options.AuthenticationResultDomain, resultCode, cancellationToken);

            if (eventTypeId is null || resultId is null)
            {
                _logger.LogWarning("Skipping authentication audit write because event/result codes were not found. EventType={EventTypeCode}, ResultCode={ResultCode}", eventTypeCode, resultCode);
                return;
            }

            await using var command = connection.CreateCommand();
            command.CommandText = """
                INSERT INTO audit.AuthenticationEvent
                (
                    PortalUserID,
                    PortalCredentialID,
                    LoginSessionID,
                    UserNameAttempted,
                    AuthenticationEventTypeCodeValueID,
                    AuthenticationResultCodeValueID,
                    FailureReason,
                    RemoteAddress,
                    UserAgent,
                    Notes
                )
                VALUES
                (
                    @PortalUserID,
                    @PortalCredentialID,
                    @LoginSessionID,
                    @UserNameAttempted,
                    @AuthenticationEventTypeCodeValueID,
                    @AuthenticationResultCodeValueID,
                    @FailureReason,
                    @RemoteAddress,
                    @UserAgent,
                    @Notes
                );
                """;
            command.Parameters.AddWithValue("@PortalUserID", (object?)portalUserId ?? DBNull.Value);
            command.Parameters.AddWithValue("@PortalCredentialID", (object?)portalCredentialId ?? DBNull.Value);
            command.Parameters.AddWithValue("@LoginSessionID", (object?)loginSessionId ?? DBNull.Value);
            command.Parameters.AddWithValue("@UserNameAttempted", (object?)userNameAttempted ?? DBNull.Value);
            command.Parameters.AddWithValue("@AuthenticationEventTypeCodeValueID", eventTypeId.Value);
            command.Parameters.AddWithValue("@AuthenticationResultCodeValueID", resultId.Value);
            command.Parameters.AddWithValue("@FailureReason", (object?)failureReason ?? DBNull.Value);
            command.Parameters.AddWithValue("@RemoteAddress", (object?)remoteAddress ?? DBNull.Value);
            command.Parameters.AddWithValue("@UserAgent", (object?)userAgent ?? DBNull.Value);
            command.Parameters.AddWithValue("@Notes", (object?)notes ?? DBNull.Value);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Authentication audit write failed. EventType={EventTypeCode}, ResultCode={ResultCode}", eventTypeCode, resultCode);
        }
    }

    private static async Task<int?> LookupCodeValueIdAsync(SqlConnection connection, string domain, string value, CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT TOP (1) CodeValueID
            FROM ref.CodeValue
            WHERE CodeDomain = @CodeDomain
              AND CodeValue = @CodeValue
              AND IsActive = 1;
            """;
        command.Parameters.AddWithValue("@CodeDomain", domain);
        command.Parameters.AddWithValue("@CodeValue", value);

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int id ? id : null;
    }
}
