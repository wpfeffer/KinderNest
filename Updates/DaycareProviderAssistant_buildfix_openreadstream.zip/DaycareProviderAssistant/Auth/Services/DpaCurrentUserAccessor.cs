using System.Security.Claims;
using DaycareProviderAssistant.Auth.Configuration;
using Microsoft.AspNetCore.Http;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class DpaCurrentUserAccessor
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public DpaCurrentUserAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public ClaimsPrincipal Principal => _httpContextAccessor.HttpContext?.User ?? new ClaimsPrincipal(new ClaimsIdentity());

    public int? PortalUserId => TryGetIntClaim(DpaClaimTypes.PortalUserId);
    public int? PersonId => TryGetIntClaim(DpaClaimTypes.PersonId);
    public long? SessionId => TryGetLongClaim(DpaClaimTypes.SessionId);
    public string DisplayName => Principal.FindFirst(DpaClaimTypes.DisplayName)?.Value
        ?? Principal.Identity?.Name
        ?? "Anonymous";

    public bool HasPortalAccess(string portalValue)
        => Principal.Claims.Any(claim => claim.Type == DpaClaimTypes.PortalAccess && string.Equals(claim.Value, portalValue, StringComparison.OrdinalIgnoreCase));

    private int? TryGetIntClaim(string claimType)
        => int.TryParse(Principal.FindFirst(claimType)?.Value, out var value) ? value : null;

    private long? TryGetLongClaim(string claimType)
        => long.TryParse(Principal.FindFirst(claimType)?.Value, out var value) ? value : null;
}
