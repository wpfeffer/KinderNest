using DaycareProviderAssistant.Auth.Models;

namespace DaycareProviderAssistant.Auth.Services;

public interface IProviderRegistrationService
{
    Task<ProviderRegistrationOutcome> RegisterProviderOwnerAsync(
        ProviderRegistrationRequest request,
        string? remoteAddress,
        string? userAgent,
        CancellationToken cancellationToken = default);
}
