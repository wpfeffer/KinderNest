using Microsoft.AspNetCore.Identity;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class DpaPasswordHasher
{
    private sealed class PasswordSubject;

    private readonly PasswordHasher<PasswordSubject> _hasher = new();
    private readonly PasswordSubject _subject = new();

    public PasswordVerificationResult Verify(string hashedPassword, string providedPassword)
    {
        return _hasher.VerifyHashedPassword(_subject, hashedPassword, providedPassword);
    }

    public string Hash(string password)
    {
        return _hasher.HashPassword(_subject, password);
    }
}
