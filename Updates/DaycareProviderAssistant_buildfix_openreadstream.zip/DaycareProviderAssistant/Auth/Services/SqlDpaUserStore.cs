using System.Security.Cryptography;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class SqlDpaUserStore : IDpaUserStore
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IAuthenticationAuditWriter _auditWriter;
    private readonly DpaAuthOptions _options;
    private readonly ILogger<SqlDpaUserStore> _logger;

    public SqlDpaUserStore(
        ISqlConnectionFactory connectionFactory,
        IAuthenticationAuditWriter auditWriter,
        IOptions<DpaAuthOptions> options,
        ILogger<SqlDpaUserStore> logger)
    {
        _connectionFactory = connectionFactory;
        _auditWriter = auditWriter;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<AuthenticatedPortalUser?> FindByNormalizedUserNameAsync(string normalizedUserName, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT TOP (1)
                u.PortalUserID,
                u.PersonID,
                u.UserName,
                u.NormalizedUserName,
                u.AccountStatusCode,
                u.MFAEnabled,
                p.FirstName,
                p.LastName,
                c.PortalCredentialID,
                c.PasswordHash,
                typeCv.CodeValue AS CredentialTypeCode,
                statusCv.CodeValue AS CredentialStatusCode,
                c.MustChangePassword,
                c.FailedAttemptCount,
                c.LockoutEndUTC,
                c.IsActive AS CredentialIsActive,
                c.IsDeleted AS CredentialIsDeleted
            FROM party.PortalUser u
            INNER JOIN party.Person p ON p.PersonID = u.PersonID
            LEFT JOIN sec.PortalCredential c ON c.PortalUserID = u.PortalUserID AND c.IsPrimary = 1 AND c.IsDeleted = 0
            LEFT JOIN ref.CodeValue typeCv ON typeCv.CodeValueID = c.CredentialTypeCodeValueID
            LEFT JOIN ref.CodeValue statusCv ON statusCv.CodeValueID = c.CredentialStatusCodeValueID
            WHERE u.NormalizedUserName = @NormalizedUserName
              AND u.IsActive = 1
              AND u.IsDeleted = 0
              AND p.IsActive = 1
              AND p.IsDeleted = 0;
            """;
        command.Parameters.AddWithValue("@NormalizedUserName", normalizedUserName);

        AuthenticatedPortalUser? user = null;

        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
        {
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            user = new AuthenticatedPortalUser
            {
                PortalUserId = reader.GetInt32(reader.GetOrdinal("PortalUserID")),
                PersonId = reader.GetInt32(reader.GetOrdinal("PersonID")),
                UserName = reader.GetString(reader.GetOrdinal("UserName")),
                NormalizedUserName = reader.GetString(reader.GetOrdinal("NormalizedUserName")),
                AccountStatusCode = reader.GetString(reader.GetOrdinal("AccountStatusCode")),
                MfaEnabled = reader.GetBoolean(reader.GetOrdinal("MFAEnabled")),
                DisplayName = BuildDisplayName(reader.GetString(reader.GetOrdinal("FirstName")), reader.GetString(reader.GetOrdinal("LastName"))),
                Credential = reader.IsDBNull(reader.GetOrdinal("PortalCredentialID"))
                    ? null
                    : new DpaCredentialRecord
                    {
                        PortalCredentialId = reader.GetInt32(reader.GetOrdinal("PortalCredentialID")),
                        PasswordHash = reader.GetString(reader.GetOrdinal("PasswordHash")),
                        CredentialTypeCode = reader.IsDBNull(reader.GetOrdinal("CredentialTypeCode")) ? null : reader.GetString(reader.GetOrdinal("CredentialTypeCode")),
                        CredentialStatusCode = reader.IsDBNull(reader.GetOrdinal("CredentialStatusCode")) ? null : reader.GetString(reader.GetOrdinal("CredentialStatusCode")),
                        MustChangePassword = reader.GetBoolean(reader.GetOrdinal("MustChangePassword")),
                        FailedAttemptCount = reader.GetInt32(reader.GetOrdinal("FailedAttemptCount")),
                        LockoutEndUtc = reader.IsDBNull(reader.GetOrdinal("LockoutEndUTC")) ? null : new DateTimeOffset(DateTime.SpecifyKind(reader.GetDateTime(reader.GetOrdinal("LockoutEndUTC")), DateTimeKind.Utc)),
                        IsActive = reader.GetBoolean(reader.GetOrdinal("CredentialIsActive")),
                        IsDeleted = reader.GetBoolean(reader.GetOrdinal("CredentialIsDeleted"))
                    }
            };
        }

        user.RoleCodes = await LoadRoleCodesAsync(connection, user.PortalUserId, cancellationToken);
        user.SiteIds = await LoadSiteIdsAsync(connection, user.PortalUserId, cancellationToken);
        user.GuardianChildIds = await LoadGuardianChildIdsAsync(connection, user.PersonId, cancellationToken);

        return user;
    }

    public async Task<bool> IsSessionActiveAsync(long loginSessionId, int portalUserId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT CASE WHEN EXISTS
            (
                SELECT 1
                FROM sec.LoginSession ls
                WHERE ls.LoginSessionID = @LoginSessionID
                  AND ls.PortalUserID = @PortalUserID
                  AND ls.RevokedUTC IS NULL
                  AND ls.RefreshTokenExpiresUTC >= SYSUTCDATETIME()
            ) THEN 1 ELSE 0 END;
            """;
        command.Parameters.AddWithValue("@LoginSessionID", loginSessionId);
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    public async Task<long> CreateLoginSessionAsync(AuthenticatedPortalUser user, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        var sessionStatusId = await LookupCodeValueIdAsync(connection, _options.SessionStatusDomain, _options.SessionStatusActiveCode, cancellationToken)
            ?? throw new InvalidOperationException($"Code value '{_options.SessionStatusActiveCode}' in domain '{_options.SessionStatusDomain}' was not found.");

        var tokenHash = CreateRandomTokenHash();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO sec.LoginSession
            (
                PortalUserID,
                PortalCredentialID,
                SessionStatusCodeValueID,
                RefreshTokenHash,
                RefreshTokenExpiresUTC,
                RemoteAddress,
                UserAgent,
                CreatedByUserID
            )
            OUTPUT INSERTED.LoginSessionID
            VALUES
            (
                @PortalUserID,
                @PortalCredentialID,
                @SessionStatusCodeValueID,
                @RefreshTokenHash,
                @RefreshTokenExpiresUTC,
                @RemoteAddress,
                @UserAgent,
                @CreatedByUserID
            );
            """;
        command.Parameters.AddWithValue("@PortalUserID", user.PortalUserId);
        command.Parameters.AddWithValue("@PortalCredentialID", (object?)user.Credential?.PortalCredentialId ?? DBNull.Value);
        command.Parameters.AddWithValue("@SessionStatusCodeValueID", sessionStatusId);
        command.Parameters.AddWithValue("@RefreshTokenHash", tokenHash);
        command.Parameters.AddWithValue("@RefreshTokenExpiresUTC", DateTime.UtcNow.AddMinutes(_options.CookieSlidingExpirationMinutes));
        command.Parameters.AddWithValue("@RemoteAddress", (object?)remoteAddress ?? DBNull.Value);
        command.Parameters.AddWithValue("@UserAgent", (object?)userAgent ?? DBNull.Value);
        command.Parameters.AddWithValue("@CreatedByUserID", user.PortalUserId);

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return Convert.ToInt64(result);
    }

    public async Task RecordSuccessfulLoginAsync(AuthenticatedPortalUser user, long loginSessionId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(cancellationToken);

        try
        {
            await ExecuteNonQueryAsync(connection, transaction, """
                UPDATE party.PortalUser
                   SET LastLoginUTC = SYSUTCDATETIME(),
                       ModifiedUTC = SYSUTCDATETIME(),
                       ModifiedByUserID = @PortalUserID
                 WHERE PortalUserID = @PortalUserID;
                """,
                cancellationToken,
                new SqlParameter("@PortalUserID", user.PortalUserId));

            if (user.Credential is not null)
            {
                await ExecuteNonQueryAsync(connection, transaction, """
                    UPDATE sec.PortalCredential
                       SET FailedAttemptCount = 0,
                           LastFailedAttemptUTC = NULL,
                           LockoutStartUTC = NULL,
                           LockoutEndUTC = NULL,
                           LastSuccessfulLoginUTC = SYSUTCDATETIME(),
                           ModifiedUTC = SYSUTCDATETIME(),
                           ModifiedByUserID = @PortalUserID
                     WHERE PortalCredentialID = @PortalCredentialID;
                    """,
                    cancellationToken,
                    new SqlParameter("@PortalUserID", user.PortalUserId),
                    new SqlParameter("@PortalCredentialID", user.Credential.PortalCredentialId));
            }

            await transaction.CommitAsync(cancellationToken);
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }

        await _auditWriter.WriteAsync(
            eventTypeCode: "LOGIN_SUCCESS",
            resultCode: _options.AuthenticationResultSuccessCode,
            portalUserId: user.PortalUserId,
            portalCredentialId: user.Credential?.PortalCredentialId,
            loginSessionId: loginSessionId,
            userNameAttempted: user.UserName,
            failureReason: null,
            remoteAddress: remoteAddress,
            userAgent: userAgent,
            notes: "Login session created.",
            cancellationToken: cancellationToken);
    }

    public async Task RecordFailedLoginAsync(AuthenticatedPortalUser? user, string? userNameAttempted, string? failureReason, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        int? portalUserId = user?.PortalUserId;
        int? portalCredentialId = user?.Credential?.PortalCredentialId;
        var resultCode = _options.AuthenticationResultFailureCode;
        string? notes = null;

        if (user?.Credential is not null)
        {
            await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
            var lockedStatusId = await LookupCodeValueIdAsync(connection, _options.CredentialStatusDomain, _options.CredentialStatusLockedCode, cancellationToken);
            await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(cancellationToken);

            try
            {
                await ExecuteNonQueryAsync(connection, transaction, """
                    UPDATE sec.PortalCredential
                       SET FailedAttemptCount = FailedAttemptCount + 1,
                           LastFailedAttemptUTC = SYSUTCDATETIME(),
                           LockoutStartUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN SYSUTCDATETIME() ELSE LockoutStartUTC END,
                           LockoutEndUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN DATEADD(MINUTE, @LockoutDurationMinutes, SYSUTCDATETIME()) ELSE LockoutEndUTC END,
                           CredentialStatusCodeValueID = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold AND @LockedStatusCodeValueID IS NOT NULL THEN @LockedStatusCodeValueID ELSE CredentialStatusCodeValueID END,
                           ModifiedUTC = SYSUTCDATETIME(),
                           ModifiedByUserID = @PortalUserID
                     WHERE PortalCredentialID = @PortalCredentialID;
                    """,
                    cancellationToken,
                    new SqlParameter("@LockoutThreshold", _options.LockoutThreshold),
                    new SqlParameter("@LockoutDurationMinutes", _options.LockoutDurationMinutes),
                    new SqlParameter("@LockedStatusCodeValueID", (object?)lockedStatusId ?? DBNull.Value),
                    new SqlParameter("@PortalUserID", user.PortalUserId),
                    new SqlParameter("@PortalCredentialID", user.Credential.PortalCredentialId));

                await using var readCommand = connection.CreateCommand();
                readCommand.Transaction = transaction;
                readCommand.CommandText = """
                    SELECT FailedAttemptCount, LockoutEndUTC
                    FROM sec.PortalCredential
                    WHERE PortalCredentialID = @PortalCredentialID;
                    """;
                readCommand.Parameters.AddWithValue("@PortalCredentialID", user.Credential.PortalCredentialId);

                await using (var reader = await readCommand.ExecuteReaderAsync(cancellationToken))
                {
                    if (await reader.ReadAsync(cancellationToken))
                    {
                        var failedCount = reader.GetInt32(0);
                        var lockedUntil = reader.IsDBNull(1) ? (DateTime?)null : reader.GetDateTime(1);
                        notes = $"FailedAttemptCount={failedCount}";
                        if (lockedUntil.HasValue && lockedUntil.Value >= DateTime.UtcNow)
                        {
                            resultCode = _options.AuthenticationResultBlockedCode;
                        }
                    }
                }

                await transaction.CommitAsync(cancellationToken);
            }
            catch
            {
                await transaction.RollbackAsync(cancellationToken);
                throw;
            }
        }

        await _auditWriter.WriteAsync(
            eventTypeCode: "LOGIN_FAILED",
            resultCode: resultCode,
            portalUserId: portalUserId,
            portalCredentialId: portalCredentialId,
            loginSessionId: null,
            userNameAttempted: userNameAttempted,
            failureReason: failureReason,
            remoteAddress: remoteAddress,
            userAgent: userAgent,
            notes: notes,
            cancellationToken: cancellationToken);
    }

    public async Task RevokeSessionAsync(long loginSessionId, int portalUserId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        var revokedStatusId = await LookupCodeValueIdAsync(connection, _options.SessionStatusDomain, _options.SessionStatusRevokedCode, cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = """
            UPDATE sec.LoginSession
               SET RevokedUTC = SYSUTCDATETIME(),
                   SessionStatusCodeValueID = COALESCE(@SessionStatusCodeValueID, SessionStatusCodeValueID),
                   RevocationReason = N'User signed out.',
                   ModifiedUTC = SYSUTCDATETIME(),
                   ModifiedByUserID = @PortalUserID
             WHERE LoginSessionID = @LoginSessionID
               AND PortalUserID = @PortalUserID
               AND RevokedUTC IS NULL;
            """;
        command.Parameters.AddWithValue("@SessionStatusCodeValueID", (object?)revokedStatusId ?? DBNull.Value);
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        command.Parameters.AddWithValue("@LoginSessionID", loginSessionId);
        await command.ExecuteNonQueryAsync(cancellationToken);

        await _auditWriter.WriteAsync(
            eventTypeCode: "LOGOUT",
            resultCode: _options.AuthenticationResultSuccessCode,
            portalUserId: portalUserId,
            portalCredentialId: null,
            loginSessionId: loginSessionId,
            userNameAttempted: null,
            failureReason: null,
            remoteAddress: remoteAddress,
            userAgent: userAgent,
            notes: "User signed out.",
            cancellationToken: cancellationToken);
    }

    public async Task<bool> CanAccessSiteAsync(int portalUserId, int siteId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT CASE WHEN EXISTS
            (
                SELECT 1
                FROM party.SiteUserAssignment sua
                WHERE sua.PortalUserID = @PortalUserID
                  AND sua.SiteID = @SiteID
                  AND sua.IsActive = 1
                  AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
                  AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
            ) THEN 1 ELSE 0 END;
            """;
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        command.Parameters.AddWithValue("@SiteID", siteId);
        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    public async Task<bool> CanAccessChildAsync(int portalUserId, int childId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT CASE WHEN EXISTS
            (
                SELECT 1
                FROM child.Child c
                WHERE c.ChildID = @ChildID
                  AND c.IsActive = 1
                  AND c.IsDeleted = 0
                  AND EXISTS
                  (
                      SELECT 1
                      FROM party.SiteUserAssignment sua
                      WHERE sua.PortalUserID = @PortalUserID
                        AND sua.SiteID = c.SiteID
                        AND sua.IsActive = 1
                        AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
                        AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
                  )
            )
            OR EXISTS
            (
                SELECT 1
                FROM party.PortalUser pu
                INNER JOIN child.ChildPersonRelationship cpr ON cpr.PersonID = pu.PersonID
                WHERE pu.PortalUserID = @PortalUserID
                  AND cpr.ChildID = @ChildID
                  AND cpr.IsActive = 1
                  AND cpr.IsDeleted = 0
                  AND cpr.HasPortalAccess = 1
                  AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
                  AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
            )
            THEN 1 ELSE 0 END;
            """;
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        command.Parameters.AddWithValue("@ChildID", childId);
        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int number && number == 1;
    }

    private static async Task<IReadOnlyCollection<string>> LoadRoleCodesAsync(SqlConnection connection, int portalUserId, CancellationToken cancellationToken)
    {
        var roles = new List<string>();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT DISTINCT r.RoleCode
            FROM party.PortalUserRole pur
            INNER JOIN ref.Role r ON r.RoleID = pur.RoleID
            WHERE pur.PortalUserID = @PortalUserID
              AND pur.IsActive = 1
              AND r.IsActive = 1
              AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
              AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME());
            """;
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            roles.Add(reader.GetString(0));
        }

        return roles;
    }

    private static async Task<IReadOnlyCollection<int>> LoadSiteIdsAsync(SqlConnection connection, int portalUserId, CancellationToken cancellationToken)
    {
        var siteIds = new List<int>();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT DISTINCT sua.SiteID
            FROM party.SiteUserAssignment sua
            WHERE sua.PortalUserID = @PortalUserID
              AND sua.IsActive = 1
              AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
              AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME());
            """;
        command.Parameters.AddWithValue("@PortalUserID", portalUserId);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            siteIds.Add(reader.GetInt32(0));
        }

        return siteIds;
    }

    private static async Task<IReadOnlyCollection<int>> LoadGuardianChildIdsAsync(SqlConnection connection, int personId, CancellationToken cancellationToken)
    {
        var childIds = new List<int>();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT DISTINCT cpr.ChildID
            FROM child.ChildPersonRelationship cpr
            WHERE cpr.PersonID = @PersonID
              AND cpr.HasPortalAccess = 1
              AND cpr.IsActive = 1
              AND cpr.IsDeleted = 0
              AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
              AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date));
            """;
        command.Parameters.AddWithValue("@PersonID", personId);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            childIds.Add(reader.GetInt32(0));
        }

        return childIds;
    }

    private static string BuildDisplayName(string firstName, string lastName)
        => string.Join(' ', new[] { firstName, lastName }.Where(part => !string.IsNullOrWhiteSpace(part)));

    private static async Task<int?> LookupCodeValueIdAsync(SqlConnection connection, string domain, string value, CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT TOP (1) CodeValueID
            FROM ref.CodeValue
            WHERE CodeDomain = @CodeDomain
              AND CodeValue = @CodeValue
              AND IsActive = 1;
            """;
        command.Parameters.AddWithValue("@CodeDomain", domain);
        command.Parameters.AddWithValue("@CodeValue", value);
        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is int codeValueId ? codeValueId : null;
    }

    private static byte[] CreateRandomTokenHash()
    {
        Span<byte> rawToken = stackalloc byte[32];
        RandomNumberGenerator.Fill(rawToken);
        return SHA256.HashData(rawToken);
    }

    private static async Task ExecuteNonQueryAsync(SqlConnection connection, SqlTransaction transaction, string sql, CancellationToken cancellationToken, params SqlParameter[] parameters)
    {
        await using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = sql;
        foreach (var parameter in parameters)
        {
            command.Parameters.Add(parameter);
        }

        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
