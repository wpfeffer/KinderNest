using DaycareProviderAssistant.Auth.Models;

namespace DaycareProviderAssistant.Auth.Services;

public interface IDpaUserStore
{
    Task<AuthenticatedPortalUser?> FindByNormalizedUserNameAsync(string normalizedUserName, CancellationToken cancellationToken = default);
    Task<bool> IsSessionActiveAsync(long loginSessionId, int portalUserId, CancellationToken cancellationToken = default);
    Task<long> CreateLoginSessionAsync(AuthenticatedPortalUser user, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
    Task RecordSuccessfulLoginAsync(AuthenticatedPortalUser user, long loginSessionId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
    Task RecordFailedLoginAsync(AuthenticatedPortalUser? user, string? userNameAttempted, string? failureReason, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
    Task RevokeSessionAsync(long loginSessionId, int portalUserId, string? remoteAddress, string? userAgent, CancellationToken cancellationToken = default);
    Task<bool> CanAccessSiteAsync(int portalUserId, int siteId, CancellationToken cancellationToken = default);
    Task<bool> CanAccessChildAsync(int portalUserId, int childId, CancellationToken cancellationToken = default);
}
