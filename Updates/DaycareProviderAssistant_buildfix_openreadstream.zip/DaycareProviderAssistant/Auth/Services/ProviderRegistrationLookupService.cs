using System.Data;
using DaycareProviderAssistant.Auth.Models;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Auth.Services;

public sealed class ProviderRegistrationLookupService : IProviderRegistrationLookupService
{
    private const string LicenseClassListStoredProcedure = "lic.usp_LicenseClass_ListActive";
    private const string TimeZoneListStoredProcedure = "ref.usp_TimeZone_ListActive";

    private readonly ISqlConnectionFactory _connectionFactory;

    public ProviderRegistrationLookupService(ISqlConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<ProviderRegistrationFormOptions> GetFormOptionsAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);

        var licenseClasses = await LoadLicenseClassesAsync(connection, cancellationToken);
        var timeZones = await LoadTimeZonesAsync(connection, cancellationToken);

        return new ProviderRegistrationFormOptions
        {
            LicenseClasses = licenseClasses,
            TimeZones = timeZones
        };
    }

    private static async Task<IReadOnlyList<ProviderRegistrationLicenseClassOption>> LoadLicenseClassesAsync(
        SqlConnection connection,
        CancellationToken cancellationToken)
    {
        var results = new List<ProviderRegistrationLicenseClassOption>();

        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = LicenseClassListStoredProcedure;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new ProviderRegistrationLicenseClassOption
            {
                LicenseClassId = reader.GetInt32(reader.GetOrdinal("LicenseClassID")),
                LicenseClassCode = reader.GetString(reader.GetOrdinal("LicenseClassCode")),
                LicenseClassName = reader.GetString(reader.GetOrdinal("LicenseClassName")),
                LicenseFamilyCode = reader.GetString(reader.GetOrdinal("LicenseFamilyCode")),
                Description = reader.IsDBNull(reader.GetOrdinal("Description"))
                    ? null
                    : reader.GetString(reader.GetOrdinal("Description"))
            });
        }

        return results;
    }

    private static async Task<IReadOnlyList<ProviderRegistrationTimeZoneOption>> LoadTimeZonesAsync(
        SqlConnection connection,
        CancellationToken cancellationToken)
    {
        var results = new List<ProviderRegistrationTimeZoneOption>();

        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = TimeZoneListStoredProcedure;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new ProviderRegistrationTimeZoneOption
            {
                TimeZoneId = reader.GetInt32(reader.GetOrdinal("TimeZoneID")),
                TimeZoneCode = reader.GetString(reader.GetOrdinal("TimeZoneCode")),
                WindowsTimeZoneName = reader.GetString(reader.GetOrdinal("WindowsTimeZoneName")),
                DisplayName = reader.GetString(reader.GetOrdinal("DisplayName")),
                UtcOffsetMinutesStandard = reader.GetInt32(reader.GetOrdinal("UtcOffsetMinutesStandard")),
                ObservesDst = reader.GetBoolean(reader.GetOrdinal("ObservesDst"))
            });
        }

        return results;
    }
}
