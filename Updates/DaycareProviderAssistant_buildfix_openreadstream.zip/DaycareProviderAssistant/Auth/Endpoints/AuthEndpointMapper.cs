using System.ComponentModel.DataAnnotations;
using DaycareProviderAssistant.Auth.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DaycareProviderAssistant.Auth.Endpoints;

public static class AuthEndpointMapper
{
    public static IEndpointRouteBuilder MapDpaAuthEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/auth");

        group.MapPost("/login", HandleLoginAsync)
            .AllowAnonymous()
            .DisableAntiforgery();

        group.MapPost("/logout", HandleLogoutAsync)
            .RequireAuthorization()
            .DisableAntiforgery();

        group.MapPost("/register/provider", HandleProviderRegistrationAsync)
            .AllowAnonymous();

        return endpoints;
    }

    private static async Task<IResult> HandleLoginAsync(
        [FromForm] LoginFormInput input,
        HttpContext httpContext,
        IDpaAuthenticationService authenticationService,
        CancellationToken cancellationToken)
    {
        var outcome = await authenticationService.PasswordSignInAsync(
            input.UserName ?? string.Empty,
            input.Password ?? string.Empty,
            httpContext.Connection.RemoteIpAddress?.ToString(),
            httpContext.Request.Headers.UserAgent.ToString(),
            cancellationToken);

        if (!outcome.Succeeded || outcome.Principal is null || outcome.Properties is null)
        {
            return TypedResults.LocalRedirect(BuildLoginRedirect(input.ReturnUrl, outcome.ErrorMessage ?? "Sign-in failed."));
        }

        await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, outcome.Principal, outcome.Properties);
        return TypedResults.LocalRedirect(NormalizeReturnUrl(input.ReturnUrl));
    }

    private static async Task<IResult> HandleLogoutAsync(
        [FromForm] LogoutFormInput input,
        HttpContext httpContext,
        IDpaAuthenticationService authenticationService,
        CancellationToken cancellationToken)
    {
        await authenticationService.SignOutAsync(
            httpContext.User,
            httpContext.Connection.RemoteIpAddress?.ToString(),
            httpContext.Request.Headers.UserAgent.ToString(),
            cancellationToken);

        await httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return TypedResults.LocalRedirect(NormalizeReturnUrl(input.ReturnUrl, fallback: "/"));
    }

    private static async Task<IResult> HandleProviderRegistrationAsync(
        [FromForm] ProviderRegistrationRequest? input,
        HttpContext httpContext,
        IProviderRegistrationService providerRegistrationService,
        CancellationToken cancellationToken)
    {
        if (input is null)
        {
            return TypedResults.LocalRedirect(BuildProviderRegistrationRedirect("error", "Registration form submission was empty or invalid."));
        }

        var outcome = await providerRegistrationService.RegisterProviderOwnerAsync(
            input,
            httpContext.Connection.RemoteIpAddress?.ToString(),
            httpContext.Request.Headers.UserAgent.ToString(),
            cancellationToken);

        if (!outcome.Succeeded)
        {
            return TypedResults.LocalRedirect(BuildProviderRegistrationRedirect("error", outcome.ErrorMessage ?? "Registration failed."));
        }

        return TypedResults.LocalRedirect(BuildProviderRegistrationRedirect("submitted", null));
    }

    private static string NormalizeReturnUrl(string? returnUrl, string fallback = "/")
    {
        if (string.IsNullOrWhiteSpace(returnUrl))
        {
            return fallback;
        }

        if (!Uri.TryCreate(returnUrl, UriKind.Relative, out _))
        {
            return fallback;
        }

        return returnUrl.StartsWith('/') ? returnUrl : fallback;
    }

    private static string BuildLoginRedirect(string? returnUrl, string error)
    {
        var encodedError = Uri.EscapeDataString(error);
        var encodedReturnUrl = Uri.EscapeDataString(NormalizeReturnUrl(returnUrl));
        return $"/auth/login?error={encodedError}&returnUrl={encodedReturnUrl}";
    }

    private static string BuildProviderRegistrationRedirect(string status, string? error)
    {
        var parts = new List<string> { $"status={Uri.EscapeDataString(status)}" };

        if (!string.IsNullOrWhiteSpace(error))
        {
            parts.Add($"error={Uri.EscapeDataString(error)}");
        }

        return $"/auth/register/provider?{string.Join("&", parts)}";
    }

    public sealed class LoginFormInput
    {
        [Required]
        public string? UserName { get; set; }

        [Required]
        public string? Password { get; set; }

        public string? ReturnUrl { get; set; }
    }

    public sealed class LogoutFormInput
    {
        public string? ReturnUrl { get; set; }
    }
}
