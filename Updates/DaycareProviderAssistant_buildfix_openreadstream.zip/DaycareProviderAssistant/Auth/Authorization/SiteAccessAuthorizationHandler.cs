using System.Security.Claims;
using DaycareProviderAssistant.Auth.Configuration;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.AspNetCore.Authorization;

namespace DaycareProviderAssistant.Auth.Authorization;

public sealed class SiteAccessAuthorizationHandler : AuthorizationHandler<SiteAccessRequirement>
{
    private readonly IDpaUserStore _userStore;
    private readonly DpaAuthOptions _options;

    public SiteAccessAuthorizationHandler(IDpaUserStore userStore, Microsoft.Extensions.Options.IOptions<DpaAuthOptions> options)
    {
        _userStore = userStore;
        _options = options.Value;
    }

    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, SiteAccessRequirement requirement)
    {
        var portalUserIdText = context.User.FindFirstValue(DpaClaimTypes.PortalUserId);
        if (!int.TryParse(portalUserIdText, out var portalUserId))
        {
            return;
        }

        if (context.User.Claims.Any(claim => claim.Type == ClaimTypes.Role && _options.AdminRoleCodes.Contains(claim.Value, StringComparer.OrdinalIgnoreCase)))
        {
            context.Succeed(requirement);
            return;
        }

        if (await _userStore.CanAccessSiteAsync(portalUserId, requirement.SiteId))
        {
            context.Succeed(requirement);
        }
    }
}
