using Microsoft.AspNetCore.Authorization;

namespace DaycareProviderAssistant.Auth.Authorization;

public sealed record SiteAccessRequirement(int SiteId) : IAuthorizationRequirement;
