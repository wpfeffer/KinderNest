using Microsoft.AspNetCore.Authorization;

namespace DaycareProviderAssistant.Auth.Authorization;

public sealed record ChildAccessRequirement(int ChildId) : IAuthorizationRequirement;
