namespace DaycareProviderAssistant.Auth.Configuration;

public static class DpaClaimTypes
{
    public const string PortalUserId = "dpa_portal_user_id";
    public const string PersonId = "dpa_person_id";
    public const string SessionId = "dpa_session_id";
    public const string PortalAccess = "dpa_portal_access";
    public const string DisplayName = "dpa_display_name";
}

public static class DpaPortalValues
{
    public const string Admin = "Admin";
    public const string Provider = "Provider";
    public const string Guardian = "Guardian";
}

public static class DpaPolicies
{
    public const string AdminPortal = "Dpa.AdminPortal";
    public const string ProviderPortal = "Dpa.ProviderPortal";
    public const string GuardianPortal = "Dpa.GuardianPortal";
}
