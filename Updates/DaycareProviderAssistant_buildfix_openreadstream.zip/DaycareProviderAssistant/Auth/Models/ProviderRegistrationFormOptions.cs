namespace DaycareProviderAssistant.Auth.Models;

public sealed class ProviderRegistrationFormOptions
{
    public static ProviderRegistrationFormOptions Empty { get; } = new();

    public IReadOnlyList<ProviderRegistrationLicenseClassOption> LicenseClasses { get; init; }
        = Array.Empty<ProviderRegistrationLicenseClassOption>();

    public IReadOnlyList<ProviderRegistrationTimeZoneOption> TimeZones { get; init; }
        = Array.Empty<ProviderRegistrationTimeZoneOption>();
}
