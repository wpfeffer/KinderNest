namespace DaycareProviderAssistant.Auth.Models;

public sealed class ProviderRegistrationTimeZoneOption
{
    public int TimeZoneId { get; init; }
    public string TimeZoneCode { get; init; } = string.Empty;
    public string WindowsTimeZoneName { get; init; } = string.Empty;
    public string DisplayName { get; init; } = string.Empty;
    public int UtcOffsetMinutesStandard { get; init; }
    public bool ObservesDst { get; init; }

    public string DisplayLabel => string.IsNullOrWhiteSpace(DisplayName)
        ? TimeZoneCode
        : $"{DisplayName} ({TimeZoneCode})";
}
