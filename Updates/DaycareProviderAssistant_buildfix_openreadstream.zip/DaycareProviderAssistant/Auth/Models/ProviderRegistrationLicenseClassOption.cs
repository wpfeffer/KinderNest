namespace DaycareProviderAssistant.Auth.Models;

public sealed class ProviderRegistrationLicenseClassOption
{
    public int LicenseClassId { get; init; }
    public string LicenseClassCode { get; init; } = string.Empty;
    public string LicenseClassName { get; init; } = string.Empty;
    public string LicenseFamilyCode { get; init; } = string.Empty;
    public string? Description { get; init; }

    public string DisplayLabel => string.IsNullOrWhiteSpace(LicenseClassName)
        ? LicenseClassCode
        : $"{LicenseClassCode} - {LicenseClassName}";
}
