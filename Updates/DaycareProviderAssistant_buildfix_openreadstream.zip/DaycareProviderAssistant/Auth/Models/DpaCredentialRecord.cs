namespace DaycareProviderAssistant.Auth.Models;

public sealed class DpaCredentialRecord
{
    public int PortalCredentialId { get; init; }
    public string PasswordHash { get; init; } = string.Empty;
    public string? CredentialTypeCode { get; init; }
    public string? CredentialStatusCode { get; init; }
    public bool MustChangePassword { get; init; }
    public int FailedAttemptCount { get; init; }
    public DateTimeOffset? LockoutEndUtc { get; init; }
    public bool IsActive { get; init; }
    public bool IsDeleted { get; init; }
}
