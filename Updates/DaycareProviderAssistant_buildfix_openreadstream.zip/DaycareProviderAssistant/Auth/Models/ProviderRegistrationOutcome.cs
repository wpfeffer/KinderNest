namespace DaycareProviderAssistant.Auth.Models;

public sealed class ProviderRegistrationOutcome
{
    public bool Succeeded { get; init; }
    public string? ErrorMessage { get; init; }
    public int? PortalUserId { get; init; }
    public int? ProviderId { get; init; }
    public int? SiteId { get; init; }
    public string? AccountStatusCode { get; init; }

    public Dictionary<string, List<string>> FieldErrors { get; init; } = new(StringComparer.Ordinal);

    public bool HasFieldErrors => FieldErrors.Count > 0;
}
