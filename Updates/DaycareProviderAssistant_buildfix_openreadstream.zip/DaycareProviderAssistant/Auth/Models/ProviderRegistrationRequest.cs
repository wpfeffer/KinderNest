using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Auth.Models;

public sealed class ProviderRegistrationRequest : IValidatableObject
{
    [Required]
    [StringLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    [StringLength(320)]
    public string PrimaryEmail { get; set; } = string.Empty;

    [Required]
    [StringLength(320)]
    public string UserName { get; set; } = string.Empty;

    [Required]
    [StringLength(200)]
    public string Password { get; set; } = string.Empty;

    [Required]
    [Compare(nameof(Password), ErrorMessage = "The password and confirmation password do not match.")]
    [StringLength(200)]
    public string ConfirmPassword { get; set; } = string.Empty;

    [Required]
    [StringLength(200)]
    public string ProviderName { get; set; } = string.Empty;

    [StringLength(200)]
    public string? LegalEntityName { get; set; }

    [EmailAddress]
    [StringLength(320)]
    public string? BusinessEmail { get; set; }

    [Required]
    [StringLength(200)]
    public string SiteName { get; set; } = string.Empty;

    [StringLength(100)]
    public string? LicenseNumber { get; set; }

    [Required]
    [StringLength(10)]
    public string LicenseClassCode { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string TimeZoneCode { get; set; } = "America/Chicago";

    [Range(typeof(bool), "true", "true", ErrorMessage = "You must accept the registration terms before continuing.")]
    public bool TermsAccepted { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!string.IsNullOrWhiteSpace(Password))
        {
            if (Password.Length < 12)
            {
                yield return new ValidationResult(
                    "Choose a password that is at least 12 characters long.",
                    new[] { nameof(Password) });
            }

            if (!Password.Any(char.IsLetter) || !Password.Any(char.IsDigit))
            {
                yield return new ValidationResult(
                    "Choose a password that includes at least one letter and one number.",
                    new[] { nameof(Password) });
            }
        }
    }
}
