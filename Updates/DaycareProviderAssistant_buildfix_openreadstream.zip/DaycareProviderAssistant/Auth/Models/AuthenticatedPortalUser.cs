namespace DaycareProviderAssistant.Auth.Models;

public sealed class AuthenticatedPortalUser
{
    public int PortalUserId { get; init; }
    public int PersonId { get; init; }
    public string UserName { get; init; } = string.Empty;
    public string NormalizedUserName { get; init; } = string.Empty;
    public string DisplayName { get; init; } = string.Empty;
    public string AccountStatusCode { get; init; } = string.Empty;
    public bool MfaEnabled { get; init; }
    public DpaCredentialRecord? Credential { get; set; }
    public IReadOnlyCollection<string> RoleCodes { get; set; } = Array.Empty<string>();
    public IReadOnlyCollection<int> SiteIds { get; set; } = Array.Empty<int>();
    public IReadOnlyCollection<int> GuardianChildIds { get; set; } = Array.Empty<int>();

    public bool HasProviderPortalAccess => SiteIds.Count > 0;
    public bool HasGuardianPortalAccess => GuardianChildIds.Count > 0;
}
