using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;

namespace DaycareProviderAssistant.Auth.Models;

public sealed class LoginOutcome
{
    public bool Succeeded { get; init; }
    public string? ErrorMessage { get; init; }
    public ClaimsPrincipal? Principal { get; init; }
    public AuthenticationProperties? Properties { get; init; }
}
