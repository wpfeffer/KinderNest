﻿CREATE SCHEMA [party]
    AUTHORIZATION [dbo];

