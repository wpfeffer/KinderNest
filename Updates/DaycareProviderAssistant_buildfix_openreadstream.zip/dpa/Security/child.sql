﻿CREATE SCHEMA [child]
    AUTHORIZATION [dbo];

