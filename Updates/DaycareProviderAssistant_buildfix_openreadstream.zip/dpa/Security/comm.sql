﻿CREATE SCHEMA [comm]
    AUTHORIZATION [dbo];

