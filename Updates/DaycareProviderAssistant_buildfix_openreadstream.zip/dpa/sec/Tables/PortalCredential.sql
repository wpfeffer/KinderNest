IF OBJECT_ID(N'sec.PortalCredential', N'U') IS NULL
BEGIN
    CREATE TABLE sec.PortalCredential
    (
        PortalCredentialID              INT IDENTITY(1,1)         NOT NULL,
        PortalUserID                    INT                       NOT NULL,
        CredentialTypeCodeValueID       INT                       NOT NULL,
        CredentialStatusCodeValueID     INT                       NOT NULL,
        PasswordHash                    NVARCHAR(1000)            NOT NULL,
        HashAlgorithmCodeValueID        INT                       NOT NULL,
        HashVersion                     INT                       NOT NULL CONSTRAINT DF_PortalCredential_HashVersion DEFAULT (1),
        PasswordSetUTC                  DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalCredential_PasswordSetUTC DEFAULT (SYSUTCDATETIME()),
        MustChangePassword              BIT                       NOT NULL CONSTRAINT DF_PortalCredential_MustChangePassword DEFAULT (0),
        FailedAttemptCount              INT                       NOT NULL CONSTRAINT DF_PortalCredential_FailedAttemptCount DEFAULT (0),
        LastFailedAttemptUTC            DATETIME2(0)              NULL,
        LockoutStartUTC                 DATETIME2(0)              NULL,
        LockoutEndUTC                   DATETIME2(0)              NULL,
        LastSuccessfulLoginUTC          DATETIME2(0)              NULL,
        LastPasswordResetUTC            DATETIME2(0)              NULL,
        IsPrimary                       BIT                       NOT NULL CONSTRAINT DF_PortalCredential_IsPrimary DEFAULT (1),
        IsActive                        BIT                       NOT NULL CONSTRAINT DF_PortalCredential_IsActive DEFAULT (1),
        IsDeleted                       BIT                       NOT NULL CONSTRAINT DF_PortalCredential_IsDeleted DEFAULT (0),
        CreatedUTC                      DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalCredential_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID                 INT                       NULL,
        ModifiedUTC                     DATETIME2(0)              NULL,
        ModifiedByUserID                INT                       NULL,
        DeletedUTC                      DATETIME2(0)              NULL,
        DeletedByUserID                 INT                       NULL,
        DeletedReason                   NVARCHAR(500)             NULL,
        RowVer                          ROWVERSION                NOT NULL,
        CONSTRAINT PK_PortalCredential PRIMARY KEY CLUSTERED (PortalCredentialID),
        CONSTRAINT FK_PortalCredential_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PortalCredential_CredentialTypeCodeValue FOREIGN KEY (CredentialTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_PortalCredential_CredentialStatusCodeValue FOREIGN KEY (CredentialStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_PortalCredential_HashAlgorithmCodeValue FOREIGN KEY (HashAlgorithmCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_PortalCredential_CreatedByUser FOREIGN KEY (CreatedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PortalCredential_ModifiedByUser FOREIGN KEY (ModifiedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PortalCredential_DeletedByUser FOREIGN KEY (DeletedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT CK_PortalCredential_FailedAttemptCount_NonNegative CHECK (FailedAttemptCount >= 0),
        CONSTRAINT CK_PortalCredential_LockoutWindow CHECK (LockoutEndUTC IS NULL OR LockoutStartUTC IS NULL OR LockoutEndUTC >= LockoutStartUTC),
        CONSTRAINT CK_PortalCredential_PasswordHash_NotBlank CHECK (LEN(LTRIM(RTRIM(PasswordHash))) > 0)
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_PortalCredential_PortalUser_PrimaryActive' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE UNIQUE INDEX UX_PortalCredential_PortalUser_PrimaryActive ON sec.PortalCredential (PortalUserID) WHERE IsDeleted = 0 AND IsActive = 1 AND IsPrimary = 1;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_CredentialTypeCodeValueID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_CredentialTypeCodeValueID ON sec.PortalCredential (CredentialTypeCodeValueID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_CredentialStatusCodeValueID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_CredentialStatusCodeValueID ON sec.PortalCredential (CredentialStatusCodeValueID, IsDeleted, IsActive);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_HashAlgorithmCodeValueID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_HashAlgorithmCodeValueID ON sec.PortalCredential (HashAlgorithmCodeValueID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_CreatedByUserID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_CreatedByUserID ON sec.PortalCredential (CreatedByUserID) WHERE CreatedByUserID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_ModifiedByUserID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_ModifiedByUserID ON sec.PortalCredential (ModifiedByUserID) WHERE ModifiedByUserID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredential_DeletedByUserID' AND object_id = OBJECT_ID(N'sec.PortalCredential'))
    CREATE INDEX IX_PortalCredential_DeletedByUserID ON sec.PortalCredential (DeletedByUserID) WHERE DeletedByUserID IS NOT NULL;
GO
