IF OBJECT_ID(N'sec.PortalCredentialHistory', N'U') IS NULL
BEGIN
    CREATE TABLE sec.PortalCredentialHistory
    (
        PortalCredentialHistoryID       BIGINT IDENTITY(1,1)      NOT NULL,
        PortalCredentialID              INT                       NOT NULL,
        PortalUserID                    INT                       NOT NULL,
        PasswordHash                    NVARCHAR(1000)            NOT NULL,
        HashAlgorithmCodeValueID        INT                       NOT NULL,
        HashVersion                     INT                       NOT NULL,
        ArchivedUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalCredentialHistory_ArchivedUTC DEFAULT (SYSUTCDATETIME()),
        ArchivedReason                  NVARCHAR(500)             NULL,
        CreatedUTC                      DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalCredentialHistory_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID                 INT                       NULL,
        CONSTRAINT PK_PortalCredentialHistory PRIMARY KEY CLUSTERED (PortalCredentialHistoryID),
        CONSTRAINT FK_PortalCredentialHistory_PortalCredential FOREIGN KEY (PortalCredentialID) REFERENCES sec.PortalCredential (PortalCredentialID),
        CONSTRAINT FK_PortalCredentialHistory_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PortalCredentialHistory_HashAlgorithmCodeValue FOREIGN KEY (HashAlgorithmCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_PortalCredentialHistory_CreatedByUser FOREIGN KEY (CreatedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT CK_PortalCredentialHistory_PasswordHash_NotBlank CHECK (LEN(LTRIM(RTRIM(PasswordHash))) > 0)
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredentialHistory_PortalCredentialID' AND object_id = OBJECT_ID(N'sec.PortalCredentialHistory'))
    CREATE INDEX IX_PortalCredentialHistory_PortalCredentialID ON sec.PortalCredentialHistory (PortalCredentialID, ArchivedUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredentialHistory_PortalUserID' AND object_id = OBJECT_ID(N'sec.PortalCredentialHistory'))
    CREATE INDEX IX_PortalCredentialHistory_PortalUserID ON sec.PortalCredentialHistory (PortalUserID, ArchivedUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredentialHistory_HashAlgorithmCodeValueID' AND object_id = OBJECT_ID(N'sec.PortalCredentialHistory'))
    CREATE INDEX IX_PortalCredentialHistory_HashAlgorithmCodeValueID ON sec.PortalCredentialHistory (HashAlgorithmCodeValueID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PortalCredentialHistory_CreatedByUserID' AND object_id = OBJECT_ID(N'sec.PortalCredentialHistory'))
    CREATE INDEX IX_PortalCredentialHistory_CreatedByUserID ON sec.PortalCredentialHistory (CreatedByUserID) WHERE CreatedByUserID IS NOT NULL;
GO
