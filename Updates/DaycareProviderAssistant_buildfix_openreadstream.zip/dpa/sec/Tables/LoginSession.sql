IF OBJECT_ID(N'sec.LoginSession', N'U') IS NULL
BEGIN
    CREATE TABLE sec.LoginSession
    (
        LoginSessionID                  BIGINT IDENTITY(1,1)      NOT NULL,
        PortalUserID                    INT                       NOT NULL,
        PortalCredentialID              INT                       NULL,
        SessionStatusCodeValueID        INT                       NOT NULL,
        RefreshTokenHash                VARBINARY(64)             NOT NULL,
        SessionStartedUTC               DATETIME2(0)              NOT NULL CONSTRAINT DF_LoginSession_SessionStartedUTC DEFAULT (SYSUTCDATETIME()),
        LastSeenUTC                     DATETIME2(0)              NULL,
        RefreshTokenExpiresUTC          DATETIME2(0)              NOT NULL,
        RevokedUTC                      DATETIME2(0)              NULL,
        RevocationReason                NVARCHAR(MAX)             NULL,
        MfaCompletedUTC                 DATETIME2(0)              NULL,
        RemoteAddress                   NVARCHAR(100)             NULL,
        UserAgent                       NVARCHAR(MAX)             NULL,
        DeviceName                      NVARCHAR(200)             NULL,
        DeviceFingerprint               NVARCHAR(500)             NULL,
        CreatedUTC                      DATETIME2(0)              NOT NULL CONSTRAINT DF_LoginSession_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID                 INT                       NULL,
        ModifiedUTC                     DATETIME2(0)              NULL,
        ModifiedByUserID                INT                       NULL,
        RowVer                          ROWVERSION                NOT NULL,
        CONSTRAINT PK_LoginSession PRIMARY KEY CLUSTERED (LoginSessionID),
        CONSTRAINT FK_LoginSession_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_LoginSession_PortalCredential FOREIGN KEY (PortalCredentialID) REFERENCES sec.PortalCredential (PortalCredentialID),
        CONSTRAINT FK_LoginSession_SessionStatusCodeValue FOREIGN KEY (SessionStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_LoginSession_CreatedByUser FOREIGN KEY (CreatedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_LoginSession_ModifiedByUser FOREIGN KEY (ModifiedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT CK_LoginSession_RefreshTokenWindow CHECK (RefreshTokenExpiresUTC >= SessionStartedUTC)
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LoginSession_PortalUserID' AND object_id = OBJECT_ID(N'sec.LoginSession'))
    CREATE INDEX IX_LoginSession_PortalUserID ON sec.LoginSession (PortalUserID, SessionStartedUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LoginSession_PortalCredentialID' AND object_id = OBJECT_ID(N'sec.LoginSession'))
    CREATE INDEX IX_LoginSession_PortalCredentialID ON sec.LoginSession (PortalCredentialID, SessionStartedUTC DESC) WHERE PortalCredentialID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LoginSession_SessionStatusCodeValueID' AND object_id = OBJECT_ID(N'sec.LoginSession'))
    CREATE INDEX IX_LoginSession_SessionStatusCodeValueID ON sec.LoginSession (SessionStatusCodeValueID, RefreshTokenExpiresUTC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LoginSession_CreatedByUserID' AND object_id = OBJECT_ID(N'sec.LoginSession'))
    CREATE INDEX IX_LoginSession_CreatedByUserID ON sec.LoginSession (CreatedByUserID) WHERE CreatedByUserID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LoginSession_ModifiedByUserID' AND object_id = OBJECT_ID(N'sec.LoginSession'))
    CREATE INDEX IX_LoginSession_ModifiedByUserID ON sec.LoginSession (ModifiedByUserID) WHERE ModifiedByUserID IS NOT NULL;
GO
