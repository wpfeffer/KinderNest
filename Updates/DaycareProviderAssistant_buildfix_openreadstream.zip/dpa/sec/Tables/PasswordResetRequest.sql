IF OBJECT_ID(N'sec.PasswordResetRequest', N'U') IS NULL
BEGIN
    CREATE TABLE sec.PasswordResetRequest
    (
        PasswordResetRequestID         BIGINT IDENTITY(1,1)      NOT NULL,
        PortalUserID                   INT                       NOT NULL,
        PortalCredentialID             INT                       NULL,
        ResetTokenHash                 VARBINARY(64)             NOT NULL,
        RequestStatusCodeValueID       INT                       NOT NULL,
        RequestedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_PasswordResetRequest_RequestedUTC DEFAULT (SYSUTCDATETIME()),
        ExpiresUTC                     DATETIME2(0)              NOT NULL,
        ConsumedUTC                    DATETIME2(0)              NULL,
        RevokedUTC                     DATETIME2(0)              NULL,
        RequestedByRemoteAddress       NVARCHAR(100)             NULL,
        RequestedByUserAgent           NVARCHAR(MAX)             NULL,
        CreatedUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_PasswordResetRequest_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID                INT                       NULL,
        ModifiedUTC                    DATETIME2(0)              NULL,
        ModifiedByUserID               INT                       NULL,
        RowVer                         ROWVERSION                NOT NULL,
        CONSTRAINT PK_PasswordResetRequest PRIMARY KEY CLUSTERED (PasswordResetRequestID),
        CONSTRAINT FK_PasswordResetRequest_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PasswordResetRequest_PortalCredential FOREIGN KEY (PortalCredentialID) REFERENCES sec.PortalCredential (PortalCredentialID),
        CONSTRAINT FK_PasswordResetRequest_RequestStatusCodeValue FOREIGN KEY (RequestStatusCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_PasswordResetRequest_CreatedByUser FOREIGN KEY (CreatedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_PasswordResetRequest_ModifiedByUser FOREIGN KEY (ModifiedByUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT CK_PasswordResetRequest_Window CHECK (ExpiresUTC >= RequestedUTC)
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PasswordResetRequest_PortalUserID' AND object_id = OBJECT_ID(N'sec.PasswordResetRequest'))
    CREATE INDEX IX_PasswordResetRequest_PortalUserID ON sec.PasswordResetRequest (PortalUserID, RequestedUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PasswordResetRequest_PortalCredentialID' AND object_id = OBJECT_ID(N'sec.PasswordResetRequest'))
    CREATE INDEX IX_PasswordResetRequest_PortalCredentialID ON sec.PasswordResetRequest (PortalCredentialID, RequestedUTC DESC) WHERE PortalCredentialID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PasswordResetRequest_RequestStatusCodeValueID' AND object_id = OBJECT_ID(N'sec.PasswordResetRequest'))
    CREATE INDEX IX_PasswordResetRequest_RequestStatusCodeValueID ON sec.PasswordResetRequest (RequestStatusCodeValueID, ExpiresUTC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PasswordResetRequest_CreatedByUserID' AND object_id = OBJECT_ID(N'sec.PasswordResetRequest'))
    CREATE INDEX IX_PasswordResetRequest_CreatedByUserID ON sec.PasswordResetRequest (CreatedByUserID) WHERE CreatedByUserID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_PasswordResetRequest_ModifiedByUserID' AND object_id = OBJECT_ID(N'sec.PasswordResetRequest'))
    CREATE INDEX IX_PasswordResetRequest_ModifiedByUserID ON sec.PasswordResetRequest (ModifiedByUserID) WHERE ModifiedByUserID IS NOT NULL;
GO
