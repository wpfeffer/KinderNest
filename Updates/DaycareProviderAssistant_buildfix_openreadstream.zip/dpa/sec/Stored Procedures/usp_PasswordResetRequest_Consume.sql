CREATE OR ALTER PROCEDURE sec.usp_PasswordResetRequest_Consume
    @PasswordResetRequestID          BIGINT,
    @NewPasswordHash                 NVARCHAR(1000),
    @HashAlgorithmCode               NVARCHAR(100),
    @HashVersion                     INT                = 1,
    @ChangedByUserID                 INT                = NULL,
    @MustChangePassword              BIT                = 0,
    @SiteID                          INT                = NULL,
    @CorrelationID                   UNIQUEIDENTIFIER   = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PortalCredentialID INT;
    DECLARE @RequestStatusCodeValueID INT;
    DECLARE @ConsumedStatusCodeValueID INT;
    DECLARE @Now DATETIME2(0) = SYSUTCDATETIME();

    SELECT @RequestStatusCodeValueID = prr.RequestStatusCodeValueID,
           @PortalUserID = prr.PortalUserID,
           @PortalCredentialID = prr.PortalCredentialID
    FROM sec.PasswordResetRequest prr
    WHERE prr.PasswordResetRequestID = @PasswordResetRequestID
      AND prr.RevokedUTC IS NULL
      AND prr.ConsumedUTC IS NULL
      AND prr.ExpiresUTC >= @Now;

    IF @PortalUserID IS NULL
    BEGIN
        THROW 50450, 'Password reset request was not found, already consumed, revoked, or expired.', 1;
    END;

    SELECT @ConsumedStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PasswordResetRequestStatus'
      AND cv.CodeValue = N'CONSUMED'
      AND cv.IsActive = 1;

    IF @ConsumedStatusCodeValueID IS NULL
    BEGIN
        THROW 50451, 'Consumed password reset request status code was not found.', 1;
    END;

    BEGIN TRANSACTION;

    EXEC sec.usp_PortalCredential_SetPassword
         @PortalUserID = @PortalUserID,
         @PasswordHash = @NewPasswordHash,
         @HashAlgorithmCode = @HashAlgorithmCode,
         @HashVersion = @HashVersion,
         @MustChangePassword = @MustChangePassword,
         @ChangedByUserID = @ChangedByUserID,
         @AuthenticationEventTypeCode = N'PASSWORD_RESET_COMPLETED',
         @SiteID = @SiteID,
         @CorrelationID = @CorrelationID,
         @Notes = N'Password reset request consumed.';

    UPDATE sec.PasswordResetRequest
       SET RequestStatusCodeValueID = @ConsumedStatusCodeValueID,
           ConsumedUTC = @Now,
           ModifiedUTC = @Now,
           ModifiedByUserID = @ChangedByUserID
     WHERE PasswordResetRequestID = @PasswordResetRequestID;

    COMMIT TRANSACTION;

    SELECT @PasswordResetRequestID AS PasswordResetRequestID;
END;
GO
