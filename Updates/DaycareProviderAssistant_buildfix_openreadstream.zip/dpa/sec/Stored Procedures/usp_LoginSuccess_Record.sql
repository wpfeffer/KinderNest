CREATE OR ALTER PROCEDURE sec.usp_LoginSuccess_Record
    @PortalUserID                    INT,
    @PortalCredentialID              INT                = NULL,
    @RefreshTokenHash                VARBINARY(64),
    @RefreshTokenExpiresUTC          DATETIME2(0),
    @RemoteAddress                   NVARCHAR(100)      = NULL,
    @UserAgent                       NVARCHAR(MAX)      = NULL,
    @DeviceName                      NVARCHAR(200)      = NULL,
    @DeviceFingerprint               NVARCHAR(500)      = NULL,
    @SiteID                          INT                = NULL,
    @CorrelationID                   UNIQUEIDENTIFIER   = NULL,
    @CreatedByUserID                 INT                = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ActiveStatusCodeValueID INT;
    DECLARE @SessionStatusCodeValueID INT;
    DECLARE @LoginSessionID BIGINT;

    SELECT @ActiveStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'ACTIVE'
      AND cv.IsActive = 1;

    SELECT @SessionStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'LoginSessionStatus'
      AND cv.CodeValue = N'ACTIVE'
      AND cv.IsActive = 1;

    IF @SessionStatusCodeValueID IS NULL
    BEGIN
        THROW 50420, 'Active login session status code was not found.', 1;
    END;

    BEGIN TRANSACTION;

    INSERT INTO sec.LoginSession
    (
        PortalUserID,
        PortalCredentialID,
        SessionStatusCodeValueID,
        RefreshTokenHash,
        RefreshTokenExpiresUTC,
        RemoteAddress,
        UserAgent,
        DeviceName,
        DeviceFingerprint,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @PortalCredentialID,
        @SessionStatusCodeValueID,
        @RefreshTokenHash,
        @RefreshTokenExpiresUTC,
        @RemoteAddress,
        @UserAgent,
        @DeviceName,
        @DeviceFingerprint,
        @CreatedByUserID
    );

    SET @LoginSessionID = SCOPE_IDENTITY();

    UPDATE party.PortalUser
       SET LastLoginUTC = SYSUTCDATETIME(),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = COALESCE(@CreatedByUserID, @PortalUserID)
     WHERE PortalUserID = @PortalUserID;

    IF @PortalCredentialID IS NOT NULL
    BEGIN
        UPDATE sec.PortalCredential
           SET CredentialStatusCodeValueID = COALESCE(@ActiveStatusCodeValueID, CredentialStatusCodeValueID),
               FailedAttemptCount = 0,
               LastFailedAttemptUTC = NULL,
               LockoutStartUTC = NULL,
               LockoutEndUTC = NULL,
               LastSuccessfulLoginUTC = SYSUTCDATETIME(),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = COALESCE(@CreatedByUserID, @PortalUserID)
         WHERE PortalCredentialID = @PortalCredentialID;
    END;

    EXEC audit.usp_WriteAuthenticationEvent
         @AuthenticationEventTypeCode = N'LOGIN_SUCCESS',
         @AuthenticationResultCode = N'SUCCESS',
         @PortalUserID = @PortalUserID,
         @PortalCredentialID = @PortalCredentialID,
         @LoginSessionID = @LoginSessionID,
         @SiteID = @SiteID,
         @RemoteAddress = @RemoteAddress,
         @UserAgent = @UserAgent,
         @CorrelationID = @CorrelationID,
         @Notes = N'Login session created.';

    COMMIT TRANSACTION;

    SELECT @LoginSessionID AS LoginSessionID;
END;
GO
