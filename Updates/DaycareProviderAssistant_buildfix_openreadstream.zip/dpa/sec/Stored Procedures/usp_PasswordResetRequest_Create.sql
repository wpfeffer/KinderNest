CREATE OR ALTER PROCEDURE sec.usp_PasswordResetRequest_Create
    @PortalUserID                    INT,
    @PortalCredentialID              INT                = NULL,
    @ResetTokenHash                  VARBINARY(64),
    @ExpiresUTC                      DATETIME2(0),
    @RequestedByRemoteAddress        NVARCHAR(100)      = NULL,
    @RequestedByUserAgent            NVARCHAR(MAX)      = NULL,
    @CorrelationID                   UNIQUEIDENTIFIER   = NULL,
    @CreatedByUserID                 INT                = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RequestStatusCodeValueID INT;
    DECLARE @PasswordResetRequestID BIGINT;

    SELECT @RequestStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PasswordResetRequestStatus'
      AND cv.CodeValue = N'PENDING'
      AND cv.IsActive = 1;

    IF @RequestStatusCodeValueID IS NULL
    BEGIN
        THROW 50440, 'Pending password reset request status code was not found.', 1;
    END;

    INSERT INTO sec.PasswordResetRequest
    (
        PortalUserID,
        PortalCredentialID,
        ResetTokenHash,
        RequestStatusCodeValueID,
        ExpiresUTC,
        RequestedByRemoteAddress,
        RequestedByUserAgent,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @PortalCredentialID,
        @ResetTokenHash,
        @RequestStatusCodeValueID,
        @ExpiresUTC,
        @RequestedByRemoteAddress,
        @RequestedByUserAgent,
        @CreatedByUserID
    );

    SET @PasswordResetRequestID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuthenticationEvent
         @AuthenticationEventTypeCode = N'PASSWORD_RESET_REQUESTED',
         @AuthenticationResultCode = N'SUCCESS',
         @PortalUserID = @PortalUserID,
         @PortalCredentialID = @PortalCredentialID,
         @RemoteAddress = @RequestedByRemoteAddress,
         @UserAgent = @RequestedByUserAgent,
         @CorrelationID = @CorrelationID,
         @Notes = N'Password reset request created.';

    SELECT @PasswordResetRequestID AS PasswordResetRequestID;
END;
GO
