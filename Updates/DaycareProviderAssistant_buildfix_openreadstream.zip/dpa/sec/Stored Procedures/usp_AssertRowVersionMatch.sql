CREATE OR ALTER PROCEDURE sec.usp_AssertRowVersionMatch
    @SchemaName                 NVARCHAR(128),
    @TableName                  NVARCHAR(128),
    @PrimaryKeyColumn           NVARCHAR(128),
    @PrimaryKeyValue            NVARCHAR(128),
    @ExpectedRowVer             BINARY(8)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Sql NVARCHAR(MAX);
    DECLARE @ActualRowVer BINARY(8);

    SET @Sql = N'
        SELECT @OutRowVer = RowVer
        FROM ' + QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName) + N'
        WHERE ' + QUOTENAME(@PrimaryKeyColumn) + N' = @PkValue;';

    EXEC sp_executesql
        @Sql,
        N'@PkValue NVARCHAR(128), @OutRowVer BINARY(8) OUTPUT',
        @PkValue = @PrimaryKeyValue,
        @OutRowVer = @ActualRowVer OUTPUT;

    IF @ActualRowVer IS NULL
    BEGIN
        THROW 50260, 'Concurrency check failed because the target record was not found.', 1;
    END;

    IF @ActualRowVer <> @ExpectedRowVer
    BEGIN
        THROW 50261, 'Concurrency check failed because the record has changed since it was last read.', 1;
    END;
END;