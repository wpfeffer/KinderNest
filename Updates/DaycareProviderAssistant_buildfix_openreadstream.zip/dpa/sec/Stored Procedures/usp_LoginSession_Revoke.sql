CREATE OR ALTER PROCEDURE sec.usp_LoginSession_Revoke
    @LoginSessionID                  BIGINT,
    @RevokedByUserID                INT                = NULL,
    @RevocationReason               NVARCHAR(MAX)      = NULL,
    @CorrelationID                  UNIQUEIDENTIFIER   = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PortalCredentialID INT;
    DECLARE @RemoteAddress NVARCHAR(100);
    DECLARE @UserAgent NVARCHAR(MAX);
    DECLARE @RevokedStatusCodeValueID INT;

    SELECT @RevokedStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'LoginSessionStatus'
      AND cv.CodeValue = N'REVOKED'
      AND cv.IsActive = 1;

    IF @RevokedStatusCodeValueID IS NULL
    BEGIN
        THROW 50430, 'Revoked login session status code was not found.', 1;
    END;

    SELECT
        @PortalUserID = ls.PortalUserID,
        @PortalCredentialID = ls.PortalCredentialID,
        @RemoteAddress = ls.RemoteAddress,
        @UserAgent = ls.UserAgent
    FROM sec.LoginSession ls
    WHERE ls.LoginSessionID = @LoginSessionID;

    IF @PortalUserID IS NULL
    BEGIN
        THROW 50431, 'Login session was not found.', 1;
    END;

    UPDATE sec.LoginSession
       SET SessionStatusCodeValueID = @RevokedStatusCodeValueID,
           RevokedUTC = SYSUTCDATETIME(),
           RevocationReason = @RevocationReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @RevokedByUserID
     WHERE LoginSessionID = @LoginSessionID;

    EXEC audit.usp_WriteAuthenticationEvent
         @AuthenticationEventTypeCode = N'LOGOUT',
         @AuthenticationResultCode = N'SUCCESS',
         @PortalUserID = @PortalUserID,
         @PortalCredentialID = @PortalCredentialID,
         @LoginSessionID = @LoginSessionID,
         @RemoteAddress = @RemoteAddress,
         @UserAgent = @UserAgent,
         @CorrelationID = @CorrelationID,
         @Notes = @RevocationReason;

    SELECT @LoginSessionID AS LoginSessionID;
END;
GO
