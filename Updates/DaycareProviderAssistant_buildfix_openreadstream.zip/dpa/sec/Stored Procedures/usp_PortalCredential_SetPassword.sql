CREATE OR ALTER PROCEDURE sec.usp_PortalCredential_SetPassword
    @PortalUserID                    INT,
    @PasswordHash                    NVARCHAR(1000),
    @HashAlgorithmCode               NVARCHAR(100),
    @HashVersion                     INT                = 1,
    @MustChangePassword              BIT                = 0,
    @ChangedByUserID                 INT                = NULL,
    @AuthenticationEventTypeCode     NVARCHAR(100)      = N'PASSWORD_CHANGED',
    @SiteID                          INT                = NULL,
    @CorrelationID                   UNIQUEIDENTIFIER   = NULL,
    @Notes                           NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @CredentialTypeCodeValueID INT;
    DECLARE @CredentialStatusCodeValueID INT;
    DECLARE @HashAlgorithmCodeValueID INT;
    DECLARE @PortalCredentialID INT;

    SELECT @CredentialTypeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialType'
      AND cv.CodeValue = N'PASSWORD'
      AND cv.IsActive = 1;

    SELECT @CredentialStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'ACTIVE'
      AND cv.IsActive = 1;

    SELECT @HashAlgorithmCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HashAlgorithm'
      AND cv.CodeValue = @HashAlgorithmCode
      AND cv.IsActive = 1;

    IF @CredentialTypeCodeValueID IS NULL OR @CredentialStatusCodeValueID IS NULL OR @HashAlgorithmCodeValueID IS NULL
    BEGIN
        THROW 50410, 'One or more credential reference codes required for password storage were not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50411, 'Portal user not found or deleted.', 1;
    END;

    BEGIN TRANSACTION;

    SELECT TOP (1)
           @PortalCredentialID = pc.PortalCredentialID
    FROM sec.PortalCredential pc
    WHERE pc.PortalUserID = @PortalUserID
      AND pc.IsDeleted = 0
      AND pc.IsActive = 1
      AND pc.IsPrimary = 1
    ORDER BY pc.PortalCredentialID DESC;

    IF @PortalCredentialID IS NOT NULL
    BEGIN
        INSERT INTO sec.PortalCredentialHistory
        (
            PortalCredentialID,
            PortalUserID,
            PasswordHash,
            HashAlgorithmCodeValueID,
            HashVersion,
            ArchivedReason,
            CreatedByUserID
        )
        SELECT
            pc.PortalCredentialID,
            pc.PortalUserID,
            pc.PasswordHash,
            pc.HashAlgorithmCodeValueID,
            pc.HashVersion,
            N'Password hash superseded.',
            @ChangedByUserID
        FROM sec.PortalCredential pc
        WHERE pc.PortalCredentialID = @PortalCredentialID;

        UPDATE sec.PortalCredential
           SET CredentialTypeCodeValueID = @CredentialTypeCodeValueID,
               CredentialStatusCodeValueID = @CredentialStatusCodeValueID,
               PasswordHash = @PasswordHash,
               HashAlgorithmCodeValueID = @HashAlgorithmCodeValueID,
               HashVersion = @HashVersion,
               PasswordSetUTC = SYSUTCDATETIME(),
               MustChangePassword = @MustChangePassword,
               FailedAttemptCount = 0,
               LastFailedAttemptUTC = NULL,
               LockoutStartUTC = NULL,
               LockoutEndUTC = NULL,
               LastPasswordResetUTC = CASE WHEN @AuthenticationEventTypeCode = N'PASSWORD_RESET_COMPLETED' THEN SYSUTCDATETIME() ELSE LastPasswordResetUTC END,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PortalCredentialID = @PortalCredentialID;
    END
    ELSE
    BEGIN
        INSERT INTO sec.PortalCredential
        (
            PortalUserID,
            CredentialTypeCodeValueID,
            CredentialStatusCodeValueID,
            PasswordHash,
            HashAlgorithmCodeValueID,
            HashVersion,
            MustChangePassword,
            IsPrimary,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @PortalUserID,
            @CredentialTypeCodeValueID,
            @CredentialStatusCodeValueID,
            @PasswordHash,
            @HashAlgorithmCodeValueID,
            @HashVersion,
            @MustChangePassword,
            1,
            1,
            0,
            @ChangedByUserID
        );

        SET @PortalCredentialID = SCOPE_IDENTITY();
    END;

    EXEC audit.usp_WriteAuthenticationEvent
         @AuthenticationEventTypeCode = @AuthenticationEventTypeCode,
         @AuthenticationResultCode = N'SUCCESS',
         @PortalUserID = @PortalUserID,
         @PortalCredentialID = @PortalCredentialID,
         @SiteID = @SiteID,
         @CorrelationID = @CorrelationID,
         @Notes = @Notes;

    COMMIT TRANSACTION;

    SELECT @PortalCredentialID AS PortalCredentialID;
END;
GO
