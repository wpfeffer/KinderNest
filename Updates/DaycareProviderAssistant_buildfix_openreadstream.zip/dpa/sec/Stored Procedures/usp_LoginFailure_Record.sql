CREATE OR ALTER PROCEDURE sec.usp_LoginFailure_Record
    @PortalUserID                    INT                = NULL,
    @PortalCredentialID              INT                = NULL,
    @UserNameAttempted               NVARCHAR(320)      = NULL,
    @FailureReason                   NVARCHAR(MAX)      = NULL,
    @RemoteAddress                   NVARCHAR(100)      = NULL,
    @UserAgent                       NVARCHAR(MAX)      = NULL,
    @SiteID                          INT                = NULL,
    @CorrelationID                   UNIQUEIDENTIFIER   = NULL,
    @LockoutThreshold                INT                = 5,
    @LockoutDurationMinutes          INT                = 15
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LockedStatusCodeValueID INT;
    DECLARE @NewFailedAttemptCount INT;
    DECLARE @LockoutTriggered BIT = 0;
    DECLARE @AuthenticationResultCode NVARCHAR(100) = N'FAILURE';
    DECLARE @Notes NVARCHAR(MAX) = NULL;

    SELECT @LockedStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    BEGIN TRANSACTION;

    IF @PortalCredentialID IS NOT NULL
    BEGIN
        UPDATE sec.PortalCredential
           SET FailedAttemptCount = FailedAttemptCount + 1,
               LastFailedAttemptUTC = SYSUTCDATETIME(),
               LockoutStartUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN SYSUTCDATETIME() ELSE LockoutStartUTC END,
               LockoutEndUTC = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold THEN DATEADD(MINUTE, @LockoutDurationMinutes, SYSUTCDATETIME()) ELSE LockoutEndUTC END,
               CredentialStatusCodeValueID = CASE WHEN FailedAttemptCount + 1 >= @LockoutThreshold AND @LockedStatusCodeValueID IS NOT NULL THEN @LockedStatusCodeValueID ELSE CredentialStatusCodeValueID END,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @PortalUserID
         WHERE PortalCredentialID = @PortalCredentialID;

        SELECT
            @NewFailedAttemptCount = pc.FailedAttemptCount,
            @LockoutTriggered = CASE WHEN pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME() THEN 1 ELSE 0 END
        FROM sec.PortalCredential pc
        WHERE pc.PortalCredentialID = @PortalCredentialID;
    END;

    COMMIT TRANSACTION;

    IF @LockoutTriggered = 1
    BEGIN
        SET @AuthenticationResultCode = N'BLOCKED';
    END;

    IF @PortalCredentialID IS NOT NULL
    BEGIN
        SET @Notes = CONCAT(N'FailedAttemptCount=', COALESCE(CONVERT(NVARCHAR(20), @NewFailedAttemptCount), N'0'));
    END;

    EXEC audit.usp_WriteAuthenticationEvent
         @AuthenticationEventTypeCode = N'LOGIN_FAILED',
         @AuthenticationResultCode = @AuthenticationResultCode,
         @PortalUserID = @PortalUserID,
         @PortalCredentialID = @PortalCredentialID,
         @UserNameAttempted = @UserNameAttempted,
         @FailureReason = @FailureReason,
         @SiteID = @SiteID,
         @RemoteAddress = @RemoteAddress,
         @UserAgent = @UserAgent,
         @CorrelationID = @CorrelationID,
         @Notes = @Notes;

    IF @LockoutTriggered = 1
    BEGIN
        EXEC audit.usp_WriteAuthenticationEvent
             @AuthenticationEventTypeCode = N'ACCOUNT_LOCKED',
             @AuthenticationResultCode = N'SUCCESS',
             @PortalUserID = @PortalUserID,
             @PortalCredentialID = @PortalCredentialID,
             @UserNameAttempted = @UserNameAttempted,
             @FailureReason = @FailureReason,
             @SiteID = @SiteID,
             @RemoteAddress = @RemoteAddress,
             @UserAgent = @UserAgent,
             @CorrelationID = @CorrelationID,
             @Notes = N'Credential lockout triggered by repeated failed login attempts.';
    END;

    SELECT COALESCE(@NewFailedAttemptCount, 0) AS FailedAttemptCount,
           @LockoutTriggered AS LockoutTriggered;
END;
GO
