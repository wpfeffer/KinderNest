﻿CREATE FUNCTION sec.fn_HasRoleCode
(
    @PortalUserID                INT,
    @RoleCode                    NVARCHAR(50)
)
RETURNS BIT
AS
BEGIN
    DECLARE @HasRole BIT = 0;

    IF EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND r.RoleCode = @RoleCode
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        SET @HasRole = 1;
    END;

    RETURN @HasRole;
END;