﻿CREATE FUNCTION sec.fn_UserAssignedToSite
(
    @PortalUserID                INT,
    @SiteID                      INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @IsAssigned BIT = 0;

    IF EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.SiteID = @SiteID
          AND sua.IsActive = 1
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        SET @IsAssigned = 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.LicensorAssignment la
        WHERE la.PortalUserID = @PortalUserID
          AND la.SiteID = @SiteID
          AND la.IsActive = 1
          AND (la.EffectiveEndUTC IS NULL OR la.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        SET @IsAssigned = 1;
    END;

    RETURN @IsAssigned;
END;