﻿CREATE FUNCTION sec.fn_UserCanAccessChildDetail
(
    @PortalUserID                INT,
    @ChildID                     INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @CanAccess BIT = 0;
    DECLARE @SiteID INT;

    SELECT @SiteID = c.SiteID
    FROM child.Child c
    WHERE c.ChildID = @ChildID
      AND c.IsDeleted = 0;

    IF @SiteID IS NULL
        RETURN 0;

    IF sec.fn_HasRoleCode(@PortalUserID, N'PLATFORM_ADMIN') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'COMPLIANCE_ADMIN') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'DATABASE_ADMIN') = 1
        OR sec.fn_UserAssignedToSite(@PortalUserID, @SiteID) = 1
        OR sec.fn_UserLinkedToChild(@PortalUserID, @ChildID) = 1
    BEGIN
        SET @CanAccess = 1;
    END;

    RETURN @CanAccess;
END;