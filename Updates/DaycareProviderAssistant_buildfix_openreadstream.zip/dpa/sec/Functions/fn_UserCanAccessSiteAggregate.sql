﻿CREATE FUNCTION sec.fn_UserCanAccessSiteAggregate
(
    @PortalUserID                INT,
    @SiteID                      INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @CanAccess BIT = 0;

    IF sec.fn_HasRoleCode(@PortalUserID, N'PLATFORM_ADMIN') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'COMPLIANCE_ADMIN') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'DATABASE_ADMIN') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'LICENSOR_USER') = 1
        OR sec.fn_HasRoleCode(@PortalUserID, N'LICENSOR_SUPERVISOR') = 1
        OR sec.fn_UserAssignedToSite(@PortalUserID, @SiteID) = 1
    BEGIN
        SET @CanAccess = 1;
    END;

    RETURN @CanAccess;
END;