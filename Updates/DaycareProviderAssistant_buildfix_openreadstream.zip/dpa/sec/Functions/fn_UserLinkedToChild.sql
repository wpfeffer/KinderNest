﻿CREATE FUNCTION sec.fn_UserLinkedToChild
(
    @PortalUserID                INT,
    @ChildID                     INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @IsLinked BIT = 0;

    IF EXISTS
    (
        SELECT 1
        FROM child.ChildPersonRelationship cpr
        INNER JOIN party.PortalUser pu
            ON pu.PersonID = cpr.PersonID
        WHERE pu.PortalUserID = @PortalUserID
          AND cpr.ChildID = @ChildID
          AND cpr.IsDeleted = 0
          AND cpr.IsActive = 1
          AND cpr.HasPortalAccess = 1
          AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS DATE))
    )
    BEGIN
        SET @IsLinked = 1;
    END;

    RETURN @IsLinked;
END;