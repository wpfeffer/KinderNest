﻿CREATE FUNCTION sec.fn_GetSessionPortalUserID()
RETURNS INT
AS
BEGIN
    DECLARE @PortalUserID INT;

    SELECT @PortalUserID = TRY_CAST(SESSION_CONTEXT(N'PortalUserID') AS INT);

    RETURN @PortalUserID;
END;