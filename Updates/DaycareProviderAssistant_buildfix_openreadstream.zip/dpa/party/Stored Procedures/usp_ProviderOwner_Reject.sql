CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Reject
    @PortalUserID INT,
    @RejectedByUserID INT,
    @ReasonText NVARCHAR(MAX),
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @RejectedAccountStatusCode NVARCHAR(50) = N'REJECTED',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration rejected.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = NULLIF(LTRIM(RTRIM(@ReasonText)), N'');

    IF @EffectiveReasonText IS NULL
    BEGIN
        THROW 50709, 'A rejection reason is required.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50710, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50711, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @RejectedAccountStatusCode,
           RejectionReason = @EffectiveReasonText,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @RejectedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50712, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'REJECT_PROVIDER_REGISTRATION',
        @ChangedByUserID = @RejectedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","RejectionReason","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @RejectedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO
