﻿CREATE PROCEDURE party.usp_PhoneNumber_FindCanonical
    @CountryCode             NVARCHAR(10),
    @PhoneNumber             NVARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
        p.PhoneNumberID,
        p.CountryCode,
        p.PhoneNumber,
        p.IsVoice,
        p.IsSms,
        p.IsActive,
        p.IsDeleted
    FROM party.PhoneNumber p
    WHERE p.CountryCode = @CountryCode
      AND p.PhoneNumber = @PhoneNumber
      AND p.IsDeleted = 0
    ORDER BY p.PhoneNumberID;
END;