CREATE OR ALTER PROCEDURE party.usp_AdminSite_GetDetail
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        s.SiteID,
        s.ProviderID,
        pr.ProviderName,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        s.IsActive
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    WHERE s.SiteID = @SiteID
      AND s.IsDeleted = 0;

    SELECT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    WHERE sua.SiteID = @SiteID
    ORDER BY sua.EffectiveStartUTC DESC, DisplayName;
END;
GO
