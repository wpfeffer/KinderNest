CREATE OR ALTER PROCEDURE party.usp_AdminPendingProvider_List
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pu.PortalUserID,
        p.ProviderID,
        s.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(prsn.FirstName, N' ', prsn.LastName),
        pu.UserName,
        PrimaryEmail = prsn.PrimaryEmail,
        p.ProviderName,
        p.BusinessEmail,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        LicenseClassName = lc.LicenseClassName,
        pu.AccountStatusCode
    FROM party.PortalUser pu
    INNER JOIN party.Person prsn
        ON prsn.PersonID = pu.PersonID
       AND prsn.IsDeleted = 0
       AND prsn.IsActive = 1
    INNER JOIN party.PortalUserRole pur
        ON pur.PortalUserID = pu.PortalUserID
       AND pur.IsActive = 1
       AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
       AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
       AND r.RoleCode = @ProviderOwnerRoleCode
       AND r.IsActive = 1
    LEFT JOIN party.SiteUserAssignment sua
        ON sua.PortalUserID = pu.PortalUserID
       AND sua.IsActive = 1
    LEFT JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
    LEFT JOIN party.Provider p
        ON p.ProviderID = s.ProviderID
       AND p.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
       AND lc.IsActive = 1
    WHERE pu.IsDeleted = 0
      AND pu.IsActive = 1
      AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
    ORDER BY pu.CreatedUTC ASC,
             pu.PortalUserID ASC;
END;
GO
