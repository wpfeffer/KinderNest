CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ActiveRoles AS
    (
        SELECT
            pur.PortalUserID,
            r.RoleCode
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC > SYSUTCDATETIME())
          AND r.IsActive = 1
    ),
    RoleAgg AS
    (
        SELECT
            ar.PortalUserID,
            STRING_AGG(ar.RoleCode, N', ') WITHIN GROUP (ORDER BY ar.RoleCode) AS RoleCodes
        FROM ActiveRoles ar
        GROUP BY ar.PortalUserID
    ),
    SiteAgg AS
    (
        SELECT
            sua.PortalUserID,
            COUNT(DISTINCT sua.SiteID) AS SiteCount
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
        WHERE sua.IsActive = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
          AND s.IsDeleted = 0
        GROUP BY sua.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE WHEN pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC > SYSUTCDATETIME() THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsLocked,
        pc.LockoutEndUTC,
        pu.LastLoginUTC,
        ISNULL(ra.RoleCodes, N'') AS RoleCodes,
        ISNULL(sa.SiteCount, 0) AS SiteCount,
        pu.IsActive
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    OUTER APPLY
    (
        SELECT TOP (1)
            c.LockoutEndUTC
        FROM sec.PortalCredential c
        WHERE c.PortalUserID = pu.PortalUserID
          AND c.IsDeleted = 0
          AND c.IsActive = 1
          AND c.IsPrimary = 1
        ORDER BY c.PortalCredentialID DESC
    ) pc
    LEFT JOIN RoleAgg ra
        ON ra.PortalUserID = pu.PortalUserID
    LEFT JOIN SiteAgg sa
        ON sa.PortalUserID = pu.PortalUserID
    WHERE pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY p.LastName, p.FirstName, pu.UserName;
END;
GO
