﻿CREATE PROCEDURE party.usp_Address_FindCanonical
    @CountryCode             NVARCHAR(10),
    @AddressLine1            NVARCHAR(200),
    @AddressLine2            NVARCHAR(200) = NULL,
    @City                    NVARCHAR(100),
    @StateProvinceCode       NVARCHAR(20),
    @PostalCode              NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
        a.AddressID,
        a.CountryCode,
        a.AddressLine1,
        a.AddressLine2,
        a.City,
        a.StateProvinceCode,
        a.PostalCode,
        a.CountyName,
        a.IsActive,
        a.IsDeleted
    FROM party.Address a
    WHERE a.CountryCode = @CountryCode
      AND a.AddressLine1 = @AddressLine1
      AND ISNULL(a.AddressLine2, N'') = ISNULL(@AddressLine2, N'')
      AND a.City = @City
      AND a.StateProvinceCode = @StateProvinceCode
      AND a.PostalCode = @PostalCode
      AND a.IsDeleted = 0
    ORDER BY a.AddressID;
END;