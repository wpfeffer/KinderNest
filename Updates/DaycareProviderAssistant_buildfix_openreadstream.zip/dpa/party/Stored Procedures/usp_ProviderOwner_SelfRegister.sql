CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_SelfRegister
    @FirstName                         NVARCHAR(100),
    @LastName                          NVARCHAR(100),
    @PrimaryEmail                      NVARCHAR(320),
    @UserName                          NVARCHAR(320),
    @NormalizedUserName                NVARCHAR(320),
    @ProviderName                      NVARCHAR(200),
    @LegalEntityName                   NVARCHAR(200),
    @BusinessEmail                     NVARCHAR(320),
    @SiteName                          NVARCHAR(200),
    @LicenseNumber                     NVARCHAR(100) = NULL,
    @LicenseClassCode                  NVARCHAR(10),
    @TimeZoneCode                      NVARCHAR(100),
    @PasswordHash                      NVARCHAR(1000),
    @HashAlgorithmCode                 NVARCHAR(100),
    @ProviderOwnerRoleCode             NVARCHAR(50),
    @PendingApprovalAccountStatusCode  NVARCHAR(50),
    @RemoteAddress                     NVARCHAR(64) = NULL,
    @UserAgent                         NVARCHAR(512) = NULL,
    @CorrelationID                     UNIQUEIDENTIFIER = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PersonID INT;
    DECLARE @ProviderID INT;
    DECLARE @SiteID INT;
    DECLARE @PortalUserRoleID INT;
    DECLARE @SiteUserAssignmentID INT;
    DECLARE @RoleID INT;
    DECLARE @LicenseClassID INT;
    DECLARE @TimeZoneID INT;
    DECLARE @ReasonText NVARCHAR(MAX) = N'Self-service provider registration.';

    DECLARE @HashVersion INT = 1;
    DECLARE @MustChangePassword BIT = 0;
    DECLARE @AuthenticationEventTypeCode NVARCHAR(100) = N'PASSWORD_CHANGED';
    DECLARE @PasswordNotes NVARCHAR(4000) = N'Password established during provider self-registration.';

    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @NewValuesJson NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SELECT @RoleID = r.RoleID
    FROM ref.Role r
    WHERE r.RoleCode = @ProviderOwnerRoleCode
      AND r.IsActive = 1;

    IF @RoleID IS NULL
    BEGIN
        THROW 50500, 'Provider owner role was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'AccountStatus'
          AND cv.CodeValue = @PendingApprovalAccountStatusCode
          AND cv.IsActive = 1
    )
    BEGIN
        THROW 50501, 'Pending approval account status code was not found.', 1;
    END;

    SELECT @LicenseClassID = lc.LicenseClassID
    FROM lic.LicenseClass lc
    WHERE lc.LicenseClassCode = @LicenseClassCode
      AND lc.IsActive = 1;

    IF @LicenseClassID IS NULL
    BEGIN
        THROW 50502, 'License class code was not found.', 1;
    END;

    SELECT @TimeZoneID = tz.TimeZoneID
    FROM ref.TimeZone tz
    WHERE tz.TimeZoneCode = @TimeZoneCode
      AND tz.IsActive = 1;

    IF @TimeZoneID IS NULL
    BEGIN
        THROW 50503, 'Time zone code was not found.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.NormalizedUserName = @NormalizedUserName
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50504, 'That username is already registered.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.Person p
        WHERE UPPER(ISNULL(p.PrimaryEmail, N'')) = UPPER(@PrimaryEmail)
          AND p.IsDeleted = 0
    )
    BEGIN
        THROW 50505, 'That email is already registered.', 1;
    END;

    BEGIN TRANSACTION;

    INSERT INTO party.Person
    (
        FirstName,
        LastName,
        PrimaryEmail,
        IsActive,
        IsDeleted
    )
    VALUES
    (
        @FirstName,
        @LastName,
        @PrimaryEmail,
        1,
        0
    );

    SET @PersonID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUser
    (
        PersonID,
        UserName,
        NormalizedUserName,
        AccountStatusCode,
        MFAEnabled,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @PersonID,
        @UserName,
        @NormalizedUserName,
        @PendingApprovalAccountStatusCode,
        0,
        1,
        0,
        NULL
    );

    SET @PortalUserID = SCOPE_IDENTITY();

    INSERT INTO party.Provider
    (
        ProviderName,
        LegalEntityName,
        LicenseHolderPersonID,
        BusinessEmail,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ProviderName,
        @LegalEntityName,
        @PersonID,
        @BusinessEmail,
        1,
        0,
        @PortalUserID
    );

    SET @ProviderID = SCOPE_IDENTITY();

    INSERT INTO party.Site
    (
        ProviderID,
        SiteName,
        LicenseNumber,
        LicenseClassID,
        TimeZoneID,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ProviderID,
        @SiteName,
        @LicenseNumber,
        @LicenseClassID,
        @TimeZoneID,
        1,
        0,
        @PortalUserID
    );

    SET @SiteID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUserRole
    (
        PortalUserID,
        RoleID,
        EffectiveStartUTC,
        IsActive,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @RoleID,
        SYSUTCDATETIME(),
        1,
        @PortalUserID
    );

    SET @PortalUserRoleID = SCOPE_IDENTITY();

    INSERT INTO party.SiteUserAssignment
    (
        SiteID,
        PortalUserID,
        AssignmentTypeCode,
        IsPrimaryProviderContact,
        EffectiveStartUTC,
        IsActive,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        @PortalUserID,
        @ProviderOwnerRoleCode,
        1,
        SYSUTCDATETIME(),
        1,
        @PortalUserID
    );

    SET @SiteUserAssignmentID = SCOPE_IDENTITY();

    EXEC sec.usp_PortalCredential_SetPassword
        @PortalUserID = @PortalUserID,
        @PasswordHash = @PasswordHash,
        @HashAlgorithmCode = @HashAlgorithmCode,
        @HashVersion = @HashVersion,
        @MustChangePassword = @MustChangePassword,
        @ChangedByUserID = @PortalUserID,
        @AuthenticationEventTypeCode = @AuthenticationEventTypeCode,
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @Notes = @PasswordNotes;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PersonID);
    SELECT @NewValuesJson = (SELECT p.* FROM party.Person p WHERE p.PersonID = @PersonID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Person',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);
    SELECT @NewValuesJson = (SELECT pu.* FROM party.PortalUser pu WHERE pu.PortalUserID = @PortalUserID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @ProviderID);
    SELECT @NewValuesJson = (SELECT pr.* FROM party.Provider pr WHERE pr.ProviderID = @ProviderID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Provider',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @SiteID);
    SELECT @NewValuesJson = (SELECT s.* FROM party.Site s WHERE s.SiteID = @SiteID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Site',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @SiteID = @SiteID,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserRoleID);
    SELECT @NewValuesJson = (SELECT pur.* FROM party.PortalUserRole pur WHERE pur.PortalUserRoleID = @PortalUserRoleID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUserRole',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @SiteUserAssignmentID);
    SELECT @NewValuesJson = (SELECT sua.* FROM party.SiteUserAssignment sua WHERE sua.SiteUserAssignmentID = @SiteUserAssignmentID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'SiteUserAssignment',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    COMMIT TRANSACTION;

    SELECT
        @PortalUserID AS PortalUserID,
        @ProviderID AS ProviderID,
        @SiteID AS SiteID,
        @PendingApprovalAccountStatusCode AS AccountStatusCode;
END;
GO

