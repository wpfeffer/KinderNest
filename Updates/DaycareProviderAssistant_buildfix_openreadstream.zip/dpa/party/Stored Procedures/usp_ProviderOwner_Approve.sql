CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Approve
    @PortalUserID INT,
    @ApprovedByUserID INT,
    @ReasonText NVARCHAR(MAX) = NULL,
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ApprovedAccountStatusCode NVARCHAR(50) = N'ACTIVE',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration approved.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = COALESCE(NULLIF(LTRIM(RTRIM(@ReasonText)), N''), N'Provider registration approved from admin portal.');

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50700, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50701, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @ApprovedAccountStatusCode,
           RejectionReason = NULL,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ApprovedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50702, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'APPROVE_PROVIDER_REGISTRATION',
        @ChangedByUserID = @ApprovedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","RejectionReason","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @ApprovedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO
