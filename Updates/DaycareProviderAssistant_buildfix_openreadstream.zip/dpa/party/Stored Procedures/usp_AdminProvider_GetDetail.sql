CREATE OR ALTER PROCEDURE party.usp_AdminProvider_GetDetail
    @ProviderID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        pr.BusinessEmail,
        CONCAT(lp.FirstName, N' ', lp.LastName) AS LicenseHolderDisplayName,
        pr.IsActive
    FROM party.Provider pr
    LEFT JOIN party.Person lp
        ON lp.PersonID = pr.LicenseHolderPersonID
    WHERE pr.ProviderID = @ProviderID
      AND pr.IsDeleted = 0;

    ;WITH RoleSnapshot AS
    (
        SELECT
            pur.PortalUserID,
            STRING_AGG(r.RoleCode, N', ') WITHIN GROUP (ORDER BY r.RoleCode) AS RoleCodes
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND pur.EffectiveEndUTC IS NULL
          AND r.IsActive = 1
        GROUP BY pur.PortalUserID
    )
    SELECT DISTINCT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        ISNULL(rs.RoleCodes, N'') AS RoleCodes,
        sua.IsPrimaryProviderContact,
        pu.IsActive
    FROM party.Site s
    INNER JOIN party.SiteUserAssignment sua
        ON sua.SiteID = s.SiteID
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN RoleSnapshot rs
        ON rs.PortalUserID = pu.PortalUserID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY DisplayName, pu.UserName;

    ;WITH AssignmentCounts AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS AssignedUserCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        ISNULL(ac.AssignedUserCount, 0) AS AssignedUserCount,
        s.IsActive
    FROM party.Site s
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN AssignmentCounts ac
        ON ac.SiteID = s.SiteID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
    ORDER BY s.SiteName;
END;
GO
