﻿CREATE TABLE party.Address
(
    AddressID                    INT IDENTITY(1,1)         NOT NULL,
    CountryCode                  NVARCHAR(10)              NOT NULL,
    AddressLine1                 NVARCHAR(200)             NOT NULL,
    AddressLine2                 NVARCHAR(200)             NULL,
    City                         NVARCHAR(100)             NOT NULL,
    StateProvinceCode            NVARCHAR(20)              NOT NULL,
    PostalCode                   NVARCHAR(20)              NOT NULL,
    CountyName                   NVARCHAR(100)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Address_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Address_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Address_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Address PRIMARY KEY CLUSTERED (AddressID),
    CONSTRAINT UQ_Address UNIQUE (CountryCode, AddressLine1, AddressLine2, City, StateProvinceCode, PostalCode)
);
GO
CREATE INDEX IX_Address_Canonical ON party.Address (CountryCode, AddressLine1, City, StateProvinceCode, PostalCode, IsDeleted, IsActive);