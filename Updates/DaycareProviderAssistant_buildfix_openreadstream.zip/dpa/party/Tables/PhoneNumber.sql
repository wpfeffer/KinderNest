﻿CREATE TABLE party.PhoneNumber
(
    PhoneNumberID                INT IDENTITY(1,1)         NOT NULL,
    CountryCode                  NVARCHAR(10)              NOT NULL,
    PhoneNumber                  NVARCHAR(30)              NOT NULL,
    IsVoice                      BIT                       NOT NULL CONSTRAINT DF_PhoneNumber_IsVoice DEFAULT (1),
    IsSms                        BIT                       NOT NULL CONSTRAINT DF_PhoneNumber_IsSms DEFAULT (0),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_PhoneNumber_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_PhoneNumber_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_PhoneNumber_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_PhoneNumber PRIMARY KEY CLUSTERED (PhoneNumberID),
    CONSTRAINT UQ_PhoneNumber_CountryCode_PhoneNumber UNIQUE (CountryCode, PhoneNumber)
);
GO
CREATE INDEX IX_PhoneNumber_CountryCode_PhoneNumber ON party.PhoneNumber (CountryCode, PhoneNumber, IsDeleted, IsActive);