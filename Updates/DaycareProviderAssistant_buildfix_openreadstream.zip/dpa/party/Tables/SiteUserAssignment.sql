﻿CREATE TABLE party.SiteUserAssignment
(
    SiteUserAssignmentID         INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    PortalUserID                 INT                       NOT NULL,
    AssignmentTypeCode           NVARCHAR(50)              NOT NULL,
    IsPrimaryProviderContact     BIT                       NOT NULL CONSTRAINT DF_SiteUserAssignment_IsPrimary DEFAULT (0),
    EffectiveStartUTC            DATETIME2(0)              NOT NULL,
    EffectiveEndUTC              DATETIME2(0)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_SiteUserAssignment_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_SiteUserAssignment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_SiteUserAssignment PRIMARY KEY CLUSTERED (SiteUserAssignmentID),
    CONSTRAINT FK_SiteUserAssignment_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_SiteUserAssignment_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_SiteUserAssignment_SiteID ON party.SiteUserAssignment (SiteID, PortalUserID, IsActive);