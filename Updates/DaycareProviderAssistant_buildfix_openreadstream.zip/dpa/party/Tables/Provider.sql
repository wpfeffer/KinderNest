﻿CREATE TABLE party.Provider
(
    ProviderID                   INT IDENTITY(1,1)         NOT NULL,
    ProviderName                 NVARCHAR(200)             NOT NULL,
    LegalEntityName              NVARCHAR(200)             NOT NULL,
    LicenseHolderPersonID        INT                       NULL,
    BusinessEmail                NVARCHAR(320)             NULL,
    BusinessPhoneNumberID        INT                       NULL,
    BusinessAddressID            INT                       NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Provider_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Provider_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Provider_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Provider PRIMARY KEY CLUSTERED (ProviderID),
    CONSTRAINT FK_Provider_LicenseHolderPerson FOREIGN KEY (LicenseHolderPersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT FK_Provider_BusinessPhoneNumber FOREIGN KEY (BusinessPhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
    CONSTRAINT FK_Provider_BusinessAddress FOREIGN KEY (BusinessAddressID) REFERENCES party.Address (AddressID)
);
GO
CREATE INDEX IX_Provider_LicenseHolderPersonID ON party.Provider (LicenseHolderPersonID) WHERE LicenseHolderPersonID IS NOT NULL;
GO
CREATE INDEX IX_Provider_BusinessPhoneNumberID ON party.Provider (BusinessPhoneNumberID) WHERE BusinessPhoneNumberID IS NOT NULL;
GO
CREATE INDEX IX_Provider_BusinessAddressID ON party.Provider (BusinessAddressID) WHERE BusinessAddressID IS NOT NULL;