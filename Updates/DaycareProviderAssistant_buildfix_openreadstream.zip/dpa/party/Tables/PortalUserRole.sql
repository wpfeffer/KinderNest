﻿CREATE TABLE party.PortalUserRole
(
    PortalUserRoleID             INT IDENTITY(1,1)         NOT NULL,
    PortalUserID                 INT                       NOT NULL,
    RoleID                       INT                       NOT NULL,
    EffectiveStartUTC            DATETIME2(0)              NOT NULL,
    EffectiveEndUTC              DATETIME2(0)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_PortalUserRole_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalUserRole_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_PortalUserRole PRIMARY KEY CLUSTERED (PortalUserRoleID),
    CONSTRAINT FK_PortalUserRole_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_PortalUserRole_Role FOREIGN KEY (RoleID) REFERENCES ref.Role (RoleID),
    CONSTRAINT UQ_PortalUserRole UNIQUE (PortalUserID, RoleID, EffectiveStartUTC)
);
GO
CREATE INDEX IX_PortalUserRole_PortalUserID ON party.PortalUserRole (PortalUserID, IsActive, EffectiveStartUTC, EffectiveEndUTC);