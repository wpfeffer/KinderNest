﻿CREATE TABLE party.LicensorAssignment
(
    LicensorAssignmentID         INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    PortalUserID                 INT                       NOT NULL,
    AssignmentTypeCode           NVARCHAR(50)              NOT NULL,
    EffectiveStartUTC            DATETIME2(0)              NOT NULL,
    EffectiveEndUTC              DATETIME2(0)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_LicensorAssignment_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_LicensorAssignment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_LicensorAssignment PRIMARY KEY CLUSTERED (LicensorAssignmentID),
    CONSTRAINT FK_LicensorAssignment_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_LicensorAssignment_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_LicensorAssignment_SiteID ON party.LicensorAssignment (SiteID, PortalUserID, IsActive);