﻿CREATE TABLE party.Person
(
    PersonID                     INT IDENTITY(1,1)         NOT NULL,
    FirstName                    NVARCHAR(100)             NOT NULL,
    MiddleName                   NVARCHAR(100)             NULL,
    LastName                     NVARCHAR(100)             NOT NULL,
    DateOfBirth                  DATE                      NULL,
    PrimaryEmail                 NVARCHAR(320)             NULL,
    PrimaryPhoneNumberID         INT                       NULL,
    PrimaryAddressID             INT                       NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Person_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Person_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Person_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Person PRIMARY KEY CLUSTERED (PersonID),
    CONSTRAINT FK_Person_PrimaryPhoneNumber FOREIGN KEY (PrimaryPhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
    CONSTRAINT FK_Person_PrimaryAddress FOREIGN KEY (PrimaryAddressID) REFERENCES party.Address (AddressID)
);
GO
CREATE INDEX IX_Person_PrimaryEmail ON party.Person (PrimaryEmail) WHERE PrimaryEmail IS NOT NULL;
GO
CREATE INDEX IX_Person_PrimaryPhoneNumberID ON party.Person (PrimaryPhoneNumberID) WHERE PrimaryPhoneNumberID IS NOT NULL;
GO
CREATE INDEX IX_Person_PrimaryAddressID ON party.Person (PrimaryAddressID) WHERE PrimaryAddressID IS NOT NULL;