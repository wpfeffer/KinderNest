﻿CREATE TABLE party.MedicalProvider
    (
        MedicalProviderID            INT IDENTITY(1,1)     NOT NULL,
        MedicalProviderTypeID        INT                   NOT NULL,
        ProviderName                 NVARCHAR(200)         NOT NULL,
        PhoneNumberID                INT                   NULL,
        AddressID                    INT                   NULL,
        EmailAddress                 NVARCHAR(320)         NULL,
        Notes                        NVARCHAR(MAX)         NULL,
        IsActive                     BIT                   NOT NULL CONSTRAINT DF_MedicalProvider_IsActive DEFAULT (1),
        IsDeleted                    BIT                   NOT NULL CONSTRAINT DF_MedicalProvider_IsDeleted DEFAULT (0),
        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_MedicalProvider_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID              INT                   NULL,
        ModifiedUTC                  DATETIME2(0)          NULL,
        ModifiedByUserID             INT                   NULL,
        DeletedUTC                   DATETIME2(0)          NULL,
        DeletedByUserID              INT                   NULL,
        DeletedReason                NVARCHAR(MAX)         NULL,
        RowVer                       ROWVERSION            NOT NULL,
        CONSTRAINT PK_MedicalProvider PRIMARY KEY CLUSTERED (MedicalProviderID),
        CONSTRAINT FK_MedicalProvider_MedicalProviderType FOREIGN KEY (MedicalProviderTypeID) REFERENCES ref.MedicalProviderType (MedicalProviderTypeID),
        CONSTRAINT FK_MedicalProvider_PhoneNumber FOREIGN KEY (PhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
        CONSTRAINT FK_MedicalProvider_Address FOREIGN KEY (AddressID) REFERENCES party.Address (AddressID)
    );
GO
CREATE INDEX IX_MedicalProvider_Type_Name ON party.MedicalProvider (MedicalProviderTypeID, ProviderName, IsDeleted, IsActive);