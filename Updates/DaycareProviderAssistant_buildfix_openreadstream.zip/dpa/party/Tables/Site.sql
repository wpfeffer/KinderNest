﻿CREATE TABLE party.Site
(
    SiteID                       INT IDENTITY(1,1)         NOT NULL,
    ProviderID                   INT                       NOT NULL,
    SiteName                     NVARCHAR(200)             NOT NULL,
    LicenseNumber                NVARCHAR(100)             NULL,
    LicenseClassID               INT                       NOT NULL,
    TimeZoneID                   INT                       NOT NULL,
    SiteAddressID                INT                       NULL,
    SiteEmail                    NVARCHAR(320)             NULL,
    SitePhoneNumberID            INT                       NULL,
    EmergencyPhoneNumberID       INT                       NULL,
    LiabilityInsuranceStatusCode NVARCHAR(50)              NULL,
    WorkersCompStatusCode        NVARCHAR(50)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Site_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Site_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Site_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Site PRIMARY KEY CLUSTERED (SiteID),
    CONSTRAINT FK_Site_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_Site_LicenseClass FOREIGN KEY (LicenseClassID) REFERENCES lic.LicenseClass (LicenseClassID),
    CONSTRAINT FK_Site_TimeZone FOREIGN KEY (TimeZoneID) REFERENCES ref.TimeZone (TimeZoneID),
    CONSTRAINT FK_Site_Address FOREIGN KEY (SiteAddressID) REFERENCES party.Address (AddressID),
    CONSTRAINT FK_Site_SitePhoneNumber FOREIGN KEY (SitePhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
    CONSTRAINT FK_Site_EmergencyPhoneNumber FOREIGN KEY (EmergencyPhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID)
);
GO
CREATE INDEX IX_Site_ProviderID ON party.Site (ProviderID, IsDeleted, IsActive);
GO
CREATE INDEX IX_Site_AddressID ON party.Site (SiteAddressID) WHERE SiteAddressID IS NOT NULL;
GO
CREATE INDEX IX_Site_SitePhoneNumberID ON party.Site (SitePhoneNumberID) WHERE SitePhoneNumberID IS NOT NULL;
GO
CREATE INDEX IX_Site_EmergencyPhoneNumberID ON party.Site (EmergencyPhoneNumberID) WHERE EmergencyPhoneNumberID IS NOT NULL;