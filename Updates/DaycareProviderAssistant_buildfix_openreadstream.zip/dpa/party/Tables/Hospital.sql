﻿CREATE TABLE party.Hospital
    (
        HospitalID                   INT IDENTITY(1,1)     NOT NULL,
        HospitalName                 NVARCHAR(200)         NOT NULL,
        MainPhoneNumberID            INT                   NULL,
        AddressID                    INT                   NULL,
        Notes                        NVARCHAR(MAX)         NULL,
        IsActive                     BIT                   NOT NULL CONSTRAINT DF_Hospital_IsActive DEFAULT (1),
        IsDeleted                    BIT                   NOT NULL CONSTRAINT DF_Hospital_IsDeleted DEFAULT (0),
        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_Hospital_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID              INT                   NULL,
        ModifiedUTC                  DATETIME2(0)          NULL,
        ModifiedByUserID             INT                   NULL,
        DeletedUTC                   DATETIME2(0)          NULL,
        DeletedByUserID              INT                   NULL,
        DeletedReason                NVARCHAR(MAX)         NULL,
        RowVer                       ROWVERSION            NOT NULL,
        CONSTRAINT PK_Hospital PRIMARY KEY CLUSTERED (HospitalID),
        CONSTRAINT FK_Hospital_PhoneNumber FOREIGN KEY (MainPhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
        CONSTRAINT FK_Hospital_Address FOREIGN KEY (AddressID) REFERENCES party.Address (AddressID)
    );
GO
CREATE INDEX IX_Hospital_Name ON party.Hospital (HospitalName, IsDeleted, IsActive);