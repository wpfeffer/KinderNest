CREATE TABLE party.PortalUser
(
    PortalUserID                 INT IDENTITY(1,1)         NOT NULL,
    PersonID                     INT                       NOT NULL,
    UserName                     NVARCHAR(320)             NOT NULL,
    NormalizedUserName           NVARCHAR(320)             NOT NULL,
    AccountStatusCode            NVARCHAR(50)              NOT NULL,
    MFAEnabled                   BIT                       NOT NULL CONSTRAINT DF_PortalUser_MFAEnabled DEFAULT (0),
    LastLoginUTC                 DATETIME2(0)              NULL,
    RejectionReason              NVARCHAR(MAX)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_PortalUser_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_PortalUser_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_PortalUser_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_PortalUser PRIMARY KEY CLUSTERED (PortalUserID),
    CONSTRAINT FK_PortalUser_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT UQ_PortalUser_UserName UNIQUE (UserName),
    CONSTRAINT UQ_PortalUser_NormalizedUserName UNIQUE (NormalizedUserName)
);
GO
CREATE INDEX IX_PortalUser_PersonID ON party.PortalUser (PersonID, IsDeleted, IsActive);