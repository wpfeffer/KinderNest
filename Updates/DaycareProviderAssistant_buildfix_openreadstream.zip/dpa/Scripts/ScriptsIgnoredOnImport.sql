﻿
SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ref')
BEGIN
    EXEC(N'CREATE SCHEMA ref AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'lic')
BEGIN
    EXEC(N'CREATE SCHEMA lic AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'party')
BEGIN
    EXEC(N'CREATE SCHEMA party AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'child')
BEGIN
    EXEC(N'CREATE SCHEMA child AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'doc')
BEGIN
    EXEC(N'CREATE SCHEMA doc AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ops')
BEGIN
    EXEC(N'CREATE SCHEMA ops AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'comm')
BEGIN
    EXEC(N'CREATE SCHEMA comm AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'audit')
BEGIN
    EXEC(N'CREATE SCHEMA audit AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'sec')
BEGIN
    EXEC(N'CREATE SCHEMA sec AUTHORIZATION dbo;');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'rpt')
BEGIN
    EXEC(N'CREATE SCHEMA rpt AUTHORIZATION dbo;');
END;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO ref.TimeZone
(
    TimeZoneCode,
    WindowsTimeZoneName,
    DisplayName,
    UtcOffsetMinutesStandard,
    ObservesDst
)
VALUES
(N'America/Chicago', N'Central Standard Time', N'Central Time (US & Canada)', -360, 1),
(N'America/New_York', N'Eastern Standard Time', N'Eastern Time (US & Canada)', -300, 1),
(N'America/Denver', N'Mountain Standard Time', N'Mountain Time (US & Canada)', -420, 1),
(N'America/Los_Angeles', N'Pacific Standard Time', N'Pacific Time (US & Canada)', -480, 1),
(N'UTC', N'UTC', N'Coordinated Universal Time', 0, 0);
GO

INSERT INTO ref.Role
(
    RoleCode,
    RoleName,
    RoleDescription,
    IsSystemRole
)
VALUES
(N'PROVIDER_OWNER', N'Provider Owner', N'Primary provider account owner.', 1),
(N'PROVIDER_STAFF', N'Provider Staff', N'Provider-side staff account with limited permissions.', 1),
(N'GUARDIAN', N'Guardian', N'Parent or guardian portal user.', 1),
(N'LICENSOR_USER', N'Licensor User', N'County/state licensing staff user.', 1),
(N'LICENSOR_SUPERVISOR', N'Licensor Supervisor', N'Licensing supervisory user.', 1),
(N'SUPPORT_ADMIN', N'Support Admin', N'Administrative support user with outbound-only chat initiation.', 1),
(N'PLATFORM_ADMIN', N'Platform Admin', N'Platform administration user.', 1),
(N'COMPLIANCE_ADMIN', N'Compliance Admin', N'Administrative user for compliance review and escalation.', 1),
(N'DATABASE_ADMIN', N'Database Admin', N'Privileged database administrator role.', 1),
(N'AUDITOR', N'Auditor', N'Read-only auditor role.', 1);
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO lic.LicenseClass
(
    LicenseClassCode,
    LicenseClassName,
    LicenseFamilyCode,
    Description
)
VALUES
(N'A', N'Class A Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class A.'),
(N'B1', N'Class B1 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B1.'),
(N'B2', N'Class B2 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B2.'),
(N'C1', N'Class C1 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C1.'),
(N'C2', N'Class C2 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C2.'),
(N'C3', N'Class C3 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C3.'),
(N'D', N'Class D Special Family Child Care', N'FAMILY_CHILD_CARE', N'Special family child care classification.');
GO

INSERT INTO lic.RequirementCatalog
(
    RequirementCode,
    RequirementTitle,
    RequirementCategoryCode,
    AppliesToLicenseFamilyCode,
    AppliesToChildFlag,
    AppliesToSiteFlag,
    Description
)
VALUES
(N'EMERGENCY_PLAN', N'Emergency Preparedness Plan', N'SITE_DOCUMENT', N'ALL', 0, 1, N'Site must maintain a current emergency preparedness plan.'),
(N'ALLERGY_PLAN', N'Child Allergy Plan', N'CHILD_DOCUMENT', N'ALL', 1, 0, N'Child allergy plan must be on file when applicable.'),
(N'MED_PERMISSION', N'Medication Permission', N'CHILD_CONSENT', N'ALL', 1, 0, N'Medication administration consent must be current when medication is administered.'),
(N'GUARDIAN_INVITE', N'Guardian Portal Identity', N'CHILD_ACCESS', N'ALL', 1, 0, N'Guardian portal access requires provider-mediated identity invitation and token claim.'),
(N'TRAINING_CURRENT', N'Staff Training Current', N'STAFF_COMPLIANCE', N'ALL', 0, 1, N'Required staff training must be current.'),
(N'BACKGROUND_STUDY', N'Background Study Cleared', N'STAFF_COMPLIANCE', N'ALL', 0, 1, N'Background study clearance must be current for covered staff.');
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.MedicalProviderType', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named ref.MedicalProviderType.
--CREATE TABLE ref.MedicalProviderType
--    (
--        MedicalProviderTypeID        INT IDENTITY(1,1)     NOT NULL,
--        MedicalProviderTypeCode      NVARCHAR(50)          NOT NULL,
--        MedicalProviderTypeName      NVARCHAR(200)         NOT NULL,
--        IsActive                     BIT                   NOT NULL CONSTRAINT DF_MedicalProviderType_IsActive DEFAULT (1),
--        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_MedicalProviderType_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CONSTRAINT PK_MedicalProviderType PRIMARY KEY CLUSTERED (MedicalProviderTypeID),
--        CONSTRAINT UQ_MedicalProviderType_Code UNIQUE (MedicalProviderTypeCode)
--    );

END;
GO

IF OBJECT_ID(N'party.MedicalProvider', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named party.MedicalProvider.
--CREATE TABLE party.MedicalProvider
--    (
--        MedicalProviderID            INT IDENTITY(1,1)     NOT NULL,
--        MedicalProviderTypeID        INT                   NOT NULL,
--        ProviderName                 NVARCHAR(200)         NOT NULL,
--        PhoneNumberID                INT                   NULL,
--        AddressID                    INT                   NULL,
--        EmailAddress                 NVARCHAR(320)         NULL,
--        Notes                        NVARCHAR(MAX)         NULL,
--        IsActive                     BIT                   NOT NULL CONSTRAINT DF_MedicalProvider_IsActive DEFAULT (1),
--        IsDeleted                    BIT                   NOT NULL CONSTRAINT DF_MedicalProvider_IsDeleted DEFAULT (0),
--        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_MedicalProvider_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CreatedByUserID              INT                   NULL,
--        ModifiedUTC                  DATETIME2(0)          NULL,
--        ModifiedByUserID             INT                   NULL,
--        DeletedUTC                   DATETIME2(0)          NULL,
--        DeletedByUserID              INT                   NULL,
--        DeletedReason                NVARCHAR(MAX)         NULL,
--        RowVer                       ROWVERSION            NOT NULL,
--        CONSTRAINT PK_MedicalProvider PRIMARY KEY CLUSTERED (MedicalProviderID),
--        CONSTRAINT FK_MedicalProvider_MedicalProviderType FOREIGN KEY (MedicalProviderTypeID) REFERENCES ref.MedicalProviderType (MedicalProviderTypeID),
--        CONSTRAINT FK_MedicalProvider_PhoneNumber FOREIGN KEY (PhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
--        CONSTRAINT FK_MedicalProvider_Address FOREIGN KEY (AddressID) REFERENCES party.Address (AddressID)
--    );

END;
GO

IF OBJECT_ID(N'party.Hospital', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named party.Hospital.
--CREATE TABLE party.Hospital
--    (
--        HospitalID                   INT IDENTITY(1,1)     NOT NULL,
--        HospitalName                 NVARCHAR(200)         NOT NULL,
--        MainPhoneNumberID            INT                   NULL,
--        AddressID                    INT                   NULL,
--        Notes                        NVARCHAR(MAX)         NULL,
--        IsActive                     BIT                   NOT NULL CONSTRAINT DF_Hospital_IsActive DEFAULT (1),
--        IsDeleted                    BIT                   NOT NULL CONSTRAINT DF_Hospital_IsDeleted DEFAULT (0),
--        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_Hospital_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CreatedByUserID              INT                   NULL,
--        ModifiedUTC                  DATETIME2(0)          NULL,
--        ModifiedByUserID             INT                   NULL,
--        DeletedUTC                   DATETIME2(0)          NULL,
--        DeletedByUserID              INT                   NULL,
--        DeletedReason                NVARCHAR(MAX)         NULL,
--        RowVer                       ROWVERSION            NOT NULL,
--        CONSTRAINT PK_Hospital PRIMARY KEY CLUSTERED (HospitalID),
--        CONSTRAINT FK_Hospital_PhoneNumber FOREIGN KEY (MainPhoneNumberID) REFERENCES party.PhoneNumber (PhoneNumberID),
--        CONSTRAINT FK_Hospital_Address FOREIGN KEY (AddressID) REFERENCES party.Address (AddressID)
--    );

END;
GO

IF NOT EXISTS (SELECT 1 FROM ref.MedicalProviderType WHERE MedicalProviderTypeCode = N'PHYSICIAN')
    INSERT INTO ref.MedicalProviderType (MedicalProviderTypeCode, MedicalProviderTypeName) VALUES (N'PHYSICIAN', N'Physician');
GO

IF NOT EXISTS (SELECT 1 FROM ref.MedicalProviderType WHERE MedicalProviderTypeCode = N'DENTIST')
    INSERT INTO ref.MedicalProviderType (MedicalProviderTypeCode, MedicalProviderTypeName) VALUES (N'DENTIST', N'Dentist');
GO

-- Post-deploy conditional DDL moved to dpa/PostDeploy/Patches.sql
-- This keeps the SSDT model files static and avoids SQL70001 errors.
-- Run the post-deploy script after deployment to apply idempotent ALTER/CREATE statements.
GO

ALTER TABLE child.Child ALTER COLUMN SpecialDietNotes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.Child ALTER COLUMN SpecialNeedsNotes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.Child ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildEnrollment ALTER COLUMN FinancialArrangementNotes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildEnrollment ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildPersonRelationship ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.PickupDropoffAuthorization ALTER COLUMN Notes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.PickupDropoffAuthorization ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAttendance ALTER COLUMN CorrectionReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAttendance ALTER COLUMN Notes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAttendance ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildMedicalProfile ALTER COLUMN MedicalNotes NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildMedicalProfile ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN AllergenSummary NVARCHAR(MAX) NOT NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN TriggerDescription NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN AvoidanceInstructions NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN SymptomInstructions NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN TreatmentInstructions NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.ChildAllergyPlan ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.MedicationPermission ALTER COLUMN Instructions NVARCHAR(MAX) NULL;
GO

ALTER TABLE child.MedicationPermission ALTER COLUMN DeletedReason NVARCHAR(MAX) NULL;
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.Child') AND name = N'AddressLine1')
BEGIN
    ALTER TABLE child.Child DROP COLUMN AddressLine1, AddressLine2, City, StateCode, PostalCode;
END;
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.ChildMedicalProfile') AND name = N'PhysicianName')
BEGIN
    ALTER TABLE child.ChildMedicalProfile DROP COLUMN PhysicianName, PhysicianPhone, DentistName, DentistPhone, HospitalName, HospitalPhone;
END;
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.ChildAllergyPlan') AND name = N'PhysicianName')
BEGIN
    ALTER TABLE child.ChildAllergyPlan DROP COLUMN PhysicianName, PhysicianPhone;
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Child_ChildAddressID' AND object_id = OBJECT_ID(N'child.Child'))
    --The following statement was imported into the database project as a schema object and named child.Child.IX_Child_ChildAddressID.
--CREATE INDEX IX_Child_ChildAddressID ON child.Child (ChildAddressID) WHERE ChildAddressID IS NOT NULL;

GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ChildMedicalProfile_PrimaryCarePhysicianID' AND object_id = OBJECT_ID(N'child.ChildMedicalProfile'))
    --The following statement was imported into the database project as a schema object and named child.ChildMedicalProfile.IX_ChildMedicalProfile_PrimaryCarePhysicianID.
--CREATE INDEX IX_ChildMedicalProfile_PrimaryCarePhysicianID ON child.ChildMedicalProfile (PrimaryCarePhysicianID) WHERE PrimaryCarePhysicianID IS NOT NULL;

GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ChildMedicalProfile_DentistMedicalProviderID' AND object_id = OBJECT_ID(N'child.ChildMedicalProfile'))
    --The following statement was imported into the database project as a schema object and named child.ChildMedicalProfile.IX_ChildMedicalProfile_DentistMedicalProviderID.
--CREATE INDEX IX_ChildMedicalProfile_DentistMedicalProviderID ON child.ChildMedicalProfile (DentistMedicalProviderID) WHERE DentistMedicalProviderID IS NOT NULL;

GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ChildMedicalProfile_HospitalID' AND object_id = OBJECT_ID(N'child.ChildMedicalProfile'))
    --The following statement was imported into the database project as a schema object and named child.ChildMedicalProfile.IX_ChildMedicalProfile_HospitalID.
--CREATE INDEX IX_ChildMedicalProfile_HospitalID ON child.ChildMedicalProfile (HospitalID) WHERE HospitalID IS NOT NULL;

GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ChildAllergyPlan_PhysicianMedicalProviderID' AND object_id = OBJECT_ID(N'child.ChildAllergyPlan'))
    --The following statement was imported into the database project as a schema object and named child.ChildAllergyPlan.IX_ChildAllergyPlan_PhysicianMedicalProviderID.
--CREATE INDEX IX_ChildAllergyPlan_PhysicianMedicalProviderID ON child.ChildAllergyPlan (PhysicianMedicalProviderID) WHERE PhysicianMedicalProviderID IS NOT NULL;

GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO doc.DocumentType
(
    DocumentTypeCode,
    DocumentTypeName,
    Description
)
VALUES
(N'LICENSE_DOC', N'License Document', N'Provider or site licensing documentation.'),
(N'EMERGENCY_PLAN', N'Emergency Plan', N'Site emergency preparedness plan document.'),
(N'CONSENT_FORM', N'Consent Form', N'Consent or authorization form.'),
(N'ALLERGY_PLAN', N'Allergy Plan', N'Child allergy or medical action plan document.'),
(N'TRAINING_CERT', N'Training Certificate', N'Staff training completion document.'),
(N'BACKGROUND_CLEARANCE', N'Background Clearance', N'Background study or clearance document.'),
(N'INCIDENT_ATTACHMENT', N'Incident Attachment', N'Attachment associated with an incident record.');
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO comm.NotificationTemplate
(
    TemplateCode,
    TemplateName,
    ChannelCode,
    SubjectTemplate,
    BodyTemplate,
    CreatedByUserID
)
VALUES
(N'GUARDIAN_INVITE', N'Guardian Invitation', N'EMAIL', N'You have been invited to access the Daycare Provider Assistant', N'Guardian invitation template body placeholder.', NULL),
(N'LICENSOR_ACCESS_NOTICE', N'Licensor Access Notice', N'EMAIL', N'A licensor viewed your provider information', N'Licensor access notice template body placeholder.', NULL),
(N'ADMIN_OUTBOUND_NOTICE', N'Admin Outbound Notice', N'EMAIL', N'New administrative message', N'Administrative outbound message template body placeholder.', NULL),
(N'DOCUMENT_EXPIRATION_REMINDER', N'Document Expiration Reminder', N'EMAIL', N'Document expiration reminder', N'Document expiration reminder template body placeholder.', NULL);
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE child.usp_ChildMedicalProfile_GetByChildID
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        cmp.ChildMedicalProfileID,
        cmp.ChildID,
        cmp.PrimaryCarePhysicianID,
        pcp.ProviderName AS PrimaryCarePhysicianName,
        pcp.MedicalProviderTypeID AS PrimaryCarePhysicianTypeID,
        pcp.PhoneNumberID AS PrimaryCarePhysicianPhoneNumberID,
        cmp.DentistMedicalProviderID,
        dmp.ProviderName AS DentistName,
        dmp.MedicalProviderTypeID AS DentistTypeID,
        dmp.PhoneNumberID AS DentistPhoneNumberID,
        cmp.HospitalID,
        h.HospitalName,
        h.MainPhoneNumberID AS HospitalPhoneNumberID,
        h.AddressID AS HospitalAddressID,
        cmp.EmergencyMedicalConsentFlag,
        cmp.MedicalNotes,
        cmp.IsActive,
        cmp.IsDeleted,
        cmp.CreatedUTC,
        cmp.CreatedByUserID,
        cmp.ModifiedUTC,
        cmp.ModifiedByUserID,
        cmp.DeletedUTC,
        cmp.DeletedByUserID,
        cmp.DeletedReason
    FROM child.ChildMedicalProfile cmp
    LEFT JOIN party.MedicalProvider pcp ON pcp.MedicalProviderID = cmp.PrimaryCarePhysicianID
    LEFT JOIN party.MedicalProvider dmp ON dmp.MedicalProviderID = cmp.DentistMedicalProviderID
    LEFT JOIN party.Hospital h ON h.HospitalID = cmp.HospitalID
    WHERE cmp.ChildID = @ChildID
      AND cmp.IsDeleted = 0;
END;
GO

CREATE OR ALTER PROCEDURE child.usp_ChildAllergyPlan_GetByChildID
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        cap.ChildAllergyPlanID,
        cap.ChildID,
        cap.PhysicianMedicalProviderID,
        pmp.ProviderName AS PhysicianName,
        pmp.PhoneNumberID AS PhysicianPhoneNumberID,
        cap.AllergenSummary,
        cap.TriggerDescription,
        cap.AvoidanceInstructions,
        cap.SymptomInstructions,
        cap.TreatmentInstructions,
        cap.EffectiveDate,
        cap.ReviewDate,
        cap.IsActive,
        cap.IsDeleted,
        cap.CreatedUTC,
        cap.CreatedByUserID,
        cap.ModifiedUTC,
        cap.ModifiedByUserID,
        cap.DeletedUTC,
        cap.DeletedByUserID,
        cap.DeletedReason
    FROM child.ChildAllergyPlan cap
    LEFT JOIN party.MedicalProvider pmp ON pmp.MedicalProviderID = cap.PhysicianMedicalProviderID
    WHERE cap.ChildID = @ChildID
      AND cap.IsDeleted = 0
    ORDER BY cap.EffectiveDate DESC, cap.ChildAllergyPlanID DESC;
END;
GO

CREATE OR ALTER PROCEDURE child.usp_MedicationPermission_GetByChildID
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        mp.MedicationPermissionID,
        mp.ChildID,
        mp.ConsentTypeCode,
        mp.IsApproved,
        mp.Instructions,
        mp.EffectiveDate,
        mp.ExpirationDate,
        mp.SignedByPersonID,
        p.FirstName AS SignedByFirstName,
        p.LastName AS SignedByLastName,
        mp.SignedUTC,
        mp.IsActive,
        mp.IsDeleted,
        mp.CreatedUTC,
        mp.CreatedByUserID,
        mp.ModifiedUTC,
        mp.ModifiedByUserID,
        mp.DeletedUTC,
        mp.DeletedByUserID,
        mp.DeletedReason
    FROM child.MedicationPermission mp
    LEFT JOIN party.Person p ON p.PersonID = mp.SignedByPersonID
    WHERE mp.ChildID = @ChildID
      AND mp.IsDeleted = 0
    ORDER BY mp.EffectiveDate DESC, mp.MedicationPermissionID DESC;
END;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO ref.CodeValue
(
    CodeDomain,
    CodeValue,
    CodeName
)
VALUES
(N'RelationshipType', N'GUARDIAN', N'Guardian'),
(N'RelationshipType', N'PARENT', N'Parent'),
(N'RelationshipType', N'EMERGENCY_CONTACT', N'Emergency Contact'),
(N'EnrollmentStatus', N'ACTIVE', N'Active'),
(N'EnrollmentStatus', N'INACTIVE', N'Inactive'),
(N'EnrollmentStatus', N'WAITLIST', N'Waitlist'),
(N'AssignmentType', N'OWNER', N'Owner'),
(N'AssignmentType', N'STAFF', N'Staff'),
(N'AssignmentType', N'LICENSOR', N'Licensor'),
(N'IncidentType', N'INJURY', N'Injury'),
(N'IncidentType', N'ILLNESS', N'Illness'),
(N'IncidentType', N'SAFETY', N'Safety'),
(N'ConversationType', N'DIRECT', N'Direct'),
(N'ConversationType', N'GROUP', N'Group'),
(N'ConversationType', N'ADMIN_OUTBOUND', N'Admin Outbound'),
(N'AccountStatus', N'ACTIVE', N'Active'),
(N'AccountStatus', N'INVITED', N'Invited'),
(N'AccountStatus', N'DISABLED', N'Disabled'),
(N'DrillType', N'FIRE', N'Fire'),
(N'DrillType', N'TORNADO', N'Tornado'),
(N'DrillType', N'LOCKDOWN', N'Lockdown'),
(N'InspectionType', N'SAFETY', N'Safety'),
(N'InspectionType', N'ANNUAL', N'Annual'),
(N'InspectionResult', N'PASS', N'Pass'),
(N'InspectionResult', N'FAIL', N'Fail'),
(N'InspectionResult', N'CONDITIONAL', N'Conditional'),
(N'BackgroundStudyStatus', N'PENDING', N'Pending'),
(N'BackgroundStudyStatus', N'CLEARED', N'Cleared'),
(N'BackgroundStudyStatus', N'DENIED', N'Denied'),
(N'GuardianInvitationStatus', N'PENDING', N'Pending'),
(N'GuardianInvitationStatus', N'REDEEMED', N'Redeemed'),
(N'GuardianInvitationStatus', N'REVOKED', N'Revoked');
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF COL_LENGTH('party.Person', 'RowVer') IS NULL
BEGIN
    ALTER TABLE party.Person ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('party.Provider', 'RowVer') IS NULL
BEGIN
    ALTER TABLE party.Provider ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('party.Site', 'RowVer') IS NULL
BEGIN
    ALTER TABLE party.Site ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('party.PortalUser', 'RowVer') IS NULL
BEGIN
    ALTER TABLE party.PortalUser ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.Child', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.Child ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.ChildEnrollment', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.ChildEnrollment ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.ChildPersonRelationship', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.ChildPersonRelationship ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.ChildAttendance', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.ChildAttendance ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.ChildMedicalProfile', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.ChildMedicalProfile ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.ChildAllergyPlan', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.ChildAllergyPlan ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('child.MedicationPermission', 'RowVer') IS NULL
BEGIN
    ALTER TABLE child.MedicationPermission ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('doc.Document', 'RowVer') IS NULL
BEGIN
    ALTER TABLE doc.Document ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('doc.ConsentRecord', 'RowVer') IS NULL
BEGIN
    ALTER TABLE doc.ConsentRecord ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('ops.EmergencyPlan', 'RowVer') IS NULL
BEGIN
    ALTER TABLE ops.EmergencyPlan ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('ops.IncidentReport', 'RowVer') IS NULL
BEGIN
    ALTER TABLE ops.IncidentReport ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('ops.StaffAssignment', 'RowVer') IS NULL
BEGIN
    ALTER TABLE ops.StaffAssignment ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('comm.Conversation', 'RowVer') IS NULL
BEGIN
    ALTER TABLE comm.Conversation ADD RowVer ROWVERSION;
END;
GO

IF COL_LENGTH('comm.Message', 'RowVer') IS NULL
BEGIN
    ALTER TABLE comm.Message ADD RowVer ROWVERSION;
END;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

INSERT INTO ref.SeedBatch
(
    SeedBatchCode,
    SeedBatchName,
    SeedBatchDescription,
    TargetSchemaName,
    TargetObjectName,
    BatchVersion,
    IsRequired,
    IsActive,
    CreatedByUserID
)
VALUES
(N'CORE_TIMEZONE_SEED', N'Core Time Zone Seed', N'Initial time zone reference data.', N'ref', N'TimeZone', N'1.0.0', 1, 1, NULL),
(N'CORE_ROLE_SEED', N'Core Role Seed', N'Initial portal/security role data.', N'ref', N'Role', N'1.0.0', 1, 1, NULL),
(N'LICENSE_CLASS_SEED', N'License Class Seed', N'Initial Minnesota family child care license class data.', N'lic', N'LicenseClass', N'1.0.0', 1, 1, NULL),
(N'REQUIREMENT_CATALOG_SEED', N'Requirement Catalog Seed', N'Initial compliance requirement catalog data.', N'lic', N'RequirementCatalog', N'1.0.0', 1, 1, NULL),
(N'DOCUMENT_TYPE_SEED', N'Document Type Seed', N'Initial document type reference data.', N'doc', N'DocumentType', N'1.0.0', 1, 1, NULL),
(N'CODE_VALUE_SEED', N'Code Value Seed', N'Initial shared code domain/value data.', N'ref', N'CodeValue', N'1.0.0', 1, 1, NULL),
(N'NOTIFICATION_TEMPLATE_SEED', N'Notification Template Seed', N'Initial notification templates for outbound messaging.', N'comm', N'NotificationTemplate', N'1.0.0', 1, 1, NULL);
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named ref.CodeValue.
--CREATE TABLE ref.CodeValue
--    (
--        CodeValueID                  INT IDENTITY(1,1)         NOT NULL,
--        CodeDomain                   NVARCHAR(100)             NOT NULL,
--        CodeValue                    NVARCHAR(100)             NOT NULL,
--        CodeName                     NVARCHAR(200)             NOT NULL,
--        IsActive                     BIT                       NOT NULL CONSTRAINT DF_CodeValue_IsActive DEFAULT (1),
--        CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_CodeValue_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CONSTRAINT PK_CodeValue PRIMARY KEY CLUSTERED (CodeValueID),
--        CONSTRAINT UQ_CodeValue UNIQUE (CodeDomain, CodeValue)
--    );

END;
GO

CREATE OR ALTER VIEW ref.vwCodeDomains
AS
SELECT DISTINCT CodeDomain
FROM ref.CodeValue;
GO

INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
SELECT v.CodeDomain, v.CodeValue, v.CodeName
FROM (VALUES
    (N'RelationshipType', N'GUARDIAN', N'Guardian'),
    (N'RelationshipType', N'PARENT', N'Parent'),
    (N'RelationshipType', N'EMERGENCY_CONTACT', N'Emergency Contact'),
    (N'EnrollmentStatus', N'ACTIVE', N'Active'),
    (N'EnrollmentStatus', N'INACTIVE', N'Inactive'),
    (N'EnrollmentStatus', N'WAITLIST', N'Waitlist'),
    (N'AssignmentType', N'OWNER', N'Owner'),
    (N'AssignmentType', N'STAFF', N'Staff'),
    (N'AssignmentType', N'LICENSOR', N'Licensor'),
    (N'IncidentType', N'INJURY', N'Injury'),
    (N'IncidentType', N'ILLNESS', N'Illness'),
    (N'IncidentType', N'SAFETY', N'Safety'),
    (N'ConversationType', N'DIRECT', N'Direct'),
    (N'ConversationType', N'GROUP', N'Group'),
    (N'ConversationType', N'ADMIN_OUTBOUND', N'Admin Outbound'),
    (N'AccountStatus', N'ACTIVE', N'Active'),
    (N'AccountStatus', N'INVITED', N'Invited'),
    (N'AccountStatus', N'DISABLED', N'Disabled'),
    (N'DrillType', N'FIRE', N'Fire'),
    (N'DrillType', N'TORNADO', N'Tornado'),
    (N'DrillType', N'LOCKDOWN', N'Lockdown'),
    (N'InspectionType', N'SAFETY', N'Safety'),
    (N'InspectionType', N'ANNUAL', N'Annual'),
    (N'InspectionResult', N'PASS', N'Pass'),
    (N'InspectionResult', N'FAIL', N'Fail'),
    (N'InspectionResult', N'CONDITIONAL', N'Conditional'),
    (N'BackgroundStudyStatus', N'PENDING', N'Pending'),
    (N'BackgroundStudyStatus', N'CLEARED', N'Cleared'),
    (N'BackgroundStudyStatus', N'DENIED', N'Denied'),
    (N'GuardianInvitationStatus', N'PENDING', N'Pending'),
    (N'GuardianInvitationStatus', N'REDEEMED', N'Redeemed'),
    (N'GuardianInvitationStatus', N'REVOKED', N'Revoked'),
    (N'IdentityStatus', N'PENDING', N'Pending'),
    (N'IdentityStatus', N'VERIFIED', N'Verified'),
    (N'IdentityStatus', N'REVOKED', N'Revoked'),
    (N'RecoveryRequestStatus', N'PENDING', N'Pending'),
    (N'RecoveryRequestStatus', N'APPROVED', N'Approved'),
    (N'RecoveryRequestStatus', N'REJECTED', N'Rejected'),
    (N'RecoveryRequestStatus', N'EXECUTED', N'Executed'),
    (N'RecoveryRequestStatus', N'EXECUTION_FAILED', N'Execution Failed'),
    (N'ComplianceReviewStatus', N'OPEN', N'Open'),
    (N'ComplianceReviewStatus', N'IN_PROGRESS', N'In Progress'),
    (N'ComplianceReviewStatus', N'CLOSED', N'Closed'),
    (N'FindingSeverity', N'LOW', N'Low'),
    (N'FindingSeverity', N'MEDIUM', N'Medium'),
    (N'FindingSeverity', N'HIGH', N'High'),
    (N'FindingSeverity', N'CRITICAL', N'Critical'),
    (N'FindingStatus', N'OPEN', N'Open'),
    (N'FindingStatus', N'IN_REMEDIATION', N'In Remediation'),
    (N'FindingStatus', N'RESOLVED', N'Resolved'),
    (N'FindingStatus', N'CLOSED', N'Closed')
) v(CodeDomain, CodeValue, CodeName)
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = v.CodeDomain
      AND c.CodeValue = v.CodeValue
);
GO

/*
    Phase 1 strategy:
    -----------------
    We are not converting every string ...Code column into CodeValueID FKs yet.
    That would be a broader refactor and would be dangerous while the package is
    still being manually stabilized.

    For this branch, the shared code inventory plus validation views and proc-
    level validation are the safer move.
*/

CREATE OR ALTER VIEW rpt.vwCodeUsageValidation
AS
SELECT N'child.ChildPersonRelationship' AS TableName, N'RelationshipTypeCode' AS ColumnName, r.RelationshipTypeCode AS CodeValue
FROM child.ChildPersonRelationship r
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'RelationshipType'
      AND c.CodeValue = r.RelationshipTypeCode
)
UNION ALL
SELECT N'child.ChildEnrollment', N'EnrollmentStatusCode', e.EnrollmentStatusCode
FROM child.ChildEnrollment e
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'EnrollmentStatus'
      AND c.CodeValue = e.EnrollmentStatusCode
)
UNION ALL
SELECT N'child.GuardianInvitation', N'InvitationStatusCode', g.InvitationStatusCode
FROM child.GuardianInvitation g
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'GuardianInvitationStatus'
      AND c.CodeValue = g.InvitationStatusCode
)
UNION ALL
SELECT N'ops.IncidentReport', N'IncidentTypeCode', i.IncidentTypeCode
FROM ops.IncidentReport i
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'IncidentType'
      AND c.CodeValue = i.IncidentTypeCode
)
UNION ALL
SELECT N'ops.DrillLog', N'DrillTypeCode', d.DrillTypeCode
FROM ops.DrillLog d
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'DrillType'
      AND c.CodeValue = d.DrillTypeCode
)
UNION ALL
SELECT N'ops.SafetyInspection', N'InspectionTypeCode', si.InspectionTypeCode
FROM ops.SafetyInspection si
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'InspectionType'
      AND c.CodeValue = si.InspectionTypeCode
)
UNION ALL
SELECT N'ops.SafetyInspection', N'InspectionResultCode', si.InspectionResultCode
FROM ops.SafetyInspection si
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'InspectionResult'
      AND c.CodeValue = si.InspectionResultCode
)
UNION ALL
SELECT N'ops.BackgroundStudyRecord', N'StudyStatusCode', b.StudyStatusCode
FROM ops.BackgroundStudyRecord b
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'BackgroundStudyStatus'
      AND c.CodeValue = b.StudyStatusCode
)
UNION ALL
SELECT N'comm.Conversation', N'ConversationTypeCode', c0.ConversationTypeCode
FROM comm.Conversation c0
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'ConversationType'
      AND c.CodeValue = c0.ConversationTypeCode
)
UNION ALL
SELECT N'party.PortalUser', N'AccountStatusCode', p.AccountStatusCode
FROM party.PortalUser p
WHERE NOT EXISTS
(
    SELECT 1 FROM ref.CodeValue c
    WHERE c.CodeDomain = N'AccountStatus'
      AND c.CodeValue = p.AccountStatusCode
);
GO

/*
    Business rule constraints that are safe against the current package state.
*/
IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UX_ChildMedicalProfile_Child_Active'
      AND object_id = OBJECT_ID(N'child.ChildMedicalProfile')
)
BEGIN
    --The following statement was imported into the database project as a schema object and named child.ChildMedicalProfile.UX_ChildMedicalProfile_Child_Active.
--CREATE UNIQUE INDEX UX_ChildMedicalProfile_Child_Active
--        ON child.ChildMedicalProfile (ChildID)
--        WHERE IsDeleted = 0;

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UX_ChildEnrollment_PrimaryActive'
      AND object_id = OBJECT_ID(N'child.ChildEnrollment')
)
BEGIN
    --The following statement was imported into the database project as a schema object and named child.ChildEnrollment.UX_ChildEnrollment_PrimaryActive.
--CREATE UNIQUE INDEX UX_ChildEnrollment_PrimaryActive
--        ON child.ChildEnrollment (ChildID)
--        WHERE IsDeleted = 0
--          AND IsActive = 1
--          AND IsPrimaryEnrollment = 1;

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UX_ChildPersonRelationship_PrimaryGuardianActive'
      AND object_id = OBJECT_ID(N'child.ChildPersonRelationship')
)
BEGIN
    --The following statement was imported into the database project as a schema object and named child.ChildPersonRelationship.UX_ChildPersonRelationship_PrimaryGuardianActive.
--CREATE UNIQUE INDEX UX_ChildPersonRelationship_PrimaryGuardianActive
--        ON child.ChildPersonRelationship (ChildID)
--        WHERE IsDeleted = 0
--          AND IsActive = 1
--          AND IsPrimaryGuardian = 1;

END;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF NOT EXISTS (SELECT 1 FROM ref.MedicalProviderType WHERE MedicalProviderTypeCode = N'PHYSICIAN')
    INSERT INTO ref.MedicalProviderType (MedicalProviderTypeCode, MedicalProviderTypeName) VALUES (N'PHYSICIAN', N'Physician');
GO

IF NOT EXISTS (SELECT 1 FROM ref.MedicalProviderType WHERE MedicalProviderTypeCode = N'DENTIST')
    INSERT INTO ref.MedicalProviderType (MedicalProviderTypeCode, MedicalProviderTypeName) VALUES (N'DENTIST', N'Dentist');
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_MedicalProvider_Type_Name' AND object_id = OBJECT_ID(N'party.MedicalProvider'))
    --The following statement was imported into the database project as a schema object and named party.MedicalProvider.IX_MedicalProvider_Type_Name.
--CREATE INDEX IX_MedicalProvider_Type_Name ON party.MedicalProvider (MedicalProviderTypeID, ProviderName, IsDeleted, IsActive);

GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Hospital_Name' AND object_id = OBJECT_ID(N'party.Hospital'))
    --The following statement was imported into the database project as a schema object and named party.Hospital.IX_Hospital_Name.
--CREATE INDEX IX_Hospital_Name ON party.Hospital (HospitalName, IsDeleted, IsActive);

GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'lic.RequirementStatus', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named lic.RequirementStatus.
--CREATE TABLE lic.RequirementStatus
--    (
--        RequirementStatusID           INT IDENTITY(1,1)        NOT NULL,
--        RequirementID                 INT                      NOT NULL,
--        SiteID                        INT                      NULL,
--        ChildID                       INT                      NULL,
--        PersonID                      INT                      NULL,
--        StatusCode                    NVARCHAR(50)             NOT NULL,
--        StatusDateUTC                 DATETIME2(0)             NOT NULL CONSTRAINT DF_RequirementStatus_StatusDateUTC DEFAULT (SYSUTCDATETIME()),
--        ReviewDueDate                 DATE                     NULL,
--        ReviewedByUserID              INT                      NULL,
--        Notes                         NVARCHAR(MAX)           NULL,
--        IsCurrent                     BIT                      NOT NULL CONSTRAINT DF_RequirementStatus_IsCurrent DEFAULT (1),
--        IsActive                      BIT                      NOT NULL CONSTRAINT DF_RequirementStatus_IsActive DEFAULT (1),
--        IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_RequirementStatus_IsDeleted DEFAULT (0),
--        CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_RequirementStatus_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CreatedByUserID               INT                      NULL,
--        ModifiedUTC                   DATETIME2(0)             NULL,
--        ModifiedByUserID              INT                      NULL,
--        DeletedUTC                    DATETIME2(0)             NULL,
--        DeletedByUserID               INT                      NULL,
--        DeletedReason                 NVARCHAR(500)            NULL,
--        RowVer                        ROWVERSION               NOT NULL,
--        CONSTRAINT PK_RequirementStatus PRIMARY KEY CLUSTERED (RequirementStatusID),
--        CONSTRAINT FK_RequirementStatus_Requirement FOREIGN KEY (RequirementID) REFERENCES lic.RequirementCatalog (RequirementID),
--        CONSTRAINT FK_RequirementStatus_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
--        CONSTRAINT FK_RequirementStatus_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
--        CONSTRAINT FK_RequirementStatus_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID),
--        CONSTRAINT FK_RequirementStatus_ReviewedByUser FOREIGN KEY (ReviewedByUserID) REFERENCES party.PortalUser (PortalUserID)
--    );

END;
GO

IF OBJECT_ID(N'lic.RequirementEvidence', N'U') IS NULL
BEGIN
    --The following statement was imported into the database project as a schema object and named lic.RequirementEvidence.
--CREATE TABLE lic.RequirementEvidence
--    (
--        RequirementEvidenceID         INT IDENTITY(1,1)        NOT NULL,
--        RequirementID                 INT                      NOT NULL,
--        SiteID                        INT                      NULL,
--        ChildID                       INT                      NULL,
--        PersonID                      INT                      NULL,
--        DocumentID                    INT                      NULL,
--        EvidenceTypeCode              NVARCHAR(100)            NOT NULL,
--        EvidenceStatusCode            NVARCHAR(50)             NOT NULL,
--        EvidenceDate                  DATE                     NULL,
--        ExpirationDate                DATE                     NULL,
--        Notes                         NVARCHAR(MAX)           NULL,
--        IsCurrent                     BIT                      NOT NULL CONSTRAINT DF_RequirementEvidence_IsCurrent DEFAULT (1),
--        IsActive                      BIT                      NOT NULL CONSTRAINT DF_RequirementEvidence_IsActive DEFAULT (1),
--        IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_RequirementEvidence_IsDeleted DEFAULT (0),
--        CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_RequirementEvidence_CreatedUTC DEFAULT (SYSUTCDATETIME()),
--        CreatedByUserID               INT                      NULL,
--        ModifiedUTC                   DATETIME2(0)             NULL,
--        ModifiedByUserID              INT                      NULL,
--        DeletedUTC                    DATETIME2(0)             NULL,
--        DeletedByUserID               INT                      NULL,
--        DeletedReason                 NVARCHAR(500)            NULL,
--        RowVer                        ROWVERSION               NOT NULL,
--        CONSTRAINT PK_RequirementEvidence PRIMARY KEY CLUSTERED (RequirementEvidenceID),
--        CONSTRAINT FK_RequirementEvidence_Requirement FOREIGN KEY (RequirementID) REFERENCES lic.RequirementCatalog (RequirementID),
--        CONSTRAINT FK_RequirementEvidence_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
--        CONSTRAINT FK_RequirementEvidence_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
--        CONSTRAINT FK_RequirementEvidence_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID),
--        CONSTRAINT FK_RequirementEvidence_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
--    );

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_RequirementStatus_Target'
      AND object_id = OBJECT_ID(N'lic.RequirementStatus')
)
BEGIN
    --The following statement was imported into the database project as a schema object and named lic.RequirementStatus.IX_RequirementStatus_Target.
--CREATE INDEX IX_RequirementStatus_Target
--        ON lic.RequirementStatus (RequirementID, SiteID, ChildID, PersonID, IsDeleted, IsCurrent);

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_RequirementEvidence_Target'
      AND object_id = OBJECT_ID(N'lic.RequirementEvidence')
)
BEGIN
    --The following statement was imported into the database project as a schema object and named lic.RequirementEvidence.IX_RequirementEvidence_Target.
--CREATE INDEX IX_RequirementEvidence_Target
--        ON lic.RequirementEvidence (RequirementID, SiteID, ChildID, PersonID, IsDeleted, IsCurrent);

END;
GO

CREATE OR ALTER VIEW rpt.vwRequirementComplianceSummary
AS
SELECT
    rc.RequirementID,
    rc.RequirementCode,
    rc.RequirementTitle,
    rs.SiteID,
    rs.ChildID,
    rs.PersonID,
    rs.StatusCode,
    rs.ReviewDueDate,
    re.RequirementEvidenceID,
    re.EvidenceTypeCode,
    re.EvidenceStatusCode,
    re.EvidenceDate,
    re.ExpirationDate
FROM lic.RequirementCatalog rc
LEFT JOIN lic.RequirementStatus rs
    ON rs.RequirementID = rc.RequirementID
   AND rs.IsDeleted = 0
   AND rs.IsCurrent = 1
LEFT JOIN lic.RequirementEvidence re
    ON re.RequirementID = rc.RequirementID
   AND ISNULL(re.SiteID, -1) = ISNULL(rs.SiteID, -1)
   AND ISNULL(re.ChildID, -1) = ISNULL(rs.ChildID, -1)
   AND ISNULL(re.PersonID, -1) = ISNULL(rs.PersonID, -1)
   AND re.IsDeleted = 0
   AND re.IsCurrent = 1
WHERE rc.IsActive = 1;
GO

/*
    Daycare Provider Assistant
    Database Package Part 01
    SCHEMA CREATION
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 02
    ref SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 03
    lic SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 04
    party SCHEMA OBJECTS

    Canonical recreated version aligned to the current package direction:
        - Provider.LicenseHolderPersonID is an FK to party.Person
        - Provider.LegalEntityName is NOT NULL
        - UI/business rule: LegalEntityName defaults to ProviderName at create time
        - Phone numbers are normalized into party.PhoneNumber
        - Addresses are normalized into party.Address
        - Main tables carry FK columns to canonical address / phone rows
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 05
    child SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 05
    child SCHEMA OBJECTS

    REVISION NOTES
    --------------
    1. All NVARCHAR/VARCHAR columns with declared length >= 1000 have been
       converted to NVARCHAR(MAX)/VARCHAR(MAX) as appropriate.
    2. Address relationships now use FK columns instead of inline address text.
    3. Phone number relationships now use FK columns instead of inline phone text.
    4. Hospital remains name-based in this revision. If we normalize hospital as
       its own entity next, this file should be revised again.
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_05_patch_01

    PURPOSE
    -------
    Patch current Part 05 so that:
      1. Any reason column is NVARCHAR(MAX)
      2. Any NVARCHAR/VARCHAR column >= 1000 becomes NVARCHAR(MAX)/VARCHAR(MAX)
      3. Child addresses use FK relationships
      4. Physicians and dentists normalize into their own shared table with a type FK
      5. Hospitals normalize into their own table with FKs to phone numbers and addresses

    ASSUMPTION
    ----------
    This patch is intended to run before production data exists, or after controlled
    migration planning. It removes legacy inline address/phone fields once the new
    FK-based columns are added.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 06
    doc SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 07
    ops SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 08
    comm SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 09
    audit SCHEMA OBJECTS
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 10
    sec SCHEMA OBJECTS

    SECURITY HELPER OBJECTS

    These functions support application-enforced security,
    reporting filters, procedure validation, and future row-level security work.

    Expected SESSION_CONTEXT keys:
        - PortalUserID
        - SiteID
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 11
    FUNCTION OBJECTS

    Includes:
        - child.fn_CalculateAgeInDays
        - lic.fn_GetFamilyAgeBandCode
        - lic.fn_GetNextFamilyAgeBandTransitionDate
        - lic.fn_GetSiteChildCountSnapshot
        - lic.fn_ValidateFamilyCareCapacity
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 12
    audit STORED PROCEDURES

    Includes:
        - audit.usp_WriteAuditLog
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 13
    child STORED PROCEDURES

    Includes:
        - child.usp_Child_Insert
        - child.usp_Child_Update
        - child.usp_Child_SoftDelete
        - child.usp_ChildPersonRelationship_Upsert
        - child.usp_GuardianInvitation_Create
        - child.usp_PickupDropoffAuthorization_Upsert
        - child.usp_Attendance_Insert
        - child.usp_Attendance_Update
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_13_patch_01

    PURPOSE
    -------
    Bring Part 13 into alignment with dpa_db_05_patch_01.

    Key changes:
      - Child insert/update uses ChildAddressID instead of inline address text
      - Reason parameters are NVARCHAR(MAX)
      - Child medical profile upsert uses provider/hospital FKs
      - Child allergy plan upsert uses physician provider FK
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 14
    doc STORED PROCEDURES

    Includes:
        - doc.usp_Document_Insert
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 15
    ops STORED PROCEDURES

    Includes:
        - ops.usp_IncidentReport_Insert
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 16
    lic STORED PROCEDURES

    Includes:
        - lic.usp_CapacitySnapshot_Get
        - lic.usp_CapacityForecast_Get
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 17
    comm STORED PROCEDURES

    Includes:
        - comm.usp_Conversation_Create
        - comm.usp_AdminConversation_Create
        - comm.usp_Message_Send
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 18
    rpt VIEW OBJECTS

    Includes:
        - rpt.vwActiveChildEnrollmentSummary
        - rpt.vwGuardianAccessSummary
        - rpt.vwDocumentStatus
        - rpt.vwProviderCapacityStatus
        - rpt.vwLicensorAggregateChildCounts
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 19
    END COMMENTS AND EXECUTION NOTES

    EXECUTION ORDER
    ---------------
    00 - Exists and Drops
    01 - Schema Creation
    02 - ref Schema Objects
    03 - lic Schema Objects
    04 - party Schema Objects
    05 - child Schema Objects
    06 - doc Schema Objects
    07 - ops Schema Objects
    08 - comm Schema Objects
    09 - audit Schema Objects
    10 - sec Schema Objects
    11 - Function Objects
    12 - audit Stored Procedures
    13 - child Stored Procedures
    14 - doc Stored Procedures
    15 - ops Stored Procedures
    16 - lic Stored Procedures
    17 - comm Stored Procedures
    18 - rpt View Objects
    19 - End Comments and Execution Notes

    IMPLEMENTATION NOTES
    --------------------
    1. This package is a working technical draft and should be treated as the
       base build set, not the final forever version.
    2. The current package is oriented toward Minnesota family child care and
       group family child care.
    3. Child care center support is intentionally excluded from this package.
    4. All normal writes are expected to flow through stored procedures.
    5. Soft delete is the default delete model across business tables.
    6. Audit logging is expected to be extended as additional write procedures are added.
    7. Application-layer authorization must still be enforced in addition to
       database design and helper security functions.
    8. SESSION_CONTEXT usage in sec schema helpers assumes the application sets:
           - PortalUserID
           - SiteID
    9. Count and forecast logic should be regression tested against real provider
       scenarios before production use.
   10. Licensor portal queries should prefer reporting views and aggregate
       procedures, not raw child-detail queries.
   11. Admin-outbound messaging is intentionally separated from standard messaging.

    NEXT EXPECTED DATABASE ITERATIONS
    ---------------------------------
    - Add more stored procedures for provider/site/staff/doc/consent workflows
    - Normalize additional medical/contact/address data as needed
    - Add richer audit capture for failed authorization attempts
    - Add document retention metadata and purge-hold policy fields
    - Add notification-generation procedures/jobs
    - Add more reporting views and export procedures
    - Add stronger validation procedures for guardian invitation redemption
    - Add break-glass workflow procedures and approval enforcement
    - Add unit-test harness scripts / seed data scripts / demo data scripts

    END OF PACKAGE
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 20
    CAPACITY INPUTS AND COUNT ENGINE REVISIONS

    Includes:
        - ops.CaregiverPresence
        - ops.CountedNonEnrollmentChild
        - ops.usp_CaregiverPresence_Upsert
        - ops.usp_CountedNonEnrollmentChild_Upsert
        - rpt.vwCapacityInputsByDate
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 21
    LICENSING VARIANCE AND REQUIREMENT EVIDENCE

    Includes:
        - lic.LicenseVariance
        - lic.RequirementStatus
        - lic.RequirementEvidence
        - lic.usp_LicenseVariance_Upsert
        - lic.usp_RequirementStatus_Upsert
        - lic.usp_RequirementEvidence_Upsert
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 22
    MESSAGING NOTIFICATION AND PARTICIPANT MANAGEMENT

    Includes:
        - comm.NotificationTemplate
        - comm.EmailOutbox
        - comm.ConversationParticipantAudit
        - comm.usp_ConversationParticipant_Add
        - comm.usp_ConversationParticipant_Remove
        - comm.usp_Conversation_Archive
        - comm.usp_Message_MarkRead
        - comm.usp_MessageAttachment_Add
        - comm.usp_AdminConversation_Close
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 23
    PARTY CORE CRUD STORED PROCEDURES

    Includes:
        - party.usp_Address_Upsert
        - party.usp_PhoneNumber_Upsert
        - party.usp_Person_Upsert
        - party.usp_Provider_Upsert
        - party.usp_Site_Upsert
        - party.usp_PortalUser_Upsert
        - party.usp_SiteUserAssignment_Upsert
        - party.usp_LicensorAssignment_Upsert
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_23_patch_01

    PURPOSE
    -------
    Extend Part 23 for the normalized medical-provider/hospital model and
    update reason parameters to NVARCHAR(MAX).

    Includes:
      - party.usp_MedicalProvider_Upsert
      - party.usp_Hospital_Upsert
      - signature alignment notes for existing Part 23 procedures
*/
GO


/*
    REQUIRED RECOMPILE NOTE FOR EXISTING PART 23 PROCEDURES
    -------------------------------------------------------
    The following Part 23 procedures should be recompiled so that their
    @ReasonText parameters are NVARCHAR(MAX):

        party.usp_Address_Upsert
        party.usp_PhoneNumber_Upsert
        party.usp_Person_Upsert
        party.usp_Provider_Upsert
        party.usp_Site_Upsert
        party.usp_PortalUser_Upsert
        party.usp_SiteUserAssignment_Upsert
        party.usp_LicensorAssignment_Upsert

    Address and phone procedures are explicitly patched in dpa_db_34_patch_01.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 24
    DOCUMENT AND CONSENT WRITE SURFACE

    Includes:
        - doc.usp_ConsentRecord_Upsert
        - doc.usp_Document_SoftDelete
        - doc.usp_EntityDocument_Link
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 25
    CHILD MEDICAL LOOKUP STORED PROCEDURES

    Includes:
        - child.usp_ChildMedicalProfile_GetByChildID
        - child.usp_ChildAllergyPlan_GetByChildID
        - child.usp_MedicationPermission_GetByChildID
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_25_patch_01

    PURPOSE
    -------
    Update medical lookup procedures to the FK-based provider and hospital model.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 26
    CODE TABLES AND BUSINESS RULE CONSTRAINTS

    Includes:
        - ref.CodeValue
        - ref.vwCodeDomains
        - rpt.vwCodeUsageValidation
        - filtered unique indexes / integrity constraints where safe
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 27
    SECURITY ENFORCEMENT SCAFFOLD

    Includes:
        - sec.fn_HasRoleCode
        - sec.fn_UserAssignedToSite
        - sec.fn_UserLinkedToChild
        - sec.fn_UserCanAccessChildDetail
        - sec.fn_UserCanAccessSiteAggregate
        - rpt.vwSecureChildAccess
        - rpt.vwSecureSiteAggregateAccess

    Notes:
        - This is an application/procedure-aligned security scaffold.
        - It is not a full SQL Server Row-Level Security rollout.
        - It assumes SESSION_CONTEXT('PortalUserID') and optionally SESSION_CONTEXT('SiteID').
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 28
    CONCURRENCY CONTROLS

    Includes:
        - rowversion columns for key mutable tables that do not already have one
        - sec.usp_AssertRowVersionMatch

    Notes:
        - This is an optimistic concurrency scaffold.
        - Use this with application-side read/write tokens.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 29
    GUARDIAN EMAIL IDENTITY

    Includes:
        - child.GuardianEmailIdentity
        - child.GuardianEmailClaimAttempt
        - child.GuardianEmailChangeRequest
        - child.usp_GuardianEmailIdentity_Upsert
        - child.usp_GuardianEmailClaimAttempt_Insert
        - child.usp_GuardianEmailChangeRequest_Create

    Notes:
        - This part is aligned to the current manual Part 05 state.
        - It does not assume the newer normalized child medical/hospital redesign.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 30
    ADMIN RECOVERY WORKFLOW

    Includes:
        - audit.RecoveryRequest
        - audit.RecoveryApproval
        - audit.RecoveryExecution
        - audit.usp_RecoveryRequest_Create
        - audit.usp_RecoveryRequest_Approve
        - audit.usp_RecoveryExecution_Log

    Notes:
        - This part supports the policy that deleted records are not restorable
          through ordinary user workflows.
        - This is an admin-only recovery governance layer.
        - It does NOT create generic restore procedures for users.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 31
    COMPLIANCE REVIEW STATE

    Includes:
        - lic.ComplianceReview
        - lic.ComplianceFinding
        - lic.FindingResolution
        - rpt.vwOpenComplianceFindings
        - lic.usp_ComplianceReview_Upsert
        - lic.usp_ComplianceFinding_Upsert
        - lic.usp_FindingResolution_Upsert
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 32
    SEED STRATEGY AND BATCHES

    Includes:
        - ref.SeedBatch
        - ref.SeedBatchExecution
        - ref.usp_SeedBatch_Start
        - ref.usp_SeedBatch_Complete
        - starter seed batch rows

    Purpose:
        Track what reference/seed batches have been applied, by whom, and when.
        This is not a full data seeding engine. It is the control ledger for one.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 33
    CANONICAL PACKAGE DECISIONS

    PURPOSE
    -------
    This file documents the currently selected canonical package order and
    locks the active direction for the manually curated build set.

    IMPORTANT
    ---------
    The user's manually edited canvas for:
        DPA DB 05 - Child Schema Objects
    is treated as the authoritative current Part 05 state.

    That means the active package direction currently assumes:
        - child address fields remain inline on child.Child
        - child medical profile still stores physician/dentist/hospital names and phones inline
        - hospital has NOT yet been normalized in the active branch

    CANONICAL PACKAGE ORDER
    -----------------------
    00 - Exists and Drops
    01 - Schema Creation
    02 - ref Schema Objects
    03 - lic Schema Objects
    04 - party Schema Objects
    05 - child Schema Objects
    06 - doc Schema Objects
    07 - ops Schema Objects
    08 - comm Schema Objects
    09 - audit Schema Objects
    10 - sec Schema Objects
    11 - Function Objects
    12 - audit Stored Procedures
    13 - child Stored Procedures
    14 - doc Stored Procedures
    15 - ops Stored Procedures
    16 - lic Stored Procedures
    17 - comm Stored Procedures
    18 - rpt View Objects
    19 - End Comments and Execution Notes
    20 - Capacity Inputs and Count Engine Revisions
    21 - Licensing Variance and Requirement Evidence
    22 - Messaging Notification and Participant Management
    23 - Party Core CRUD Stored Procedures
    24 - Document and Consent Write Surface
    25 - Child Medical Lookup Stored Procedures
    26 - Code Tables and Business Rule Constraints
    27 - Security Enforcement Scaffold
    28 - Concurrency Controls
    29 - Guardian Email Identity
    30 - Admin Recovery Workflow
    31 - Compliance Review State
    32 - Seed Strategy and Batches
    33 - Canonical Package Decisions

    CURRENT PACKAGE RULES
    ---------------------
    1. The package is currently branch-locked to the manually edited Part 05.
    2. New objects must not assume a different child medical/address model unless
       the user explicitly authorizes a new Part 05 replacement.
    3. The package remains family child care / group family child care focused.
    4. Child care center support is out of scope for this branch.
    5. Soft delete remains the default delete strategy.
    6. Restore remains admin-governed only, not user-facing.
    7. Application procedures remain the primary write surface.
    8. SESSION_CONTEXT-based security helpers are scaffolding, not a full RLS rollout.

    FOLLOW-UP NOTE
    --------------
    If the child schema is later re-normalized again, this file should be revised
    immediately so the package does not drift into split-brain territory.
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_33_patch_01

    CANONICAL BRANCH UPDATE
    -----------------------
    This patch updates the canonical package direction after the following design
    decisions were made:

      1. Any VARCHAR/NVARCHAR column >= 1000 becomes VARCHAR(MAX)/NVARCHAR(MAX)
      2. Any column with 'Reason' in the name should be NVARCHAR(MAX)
      3. Child address storage is FK-based via party.Address
      4. Physicians and dentists normalize through party.MedicalProvider
         with FK to ref.MedicalProviderType
      5. Hospitals normalize through party.Hospital with FKs to party.PhoneNumber
         and party.Address

    EFFECTIVE BRANCH CHANGES
    ------------------------
    The active branch is now expected to include:

      - dpa_db_05_patch_01
      - dpa_db_13_patch_01
      - dpa_db_23_patch_01
      - dpa_db_25_patch_01
      - dpa_db_34_patch_01
      - dpa_db_35_patch_01
      - dpa_db_38_patch_01
      - dpa_db_39_patch_01

    FOLLOW-UP TRUTH
    ---------------
    Because the 'reason column = NVARCHAR(MAX)' rule is global, additional patch
    work is still advisable for any parts not covered above that also contain
    reason fields, especially later administrative/compliance patches.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 34
    ADDRESS AND PHONE CRUD

    IMPORTANT
    ---------
    This part is intentionally aligned to the current canonical package state,
    including the manually edited Part 05 child schema.

    That means this part only targets the normalized party.Address and
    party.PhoneNumber objects plus core lookup helpers. It does NOT attempt
    to retrofit child medical or child address storage away from the current
    inline Part 05 design.

    Includes:
        - party.usp_Address_Upsert
        - party.usp_Address_SoftDelete
        - party.usp_Address_FindCanonical
        - party.usp_PhoneNumber_Upsert
        - party.usp_PhoneNumber_SoftDelete
        - party.usp_PhoneNumber_FindCanonical
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_34_patch_01

    PURPOSE
    -------
    Bring address and phone CRUD procedures into compliance with the rule that
    any reason parameter should be NVARCHAR(MAX).
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 35
    CODE TABLE FK FINALIZATION

    IMPORTANT
    ---------
    This part is aligned to the CURRENT manually edited package state,
    especially Part 05 as it exists right now.

    That means:
        - child.Child still has inline address fields
        - child.ChildMedicalProfile still has inline physician/dentist/hospital fields
        - this part does NOT attempt to force a different child schema model

    Includes:
        - ref.CodeValue
        - ref.vwCodeDomains
        - rpt.vwCodeUsageValidation
        - Phase 1 code inventory / validation strategy notes
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_35_patch_01

    PURPOSE
    -------
    Finalize code and reference support for the normalized medical-provider model.

    Includes:
      - validation/seed support for ref.MedicalProviderType
      - extended code validation view notes
*/
GO


/*
    Phase 1 note:
    ------------
    MedicalProviderType is implemented as a dedicated reference table instead of
    a generic CodeValue domain because the user explicitly asked for a type FK.
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 36
    STAFFING AND COUNTED CHILD INPUTS

    IMPORTANT
    ---------
    This part is aligned to the CURRENT manually edited package state,
    especially Part 05 as it exists right now.

    That means:
        - child.Child remains unchanged
        - child medical/hospital data remains inline in Part 05
        - this part adds operational count inputs only

    Includes:
        - ops.CaregiverPresence
        - ops.CountedNonEnrollmentChild
        - ops.usp_CaregiverPresence_Upsert
        - ops.usp_CountedNonEnrollmentChild_Upsert
        - rpt.vwCapacityInputsByDate
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 37
    REQUIREMENT EVIDENCE AND COMPLIANCE FINALIZATION

    IMPORTANT
    ---------
    This part is aligned to the CURRENT manually edited package state,
    especially Part 05 as it exists right now.

    That means:
        - child.Child remains unchanged
        - child medical / hospital data remains inline in Part 05
        - this part finalizes requirement status and evidence structures only

    Includes:
        - lic.RequirementStatus
        - lic.RequirementEvidence
        - lic.usp_RequirementStatus_Upsert
        - lic.usp_RequirementEvidence_Upsert
        - rpt.vwRequirementComplianceSummary
*/
GO

/*
    Daycare Provider Assistant
    Database Package Part 38
    FINAL MANIFEST AND MASTER BUILD

    SQLCMD MODE REQUIRED
    --------------------
    This file uses :r include statements and must be executed in SQLCMD mode.

    IMPORTANT
    ---------
    This manifest is aligned to the CURRENT manual package branch, including the
    latest manually edited state of:

        DPA DB 05 - Child Schema Objects

    So this build intentionally references the current manual Part 05 as-is.
    It does NOT reference any alternate normalized child-schema branch.

    DIRECTORY ASSUMPTION
    --------------------
    Place this file in the same directory as the referenced package files.
*/
GO

/*
    Daycare Provider Assistant
    Patch File: dpa_db_38_patch_01

    PURPOSE
    -------
    Update the master SQLCMD build manifest to include the new patch files.

    NOTE
    ----
    This patch file itself is documentation for the revised include order.
    Copy the include block below into the active Part 38 manifest when you are
    ready to cut the next canonical build snapshot.
*/
GO


/*
:r .\DPA DB 00 - Exists and Drops.sql
:r .\DPA DB 01 - Schema Creation.sql
:r .\DPA DB 02 - ref Schema Objects.sql
:r .\DPA DB 03 - lic Schema Objects.sql
:r .\DPA DB 04 - Party Schema Objects.sql
:r .\DPA DB 05 - Child Schema Objects.sql
:r .\dpa_db_05_patch_01.sql
:r .\DPA DB 06 - doc Schema Objects.sql
:r .\DPA DB 07 - ops Schema Objects.sql
:r .\DPA DB 08 - comm Schema Objects.sql
:r .\DPA DB 09 - audit Schema Objects.sql
:r .\DPA DB 10 - sec Schema Objects.sql
:r .\DPA DB 11 - Function Objects.sql
:r .\DPA DB 12 - audit Stored Procedures.sql
:r .\DPA DB 13 - child Stored Procedures.sql
:r .\dpa_db_13_patch_01.sql
:r .\DPA DB 14 - doc Stored Procedures.sql
:r .\DPA DB 15 - ops Stored Procedures.sql
:r .\DPA DB 16 - lic Stored Procedures.sql
:r .\DPA DB 17 - comm Stored Procedures.sql
:r .\DPA DB 18 - rpt View Objects.sql
:r .\DPA DB 19 - End Comments and Execution Notes.sql
:r .\DPA DB 20 - Capacity Inputs and Count Engine Revisions.sql
:r .\DPA DB 21 - Licensing Variance and Requirement Evidence.sql
:r .\DPA DB 22 - Messaging Notification and Participant Management.sql
:r .\DPA DB 23 - Party Core CRUD Stored Procedures.sql
:r .\dpa_db_23_patch_01.sql
:r .\DPA DB 24 - Document and Consent Write Surface.sql
:r .\DPA DB 25 - Child Medical Lookup Stored Procedures.sql
:r .\dpa_db_25_patch_01.sql
:r .\DPA DB 26 - Code Tables and Business Rule Constraints.sql
:r .\DPA DB 27 - Security Enforcement Scaffold.sql
:r .\DPA DB 28 - Concurrency Controls.sql
:r .\DPA DB 29 - Guardian Email Identity.sql
:r .\DPA DB 30 - Admin Recovery Workflow.sql
:r .\DPA DB 31 - Compliance Review State.sql
:r .\DPA DB 32 - Seed Strategy and Batches.sql
:r .\DPA DB 33 - Canonical Package Decisions.sql
:r .\dpa_db_33_patch_01.sql
:r .\DPA DB 34 - Address and Phone CRUD.sql
:r .\dpa_db_34_patch_01.sql
:r .\DPA DB 35 - Code Table FK Finalization.sql
:r .\dpa_db_35_patch_01.sql
:r .\DPA DB 36 - Staffing and Counted Child Inputs.sql
:r .\DPA DB 37 - Requirement Evidence and Compliance Finalization.sql
:r .\DPA DB 38 - Final Manifest and Master Build.sql
:r .\dpa_db_38_patch_01.sql
:r .\DPA DB 39 - Gap Review Checklist and Findings.md
:r .\dpa_db_39_patch_01.md
*/
GO


CREATE PROCEDURE child.usp_Child_Insert
    @SiteID                     INT,
    @FirstName                  NVARCHAR(100),
    @MiddleName                 NVARCHAR(100)      = NULL,
    @LastName                   NVARCHAR(100),
    @DateOfBirth                DATE,
    @AddressLine1               NVARCHAR(200)      = NULL,
    @AddressLine2               NVARCHAR(200)      = NULL,
    @City                       NVARCHAR(100)      = NULL,
    @StateCode                  NVARCHAR(10)       = NULL,
    @PostalCode                 NVARCHAR(20)       = NULL,
    @SpecialDietNotes           NVARCHAR(MAX)     = NULL,
    @SpecialNeedsNotes          NVARCHAR(MAX)     = NULL,
    @EnrollmentStartDate        DATE,
    @EnrollmentEndDate          DATE               = NULL,
    @ScheduleSummary            NVARCHAR(500)      = NULL,
    @FinancialArrangementNotes  NVARCHAR(MAX)     = NULL,
    @EnrollmentStatusCode       NVARCHAR(50),
    @CreatedByUserID            INT,
    @ReasonText                 NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ChildID INT;
    DECLARE @ChildEnrollmentID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    BEGIN TRAN;

    INSERT INTO child.Child
    (
        SiteID,
        FirstName,
        MiddleName,
        LastName,
        DateOfBirth,
        AddressLine1,
        AddressLine2,
        City,
        StateCode,
        PostalCode,
        SpecialDietNotes,
        SpecialNeedsNotes,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        @FirstName,
        @MiddleName,
        @LastName,
        @DateOfBirth,
        @AddressLine1,
        @AddressLine2,
        @City,
        @StateCode,
        @PostalCode,
        @SpecialDietNotes,
        @SpecialNeedsNotes,
        @CreatedByUserID
    );

    SET @ChildID = SCOPE_IDENTITY();

    INSERT INTO child.ChildEnrollment
    (
        ChildID,
        SiteID,
        EnrollmentStartDate,
        EnrollmentEndDate,
        ScheduleSummary,
        FinancialArrangementNotes,
        EnrollmentStatusCode,
        CreatedByUserID
    )
    VALUES
    (
        @ChildID,
        @SiteID,
        @EnrollmentStartDate,
        @EnrollmentEndDate,
        @ScheduleSummary,
        @FinancialArrangementNotes,
        @EnrollmentStatusCode,
        @CreatedByUserID
    );

    SET @ChildEnrollmentID = SCOPE_IDENTITY();

    -- capture inserted child JSON and write audit (avoid inline FROM after exec)
    DECLARE @NewValuesJson NVARCHAR(MAX) = (SELECT c.* FROM child.Child c WHERE c.ChildID = @ChildID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'Child',
        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    DECLARE @ChildEnrollmentNewValuesJson NVARCHAR(MAX) = (
        SELECT ce.* FROM child.ChildEnrollment ce WHERE ce.ChildEnrollmentID = @ChildEnrollmentID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'ChildEnrollment',
        @RecordPrimaryKeyValue = CAST(@ChildEnrollmentID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @ChildEnrollmentNewValuesJson;

    COMMIT TRAN;

    SELECT @ChildID AS ChildID, @ChildEnrollmentID AS ChildEnrollmentID;
END;
GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--Syntax Error: Incorrect syntax near '@ChildEnrollmentID'.
--
--CREATE PROCEDURE child.usp_Child_Insert
--    @SiteID                     INT,
--    @FirstName                  NVARCHAR(100),
--    @MiddleName                 NVARCHAR(100)      = NULL,
--    @LastName                   NVARCHAR(100),
--    @DateOfBirth                DATE,
--    @AddressLine1               NVARCHAR(200)      = NULL,
--    @AddressLine2               NVARCHAR(200)      = NULL,
--    @City                       NVARCHAR(100)      = NULL,
--    @StateCode                  NVARCHAR(10)       = NULL,
--    @PostalCode                 NVARCHAR(20)       = NULL,
--    @SpecialDietNotes           NVARCHAR(MAX)     = NULL,
--    @SpecialNeedsNotes          NVARCHAR(MAX)     = NULL,
--    @EnrollmentStartDate        DATE,
--    @EnrollmentEndDate          DATE               = NULL,
--    @ScheduleSummary            NVARCHAR(500)      = NULL,
--    @FinancialArrangementNotes  NVARCHAR(MAX)     = NULL,
--    @EnrollmentStatusCode       NVARCHAR(50),
--    @CreatedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @ChildID INT;
--    DECLARE @ChildEnrollmentID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    BEGIN TRAN;
--
--    INSERT INTO child.Child
--    (
--        SiteID,
--        FirstName,
--        MiddleName,
--        LastName,
--        DateOfBirth,
--        AddressLine1,
--        AddressLine2,
--        City,
--        StateCode,
--        PostalCode,
--        SpecialDietNotes,
--        SpecialNeedsNotes,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @SiteID,
--        @FirstName,
--        @MiddleName,
--        @LastName,
--        @DateOfBirth,
--        @AddressLine1,
--        @AddressLine2,
--        @City,
--        @StateCode,
--        @PostalCode,
--        @SpecialDietNotes,
--        @SpecialNeedsNotes,
--        @CreatedByUserID
--    );
--
--    SET @ChildID = SCOPE_IDENTITY();
--
--    INSERT INTO child.ChildEnrollment
--    (
--        ChildID,
--        SiteID,
--        EnrollmentStartDate,
--        EnrollmentEndDate,
--        ScheduleSummary,
--        FinancialArrangementNotes,
--        EnrollmentStatusCode,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @ChildID,
--        @SiteID,
--        @EnrollmentStartDate,
--        @EnrollmentEndDate,
--        @ScheduleSummary,
--        @FinancialArrangementNotes,
--        @EnrollmentStatusCode,
--        @CreatedByUserID
--    );
--
--    SET @ChildEnrollmentID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'Child',
--        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'ChildEnrollment',
--        @RecordPrimaryKeyValue = CAST(@ChildEnrollmentID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT ce.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildEnrollment ce
--    WHERE ce.ChildEnrollmentID = @ChildEnrollmentID;
--
--    COMMIT TRAN;
--
--    SELECT @ChildID AS ChildID, @ChildEnrollmentID AS ChildEnrollmentID;
--END;

GO


CREATE PROCEDURE child.usp_Child_Update
    @ChildID                     INT,
    @FirstName                   NVARCHAR(100),
    @MiddleName                  NVARCHAR(100)      = NULL,
    @LastName                    NVARCHAR(100),
    @DateOfBirth                 DATE,
    @AddressLine1                NVARCHAR(200)      = NULL,
    @AddressLine2                NVARCHAR(200)      = NULL,
    @City                        NVARCHAR(100)      = NULL,
    @StateCode                   NVARCHAR(10)       = NULL,
    @PostalCode                  NVARCHAR(20)       = NULL,
    @SpecialDietNotes            NVARCHAR(MAX)     = NULL,
    @SpecialNeedsNotes           NVARCHAR(MAX)     = NULL,
    @ModifiedByUserID            INT,
    @ReasonText                  NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = SiteID
    FROM child.Child c
    WHERE c.ChildID = @ChildID
      AND c.IsDeleted = 0;

    SET @OldValuesJson = (SELECT c.* FROM child.Child c WHERE c.ChildID = @ChildID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    IF @SiteID IS NULL
    BEGIN
        THROW 50001, 'Child record not found or deleted.', 1;
    END;

    UPDATE child.Child
       SET FirstName = @FirstName,
           MiddleName = @MiddleName,
           LastName = @LastName,
           DateOfBirth = @DateOfBirth,
           AddressLine1 = @AddressLine1,
           AddressLine2 = @AddressLine2,
           City = @City,
           StateCode = @StateCode,
           PostalCode = @PostalCode,
           SpecialDietNotes = @SpecialDietNotes,
           SpecialNeedsNotes = @SpecialNeedsNotes,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ModifiedByUserID
     WHERE ChildID = @ChildID
       AND IsDeleted = 0;

    SET @NewValuesJson = (SELECT c.* FROM child.Child c WHERE c.ChildID = @ChildID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'Child',
        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ModifiedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["FirstName","MiddleName","LastName","DateOfBirth","AddressLine1","AddressLine2","City","StateCode","PostalCode","SpecialDietNotes","SpecialNeedsNotes"]';

    SELECT @ChildID AS ChildID;
END;
GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--
--CREATE PROCEDURE child.usp_Child_Update
--    @ChildID                     INT,
--    @FirstName                   NVARCHAR(100),
--    @MiddleName                  NVARCHAR(100)      = NULL,
--    @LastName                    NVARCHAR(100),
--    @DateOfBirth                 DATE,
--    @AddressLine1                NVARCHAR(200)      = NULL,
--    @AddressLine2                NVARCHAR(200)      = NULL,
--    @City                        NVARCHAR(100)      = NULL,
--    @StateCode                   NVARCHAR(10)       = NULL,
--    @PostalCode                  NVARCHAR(20)       = NULL,
--    @SpecialDietNotes            NVARCHAR(MAX)     = NULL,
--    @SpecialNeedsNotes           NVARCHAR(MAX)     = NULL,
--    @ModifiedByUserID            INT,
--    @ReasonText                  NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID,
--           @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID
--      AND c.IsDeleted = 0;
--
--    IF @SiteID IS NULL
--    BEGIN
--        THROW 50001, 'Child record not found or deleted.', 1;
--    END;
--
--    UPDATE child.Child
--       SET FirstName = @FirstName,
--           MiddleName = @MiddleName,
--           LastName = @LastName,
--           DateOfBirth = @DateOfBirth,
--           AddressLine1 = @AddressLine1,
--           AddressLine2 = @AddressLine2,
--           City = @City,
--           StateCode = @StateCode,
--           PostalCode = @PostalCode,
--           SpecialDietNotes = @SpecialDietNotes,
--           SpecialNeedsNotes = @SpecialNeedsNotes,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ModifiedByUserID
--     WHERE ChildID = @ChildID
--       AND IsDeleted = 0;
--
--    SELECT @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'Child',
--        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ModifiedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson,
--        @AffectedColumnsJson = N'["FirstName","MiddleName","LastName","DateOfBirth","AddressLine1","AddressLine2","City","StateCode","PostalCode","SpecialDietNotes","SpecialNeedsNotes"]';
--
--    SELECT @ChildID AS ChildID;
--END;

GO


CREATE PROCEDURE child.usp_Child_SoftDelete
    @ChildID                     INT,
    @DeletedByUserID             INT,
    @DeletedReason               NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = SiteID
    FROM child.Child c
    WHERE c.ChildID = @ChildID
      AND c.IsDeleted = 0;

    SET @OldValuesJson = (SELECT c.* FROM child.Child c WHERE c.ChildID = @ChildID AND c.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    IF @SiteID IS NULL
    BEGIN
        THROW 50002, 'Child record not found or already deleted.', 1;
    END;

    UPDATE child.Child
       SET IsActive = 0,
           IsDeleted = 1,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE ChildID = @ChildID
       AND IsDeleted = 0;

    UPDATE child.ChildEnrollment
       SET IsActive = 0,
           IsDeleted = 1,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = ISNULL(@DeletedReason, N'Soft delete of parent child record.'),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE ChildID = @ChildID
       AND IsDeleted = 0;

    DECLARE @SoftDeleteNewValuesJson NVARCHAR(MAX) = (SELECT c.* FROM child.Child c WHERE c.ChildID = @ChildID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'Child',
        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
        @ActionTypeCode = N'SOFT_DELETE',
        @ChangedByUserID = @DeletedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @DeletedReason,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @SoftDeleteNewValuesJson;

    SELECT @ChildID AS ChildID;
END;
GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--
--CREATE PROCEDURE child.usp_Child_SoftDelete
--    @ChildID                     INT,
--    @DeletedByUserID             INT,
--    @DeletedReason               NVARCHAR(500)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID,
--           @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID
--      AND c.IsDeleted = 0;
--
--    IF @SiteID IS NULL
--    BEGIN
--        THROW 50002, 'Child record not found or already deleted.', 1;
--    END;
--
--    UPDATE child.Child
--       SET IsActive = 0,
--           IsDeleted = 1,
--           DeletedUTC = SYSUTCDATETIME(),
--           DeletedByUserID = @DeletedByUserID,
--           DeletedReason = @DeletedReason,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @DeletedByUserID
--     WHERE ChildID = @ChildID
--       AND IsDeleted = 0;
--
--    UPDATE child.ChildEnrollment
--       SET IsActive = 0,
--           IsDeleted = 1,
--           DeletedUTC = SYSUTCDATETIME(),
--           DeletedByUserID = @DeletedByUserID,
--           DeletedReason = ISNULL(@DeletedReason, N'Soft delete of parent child record.'),
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @DeletedByUserID
--     WHERE ChildID = @ChildID
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'Child',
--        @RecordPrimaryKeyValue = CAST(@ChildID AS NVARCHAR(128)),
--        @ActionTypeCode = N'SOFT_DELETE',
--        @ChangedByUserID = @DeletedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @DeletedReason,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID;
--
--    SELECT @ChildID AS ChildID;
--END;

GO


CREATE PROCEDURE child.usp_ChildPersonRelationship_Upsert
    @ChildPersonRelationshipID   INT                 = NULL,
    @ChildID                     INT,
    @PersonID                    INT,
    @RelationshipTypeCode        NVARCHAR(50),
    @HasPortalAccess             BIT,
    @CanReceiveAlerts            BIT,
    @CanSignPermissions          BIT,
    @IsPrimaryGuardian           BIT,
    @EffectiveStartDate          DATE,
    @EffectiveEndDate            DATE               = NULL,
    @ChangedByUserID             INT,
    @ReasonText                  NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = SiteID
    FROM child.Child
    WHERE ChildID = @ChildID
      AND IsDeleted = 0;

    IF @SiteID IS NULL
    BEGIN
        THROW 50003, 'Child record not found or deleted.', 1;
    END;

    IF @ChildPersonRelationshipID IS NULL
    BEGIN
        INSERT INTO child.ChildPersonRelationship
        (
            ChildID,
            PersonID,
            RelationshipTypeCode,
            HasPortalAccess,
            CanReceiveAlerts,
            CanSignPermissions,
            IsPrimaryGuardian,
            EffectiveStartDate,
            EffectiveEndDate,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @PersonID,
            @RelationshipTypeCode,
            @HasPortalAccess,
            @CanReceiveAlerts,
            @CanSignPermissions,
            @IsPrimaryGuardian,
            @EffectiveStartDate,
            @EffectiveEndDate,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT r.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM child.ChildPersonRelationship r
        WHERE r.ChildPersonRelationshipID = @ChildPersonRelationshipID
          AND r.IsDeleted = 0;

        UPDATE child.ChildPersonRelationship
           SET PersonID = @PersonID,
               RelationshipTypeCode = @RelationshipTypeCode,
               HasPortalAccess = @HasPortalAccess,
               CanReceiveAlerts = @CanReceiveAlerts,
               CanSignPermissions = @CanSignPermissions,
               IsPrimaryGuardian = @IsPrimaryGuardian,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ChildPersonRelationshipID = @ChildPersonRelationshipID
           AND IsDeleted = 0;

        SET @RecordID = @ChildPersonRelationshipID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT r.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM child.ChildPersonRelationship r
    WHERE r.ChildPersonRelationshipID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'ChildPersonRelationship',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS ChildPersonRelationshipID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE child.usp_ChildPersonRelationship_Upsert
--    @ChildPersonRelationshipID   INT                 = NULL,
--    @ChildID                     INT,
--    @PersonID                    INT,
--    @RelationshipTypeCode        NVARCHAR(50),
--    @HasPortalAccess             BIT,
--    @CanReceiveAlerts            BIT,
--    @CanSignPermissions          BIT,
--    @IsPrimaryGuardian           BIT,
--    @EffectiveStartDate          DATE,
--    @EffectiveEndDate            DATE               = NULL,
--    @ChangedByUserID             INT,
--    @ReasonText                  NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID
--    FROM child.Child
--    WHERE ChildID = @ChildID
--      AND IsDeleted = 0;
--
--    IF @SiteID IS NULL
--    BEGIN
--        THROW 50003, 'Child record not found or deleted.', 1;
--    END;
--
--    IF @ChildPersonRelationshipID IS NULL
--    BEGIN
--        INSERT INTO child.ChildPersonRelationship
--        (
--            ChildID,
--            PersonID,
--            RelationshipTypeCode,
--            HasPortalAccess,
--            CanReceiveAlerts,
--            CanSignPermissions,
--            IsPrimaryGuardian,
--            EffectiveStartDate,
--            EffectiveEndDate,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ChildID,
--            @PersonID,
--            @RelationshipTypeCode,
--            @HasPortalAccess,
--            @CanReceiveAlerts,
--            @CanSignPermissions,
--            @IsPrimaryGuardian,
--            @EffectiveStartDate,
--            @EffectiveEndDate,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT r.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM child.ChildPersonRelationship r
--        WHERE r.ChildPersonRelationshipID = @ChildPersonRelationshipID
--          AND r.IsDeleted = 0;
--
--        UPDATE child.ChildPersonRelationship
--           SET PersonID = @PersonID,
--               RelationshipTypeCode = @RelationshipTypeCode,
--               HasPortalAccess = @HasPortalAccess,
--               CanReceiveAlerts = @CanReceiveAlerts,
--               CanSignPermissions = @CanSignPermissions,
--               IsPrimaryGuardian = @IsPrimaryGuardian,
--               EffectiveStartDate = @EffectiveStartDate,
--               EffectiveEndDate = @EffectiveEndDate,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ChildPersonRelationshipID = @ChildPersonRelationshipID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @ChildPersonRelationshipID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT r.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildPersonRelationship r
--    WHERE r.ChildPersonRelationshipID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'ChildPersonRelationship',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS ChildPersonRelationshipID;
--END;

GO


CREATE PROCEDURE child.usp_GuardianInvitation_Create
    @ChildPersonRelationshipID   INT,
    @InvitationEmail             NVARCHAR(320),
    @InvitationTokenHash         VARBINARY(64),
    @TokenExpiresUTC             DATETIME2(0),
    @CreatedByUserID             INT,
    @ReasonText                  NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @GuardianInvitationID INT;
    DECLARE @ChildID INT;
    DECLARE @SiteID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @ChildID = r.ChildID,
           @SiteID = c.SiteID
    FROM child.ChildPersonRelationship r
    INNER JOIN child.Child c
        ON c.ChildID = r.ChildID
    WHERE r.ChildPersonRelationshipID = @ChildPersonRelationshipID
      AND r.IsDeleted = 0
      AND c.IsDeleted = 0;

    IF @ChildID IS NULL
    BEGIN
        THROW 50004, 'Child/guardian relationship not found or deleted.', 1;
    END;

    INSERT INTO child.GuardianInvitation
    (
        ChildPersonRelationshipID,
        InvitationEmail,
        InvitationTokenHash,
        TokenExpiresUTC,
        InvitationStatusCode,
        CreatedByUserID
    )
    VALUES
    (
        @ChildPersonRelationshipID,
        @InvitationEmail,
        @InvitationTokenHash,
        @TokenExpiresUTC,
        N'PENDING',
        @CreatedByUserID
    );

    SET @GuardianInvitationID = SCOPE_IDENTITY();

    DECLARE @GuardianInvitationNewValuesJson NVARCHAR(MAX) = (
        SELECT gi.* FROM child.GuardianInvitation gi WHERE gi.GuardianInvitationID = @GuardianInvitationID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'GuardianInvitation',
        @RecordPrimaryKeyValue = CAST(@GuardianInvitationID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @GuardianInvitationNewValuesJson;

    SELECT @GuardianInvitationID AS GuardianInvitationID;
END;
GO

--Syntax Error: Incorrect syntax near '@GuardianInvitationID'.
--
--CREATE PROCEDURE child.usp_GuardianInvitation_Create
--    @ChildPersonRelationshipID   INT,
--    @InvitationEmail             NVARCHAR(320),
--    @InvitationTokenHash         VARBINARY(64),
--    @TokenExpiresUTC             DATETIME2(0),
--    @CreatedByUserID             INT,
--    @ReasonText                  NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @GuardianInvitationID INT;
--    DECLARE @ChildID INT;
--    DECLARE @SiteID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @ChildID = r.ChildID,
--           @SiteID = c.SiteID
--    FROM child.ChildPersonRelationship r
--    INNER JOIN child.Child c
--        ON c.ChildID = r.ChildID
--    WHERE r.ChildPersonRelationshipID = @ChildPersonRelationshipID
--      AND r.IsDeleted = 0
--      AND c.IsDeleted = 0;
--
--    IF @ChildID IS NULL
--    BEGIN
--        THROW 50004, 'Child/guardian relationship not found or deleted.', 1;
--    END;
--
--    INSERT INTO child.GuardianInvitation
--    (
--        ChildPersonRelationshipID,
--        InvitationEmail,
--        InvitationTokenHash,
--        TokenExpiresUTC,
--        InvitationStatusCode,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @ChildPersonRelationshipID,
--        @InvitationEmail,
--        @InvitationTokenHash,
--        @TokenExpiresUTC,
--        N'PENDING',
--        @CreatedByUserID
--    );
--
--    SET @GuardianInvitationID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'GuardianInvitation',
--        @RecordPrimaryKeyValue = CAST(@GuardianInvitationID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT gi.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.GuardianInvitation gi
--    WHERE gi.GuardianInvitationID = @GuardianInvitationID;
--
--    SELECT @GuardianInvitationID AS GuardianInvitationID;
--END;

GO


CREATE PROCEDURE child.usp_PickupDropoffAuthorization_Upsert
    @PickupDropoffAuthorizationID INT                = NULL,
    @ChildID                      INT,
    @PersonID                     INT,
    @CanPickup                    BIT,
    @CanDropoff                   BIT,
    @IsEmergencyContact           BIT,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @EffectiveStartDate           DATE,
    @EffectiveEndDate             DATE               = NULL,
    @ChangedByUserID              INT,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = SiteID
    FROM child.Child
    WHERE ChildID = @ChildID
      AND IsDeleted = 0;

    IF @SiteID IS NULL
    BEGIN
        THROW 50005, 'Child record not found or deleted.', 1;
    END;

    IF @PickupDropoffAuthorizationID IS NULL
    BEGIN
        INSERT INTO child.PickupDropoffAuthorization
        (
            ChildID,
            PersonID,
            CanPickup,
            CanDropoff,
            IsEmergencyContact,
            Notes,
            EffectiveStartDate,
            EffectiveEndDate,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @PersonID,
            @CanPickup,
            @CanDropoff,
            @IsEmergencyContact,
            @Notes,
            @EffectiveStartDate,
            @EffectiveEndDate,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM child.PickupDropoffAuthorization p
        WHERE p.PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID
          AND p.IsDeleted = 0;

        UPDATE child.PickupDropoffAuthorization
           SET PersonID = @PersonID,
               CanPickup = @CanPickup,
               CanDropoff = @CanDropoff,
               IsEmergencyContact = @IsEmergencyContact,
               Notes = @Notes,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID
           AND IsDeleted = 0;

        SET @RecordID = @PickupDropoffAuthorizationID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM child.PickupDropoffAuthorization p
    WHERE p.PickupDropoffAuthorizationID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'PickupDropoffAuthorization',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS PickupDropoffAuthorizationID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE child.usp_PickupDropoffAuthorization_Upsert
--    @PickupDropoffAuthorizationID INT                = NULL,
--    @ChildID                      INT,
--    @PersonID                     INT,
--    @CanPickup                    BIT,
--    @CanDropoff                   BIT,
--    @IsEmergencyContact           BIT,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @EffectiveStartDate           DATE,
--    @EffectiveEndDate             DATE               = NULL,
--    @ChangedByUserID              INT,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID
--    FROM child.Child
--    WHERE ChildID = @ChildID
--      AND IsDeleted = 0;
--
--    IF @SiteID IS NULL
--    BEGIN
--        THROW 50005, 'Child record not found or deleted.', 1;
--    END;
--
--    IF @PickupDropoffAuthorizationID IS NULL
--    BEGIN
--        INSERT INTO child.PickupDropoffAuthorization
--        (
--            ChildID,
--            PersonID,
--            CanPickup,
--            CanDropoff,
--            IsEmergencyContact,
--            Notes,
--            EffectiveStartDate,
--            EffectiveEndDate,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ChildID,
--            @PersonID,
--            @CanPickup,
--            @CanDropoff,
--            @IsEmergencyContact,
--            @Notes,
--            @EffectiveStartDate,
--            @EffectiveEndDate,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM child.PickupDropoffAuthorization p
--        WHERE p.PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID
--          AND p.IsDeleted = 0;
--
--        UPDATE child.PickupDropoffAuthorization
--           SET PersonID = @PersonID,
--               CanPickup = @CanPickup,
--               CanDropoff = @CanDropoff,
--               IsEmergencyContact = @IsEmergencyContact,
--               Notes = @Notes,
--               EffectiveStartDate = @EffectiveStartDate,
--               EffectiveEndDate = @EffectiveEndDate,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @PickupDropoffAuthorizationID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.PickupDropoffAuthorization p
--    WHERE p.PickupDropoffAuthorizationID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'PickupDropoffAuthorization',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS PickupDropoffAuthorizationID;
--END;

GO


CREATE PROCEDURE child.usp_Attendance_Insert
    @ChildID                      INT,
    @SiteID                       INT,
    @AttendanceDateLocal          DATE,
    @StartDateTimeUTC             DATETIME2(0),
    @EndDateTimeUTC               DATETIME2(0),
    @TimeZoneID                   INT,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @CreatedByUserID              INT,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ChildAttendanceID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @EndDateTimeUTC <= @StartDateTimeUTC
    BEGIN
        THROW 50006, 'Attendance end time must be greater than start time.', 1;
    END;

    INSERT INTO child.ChildAttendance
    (
        ChildID,
        SiteID,
        AttendanceDateLocal,
        StartDateTimeUTC,
        EndDateTimeUTC,
        TimeZoneID,
        Notes,
        CreatedByUserID
    )
    VALUES
    (
        @ChildID,
        @SiteID,
        @AttendanceDateLocal,
        @StartDateTimeUTC,
        @EndDateTimeUTC,
        @TimeZoneID,
        @Notes,
        @CreatedByUserID
    );

    SET @ChildAttendanceID = SCOPE_IDENTITY();

    DECLARE @ChildAttendanceNewValuesJson NVARCHAR(MAX) = (
        SELECT ca.* FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID = @ChildAttendanceID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'ChildAttendance',
        @RecordPrimaryKeyValue = CAST(@ChildAttendanceID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @ChildAttendanceNewValuesJson;

    SELECT @ChildAttendanceID AS ChildAttendanceID;
END;
GO

--Syntax Error: Incorrect syntax near '@ChildAttendanceID'.
--
--CREATE PROCEDURE child.usp_Attendance_Insert
--    @ChildID                      INT,
--    @SiteID                       INT,
--    @AttendanceDateLocal          DATE,
--    @StartDateTimeUTC             DATETIME2(0),
--    @EndDateTimeUTC               DATETIME2(0),
--    @TimeZoneID                   INT,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @CreatedByUserID              INT,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @ChildAttendanceID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @EndDateTimeUTC <= @StartDateTimeUTC
--    BEGIN
--        THROW 50006, 'Attendance end time must be greater than start time.', 1;
--    END;
--
--    INSERT INTO child.ChildAttendance
--    (
--        ChildID,
--        SiteID,
--        AttendanceDateLocal,
--        StartDateTimeUTC,
--        EndDateTimeUTC,
--        TimeZoneID,
--        Notes,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @ChildID,
--        @SiteID,
--        @AttendanceDateLocal,
--        @StartDateTimeUTC,
--        @EndDateTimeUTC,
--        @TimeZoneID,
--        @Notes,
--        @CreatedByUserID
--    );
--
--    SET @ChildAttendanceID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'ChildAttendance',
--        @RecordPrimaryKeyValue = CAST(@ChildAttendanceID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildAttendance ca
--    WHERE ca.ChildAttendanceID = @ChildAttendanceID;
--
--    SELECT @ChildAttendanceID AS ChildAttendanceID;
--END;

GO


CREATE PROCEDURE child.usp_Attendance_Update
    @ChildAttendanceID            INT,
    @AttendanceDateLocal          DATE,
    @StartDateTimeUTC             DATETIME2(0),
    @EndDateTimeUTC               DATETIME2(0),
    @TimeZoneID                   INT,
    @CorrectionReason             NVARCHAR(MAX),
    @Notes                        NVARCHAR(MAX)     = NULL,
    @ModifiedByUserID             INT,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ChildID INT;
    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @EndDateTimeUTC <= @StartDateTimeUTC
    BEGIN
        THROW 50007, 'Attendance end time must be greater than start time.', 1;
    END;

    SELECT @ChildID = ca.ChildID,
           @SiteID = ca.SiteID
    FROM child.ChildAttendance ca
    WHERE ca.ChildAttendanceID = @ChildAttendanceID
      AND ca.IsDeleted = 0;

    SET @OldValuesJson = (SELECT ca.* FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID = @ChildAttendanceID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    IF @ChildID IS NULL
    BEGIN
        THROW 50008, 'Attendance record not found or deleted.', 1;
    END;

    UPDATE child.ChildAttendance
       SET AttendanceDateLocal = @AttendanceDateLocal,
           StartDateTimeUTC = @StartDateTimeUTC,
           EndDateTimeUTC = @EndDateTimeUTC,
           TimeZoneID = @TimeZoneID,
           CorrectionReason = @CorrectionReason,
           Notes = @Notes,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ModifiedByUserID
     WHERE ChildAttendanceID = @ChildAttendanceID
       AND IsDeleted = 0;

    SET @NewValuesJson = (SELECT ca.* FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID = @ChildAttendanceID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'ChildAttendance',
        @RecordPrimaryKeyValue = CAST(@ChildAttendanceID AS NVARCHAR(128)),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ModifiedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = COALESCE(@ReasonText, @CorrectionReason),
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AttendanceDateLocal","StartDateTimeUTC","EndDateTimeUTC","TimeZoneID","CorrectionReason","Notes"]';

    SELECT @ChildAttendanceID AS ChildAttendanceID;
END;
GO

--Syntax Error: Incorrect syntax near '@ChildAttendanceID'.
--
--CREATE PROCEDURE child.usp_Attendance_Update
--    @ChildAttendanceID            INT,
--    @AttendanceDateLocal          DATE,
--    @StartDateTimeUTC             DATETIME2(0),
--    @EndDateTimeUTC               DATETIME2(0),
--    @TimeZoneID                   INT,
--    @CorrectionReason             NVARCHAR(MAX),
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ModifiedByUserID             INT,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @ChildID INT;
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @EndDateTimeUTC <= @StartDateTimeUTC
--    BEGIN
--        THROW 50007, 'Attendance end time must be greater than start time.', 1;
--    END;
--
--    SELECT @ChildID = ca.ChildID,
--           @SiteID = ca.SiteID,
--           @OldValuesJson = (SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildAttendance ca
--    WHERE ca.ChildAttendanceID = @ChildAttendanceID
--      AND ca.IsDeleted = 0;
--
--    IF @ChildID IS NULL
--    BEGIN
--        THROW 50008, 'Attendance record not found or deleted.', 1;
--    END;
--
--    UPDATE child.ChildAttendance
--       SET AttendanceDateLocal = @AttendanceDateLocal,
--           StartDateTimeUTC = @StartDateTimeUTC,
--           EndDateTimeUTC = @EndDateTimeUTC,
--           TimeZoneID = @TimeZoneID,
--           CorrectionReason = @CorrectionReason,
--           Notes = @Notes,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ModifiedByUserID
--     WHERE ChildAttendanceID = @ChildAttendanceID
--       AND IsDeleted = 0;
--
--    SELECT @NewValuesJson = (SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildAttendance ca
--    WHERE ca.ChildAttendanceID = @ChildAttendanceID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'ChildAttendance',
--        @RecordPrimaryKeyValue = CAST(@ChildAttendanceID AS NVARCHAR(128)),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ModifiedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = COALESCE(@ReasonText, @CorrectionReason),
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson,
--        @AffectedColumnsJson = N'["AttendanceDateLocal","StartDateTimeUTC","EndDateTimeUTC","TimeZoneID","CorrectionReason","Notes"]';
--
--    SELECT @ChildAttendanceID AS ChildAttendanceID;
--END;

GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--Syntax Error: Incorrect syntax near '@ChildEnrollmentID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_Child_Insert
--    @SiteID                     INT,
--    @FirstName                  NVARCHAR(100),
--    @MiddleName                 NVARCHAR(100) = NULL,
--    @LastName                   NVARCHAR(100),
--    @DateOfBirth                DATE,
--    @ChildAddressID             INT = NULL,
--    @SpecialDietNotes           NVARCHAR(MAX) = NULL,
--    @SpecialNeedsNotes          NVARCHAR(MAX) = NULL,
--    @EnrollmentStartDate        DATE,
--    @EnrollmentEndDate          DATE = NULL,
--    @ScheduleSummary            NVARCHAR(500) = NULL,
--    @FinancialArrangementNotes  NVARCHAR(MAX) = NULL,
--    @EnrollmentStatusCode       NVARCHAR(50),
--    @CreatedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @ChildID INT, @ChildEnrollmentID INT, @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    BEGIN TRAN;
--    INSERT INTO child.Child (SiteID, FirstName, MiddleName, LastName, DateOfBirth, ChildAddressID, SpecialDietNotes, SpecialNeedsNotes, CreatedByUserID)
--    VALUES (@SiteID, @FirstName, @MiddleName, @LastName, @DateOfBirth, @ChildAddressID, @SpecialDietNotes, @SpecialNeedsNotes, @CreatedByUserID);
--    SET @ChildID = SCOPE_IDENTITY();
--
--    INSERT INTO child.ChildEnrollment (ChildID, SiteID, EnrollmentStartDate, EnrollmentEndDate, ScheduleSummary, FinancialArrangementNotes, EnrollmentStatusCode, CreatedByUserID)
--    VALUES (@ChildID, @SiteID, @EnrollmentStartDate, @EnrollmentEndDate, @ScheduleSummary, @FinancialArrangementNotes, @EnrollmentStatusCode, @CreatedByUserID);
--    SET @ChildEnrollmentID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'Child', @RecordPrimaryKeyValue=CAST(@ChildID AS NVARCHAR(128)), @ActionTypeCode=N'INSERT', @ChangedByUserID=@CreatedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @NewValuesJson=(SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.Child c WHERE c.ChildID=@ChildID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'ChildEnrollment', @RecordPrimaryKeyValue=CAST(@ChildEnrollmentID AS NVARCHAR(128)), @ActionTypeCode=N'INSERT', @ChangedByUserID=@CreatedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @NewValuesJson=(SELECT ce.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildEnrollment ce WHERE ce.ChildEnrollmentID=@ChildEnrollmentID;
--    COMMIT TRAN;
--    SELECT @ChildID AS ChildID, @ChildEnrollmentID AS ChildEnrollmentID;
--END;

GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_Child_Update
--    @ChildID                    INT,
--    @FirstName                  NVARCHAR(100),
--    @MiddleName                 NVARCHAR(100) = NULL,
--    @LastName                   NVARCHAR(100),
--    @DateOfBirth                DATE,
--    @ChildAddressID             INT = NULL,
--    @SpecialDietNotes           NVARCHAR(MAX) = NULL,
--    @SpecialNeedsNotes          NVARCHAR(MAX) = NULL,
--    @ModifiedByUserID           INT,
--    @ReasonText                 NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @SiteID INT, @OldValuesJson NVARCHAR(MAX), @NewValuesJson NVARCHAR(MAX), @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID, @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c WHERE c.ChildID = @ChildID AND c.IsDeleted = 0;
--    IF @SiteID IS NULL THROW 51001, 'Child record not found or deleted.', 1;
--
--    UPDATE child.Child
--       SET FirstName=@FirstName, MiddleName=@MiddleName, LastName=@LastName, DateOfBirth=@DateOfBirth,
--           ChildAddressID=@ChildAddressID, SpecialDietNotes=@SpecialDietNotes, SpecialNeedsNotes=@SpecialNeedsNotes,
--           ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ModifiedByUserID
--     WHERE ChildID=@ChildID AND IsDeleted=0;
--
--    SELECT @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.Child c WHERE c.ChildID=@ChildID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'Child', @RecordPrimaryKeyValue=CAST(@ChildID AS NVARCHAR(128)), @ActionTypeCode=N'UPDATE', @ChangedByUserID=@ModifiedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @ChildID AS ChildID;
--END;

GO

--Syntax Error: Incorrect syntax near '@ChildID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_Child_SoftDelete
--    @ChildID                    INT,
--    @DeletedByUserID            INT,
--    @DeletedReason              NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @SiteID INT, @OldValuesJson NVARCHAR(MAX), @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = SiteID, @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.Child c WHERE c.ChildID=@ChildID AND c.IsDeleted=0;
--    IF @SiteID IS NULL THROW 51002, 'Child record not found or already deleted.', 1;
--
--    UPDATE child.Child SET IsActive=0, IsDeleted=1, DeletedUTC=SYSUTCDATETIME(), DeletedByUserID=@DeletedByUserID, DeletedReason=@DeletedReason, ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@DeletedByUserID WHERE ChildID=@ChildID AND IsDeleted=0;
--    UPDATE child.ChildEnrollment SET IsActive=0, IsDeleted=1, DeletedUTC=SYSUTCDATETIME(), DeletedByUserID=@DeletedByUserID, DeletedReason=@DeletedReason, ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@DeletedByUserID WHERE ChildID=@ChildID AND IsDeleted=0;
--
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'Child', @RecordPrimaryKeyValue=CAST(@ChildID AS NVARCHAR(128)), @ActionTypeCode=N'SOFT_DELETE', @ChangedByUserID=@DeletedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@DeletedReason, @OldValuesJson=@OldValuesJson, @NewValuesJson=(SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.Child c WHERE c.ChildID=@ChildID;
--    SELECT @ChildID AS ChildID;
--END;

GO

--Syntax Error: Incorrect syntax near '@ChildAttendanceID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_Attendance_Insert
--    @ChildID                    INT,
--    @SiteID                     INT,
--    @AttendanceDateLocal        DATE,
--    @StartDateTimeUTC           DATETIME2(0),
--    @EndDateTimeUTC             DATETIME2(0),
--    @TimeZoneID                 INT,
--    @Notes                      NVARCHAR(MAX) = NULL,
--    @CreatedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @ChildAttendanceID INT, @CorrelationID UNIQUEIDENTIFIER = NEWID();
--    IF @EndDateTimeUTC <= @StartDateTimeUTC THROW 51003, 'Attendance end time must be greater than start time.', 1;
--
--    INSERT INTO child.ChildAttendance (ChildID, SiteID, AttendanceDateLocal, StartDateTimeUTC, EndDateTimeUTC, TimeZoneID, Notes, CreatedByUserID)
--    VALUES (@ChildID, @SiteID, @AttendanceDateLocal, @StartDateTimeUTC, @EndDateTimeUTC, @TimeZoneID, @Notes, @CreatedByUserID);
--    SET @ChildAttendanceID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'ChildAttendance', @RecordPrimaryKeyValue=CAST(@ChildAttendanceID AS NVARCHAR(128)), @ActionTypeCode=N'INSERT', @ChangedByUserID=@CreatedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @NewValuesJson=(SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID=@ChildAttendanceID;
--    SELECT @ChildAttendanceID AS ChildAttendanceID;
--END;

GO

--Syntax Error: Incorrect syntax near '@ChildAttendanceID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_Attendance_Update
--    @ChildAttendanceID          INT,
--    @AttendanceDateLocal        DATE,
--    @StartDateTimeUTC           DATETIME2(0),
--    @EndDateTimeUTC             DATETIME2(0),
--    @TimeZoneID                 INT,
--    @CorrectionReason           NVARCHAR(MAX),
--    @Notes                      NVARCHAR(MAX) = NULL,
--    @ModifiedByUserID           INT,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @ChildID INT, @SiteID INT, @OldValuesJson NVARCHAR(MAX), @NewValuesJson NVARCHAR(MAX), @CorrelationID UNIQUEIDENTIFIER = NEWID();
--    IF @EndDateTimeUTC <= @StartDateTimeUTC THROW 51004, 'Attendance end time must be greater than start time.', 1;
--
--    SELECT @ChildID=ca.ChildID, @SiteID=ca.SiteID, @OldValuesJson=(SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID=@ChildAttendanceID AND ca.IsDeleted=0;
--    IF @ChildID IS NULL THROW 51005, 'Attendance record not found or deleted.', 1;
--
--    UPDATE child.ChildAttendance
--       SET AttendanceDateLocal=@AttendanceDateLocal, StartDateTimeUTC=@StartDateTimeUTC, EndDateTimeUTC=@EndDateTimeUTC,
--           TimeZoneID=@TimeZoneID, CorrectionReason=@CorrectionReason, Notes=@Notes,
--           ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ModifiedByUserID
--     WHERE ChildAttendanceID=@ChildAttendanceID AND IsDeleted=0;
--
--    SELECT @NewValuesJson=(SELECT ca.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildAttendance ca WHERE ca.ChildAttendanceID=@ChildAttendanceID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'ChildAttendance', @RecordPrimaryKeyValue=CAST(@ChildAttendanceID AS NVARCHAR(128)), @ActionTypeCode=N'UPDATE', @ChangedByUserID=@ModifiedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=COALESCE(@ReasonText,@CorrectionReason), @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @ChildAttendanceID AS ChildAttendanceID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_ChildMedicalProfile_Upsert
--    @ChildMedicalProfileID       INT = NULL,
--    @ChildID                     INT,
--    @PrimaryCarePhysicianID      INT = NULL,
--    @DentistMedicalProviderID    INT = NULL,
--    @HospitalID                  INT = NULL,
--    @EmergencyMedicalConsentFlag BIT,
--    @MedicalNotes                NVARCHAR(MAX) = NULL,
--    @ChangedByUserID             INT,
--    @ReasonText                  NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @SiteID INT, @RecordID INT, @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @CorrelationID UNIQUEIDENTIFIER=NEWID();
--    SELECT @SiteID=SiteID FROM child.Child WHERE ChildID=@ChildID AND IsDeleted=0;
--    IF @SiteID IS NULL THROW 51006, 'Child record not found or deleted.', 1;
--
--    IF @ChildMedicalProfileID IS NULL
--    BEGIN
--        INSERT INTO child.ChildMedicalProfile (ChildID, PrimaryCarePhysicianID, DentistMedicalProviderID, HospitalID, EmergencyMedicalConsentFlag, MedicalNotes, CreatedByUserID)
--        VALUES (@ChildID, @PrimaryCarePhysicianID, @DentistMedicalProviderID, @HospitalID, @EmergencyMedicalConsentFlag, @MedicalNotes, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT cmp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildMedicalProfile cmp WHERE cmp.ChildMedicalProfileID=@ChildMedicalProfileID AND cmp.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 51007, 'Child medical profile not found or deleted.', 1;
--        UPDATE child.ChildMedicalProfile
--           SET ChildID=@ChildID, PrimaryCarePhysicianID=@PrimaryCarePhysicianID, DentistMedicalProviderID=@DentistMedicalProviderID, HospitalID=@HospitalID,
--               EmergencyMedicalConsentFlag=@EmergencyMedicalConsentFlag, MedicalNotes=@MedicalNotes, ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE ChildMedicalProfileID=@ChildMedicalProfileID AND IsDeleted=0;
--        SET @RecordID=@ChildMedicalProfileID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT cmp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildMedicalProfile cmp WHERE cmp.ChildMedicalProfileID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'ChildMedicalProfile', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS ChildMedicalProfileID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE child.usp_ChildAllergyPlan_Upsert
--    @ChildAllergyPlanID          INT = NULL,
--    @ChildID                     INT,
--    @PhysicianMedicalProviderID  INT = NULL,
--    @AllergenSummary             NVARCHAR(MAX),
--    @TriggerDescription          NVARCHAR(MAX) = NULL,
--    @AvoidanceInstructions       NVARCHAR(MAX) = NULL,
--    @SymptomInstructions         NVARCHAR(MAX) = NULL,
--    @TreatmentInstructions       NVARCHAR(MAX) = NULL,
--    @EffectiveDate               DATE,
--    @ReviewDate                  DATE = NULL,
--    @ChangedByUserID             INT,
--    @ReasonText                  NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @SiteID INT, @RecordID INT, @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @CorrelationID UNIQUEIDENTIFIER=NEWID();
--    SELECT @SiteID=SiteID FROM child.Child WHERE ChildID=@ChildID AND IsDeleted=0;
--    IF @SiteID IS NULL THROW 51008, 'Child record not found or deleted.', 1;
--
--    IF @ChildAllergyPlanID IS NULL
--    BEGIN
--        INSERT INTO child.ChildAllergyPlan (ChildID, PhysicianMedicalProviderID, AllergenSummary, TriggerDescription, AvoidanceInstructions, SymptomInstructions, TreatmentInstructions, EffectiveDate, ReviewDate, CreatedByUserID)
--        VALUES (@ChildID, @PhysicianMedicalProviderID, @AllergenSummary, @TriggerDescription, @AvoidanceInstructions, @SymptomInstructions, @TreatmentInstructions, @EffectiveDate, @ReviewDate, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT cap.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildAllergyPlan cap WHERE cap.ChildAllergyPlanID=@ChildAllergyPlanID AND cap.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 51009, 'Child allergy plan not found or deleted.', 1;
--        UPDATE child.ChildAllergyPlan
--           SET ChildID=@ChildID, PhysicianMedicalProviderID=@PhysicianMedicalProviderID, AllergenSummary=@AllergenSummary, TriggerDescription=@TriggerDescription,
--               AvoidanceInstructions=@AvoidanceInstructions, SymptomInstructions=@SymptomInstructions, TreatmentInstructions=@TreatmentInstructions,
--               EffectiveDate=@EffectiveDate, ReviewDate=@ReviewDate, ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE ChildAllergyPlanID=@ChildAllergyPlanID AND IsDeleted=0;
--        SET @RecordID=@ChildAllergyPlanID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT cap.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM child.ChildAllergyPlan cap WHERE cap.ChildAllergyPlanID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'child', @TableName=N'ChildAllergyPlan', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @SiteID=@SiteID, @ChildID=@ChildID, @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS ChildAllergyPlanID;
--END;

GO


CREATE PROCEDURE doc.usp_Document_Insert
    @DocumentTypeCode           NVARCHAR(50),
    @OriginalFileName           NVARCHAR(255),
    @StoredFileName             NVARCHAR(255),
    @ContentType                NVARCHAR(200),
    @StorageUri                 NVARCHAR(MAX),
    @FileHashHex                NVARCHAR(128)      = NULL,
    @FileSizeBytes              BIGINT             = NULL,
    @EntitySchemaName           NVARCHAR(128)      = NULL,
    @EntityTableName            NVARCHAR(128)      = NULL,
    @EntityPrimaryKeyValue      NVARCHAR(128)      = NULL,
    @EntityNotes                NVARCHAR(MAX)     = NULL,
    @CreatedByUserID            INT,
    @ReasonText                 NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @DocumentTypeID INT;
    DECLARE @DocumentID INT;
    DECLARE @EntityDocumentID INT = NULL;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @DocumentTypeID = dt.DocumentTypeID
    FROM doc.DocumentType dt
    WHERE dt.DocumentTypeCode = @DocumentTypeCode
      AND dt.IsActive = 1;

    IF @DocumentTypeID IS NULL
    BEGIN
        THROW 50020, 'Document type code not found or inactive.', 1;
    END;

    INSERT INTO doc.Document
    (
        DocumentTypeID,
        OriginalFileName,
        StoredFileName,
        ContentType,
        StorageUri,
        FileHashHex,
        FileSizeBytes,
        CreatedByUserID
    )
    VALUES
    (
        @DocumentTypeID,
        @OriginalFileName,
        @StoredFileName,
        @ContentType,
        @StorageUri,
        @FileHashHex,
        @FileSizeBytes,
        @CreatedByUserID
    );

    SET @DocumentID = SCOPE_IDENTITY();

    IF @EntitySchemaName IS NOT NULL
       AND @EntityTableName IS NOT NULL
       AND @EntityPrimaryKeyValue IS NOT NULL
    BEGIN
        INSERT INTO doc.EntityDocument
        (
            DocumentID,
            EntitySchemaName,
            EntityTableName,
            EntityPrimaryKeyValue,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @DocumentID,
            @EntitySchemaName,
            @EntityTableName,
            @EntityPrimaryKeyValue,
            @EntityNotes,
            @CreatedByUserID
        );

        SET @EntityDocumentID = SCOPE_IDENTITY();

        DECLARE @EntityDocumentNewValuesJson NVARCHAR(MAX) = (
            SELECT ed.* FROM doc.EntityDocument ed WHERE ed.EntityDocumentID = @EntityDocumentID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        EXEC audit.usp_WriteAuditLog
            @SchemaName = N'doc',
            @TableName = N'EntityDocument',
            @RecordPrimaryKeyValue = CAST(@EntityDocumentID AS NVARCHAR(128)),
            @ActionTypeCode = N'INSERT',
            @ChangedByUserID = @CreatedByUserID,
            @ChangeSourceCode = N'APPLICATION',
            @CorrelationID = @CorrelationID,
            @ReasonText = @ReasonText,
            @NewValuesJson = @EntityDocumentNewValuesJson;
    END;

    DECLARE @DocumentNewValuesJson NVARCHAR(MAX) = (
        SELECT d.* FROM doc.Document d WHERE d.DocumentID = @DocumentID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'doc',
        @TableName = N'Document',
        @RecordPrimaryKeyValue = CAST(@DocumentID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @DocumentNewValuesJson;

    SELECT
        @DocumentID AS DocumentID,
        @EntityDocumentID AS EntityDocumentID;
END;
GO

--Syntax Error: Incorrect syntax near '@EntityDocumentID'.
--Syntax Error: Incorrect syntax near '@DocumentID'.
--
--CREATE PROCEDURE doc.usp_Document_Insert
--    @DocumentTypeCode           NVARCHAR(50),
--    @OriginalFileName           NVARCHAR(255),
--    @StoredFileName             NVARCHAR(255),
--    @ContentType                NVARCHAR(200),
--    @StorageUri                 NVARCHAR(MAX),
--    @FileHashHex                NVARCHAR(128)      = NULL,
--    @FileSizeBytes              BIGINT             = NULL,
--    @EntitySchemaName           NVARCHAR(128)      = NULL,
--    @EntityTableName            NVARCHAR(128)      = NULL,
--    @EntityPrimaryKeyValue      NVARCHAR(128)      = NULL,
--    @EntityNotes                NVARCHAR(MAX)     = NULL,
--    @CreatedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @DocumentTypeID INT;
--    DECLARE @DocumentID INT;
--    DECLARE @EntityDocumentID INT = NULL;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @DocumentTypeID = dt.DocumentTypeID
--    FROM doc.DocumentType dt
--    WHERE dt.DocumentTypeCode = @DocumentTypeCode
--      AND dt.IsActive = 1;
--
--    IF @DocumentTypeID IS NULL
--    BEGIN
--        THROW 50020, 'Document type code not found or inactive.', 1;
--    END;
--
--    INSERT INTO doc.Document
--    (
--        DocumentTypeID,
--        OriginalFileName,
--        StoredFileName,
--        ContentType,
--        StorageUri,
--        FileHashHex,
--        FileSizeBytes,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @DocumentTypeID,
--        @OriginalFileName,
--        @StoredFileName,
--        @ContentType,
--        @StorageUri,
--        @FileHashHex,
--        @FileSizeBytes,
--        @CreatedByUserID
--    );
--
--    SET @DocumentID = SCOPE_IDENTITY();
--
--    IF @EntitySchemaName IS NOT NULL
--       AND @EntityTableName IS NOT NULL
--       AND @EntityPrimaryKeyValue IS NOT NULL
--    BEGIN
--        INSERT INTO doc.EntityDocument
--        (
--            DocumentID,
--            EntitySchemaName,
--            EntityTableName,
--            EntityPrimaryKeyValue,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @DocumentID,
--            @EntitySchemaName,
--            @EntityTableName,
--            @EntityPrimaryKeyValue,
--            @EntityNotes,
--            @CreatedByUserID
--        );
--
--        SET @EntityDocumentID = SCOPE_IDENTITY();
--
--        EXEC audit.usp_WriteAuditLog
--            @SchemaName = N'doc',
--            @TableName = N'EntityDocument',
--            @RecordPrimaryKeyValue = CAST(@EntityDocumentID AS NVARCHAR(128)),
--            @ActionTypeCode = N'INSERT',
--            @ChangedByUserID = @CreatedByUserID,
--            @ChangeSourceCode = N'APPLICATION',
--            @CorrelationID = @CorrelationID,
--            @ReasonText = @ReasonText,
--            @NewValuesJson = (SELECT ed.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM doc.EntityDocument ed
--        WHERE ed.EntityDocumentID = @EntityDocumentID;
--    END;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'doc',
--        @TableName = N'Document',
--        @RecordPrimaryKeyValue = CAST(@DocumentID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM doc.Document d
--    WHERE d.DocumentID = @DocumentID;
--
--    SELECT
--        @DocumentID AS DocumentID,
--        @EntityDocumentID AS EntityDocumentID;
--END;

GO


CREATE PROCEDURE ops.usp_IncidentReport_Insert
    @SiteID                       INT,
    @ChildID                      INT                 = NULL,
    @IncidentTypeCode             NVARCHAR(50),
    @IncidentDateLocal            DATE,
    @IncidentTimeLocal            TIME(0)             = NULL,
    @LocationDescription          NVARCHAR(500)       = NULL,
    @IncidentSummary              NVARCHAR(MAX),
    @ActionTaken                  NVARCHAR(MAX)       = NULL,
    @ReportedToAuthorityUTC       DATETIME2(0)        = NULL,
    @AuthorityReferenceNumber     NVARCHAR(100)       = NULL,
    @CreatedByUserID              INT,
    @ReasonText                   NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @IncidentReportID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.Site s
        WHERE s.SiteID = @SiteID
          AND s.IsDeleted = 0
    )
    BEGIN
        THROW 50030, 'Site record not found or deleted.', 1;
    END;

    IF @ChildID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM child.Child c
           WHERE c.ChildID = @ChildID
             AND c.SiteID = @SiteID
             AND c.IsDeleted = 0
       )
    BEGIN
        THROW 50031, 'Child record not found for the specified site or is deleted.', 1;
    END;

    INSERT INTO ops.IncidentReport
    (
        SiteID,
        ChildID,
        IncidentTypeCode,
        IncidentDateLocal,
        IncidentTimeLocal,
        LocationDescription,
        IncidentSummary,
        ActionTaken,
        ReportedToAuthorityUTC,
        AuthorityReferenceNumber,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        @ChildID,
        @IncidentTypeCode,
        @IncidentDateLocal,
        @IncidentTimeLocal,
        @LocationDescription,
        @IncidentSummary,
        @ActionTaken,
        @ReportedToAuthorityUTC,
        @AuthorityReferenceNumber,
        @CreatedByUserID
    );

    SET @IncidentReportID = SCOPE_IDENTITY();

    DECLARE @IncidentReportNewValuesJson NVARCHAR(MAX) = (
        SELECT ir.* FROM ops.IncidentReport ir WHERE ir.IncidentReportID = @IncidentReportID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'ops',
        @TableName = N'IncidentReport',
        @RecordPrimaryKeyValue = CAST(@IncidentReportID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @IncidentReportNewValuesJson;

    SELECT @IncidentReportID AS IncidentReportID;
END;
GO

--Syntax Error: Incorrect syntax near '@IncidentReportID'.
--
--CREATE PROCEDURE ops.usp_IncidentReport_Insert
--    @SiteID                       INT,
--    @ChildID                      INT                 = NULL,
--    @IncidentTypeCode             NVARCHAR(50),
--    @IncidentDateLocal            DATE,
--    @IncidentTimeLocal            TIME(0)             = NULL,
--    @LocationDescription          NVARCHAR(500)       = NULL,
--    @IncidentSummary              NVARCHAR(MAX),
--    @ActionTaken                  NVARCHAR(MAX)       = NULL,
--    @ReportedToAuthorityUTC       DATETIME2(0)        = NULL,
--    @AuthorityReferenceNumber     NVARCHAR(100)       = NULL,
--    @CreatedByUserID              INT,
--    @ReasonText                   NVARCHAR(MAX)      = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @IncidentReportID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF NOT EXISTS
--    (
--        SELECT 1
--        FROM party.Site s
--        WHERE s.SiteID = @SiteID
--          AND s.IsDeleted = 0
--    )
--    BEGIN
--        THROW 50030, 'Site record not found or deleted.', 1;
--    END;
--
--    IF @ChildID IS NOT NULL
--       AND NOT EXISTS
--       (
--           SELECT 1
--           FROM child.Child c
--           WHERE c.ChildID = @ChildID
--             AND c.SiteID = @SiteID
--             AND c.IsDeleted = 0
--       )
--    BEGIN
--        THROW 50031, 'Child record not found for the specified site or is deleted.', 1;
--    END;
--
--    INSERT INTO ops.IncidentReport
--    (
--        SiteID,
--        ChildID,
--        IncidentTypeCode,
--        IncidentDateLocal,
--        IncidentTimeLocal,
--        LocationDescription,
--        IncidentSummary,
--        ActionTaken,
--        ReportedToAuthorityUTC,
--        AuthorityReferenceNumber,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @SiteID,
--        @ChildID,
--        @IncidentTypeCode,
--        @IncidentDateLocal,
--        @IncidentTimeLocal,
--        @LocationDescription,
--        @IncidentSummary,
--        @ActionTaken,
--        @ReportedToAuthorityUTC,
--        @AuthorityReferenceNumber,
--        @CreatedByUserID
--    );
--
--    SET @IncidentReportID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'ops',
--        @TableName = N'IncidentReport',
--        @RecordPrimaryKeyValue = CAST(@IncidentReportID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT ir.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM ops.IncidentReport ir
--    WHERE ir.IncidentReportID = @IncidentReportID;
--
--    SELECT @IncidentReportID AS IncidentReportID;
--END;

GO


CREATE PROCEDURE comm.usp_Conversation_Create
    @ConversationTypeCode        NVARCHAR(50),
    @SiteID                      INT                 = NULL,
    @ChildID                     INT                 = NULL,
    @Subject                     NVARCHAR(200)       = NULL,
    @CreatedByUserID             INT,
    @ReasonText                  NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ConversationID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @SiteID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM party.Site s
           WHERE s.SiteID = @SiteID
             AND s.IsDeleted = 0
       )
    BEGIN
        THROW 50050, 'Site record not found or deleted.', 1;
    END;

    IF @ChildID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM child.Child c
           WHERE c.ChildID = @ChildID
             AND c.IsDeleted = 0
       )
    BEGIN
        THROW 50051, 'Child record not found or deleted.', 1;
    END;

    INSERT INTO comm.Conversation
    (
        ConversationTypeCode,
        SiteID,
        ChildID,
        Subject,
        CreatedByUserID
    )
    VALUES
    (
        @ConversationTypeCode,
        @SiteID,
        @ChildID,
        @Subject,
        @CreatedByUserID
    );

    SET @ConversationID = SCOPE_IDENTITY();

    INSERT INTO comm.ConversationParticipant
    (
        ConversationID,
        PortalUserID,
        ParticipantRoleCode,
        CanRead,
        CanPost,
        CreatedByUserID
    )
    SELECT
        @ConversationID,
        pu.PortalUserID,
        r.RoleCode,
        1,
        1,
        @CreatedByUserID
    FROM party.PortalUser pu
    INNER JOIN party.PortalUserRole pur
        ON pur.PortalUserID = pu.PortalUserID
       AND pur.IsActive = 1
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
    WHERE pu.PortalUserID = @CreatedByUserID
      AND pu.IsDeleted = 0
      AND pu.IsActive = 1;

    DECLARE @ConversationNewValuesJson NVARCHAR(MAX) = (
        SELECT c.* FROM comm.Conversation c WHERE c.ConversationID = @ConversationID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'Conversation',
        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @ConversationNewValuesJson;

    SELECT @ConversationID AS ConversationID;
END;
GO

--Syntax Error: Incorrect syntax near '@ConversationID'.
--
--CREATE PROCEDURE comm.usp_Conversation_Create
--    @ConversationTypeCode        NVARCHAR(50),
--    @SiteID                      INT                 = NULL,
--    @ChildID                     INT                 = NULL,
--    @Subject                     NVARCHAR(200)       = NULL,
--    @CreatedByUserID             INT,
--    @ReasonText                  NVARCHAR(MAX)      = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @ConversationID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @SiteID IS NOT NULL
--       AND NOT EXISTS
--       (
--           SELECT 1
--           FROM party.Site s
--           WHERE s.SiteID = @SiteID
--             AND s.IsDeleted = 0
--       )
--    BEGIN
--        THROW 50050, 'Site record not found or deleted.', 1;
--    END;
--
--    IF @ChildID IS NOT NULL
--       AND NOT EXISTS
--       (
--           SELECT 1
--           FROM child.Child c
--           WHERE c.ChildID = @ChildID
--             AND c.IsDeleted = 0
--       )
--    BEGIN
--        THROW 50051, 'Child record not found or deleted.', 1;
--    END;
--
--    INSERT INTO comm.Conversation
--    (
--        ConversationTypeCode,
--        SiteID,
--        ChildID,
--        Subject,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @ConversationTypeCode,
--        @SiteID,
--        @ChildID,
--        @Subject,
--        @CreatedByUserID
--    );
--
--    SET @ConversationID = SCOPE_IDENTITY();
--
--    INSERT INTO comm.ConversationParticipant
--    (
--        ConversationID,
--        PortalUserID,
--        ParticipantRoleCode,
--        CanRead,
--        CanPost,
--        CreatedByUserID
--    )
--    SELECT
--        @ConversationID,
--        pu.PortalUserID,
--        r.RoleCode,
--        1,
--        1,
--        @CreatedByUserID
--    FROM party.PortalUser pu
--    INNER JOIN party.PortalUserRole pur
--        ON pur.PortalUserID = pu.PortalUserID
--       AND pur.IsActive = 1
--    INNER JOIN ref.Role r
--        ON r.RoleID = pur.RoleID
--    WHERE pu.PortalUserID = @CreatedByUserID
--      AND pu.IsDeleted = 0
--      AND pu.IsActive = 1;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'Conversation',
--        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM comm.Conversation c
--    WHERE c.ConversationID = @ConversationID;
--
--    SELECT @ConversationID AS ConversationID;
--END;

GO


CREATE PROCEDURE comm.usp_AdminConversation_Create
    @SiteID                      INT                 = NULL,
    @ChildID                     INT                 = NULL,
    @Subject                     NVARCHAR(200)       = NULL,
    @AdminInitiatorUserID        INT,
    @AdminInitiatorRoleCode      NVARCHAR(50),
    @ReasonCode                  NVARCHAR(50),
    @ReasonText                  NVARCHAR(MAX)      = NULL,
    @ScopeTypeCode               NVARCHAR(50),
    @ScopeEntityID               NVARCHAR(128)       = NULL,
    @PriorityCode                NVARCHAR(50)        = NULL,
    @RequiresAcknowledgment      BIT                 = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ConversationID INT;
    DECLARE @AdminConversationMetadataID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @AdminInitiatorRoleCode NOT IN (N'SUPPORT_ADMIN', N'PLATFORM_ADMIN', N'COMPLIANCE_ADMIN', N'LICENSOR_USER', N'LICENSOR_SUPERVISOR')
    BEGIN
        THROW 50052, 'Admin initiator role code is not authorized for admin-outbound conversations.', 1;
    END;

    EXEC comm.usp_Conversation_Create
        @ConversationTypeCode = N'ADMIN_OUTBOUND',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @Subject = @Subject,
        @CreatedByUserID = @AdminInitiatorUserID,
        @ReasonText = @ReasonText;

    SELECT TOP (1) @ConversationID = c.ConversationID
    FROM comm.Conversation c
    WHERE c.CreatedByUserID = @AdminInitiatorUserID
      AND c.ConversationTypeCode = N'ADMIN_OUTBOUND'
    ORDER BY c.ConversationID DESC;

    INSERT INTO comm.AdminConversationMetadata
    (
        ConversationID,
        AdminInitiatorUserID,
        AdminInitiatorRoleCode,
        ReasonCode,
        ReasonText,
        ScopeTypeCode,
        ScopeEntityID,
        PriorityCode,
        RequiresAcknowledgment
    )
    VALUES
    (
        @ConversationID,
        @AdminInitiatorUserID,
        @AdminInitiatorRoleCode,
        @ReasonCode,
        @ReasonText,
        @ScopeTypeCode,
        @ScopeEntityID,
        @PriorityCode,
        @RequiresAcknowledgment
    );

    SET @AdminConversationMetadataID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'AdminConversationMetadata',
        @RecordPrimaryKeyValue = CAST(@AdminConversationMetadataID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @AdminInitiatorUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = (SELECT acm.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM comm.AdminConversationMetadata acm
    WHERE acm.AdminConversationMetadataID = @AdminConversationMetadataID;

    SELECT
        @ConversationID AS ConversationID,
        @AdminConversationMetadataID AS AdminConversationMetadataID;
END;
GO

--Syntax Error: Incorrect syntax near '@AdminConversationMetadataID'.
--
--CREATE PROCEDURE comm.usp_AdminConversation_Create
--    @SiteID                      INT                 = NULL,
--    @ChildID                     INT                 = NULL,
--    @Subject                     NVARCHAR(200)       = NULL,
--    @AdminInitiatorUserID        INT,
--    @AdminInitiatorRoleCode      NVARCHAR(50),
--    @ReasonCode                  NVARCHAR(50),
--    @ReasonText                  NVARCHAR(MAX)      = NULL,
--    @ScopeTypeCode               NVARCHAR(50),
--    @ScopeEntityID               NVARCHAR(128)       = NULL,
--    @PriorityCode                NVARCHAR(50)        = NULL,
--    @RequiresAcknowledgment      BIT                 = 0
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @ConversationID INT;
--    DECLARE @AdminConversationMetadataID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @AdminInitiatorRoleCode NOT IN (N'SUPPORT_ADMIN', N'PLATFORM_ADMIN', N'COMPLIANCE_ADMIN', N'LICENSOR_USER', N'LICENSOR_SUPERVISOR')
--    BEGIN
--        THROW 50052, 'Admin initiator role code is not authorized for admin-outbound conversations.', 1;
--    END;
--
--    EXEC comm.usp_Conversation_Create
--        @ConversationTypeCode = N'ADMIN_OUTBOUND',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @Subject = @Subject,
--        @CreatedByUserID = @AdminInitiatorUserID,
--        @ReasonText = @ReasonText;
--
--    SELECT TOP (1) @ConversationID = c.ConversationID
--    FROM comm.Conversation c
--    WHERE c.CreatedByUserID = @AdminInitiatorUserID
--      AND c.ConversationTypeCode = N'ADMIN_OUTBOUND'
--    ORDER BY c.ConversationID DESC;
--
--    INSERT INTO comm.AdminConversationMetadata
--    (
--        ConversationID,
--        AdminInitiatorUserID,
--        AdminInitiatorRoleCode,
--        ReasonCode,
--        ReasonText,
--        ScopeTypeCode,
--        ScopeEntityID,
--        PriorityCode,
--        RequiresAcknowledgment
--    )
--    VALUES
--    (
--        @ConversationID,
--        @AdminInitiatorUserID,
--        @AdminInitiatorRoleCode,
--        @ReasonCode,
--        @ReasonText,
--        @ScopeTypeCode,
--        @ScopeEntityID,
--        @PriorityCode,
--        @RequiresAcknowledgment
--    );
--
--    SET @AdminConversationMetadataID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'AdminConversationMetadata',
--        @RecordPrimaryKeyValue = CAST(@AdminConversationMetadataID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @AdminInitiatorUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT acm.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM comm.AdminConversationMetadata acm
--    WHERE acm.AdminConversationMetadataID = @AdminConversationMetadataID;
--
--    SELECT
--        @ConversationID AS ConversationID,
--        @AdminConversationMetadataID AS AdminConversationMetadataID;
--END;

GO


CREATE PROCEDURE comm.usp_Message_Send
    @ConversationID               INT,
    @SenderUserID                 INT,
    @MessageBody                  NVARCHAR(MAX),
    @CreatedByUserID              INT,
    @ReasonText                   NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @MessageID INT;
    DECLARE @SiteID INT;
    DECLARE @ChildID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF NOT EXISTS
    (
        SELECT 1
        FROM comm.ConversationParticipant cp
        WHERE cp.ConversationID = @ConversationID
          AND cp.PortalUserID = @SenderUserID
          AND cp.IsActive = 1
          AND cp.CanPost = 1
    )
    BEGIN
        THROW 50053, 'Sender is not an active posting participant in the conversation.', 1;
    END;

    SELECT
        @SiteID = c.SiteID,
        @ChildID = c.ChildID
    FROM comm.Conversation c
    WHERE c.ConversationID = @ConversationID
      AND c.IsDeleted = 0
      AND c.IsActive = 1;

    IF @SiteID IS NULL AND @ChildID IS NULL
    BEGIN
        IF NOT EXISTS
        (
            SELECT 1
            FROM comm.Conversation c
            WHERE c.ConversationID = @ConversationID
              AND c.IsDeleted = 0
              AND c.IsActive = 1
        )
        BEGIN
            THROW 50054, 'Conversation not found or inactive.', 1;
        END;
    END;

    INSERT INTO comm.Message
    (
        ConversationID,
        SenderUserID,
        MessageBody,
        CreatedByUserID
    )
    VALUES
    (
        @ConversationID,
        @SenderUserID,
        @MessageBody,
        @CreatedByUserID
    );

    SET @MessageID = SCOPE_IDENTITY();

    DECLARE @MessageNewValuesJson NVARCHAR(MAX) = (
        SELECT m.* FROM comm.Message m WHERE m.MessageID = @MessageID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'Message',
        @RecordPrimaryKeyValue = CAST(@MessageID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @SenderUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @MessageNewValuesJson;

    SELECT @MessageID AS MessageID;
END;
GO

--Syntax Error: Incorrect syntax near '@MessageID'.
--
--CREATE PROCEDURE comm.usp_Message_Send
--    @ConversationID               INT,
--    @SenderUserID                 INT,
--    @MessageBody                  NVARCHAR(MAX),
--    @CreatedByUserID              INT,
--    @ReasonText                   NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @MessageID INT;
--    DECLARE @SiteID INT;
--    DECLARE @ChildID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF NOT EXISTS
--    (
--        SELECT 1
--        FROM comm.ConversationParticipant cp
--        WHERE cp.ConversationID = @ConversationID
--          AND cp.PortalUserID = @SenderUserID
--          AND cp.IsActive = 1
--          AND cp.CanPost = 1
--    )
--    BEGIN
--        THROW 50053, 'Sender is not an active posting participant in the conversation.', 1;
--    END;
--
--    SELECT
--        @SiteID = c.SiteID,
--        @ChildID = c.ChildID
--    FROM comm.Conversation c
--    WHERE c.ConversationID = @ConversationID
--      AND c.IsDeleted = 0
--      AND c.IsActive = 1;
--
--    IF @SiteID IS NULL AND @ChildID IS NULL
--    BEGIN
--        IF NOT EXISTS
--        (
--            SELECT 1
--            FROM comm.Conversation c
--            WHERE c.ConversationID = @ConversationID
--              AND c.IsDeleted = 0
--              AND c.IsActive = 1
--        )
--        BEGIN
--            THROW 50054, 'Conversation not found or inactive.', 1;
--        END;
--    END;
--
--    INSERT INTO comm.Message
--    (
--        ConversationID,
--        SenderUserID,
--        MessageBody,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @ConversationID,
--        @SenderUserID,
--        @MessageBody,
--        @CreatedByUserID
--    );
--
--    SET @MessageID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'Message',
--        @RecordPrimaryKeyValue = CAST(@MessageID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @SenderUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT m.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM comm.Message m
--    WHERE m.MessageID = @MessageID;
--
--    SELECT @MessageID AS MessageID;
--END;

GO


CREATE PROCEDURE ops.usp_CaregiverPresence_Upsert
    @CaregiverPresenceID          INT                = NULL,
    @SiteID                       INT,
    @PersonID                     INT,
    @PresenceRoleCode             NVARCHAR(50),
    @StartDateTimeUTC             DATETIME2(0),
    @EndDateTimeUTC               DATETIME2(0),
    @CountsAsAdultCaregiver       BIT,
    @CountsAsHelper               BIT,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @EndDateTimeUTC <= @StartDateTimeUTC
        THROW 50210, 'Caregiver presence end time must be greater than start time.', 1;

    IF @CaregiverPresenceID IS NULL
    BEGIN
        INSERT INTO ops.CaregiverPresence
        (
            SiteID,
            PersonID,
            PresenceRoleCode,
            StartDateTimeUTC,
            EndDateTimeUTC,
            CountsAsAdultCaregiver,
            CountsAsHelper,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @PersonID,
            @PresenceRoleCode,
            @StartDateTimeUTC,
            @EndDateTimeUTC,
            @CountsAsAdultCaregiver,
            @CountsAsHelper,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
    SELECT @OldValuesJson = (
        SELECT cp.* FROM ops.CaregiverPresence cp WHERE cp.CaregiverPresenceID = @CaregiverPresenceID AND cp.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

        IF @OldValuesJson IS NULL
            THROW 50211, 'Caregiver presence record not found or deleted.', 1;

        UPDATE ops.CaregiverPresence
           SET SiteID = @SiteID,
               PersonID = @PersonID,
               PresenceRoleCode = @PresenceRoleCode,
               StartDateTimeUTC = @StartDateTimeUTC,
               EndDateTimeUTC = @EndDateTimeUTC,
               CountsAsAdultCaregiver = @CountsAsAdultCaregiver,
               CountsAsHelper = @CountsAsHelper,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE CaregiverPresenceID = @CaregiverPresenceID
           AND IsDeleted = 0;

        SET @RecordID = @CaregiverPresenceID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT cp.* FROM ops.CaregiverPresence cp WHERE cp.CaregiverPresenceID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'ops',
        @TableName = N'CaregiverPresence',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS CaregiverPresenceID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE ops.usp_CaregiverPresence_Upsert
--    @CaregiverPresenceID          INT                = NULL,
--    @SiteID                       INT,
--    @PersonID                     INT,
--    @PresenceRoleCode             NVARCHAR(50),
--    @StartDateTimeUTC             DATETIME2(0),
--    @EndDateTimeUTC               DATETIME2(0),
--    @CountsAsAdultCaregiver       BIT,
--    @CountsAsHelper               BIT,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @EndDateTimeUTC <= @StartDateTimeUTC
--        THROW 50210, 'Caregiver presence end time must be greater than start time.', 1;
--
--    IF @CaregiverPresenceID IS NULL
--    BEGIN
--        INSERT INTO ops.CaregiverPresence
--        (
--            SiteID,
--            PersonID,
--            PresenceRoleCode,
--            StartDateTimeUTC,
--            EndDateTimeUTC,
--            CountsAsAdultCaregiver,
--            CountsAsHelper,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @PersonID,
--            @PresenceRoleCode,
--            @StartDateTimeUTC,
--            @EndDateTimeUTC,
--            @CountsAsAdultCaregiver,
--            @CountsAsHelper,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT cp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM ops.CaregiverPresence cp
--        WHERE cp.CaregiverPresenceID = @CaregiverPresenceID
--          AND cp.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50211, 'Caregiver presence record not found or deleted.', 1;
--
--        UPDATE ops.CaregiverPresence
--           SET SiteID = @SiteID,
--               PersonID = @PersonID,
--               PresenceRoleCode = @PresenceRoleCode,
--               StartDateTimeUTC = @StartDateTimeUTC,
--               EndDateTimeUTC = @EndDateTimeUTC,
--               CountsAsAdultCaregiver = @CountsAsAdultCaregiver,
--               CountsAsHelper = @CountsAsHelper,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE CaregiverPresenceID = @CaregiverPresenceID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @CaregiverPresenceID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT cp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM ops.CaregiverPresence cp
--    WHERE cp.CaregiverPresenceID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'ops',
--        @TableName = N'CaregiverPresence',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS CaregiverPresenceID;
--END;

GO


CREATE PROCEDURE ops.usp_CountedNonEnrollmentChild_Upsert
    @CountedNonEnrollmentChildID  INT                = NULL,
    @SiteID                       INT,
    @ChildDisplayName             NVARCHAR(200),
    @DateOfBirth                  DATE,
    @RelationshipToProviderCode   NVARCHAR(50),
    @CountsTowardCapacityFlag     BIT,
    @EffectiveStartDate           DATE,
    @EffectiveEndDate             DATE               = NULL,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @CountedNonEnrollmentChildID IS NULL
    BEGIN
        INSERT INTO ops.CountedNonEnrollmentChild
        (
            SiteID,
            ChildDisplayName,
            DateOfBirth,
            RelationshipToProviderCode,
            CountsTowardCapacityFlag,
            EffectiveStartDate,
            EffectiveEndDate,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @ChildDisplayName,
            @DateOfBirth,
            @RelationshipToProviderCode,
            @CountsTowardCapacityFlag,
            @EffectiveStartDate,
            @EffectiveEndDate,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (
            SELECT c.* FROM ops.CountedNonEnrollmentChild c WHERE c.CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID AND c.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        IF @OldValuesJson IS NULL
            THROW 50212, 'Counted non-enrollment child record not found or deleted.', 1;

        UPDATE ops.CountedNonEnrollmentChild
           SET SiteID = @SiteID,
               ChildDisplayName = @ChildDisplayName,
               DateOfBirth = @DateOfBirth,
               RelationshipToProviderCode = @RelationshipToProviderCode,
               CountsTowardCapacityFlag = @CountsTowardCapacityFlag,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
           AND IsDeleted = 0;

        SET @RecordID = @CountedNonEnrollmentChildID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT c.* FROM ops.CountedNonEnrollmentChild c WHERE c.CountedNonEnrollmentChildID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'ops',
        @TableName = N'CountedNonEnrollmentChild',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS CountedNonEnrollmentChildID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE ops.usp_CountedNonEnrollmentChild_Upsert
--    @CountedNonEnrollmentChildID  INT                = NULL,
--    @SiteID                       INT,
--    @ChildDisplayName             NVARCHAR(200),
--    @DateOfBirth                  DATE,
--    @RelationshipToProviderCode   NVARCHAR(50),
--    @CountsTowardCapacityFlag     BIT,
--    @EffectiveStartDate           DATE,
--    @EffectiveEndDate             DATE               = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @CountedNonEnrollmentChildID IS NULL
--    BEGIN
--        INSERT INTO ops.CountedNonEnrollmentChild
--        (
--            SiteID,
--            ChildDisplayName,
--            DateOfBirth,
--            RelationshipToProviderCode,
--            CountsTowardCapacityFlag,
--            EffectiveStartDate,
--            EffectiveEndDate,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @ChildDisplayName,
--            @DateOfBirth,
--            @RelationshipToProviderCode,
--            @CountsTowardCapacityFlag,
--            @EffectiveStartDate,
--            @EffectiveEndDate,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM ops.CountedNonEnrollmentChild c
--        WHERE c.CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
--          AND c.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50212, 'Counted non-enrollment child record not found or deleted.', 1;
--
--        UPDATE ops.CountedNonEnrollmentChild
--           SET SiteID = @SiteID,
--               ChildDisplayName = @ChildDisplayName,
--               DateOfBirth = @DateOfBirth,
--               RelationshipToProviderCode = @RelationshipToProviderCode,
--               CountsTowardCapacityFlag = @CountsTowardCapacityFlag,
--               EffectiveStartDate = @EffectiveStartDate,
--               EffectiveEndDate = @EffectiveEndDate,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @CountedNonEnrollmentChildID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM ops.CountedNonEnrollmentChild c
--    WHERE c.CountedNonEnrollmentChildID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'ops',
--        @TableName = N'CountedNonEnrollmentChild',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS CountedNonEnrollmentChildID;
--END;

GO


CREATE PROCEDURE lic.usp_LicenseVariance_Upsert
    @LicenseVarianceID            INT                = NULL,
    @SiteID                       INT,
    @VarianceCode                 NVARCHAR(50),
    @VarianceTitle                NVARCHAR(200),
    @VarianceDescription          NVARCHAR(MAX)     = NULL,
    @ApprovalDate                 DATE               = NULL,
    @EffectiveStartDate           DATE,
    @EffectiveEndDate             DATE               = NULL,
    @ApprovedByAgencyName         NVARCHAR(200)      = NULL,
    @AgencyReferenceNumber        NVARCHAR(100)      = NULL,
    @DocumentID                   INT                = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @LicenseVarianceID IS NULL
    BEGIN
        INSERT INTO lic.LicenseVariance
        (
            SiteID,
            VarianceCode,
            VarianceTitle,
            VarianceDescription,
            ApprovalDate,
            EffectiveStartDate,
            EffectiveEndDate,
            ApprovedByAgencyName,
            AgencyReferenceNumber,
            DocumentID,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @VarianceCode,
            @VarianceTitle,
            @VarianceDescription,
            @ApprovalDate,
            @EffectiveStartDate,
            @EffectiveEndDate,
            @ApprovedByAgencyName,
            @AgencyReferenceNumber,
            @DocumentID,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (
            SELECT lv.* FROM lic.LicenseVariance lv WHERE lv.LicenseVarianceID = @LicenseVarianceID AND lv.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        IF @OldValuesJson IS NULL
            THROW 50230, 'License variance record not found or deleted.', 1;

        UPDATE lic.LicenseVariance
           SET SiteID = @SiteID,
               VarianceCode = @VarianceCode,
               VarianceTitle = @VarianceTitle,
               VarianceDescription = @VarianceDescription,
               ApprovalDate = @ApprovalDate,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               ApprovedByAgencyName = @ApprovedByAgencyName,
               AgencyReferenceNumber = @AgencyReferenceNumber,
               DocumentID = @DocumentID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE LicenseVarianceID = @LicenseVarianceID
           AND IsDeleted = 0;

        SET @RecordID = @LicenseVarianceID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT lv.* FROM lic.LicenseVariance lv WHERE lv.LicenseVarianceID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'LicenseVariance',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS LicenseVarianceID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_LicenseVariance_Upsert
--    @LicenseVarianceID            INT                = NULL,
--    @SiteID                       INT,
--    @VarianceCode                 NVARCHAR(50),
--    @VarianceTitle                NVARCHAR(200),
--    @VarianceDescription          NVARCHAR(MAX)     = NULL,
--    @ApprovalDate                 DATE               = NULL,
--    @EffectiveStartDate           DATE,
--    @EffectiveEndDate             DATE               = NULL,
--    @ApprovedByAgencyName         NVARCHAR(200)      = NULL,
--    @AgencyReferenceNumber        NVARCHAR(100)      = NULL,
--    @DocumentID                   INT                = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @LicenseVarianceID IS NULL
--    BEGIN
--        INSERT INTO lic.LicenseVariance
--        (
--            SiteID,
--            VarianceCode,
--            VarianceTitle,
--            VarianceDescription,
--            ApprovalDate,
--            EffectiveStartDate,
--            EffectiveEndDate,
--            ApprovedByAgencyName,
--            AgencyReferenceNumber,
--            DocumentID,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @VarianceCode,
--            @VarianceTitle,
--            @VarianceDescription,
--            @ApprovalDate,
--            @EffectiveStartDate,
--            @EffectiveEndDate,
--            @ApprovedByAgencyName,
--            @AgencyReferenceNumber,
--            @DocumentID,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT lv.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.LicenseVariance lv
--        WHERE lv.LicenseVarianceID = @LicenseVarianceID
--          AND lv.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50230, 'License variance record not found or deleted.', 1;
--
--        UPDATE lic.LicenseVariance
--           SET SiteID = @SiteID,
--               VarianceCode = @VarianceCode,
--               VarianceTitle = @VarianceTitle,
--               VarianceDescription = @VarianceDescription,
--               ApprovalDate = @ApprovalDate,
--               EffectiveStartDate = @EffectiveStartDate,
--               EffectiveEndDate = @EffectiveEndDate,
--               ApprovedByAgencyName = @ApprovedByAgencyName,
--               AgencyReferenceNumber = @AgencyReferenceNumber,
--               DocumentID = @DocumentID,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE LicenseVarianceID = @LicenseVarianceID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @LicenseVarianceID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT lv.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.LicenseVariance lv
--    WHERE lv.LicenseVarianceID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'LicenseVariance',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS LicenseVarianceID;
--END;

GO


CREATE PROCEDURE lic.usp_RequirementStatus_Upsert
    @RequirementStatusID          INT                = NULL,
    @RequirementID                INT,
    @SiteID                       INT                = NULL,
    @ChildID                      INT                = NULL,
    @PersonID                     INT                = NULL,
    @StatusCode                   NVARCHAR(50),
    @ReviewDueDate                DATE               = NULL,
    @ReviewedByUserID             INT                = NULL,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @RequirementStatusID IS NULL
    BEGIN
        INSERT INTO lic.RequirementStatus
        (
            RequirementID,
            SiteID,
            ChildID,
            PersonID,
            StatusCode,
            ReviewDueDate,
            ReviewedByUserID,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @RequirementID,
            @SiteID,
            @ChildID,
            @PersonID,
            @StatusCode,
            @ReviewDueDate,
            @ReviewedByUserID,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (
            SELECT rs.* FROM lic.RequirementStatus rs WHERE rs.RequirementStatusID = @RequirementStatusID AND rs.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        IF @OldValuesJson IS NULL
            THROW 50231, 'Requirement status record not found or deleted.', 1;

        UPDATE lic.RequirementStatus
           SET RequirementID = @RequirementID,
               SiteID = @SiteID,
               ChildID = @ChildID,
               PersonID = @PersonID,
               StatusCode = @StatusCode,
               ReviewDueDate = @ReviewDueDate,
               ReviewedByUserID = @ReviewedByUserID,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE RequirementStatusID = @RequirementStatusID
           AND IsDeleted = 0;

        SET @RecordID = @RequirementStatusID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT rs.* FROM lic.RequirementStatus rs WHERE rs.RequirementStatusID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'RequirementStatus',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS RequirementStatusID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_RequirementStatus_Upsert
--    @RequirementStatusID          INT                = NULL,
--    @RequirementID                INT,
--    @SiteID                       INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @PersonID                     INT                = NULL,
--    @StatusCode                   NVARCHAR(50),
--    @ReviewDueDate                DATE               = NULL,
--    @ReviewedByUserID             INT                = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @RequirementStatusID IS NULL
--    BEGIN
--        INSERT INTO lic.RequirementStatus
--        (
--            RequirementID,
--            SiteID,
--            ChildID,
--            PersonID,
--            StatusCode,
--            ReviewDueDate,
--            ReviewedByUserID,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @RequirementID,
--            @SiteID,
--            @ChildID,
--            @PersonID,
--            @StatusCode,
--            @ReviewDueDate,
--            @ReviewedByUserID,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT rs.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.RequirementStatus rs
--        WHERE rs.RequirementStatusID = @RequirementStatusID
--          AND rs.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50231, 'Requirement status record not found or deleted.', 1;
--
--        UPDATE lic.RequirementStatus
--           SET RequirementID = @RequirementID,
--               SiteID = @SiteID,
--               ChildID = @ChildID,
--               PersonID = @PersonID,
--               StatusCode = @StatusCode,
--               ReviewDueDate = @ReviewDueDate,
--               ReviewedByUserID = @ReviewedByUserID,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE RequirementStatusID = @RequirementStatusID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @RequirementStatusID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT rs.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.RequirementStatus rs
--    WHERE rs.RequirementStatusID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'RequirementStatus',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS RequirementStatusID;
--END;

GO


CREATE PROCEDURE lic.usp_RequirementEvidence_Upsert
    @RequirementEvidenceID        INT                = NULL,
    @RequirementID                INT,
    @SiteID                       INT                = NULL,
    @ChildID                      INT                = NULL,
    @PersonID                     INT                = NULL,
    @DocumentID                   INT                = NULL,
    @EvidenceTypeCode             NVARCHAR(100),
    @EvidenceStatusCode           NVARCHAR(50),
    @EvidenceDate                 DATE               = NULL,
    @ExpirationDate               DATE               = NULL,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @RequirementEvidenceID IS NULL
    BEGIN
        INSERT INTO lic.RequirementEvidence
        (
            RequirementID,
            SiteID,
            ChildID,
            PersonID,
            DocumentID,
            EvidenceTypeCode,
            EvidenceStatusCode,
            EvidenceDate,
            ExpirationDate,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @RequirementID,
            @SiteID,
            @ChildID,
            @PersonID,
            @DocumentID,
            @EvidenceTypeCode,
            @EvidenceStatusCode,
            @EvidenceDate,
            @ExpirationDate,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (
            SELECT re.* FROM lic.RequirementEvidence re WHERE re.RequirementEvidenceID = @RequirementEvidenceID AND re.IsDeleted = 0 FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        IF @OldValuesJson IS NULL
            THROW 50232, 'Requirement evidence record not found or deleted.', 1;

        UPDATE lic.RequirementEvidence
           SET RequirementID = @RequirementID,
               SiteID = @SiteID,
               ChildID = @ChildID,
               PersonID = @PersonID,
               DocumentID = @DocumentID,
               EvidenceTypeCode = @EvidenceTypeCode,
               EvidenceStatusCode = @EvidenceStatusCode,
               EvidenceDate = @EvidenceDate,
               ExpirationDate = @ExpirationDate,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE RequirementEvidenceID = @RequirementEvidenceID
           AND IsDeleted = 0;

        SET @RecordID = @RequirementEvidenceID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT re.* FROM lic.RequirementEvidence re WHERE re.RequirementEvidenceID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'RequirementEvidence',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS RequirementEvidenceID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_RequirementEvidence_Upsert
--    @RequirementEvidenceID        INT                = NULL,
--    @RequirementID                INT,
--    @SiteID                       INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @PersonID                     INT                = NULL,
--    @DocumentID                   INT                = NULL,
--    @EvidenceTypeCode             NVARCHAR(100),
--    @EvidenceStatusCode           NVARCHAR(50),
--    @EvidenceDate                 DATE               = NULL,
--    @ExpirationDate               DATE               = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @RequirementEvidenceID IS NULL
--    BEGIN
--        INSERT INTO lic.RequirementEvidence
--        (
--            RequirementID,
--            SiteID,
--            ChildID,
--            PersonID,
--            DocumentID,
--            EvidenceTypeCode,
--            EvidenceStatusCode,
--            EvidenceDate,
--            ExpirationDate,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @RequirementID,
--            @SiteID,
--            @ChildID,
--            @PersonID,
--            @DocumentID,
--            @EvidenceTypeCode,
--            @EvidenceStatusCode,
--            @EvidenceDate,
--            @ExpirationDate,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.RequirementEvidence re
--        WHERE re.RequirementEvidenceID = @RequirementEvidenceID
--          AND re.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50232, 'Requirement evidence record not found or deleted.', 1;
--
--        UPDATE lic.RequirementEvidence
--           SET RequirementID = @RequirementID,
--               SiteID = @SiteID,
--               ChildID = @ChildID,
--               PersonID = @PersonID,
--               DocumentID = @DocumentID,
--               EvidenceTypeCode = @EvidenceTypeCode,
--               EvidenceStatusCode = @EvidenceStatusCode,
--               EvidenceDate = @EvidenceDate,
--               ExpirationDate = @ExpirationDate,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE RequirementEvidenceID = @RequirementEvidenceID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @RequirementEvidenceID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.RequirementEvidence re
--    WHERE re.RequirementEvidenceID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'RequirementEvidence',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS RequirementEvidenceID;
--END;

GO


CREATE PROCEDURE comm.usp_ConversationParticipant_Add
    @ConversationID                INT,
    @PortalUserID                  INT,
    @ParticipantRoleCode           NVARCHAR(50),
    @CanRead                       BIT = 1,
    @CanPost                       BIT = 1,
    @ChangedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF EXISTS
    (
        SELECT 1
        FROM comm.ConversationParticipant cp
        WHERE cp.ConversationID = @ConversationID
          AND cp.PortalUserID = @PortalUserID
    )
    BEGIN
        UPDATE comm.ConversationParticipant
           SET ParticipantRoleCode = @ParticipantRoleCode,
               CanRead = @CanRead,
               CanPost = @CanPost,
               IsActive = 1,
               LeftUTC = NULL,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ConversationID = @ConversationID
           AND PortalUserID = @PortalUserID;
    END
    ELSE
    BEGIN
        INSERT INTO comm.ConversationParticipant
        (
            ConversationID,
            PortalUserID,
            ParticipantRoleCode,
            CanRead,
            CanPost,
            CreatedByUserID
        )
        VALUES
        (
            @ConversationID,
            @PortalUserID,
            @ParticipantRoleCode,
            @CanRead,
            @CanPost,
            @ChangedByUserID
        );
    END;

    INSERT INTO comm.ConversationParticipantAudit
    (
        ConversationID,
        PortalUserID,
        AuditActionCode,
        ChangedByUserID,
        Notes
    )
    VALUES
    (
        @ConversationID,
        @PortalUserID,
        N'ADD',
        @ChangedByUserID,
        @ReasonText
    );

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'ConversationParticipant',
        @RecordPrimaryKeyValue = CONCAT(@ConversationID, N':', @PortalUserID),
        @ActionTypeCode = N'UPSERT',
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = (
            SELECT cp.*
            FROM comm.ConversationParticipant cp
            WHERE cp.ConversationID = @ConversationID
              AND cp.PortalUserID = @PortalUserID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
END;
GO

--Syntax Error: Incorrect syntax near '@ConversationID'.
--
--CREATE PROCEDURE comm.usp_ConversationParticipant_Add
--    @ConversationID                INT,
--    @PortalUserID                  INT,
--    @ParticipantRoleCode           NVARCHAR(50),
--    @CanRead                       BIT = 1,
--    @CanPost                       BIT = 1,
--    @ChangedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF EXISTS
--    (
--        SELECT 1
--        FROM comm.ConversationParticipant cp
--        WHERE cp.ConversationID = @ConversationID
--          AND cp.PortalUserID = @PortalUserID
--    )
--    BEGIN
--        UPDATE comm.ConversationParticipant
--           SET ParticipantRoleCode = @ParticipantRoleCode,
--               CanRead = @CanRead,
--               CanPost = @CanPost,
--               IsActive = 1,
--               LeftUTC = NULL,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ConversationID = @ConversationID
--           AND PortalUserID = @PortalUserID;
--    END
--    ELSE
--    BEGIN
--        INSERT INTO comm.ConversationParticipant
--        (
--            ConversationID,
--            PortalUserID,
--            ParticipantRoleCode,
--            CanRead,
--            CanPost,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ConversationID,
--            @PortalUserID,
--            @ParticipantRoleCode,
--            @CanRead,
--            @CanPost,
--            @ChangedByUserID
--        );
--    END;
--
--    INSERT INTO comm.ConversationParticipantAudit
--    (
--        ConversationID,
--        PortalUserID,
--        AuditActionCode,
--        ChangedByUserID,
--        Notes
--    )
--    VALUES
--    (
--        @ConversationID,
--        @PortalUserID,
--        N'ADD',
--        @ChangedByUserID,
--        @ReasonText
--    );
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'ConversationParticipant',
--        @RecordPrimaryKeyValue = CONCAT(@ConversationID, N':', @PortalUserID),
--        @ActionTypeCode = N'UPSERT',
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (
--            SELECT cp.*
--            FROM comm.ConversationParticipant cp
--            WHERE cp.ConversationID = @ConversationID
--              AND cp.PortalUserID = @PortalUserID
--            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--        );
--END;

GO


CREATE PROCEDURE comm.usp_ConversationParticipant_Remove
    @ConversationID                INT,
    @PortalUserID                  INT,
    @ChangedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
    DECLARE @OldValuesJson NVARCHAR(MAX);

    SELECT @OldValuesJson = (
        SELECT cp.*
        FROM comm.ConversationParticipant cp
        WHERE cp.ConversationID = @ConversationID
          AND cp.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    UPDATE comm.ConversationParticipant
       SET IsActive = 0,
           LeftUTC = SYSUTCDATETIME(),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ChangedByUserID
     WHERE ConversationID = @ConversationID
       AND PortalUserID = @PortalUserID
       AND IsActive = 1;

    INSERT INTO comm.ConversationParticipantAudit
    (
        ConversationID,
        PortalUserID,
        AuditActionCode,
        ChangedByUserID,
        Notes
    )
    VALUES
    (
        @ConversationID,
        @PortalUserID,
        N'REMOVE',
        @ChangedByUserID,
        @ReasonText
    );

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'ConversationParticipant',
        @RecordPrimaryKeyValue = CONCAT(@ConversationID, N':', @PortalUserID),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (
            SELECT cp.*
            FROM comm.ConversationParticipant cp
            WHERE cp.ConversationID = @ConversationID
              AND cp.PortalUserID = @PortalUserID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
END;
GO

--Syntax Error: Incorrect syntax near '@ConversationID'.
--
--CREATE PROCEDURE comm.usp_ConversationParticipant_Remove
--    @ConversationID                INT,
--    @PortalUserID                  INT,
--    @ChangedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--
--    SELECT @OldValuesJson = (
--        SELECT cp.*
--        FROM comm.ConversationParticipant cp
--        WHERE cp.ConversationID = @ConversationID
--          AND cp.PortalUserID = @PortalUserID
--        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--    );
--
--    UPDATE comm.ConversationParticipant
--       SET IsActive = 0,
--           LeftUTC = SYSUTCDATETIME(),
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ChangedByUserID
--     WHERE ConversationID = @ConversationID
--       AND PortalUserID = @PortalUserID
--       AND IsActive = 1;
--
--    INSERT INTO comm.ConversationParticipantAudit
--    (
--        ConversationID,
--        PortalUserID,
--        AuditActionCode,
--        ChangedByUserID,
--        Notes
--    )
--    VALUES
--    (
--        @ConversationID,
--        @PortalUserID,
--        N'REMOVE',
--        @ChangedByUserID,
--        @ReasonText
--    );
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'ConversationParticipant',
--        @RecordPrimaryKeyValue = CONCAT(@ConversationID, N':', @PortalUserID),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (
--            SELECT cp.*
--            FROM comm.ConversationParticipant cp
--            WHERE cp.ConversationID = @ConversationID
--              AND cp.PortalUserID = @PortalUserID
--            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--        );
--END;

GO


CREATE PROCEDURE comm.usp_Conversation_Archive
    @ConversationID                INT,
    @ChangedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @OldValuesJson = (
        SELECT c.*
        FROM comm.Conversation c
        WHERE c.ConversationID = @ConversationID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    UPDATE comm.Conversation
       SET IsArchived = 1,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ChangedByUserID
     WHERE ConversationID = @ConversationID
       AND IsDeleted = 0;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'Conversation',
        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (
            SELECT c.*
            FROM comm.Conversation c
            WHERE c.ConversationID = @ConversationID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
END;
GO

--Syntax Error: Incorrect syntax near '@ConversationID'.
--
--CREATE PROCEDURE comm.usp_Conversation_Archive
--    @ConversationID                INT,
--    @ChangedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @OldValuesJson = (
--        SELECT c.*
--        FROM comm.Conversation c
--        WHERE c.ConversationID = @ConversationID
--        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--    );
--
--    UPDATE comm.Conversation
--       SET IsArchived = 1,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ChangedByUserID
--     WHERE ConversationID = @ConversationID
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'Conversation',
--        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (
--            SELECT c.*
--            FROM comm.Conversation c
--            WHERE c.ConversationID = @ConversationID
--            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--        );
--END;

GO


CREATE PROCEDURE comm.usp_MessageAttachment_Add
    @MessageID                     INT,
    @DocumentID                    INT,
    @CreatedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @MessageAttachmentID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    INSERT INTO comm.MessageAttachment
    (
        MessageID,
        DocumentID,
        CreatedByUserID
    )
    VALUES
    (
        @MessageID,
        @DocumentID,
        @CreatedByUserID
    );

    SET @MessageAttachmentID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'MessageAttachment',
        @RecordPrimaryKeyValue = CAST(@MessageAttachmentID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = (
            SELECT ma.*
            FROM comm.MessageAttachment ma
            WHERE ma.MessageAttachmentID = @MessageAttachmentID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
END;
GO

--Syntax Error: Incorrect syntax near '@MessageAttachmentID'.
--
--CREATE PROCEDURE comm.usp_MessageAttachment_Add
--    @MessageID                     INT,
--    @DocumentID                    INT,
--    @CreatedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @MessageAttachmentID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    INSERT INTO comm.MessageAttachment
--    (
--        MessageID,
--        DocumentID,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @MessageID,
--        @DocumentID,
--        @CreatedByUserID
--    );
--
--    SET @MessageAttachmentID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'MessageAttachment',
--        @RecordPrimaryKeyValue = CAST(@MessageAttachmentID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (
--            SELECT ma.*
--            FROM comm.MessageAttachment ma
--            WHERE ma.MessageAttachmentID = @MessageAttachmentID
--            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--        );
--END;

GO


CREATE PROCEDURE comm.usp_AdminConversation_Close
    @ConversationID                INT,
    @ChangedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
    DECLARE @OldValuesJson NVARCHAR(MAX);

    SELECT @OldValuesJson = (
        SELECT c.*
        FROM comm.Conversation c
        WHERE c.ConversationID = @ConversationID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    UPDATE comm.Conversation
       SET IsArchived = 1,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ChangedByUserID
     WHERE ConversationID = @ConversationID
       AND ConversationTypeCode = N'ADMIN_OUTBOUND'
       AND IsDeleted = 0;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'comm',
        @TableName = N'Conversation',
        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = COALESCE(@ReasonText, N'Admin conversation closed.'),
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (
            SELECT c.*
            FROM comm.Conversation c
            WHERE c.ConversationID = @ConversationID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
END;
GO

--Syntax Error: Incorrect syntax near '@ConversationID'.
--
--CREATE PROCEDURE comm.usp_AdminConversation_Close
--    @ConversationID                INT,
--    @ChangedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--
--    SELECT @OldValuesJson = (
--        SELECT c.*
--        FROM comm.Conversation c
--        WHERE c.ConversationID = @ConversationID
--        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--    );
--
--    UPDATE comm.Conversation
--       SET IsArchived = 1,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ChangedByUserID
--     WHERE ConversationID = @ConversationID
--       AND ConversationTypeCode = N'ADMIN_OUTBOUND'
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'comm',
--        @TableName = N'Conversation',
--        @RecordPrimaryKeyValue = CAST(@ConversationID AS NVARCHAR(128)),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = COALESCE(@ReasonText, N'Admin conversation closed.'),
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (
--            SELECT c.*
--            FROM comm.Conversation c
--            WHERE c.ConversationID = @ConversationID
--            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--        );
--END;

GO


CREATE PROCEDURE party.usp_Address_Upsert
    @AddressID               INT = NULL,
    @CountryCode             NVARCHAR(10),
    @AddressLine1            NVARCHAR(200),
    @AddressLine2            NVARCHAR(200) = NULL,
    @City                    NVARCHAR(100),
    @StateProvinceCode       NVARCHAR(20),
    @PostalCode              NVARCHAR(20),
    @CountyName              NVARCHAR(100) = NULL,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @AddressID IS NULL
    BEGIN
        INSERT INTO party.Address
        (
            CountryCode,
            AddressLine1,
            AddressLine2,
            City,
            StateProvinceCode,
            PostalCode,
            CountyName,
            CreatedByUserID
        )
        VALUES
        (
            @CountryCode,
            @AddressLine1,
            @AddressLine2,
            @City,
            @StateProvinceCode,
            @PostalCode,
            @CountyName,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.Address a
        WHERE a.AddressID = @AddressID
          AND a.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50240, 'Address record not found or deleted.', 1;

        UPDATE party.Address
           SET CountryCode = @CountryCode,
               AddressLine1 = @AddressLine1,
               AddressLine2 = @AddressLine2,
               City = @City,
               StateProvinceCode = @StateProvinceCode,
               PostalCode = @PostalCode,
               CountyName = @CountyName,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE AddressID = @AddressID
           AND IsDeleted = 0;

        SET @RecordID = @AddressID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT a.* FROM party.Address a WHERE a.AddressID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128) = CAST(@RecordID AS NVARCHAR(128));
    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Address',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS AddressID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_Address_Upsert
--    @AddressID               INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @AddressLine1            NVARCHAR(200),
--    @AddressLine2            NVARCHAR(200) = NULL,
--    @City                    NVARCHAR(100),
--    @StateProvinceCode       NVARCHAR(20),
--    @PostalCode              NVARCHAR(20),
--    @CountyName              NVARCHAR(100) = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @AddressID IS NULL
--    BEGIN
--        INSERT INTO party.Address
--        (
--            CountryCode,
--            AddressLine1,
--            AddressLine2,
--            City,
--            StateProvinceCode,
--            PostalCode,
--            CountyName,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @CountryCode,
--            @AddressLine1,
--            @AddressLine2,
--            @City,
--            @StateProvinceCode,
--            @PostalCode,
--            @CountyName,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.Address a
--        WHERE a.AddressID = @AddressID
--          AND a.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50240, 'Address record not found or deleted.', 1;
--
--        UPDATE party.Address
--           SET CountryCode = @CountryCode,
--               AddressLine1 = @AddressLine1,
--               AddressLine2 = @AddressLine2,
--               City = @City,
--               StateProvinceCode = @StateProvinceCode,
--               PostalCode = @PostalCode,
--               CountyName = @CountyName,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE AddressID = @AddressID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @AddressID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Address a
--    WHERE a.AddressID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Address',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS AddressID;
--END;

GO


CREATE PROCEDURE party.usp_PhoneNumber_Upsert
    @PhoneNumberID           INT = NULL,
    @CountryCode             NVARCHAR(10),
    @PhoneNumber             NVARCHAR(30),
    @IsVoice                 BIT,
    @IsSms                   BIT,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @PhoneNumberID IS NULL
    BEGIN
        INSERT INTO party.PhoneNumber
        (
            CountryCode,
            PhoneNumber,
            IsVoice,
            IsSms,
            CreatedByUserID
        )
        VALUES
        (
            @CountryCode,
            @PhoneNumber,
            @IsVoice,
            @IsSms,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.PhoneNumber p
        WHERE p.PhoneNumberID = @PhoneNumberID
          AND p.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50241, 'Phone number record not found or deleted.', 1;

        UPDATE party.PhoneNumber
           SET CountryCode = @CountryCode,
               PhoneNumber = @PhoneNumber,
               IsVoice = @IsVoice,
               IsSms = @IsSms,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PhoneNumberID = @PhoneNumberID
           AND IsDeleted = 0;

        SET @RecordID = @PhoneNumberID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.PhoneNumber p
    WHERE p.PhoneNumberID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PhoneNumber',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS PhoneNumberID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_PhoneNumber_Upsert
--    @PhoneNumberID           INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @PhoneNumber             NVARCHAR(30),
--    @IsVoice                 BIT,
--    @IsSms                   BIT,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @PhoneNumberID IS NULL
--    BEGIN
--        INSERT INTO party.PhoneNumber
--        (
--            CountryCode,
--            PhoneNumber,
--            IsVoice,
--            IsSms,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @CountryCode,
--            @PhoneNumber,
--            @IsVoice,
--            @IsSms,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.PhoneNumber p
--        WHERE p.PhoneNumberID = @PhoneNumberID
--          AND p.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50241, 'Phone number record not found or deleted.', 1;
--
--        UPDATE party.PhoneNumber
--           SET CountryCode = @CountryCode,
--               PhoneNumber = @PhoneNumber,
--               IsVoice = @IsVoice,
--               IsSms = @IsSms,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE PhoneNumberID = @PhoneNumberID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @PhoneNumberID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.PhoneNumber p
--    WHERE p.PhoneNumberID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'PhoneNumber',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS PhoneNumberID;
--END;

GO


CREATE PROCEDURE party.usp_Person_Upsert
    @PersonID                INT = NULL,
    @FirstName               NVARCHAR(100),
    @MiddleName              NVARCHAR(100) = NULL,
    @LastName                NVARCHAR(100),
    @DateOfBirth             DATE = NULL,
    @PrimaryEmail            NVARCHAR(320) = NULL,
    @PrimaryPhoneNumberID    INT = NULL,
    @PrimaryAddressID        INT = NULL,
    @Notes                   NVARCHAR(MAX) = NULL,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @PersonID IS NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName,
            MiddleName,
            LastName,
            DateOfBirth,
            PrimaryEmail,
            PrimaryPhoneNumberID,
            PrimaryAddressID,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @FirstName,
            @MiddleName,
            @LastName,
            @DateOfBirth,
            @PrimaryEmail,
            @PrimaryPhoneNumberID,
            @PrimaryAddressID,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.Person p
        WHERE p.PersonID = @PersonID
          AND p.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50242, 'Person record not found or deleted.', 1;

        UPDATE party.Person
           SET FirstName = @FirstName,
               MiddleName = @MiddleName,
               LastName = @LastName,
               DateOfBirth = @DateOfBirth,
               PrimaryEmail = @PrimaryEmail,
               PrimaryPhoneNumberID = @PrimaryPhoneNumberID,
               PrimaryAddressID = @PrimaryAddressID,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PersonID = @PersonID
           AND IsDeleted = 0;

        SET @RecordID = @PersonID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Person p
    WHERE p.PersonID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Person',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS PersonID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_Person_Upsert
--    @PersonID                INT = NULL,
--    @FirstName               NVARCHAR(100),
--    @MiddleName              NVARCHAR(100) = NULL,
--    @LastName                NVARCHAR(100),
--    @DateOfBirth             DATE = NULL,
--    @PrimaryEmail            NVARCHAR(320) = NULL,
--    @PrimaryPhoneNumberID    INT = NULL,
--    @PrimaryAddressID        INT = NULL,
--    @Notes                   NVARCHAR(MAX) = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @PersonID IS NULL
--    BEGIN
--        INSERT INTO party.Person
--        (
--            FirstName,
--            MiddleName,
--            LastName,
--            DateOfBirth,
--            PrimaryEmail,
--            PrimaryPhoneNumberID,
--            PrimaryAddressID,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @FirstName,
--            @MiddleName,
--            @LastName,
--            @DateOfBirth,
--            @PrimaryEmail,
--            @PrimaryPhoneNumberID,
--            @PrimaryAddressID,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.Person p
--        WHERE p.PersonID = @PersonID
--          AND p.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50242, 'Person record not found or deleted.', 1;
--
--        UPDATE party.Person
--           SET FirstName = @FirstName,
--               MiddleName = @MiddleName,
--               LastName = @LastName,
--               DateOfBirth = @DateOfBirth,
--               PrimaryEmail = @PrimaryEmail,
--               PrimaryPhoneNumberID = @PrimaryPhoneNumberID,
--               PrimaryAddressID = @PrimaryAddressID,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE PersonID = @PersonID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @PersonID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Person p
--    WHERE p.PersonID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Person',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS PersonID;
--END;

GO


CREATE PROCEDURE party.usp_Provider_Upsert
    @ProviderID              INT = NULL,
    @ProviderName            NVARCHAR(200),
    @LegalEntityName         NVARCHAR(200),
    @LicenseHolderPersonID   INT = NULL,
    @BusinessEmail           NVARCHAR(320) = NULL,
    @BusinessPhoneNumberID   INT = NULL,
    @BusinessAddressID       INT = NULL,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @ProviderID IS NULL
    BEGIN
        INSERT INTO party.Provider
        (
            ProviderName,
            LegalEntityName,
            LicenseHolderPersonID,
            BusinessEmail,
            BusinessPhoneNumberID,
            BusinessAddressID,
            CreatedByUserID
        )
        VALUES
        (
            @ProviderName,
            @LegalEntityName,
            @LicenseHolderPersonID,
            @BusinessEmail,
            @BusinessPhoneNumberID,
            @BusinessAddressID,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.Provider p
        WHERE p.ProviderID = @ProviderID
          AND p.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50243, 'Provider record not found or deleted.', 1;

        UPDATE party.Provider
           SET ProviderName = @ProviderName,
               LegalEntityName = @LegalEntityName,
               LicenseHolderPersonID = @LicenseHolderPersonID,
               BusinessEmail = @BusinessEmail,
               BusinessPhoneNumberID = @BusinessPhoneNumberID,
               BusinessAddressID = @BusinessAddressID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ProviderID = @ProviderID
           AND IsDeleted = 0;

        SET @RecordID = @ProviderID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Provider p
    WHERE p.ProviderID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Provider',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS ProviderID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_Provider_Upsert
--    @ProviderID              INT = NULL,
--    @ProviderName            NVARCHAR(200),
--    @LegalEntityName         NVARCHAR(200),
--    @LicenseHolderPersonID   INT = NULL,
--    @BusinessEmail           NVARCHAR(320) = NULL,
--    @BusinessPhoneNumberID   INT = NULL,
--    @BusinessAddressID       INT = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @ProviderID IS NULL
--    BEGIN
--        INSERT INTO party.Provider
--        (
--            ProviderName,
--            LegalEntityName,
--            LicenseHolderPersonID,
--            BusinessEmail,
--            BusinessPhoneNumberID,
--            BusinessAddressID,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ProviderName,
--            @LegalEntityName,
--            @LicenseHolderPersonID,
--            @BusinessEmail,
--            @BusinessPhoneNumberID,
--            @BusinessAddressID,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.Provider p
--        WHERE p.ProviderID = @ProviderID
--          AND p.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50243, 'Provider record not found or deleted.', 1;
--
--        UPDATE party.Provider
--           SET ProviderName = @ProviderName,
--               LegalEntityName = @LegalEntityName,
--               LicenseHolderPersonID = @LicenseHolderPersonID,
--               BusinessEmail = @BusinessEmail,
--               BusinessPhoneNumberID = @BusinessPhoneNumberID,
--               BusinessAddressID = @BusinessAddressID,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ProviderID = @ProviderID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @ProviderID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Provider p
--    WHERE p.ProviderID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Provider',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS ProviderID;
--END;

GO


CREATE PROCEDURE party.usp_Site_Upsert
    @SiteID                  INT = NULL,
    @ProviderID              INT,
    @SiteName                NVARCHAR(200),
    @LicenseNumber           NVARCHAR(100) = NULL,
    @LicenseClassID          INT,
    @TimeZoneID              INT,
    @SiteAddressID           INT = NULL,
    @SiteEmail               NVARCHAR(320) = NULL,
    @SitePhoneNumberID       INT = NULL,
    @EmergencyPhoneNumberID  INT = NULL,
    @LiabilityInsuranceStatusCode NVARCHAR(50) = NULL,
    @WorkersCompStatusCode   NVARCHAR(50) = NULL,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @SiteID IS NULL
    BEGIN
        INSERT INTO party.Site
        (
            ProviderID,
            SiteName,
            LicenseNumber,
            LicenseClassID,
            TimeZoneID,
            SiteAddressID,
            SiteEmail,
            SitePhoneNumberID,
            EmergencyPhoneNumberID,
            LiabilityInsuranceStatusCode,
            WorkersCompStatusCode,
            CreatedByUserID
        )
        VALUES
        (
            @ProviderID,
            @SiteName,
            @LicenseNumber,
            @LicenseClassID,
            @TimeZoneID,
            @SiteAddressID,
            @SiteEmail,
            @SitePhoneNumberID,
            @EmergencyPhoneNumberID,
            @LiabilityInsuranceStatusCode,
            @WorkersCompStatusCode,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT s.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.Site s
        WHERE s.SiteID = @SiteID
          AND s.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50244, 'Site record not found or deleted.', 1;

        UPDATE party.Site
           SET ProviderID = @ProviderID,
               SiteName = @SiteName,
               LicenseNumber = @LicenseNumber,
               LicenseClassID = @LicenseClassID,
               TimeZoneID = @TimeZoneID,
               SiteAddressID = @SiteAddressID,
               SiteEmail = @SiteEmail,
               SitePhoneNumberID = @SitePhoneNumberID,
               EmergencyPhoneNumberID = @EmergencyPhoneNumberID,
               LiabilityInsuranceStatusCode = @LiabilityInsuranceStatusCode,
               WorkersCompStatusCode = @WorkersCompStatusCode,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE SiteID = @SiteID
           AND IsDeleted = 0;

        SET @RecordID = @SiteID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT s.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Site s
    WHERE s.SiteID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Site',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @RecordID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS SiteID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_Site_Upsert
--    @SiteID                  INT = NULL,
--    @ProviderID              INT,
--    @SiteName                NVARCHAR(200),
--    @LicenseNumber           NVARCHAR(100) = NULL,
--    @LicenseClassID          INT,
--    @TimeZoneID              INT,
--    @SiteAddressID           INT = NULL,
--    @SiteEmail               NVARCHAR(320) = NULL,
--    @SitePhoneNumberID       INT = NULL,
--    @EmergencyPhoneNumberID  INT = NULL,
--    @LiabilityInsuranceStatusCode NVARCHAR(50) = NULL,
--    @WorkersCompStatusCode   NVARCHAR(50) = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @SiteID IS NULL
--    BEGIN
--        INSERT INTO party.Site
--        (
--            ProviderID,
--            SiteName,
--            LicenseNumber,
--            LicenseClassID,
--            TimeZoneID,
--            SiteAddressID,
--            SiteEmail,
--            SitePhoneNumberID,
--            EmergencyPhoneNumberID,
--            LiabilityInsuranceStatusCode,
--            WorkersCompStatusCode,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ProviderID,
--            @SiteName,
--            @LicenseNumber,
--            @LicenseClassID,
--            @TimeZoneID,
--            @SiteAddressID,
--            @SiteEmail,
--            @SitePhoneNumberID,
--            @EmergencyPhoneNumberID,
--            @LiabilityInsuranceStatusCode,
--            @WorkersCompStatusCode,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT s.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.Site s
--        WHERE s.SiteID = @SiteID
--          AND s.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50244, 'Site record not found or deleted.', 1;
--
--        UPDATE party.Site
--           SET ProviderID = @ProviderID,
--               SiteName = @SiteName,
--               LicenseNumber = @LicenseNumber,
--               LicenseClassID = @LicenseClassID,
--               TimeZoneID = @TimeZoneID,
--               SiteAddressID = @SiteAddressID,
--               SiteEmail = @SiteEmail,
--               SitePhoneNumberID = @SitePhoneNumberID,
--               EmergencyPhoneNumberID = @EmergencyPhoneNumberID,
--               LiabilityInsuranceStatusCode = @LiabilityInsuranceStatusCode,
--               WorkersCompStatusCode = @WorkersCompStatusCode,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE SiteID = @SiteID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @SiteID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT s.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Site s
--    WHERE s.SiteID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Site',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @RecordID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS SiteID;
--END;

GO


CREATE PROCEDURE party.usp_PortalUser_Upsert
    @PortalUserID             INT = NULL,
    @PersonID                 INT,
    @UserName                 NVARCHAR(320),
    @NormalizedUserName       NVARCHAR(320),
    @AccountStatusCode        NVARCHAR(50),
    @MFAEnabled               BIT,
    @ChangedByUserID          INT = NULL,
    @ReasonText               NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @PortalUserID IS NULL
    BEGIN
        INSERT INTO party.PortalUser
        (
            PersonID,
            UserName,
            NormalizedUserName,
            AccountStatusCode,
            MFAEnabled,
            CreatedByUserID
        )
        VALUES
        (
            @PersonID,
            @UserName,
            @NormalizedUserName,
            @AccountStatusCode,
            @MFAEnabled,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT pu.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50245, 'Portal user record not found or deleted.', 1;

        UPDATE party.PortalUser
           SET PersonID = @PersonID,
               UserName = @UserName,
               NormalizedUserName = @NormalizedUserName,
               AccountStatusCode = @AccountStatusCode,
               MFAEnabled = @MFAEnabled,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PortalUserID = @PortalUserID
           AND IsDeleted = 0;

        SET @RecordID = @PortalUserID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT pu.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.PortalUser pu
    WHERE pu.PortalUserID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS PortalUserID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_PortalUser_Upsert
--    @PortalUserID             INT = NULL,
--    @PersonID                 INT,
--    @UserName                 NVARCHAR(320),
--    @NormalizedUserName       NVARCHAR(320),
--    @AccountStatusCode        NVARCHAR(50),
--    @MFAEnabled               BIT,
--    @ChangedByUserID          INT = NULL,
--    @ReasonText               NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @PortalUserID IS NULL
--    BEGIN
--        INSERT INTO party.PortalUser
--        (
--            PersonID,
--            UserName,
--            NormalizedUserName,
--            AccountStatusCode,
--            MFAEnabled,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @PersonID,
--            @UserName,
--            @NormalizedUserName,
--            @AccountStatusCode,
--            @MFAEnabled,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT pu.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.PortalUser pu
--        WHERE pu.PortalUserID = @PortalUserID
--          AND pu.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50245, 'Portal user record not found or deleted.', 1;
--
--        UPDATE party.PortalUser
--           SET PersonID = @PersonID,
--               UserName = @UserName,
--               NormalizedUserName = @NormalizedUserName,
--               AccountStatusCode = @AccountStatusCode,
--               MFAEnabled = @MFAEnabled,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE PortalUserID = @PortalUserID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @PortalUserID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT pu.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.PortalUser pu
--    WHERE pu.PortalUserID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'PortalUser',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS PortalUserID;
--END;

GO


CREATE PROCEDURE party.usp_SiteUserAssignment_Upsert
    @SiteUserAssignmentID      INT = NULL,
    @SiteID                    INT,
    @PortalUserID              INT,
    @AssignmentTypeCode        NVARCHAR(50),
    @IsPrimaryProviderContact  BIT,
    @EffectiveStartUTC         DATETIME2(0),
    @EffectiveEndUTC           DATETIME2(0) = NULL,
    @ChangedByUserID           INT = NULL,
    @ReasonText                NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @SiteUserAssignmentID IS NULL
    BEGIN
        INSERT INTO party.SiteUserAssignment
        (
            SiteID,
            PortalUserID,
            AssignmentTypeCode,
            IsPrimaryProviderContact,
            EffectiveStartUTC,
            EffectiveEndUTC,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @PortalUserID,
            @AssignmentTypeCode,
            @IsPrimaryProviderContact,
            @EffectiveStartUTC,
            @EffectiveEndUTC,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT sua.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.SiteUserAssignment sua
        WHERE sua.SiteUserAssignmentID = @SiteUserAssignmentID;

        IF @OldValuesJson IS NULL
            THROW 50246, 'Site user assignment record not found.', 1;

        UPDATE party.SiteUserAssignment
           SET SiteID = @SiteID,
               PortalUserID = @PortalUserID,
               AssignmentTypeCode = @AssignmentTypeCode,
               IsPrimaryProviderContact = @IsPrimaryProviderContact,
               EffectiveStartUTC = @EffectiveStartUTC,
               EffectiveEndUTC = @EffectiveEndUTC,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE SiteUserAssignmentID = @SiteUserAssignmentID;

        SET @RecordID = @SiteUserAssignmentID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT sua.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.SiteUserAssignment sua
    WHERE sua.SiteUserAssignmentID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'SiteUserAssignment',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS SiteUserAssignmentID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_SiteUserAssignment_Upsert
--    @SiteUserAssignmentID      INT = NULL,
--    @SiteID                    INT,
--    @PortalUserID              INT,
--    @AssignmentTypeCode        NVARCHAR(50),
--    @IsPrimaryProviderContact  BIT,
--    @EffectiveStartUTC         DATETIME2(0),
--    @EffectiveEndUTC           DATETIME2(0) = NULL,
--    @ChangedByUserID           INT = NULL,
--    @ReasonText                NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @SiteUserAssignmentID IS NULL
--    BEGIN
--        INSERT INTO party.SiteUserAssignment
--        (
--            SiteID,
--            PortalUserID,
--            AssignmentTypeCode,
--            IsPrimaryProviderContact,
--            EffectiveStartUTC,
--            EffectiveEndUTC,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @PortalUserID,
--            @AssignmentTypeCode,
--            @IsPrimaryProviderContact,
--            @EffectiveStartUTC,
--            @EffectiveEndUTC,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT sua.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.SiteUserAssignment sua
--        WHERE sua.SiteUserAssignmentID = @SiteUserAssignmentID;
--
--        IF @OldValuesJson IS NULL
--            THROW 50246, 'Site user assignment record not found.', 1;
--
--        UPDATE party.SiteUserAssignment
--           SET SiteID = @SiteID,
--               PortalUserID = @PortalUserID,
--               AssignmentTypeCode = @AssignmentTypeCode,
--               IsPrimaryProviderContact = @IsPrimaryProviderContact,
--               EffectiveStartUTC = @EffectiveStartUTC,
--               EffectiveEndUTC = @EffectiveEndUTC,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE SiteUserAssignmentID = @SiteUserAssignmentID;
--
--        SET @RecordID = @SiteUserAssignmentID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT sua.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.SiteUserAssignment sua
--    WHERE sua.SiteUserAssignmentID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'SiteUserAssignment',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS SiteUserAssignmentID;
--END;

GO


CREATE PROCEDURE party.usp_LicensorAssignment_Upsert
    @LicensorAssignmentID      INT = NULL,
    @SiteID                    INT,
    @PortalUserID              INT,
    @AssignmentTypeCode        NVARCHAR(50),
    @EffectiveStartUTC         DATETIME2(0),
    @EffectiveEndUTC           DATETIME2(0) = NULL,
    @ChangedByUserID           INT = NULL,
    @ReasonText                NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @LicensorAssignmentID IS NULL
    BEGIN
        INSERT INTO party.LicensorAssignment
        (
            SiteID,
            PortalUserID,
            AssignmentTypeCode,
            EffectiveStartUTC,
            EffectiveEndUTC,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @PortalUserID,
            @AssignmentTypeCode,
            @EffectiveStartUTC,
            @EffectiveEndUTC,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT la.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.LicensorAssignment la
        WHERE la.LicensorAssignmentID = @LicensorAssignmentID;

        IF @OldValuesJson IS NULL
            THROW 50247, 'Licensor assignment record not found.', 1;

        UPDATE party.LicensorAssignment
           SET SiteID = @SiteID,
               PortalUserID = @PortalUserID,
               AssignmentTypeCode = @AssignmentTypeCode,
               EffectiveStartUTC = @EffectiveStartUTC,
               EffectiveEndUTC = @EffectiveEndUTC,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE LicensorAssignmentID = @LicensorAssignmentID;

        SET @RecordID = @LicensorAssignmentID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT la.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.LicensorAssignment la
    WHERE la.LicensorAssignmentID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'LicensorAssignment',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS LicensorAssignmentID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_LicensorAssignment_Upsert
--    @LicensorAssignmentID      INT = NULL,
--    @SiteID                    INT,
--    @PortalUserID              INT,
--    @AssignmentTypeCode        NVARCHAR(50),
--    @EffectiveStartUTC         DATETIME2(0),
--    @EffectiveEndUTC           DATETIME2(0) = NULL,
--    @ChangedByUserID           INT = NULL,
--    @ReasonText                NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @LicensorAssignmentID IS NULL
--    BEGIN
--        INSERT INTO party.LicensorAssignment
--        (
--            SiteID,
--            PortalUserID,
--            AssignmentTypeCode,
--            EffectiveStartUTC,
--            EffectiveEndUTC,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @PortalUserID,
--            @AssignmentTypeCode,
--            @EffectiveStartUTC,
--            @EffectiveEndUTC,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT la.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.LicensorAssignment la
--        WHERE la.LicensorAssignmentID = @LicensorAssignmentID;
--
--        IF @OldValuesJson IS NULL
--            THROW 50247, 'Licensor assignment record not found.', 1;
--
--        UPDATE party.LicensorAssignment
--           SET SiteID = @SiteID,
--               PortalUserID = @PortalUserID,
--               AssignmentTypeCode = @AssignmentTypeCode,
--               EffectiveStartUTC = @EffectiveStartUTC,
--               EffectiveEndUTC = @EffectiveEndUTC,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE LicensorAssignmentID = @LicensorAssignmentID;
--
--        SET @RecordID = @LicensorAssignmentID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT la.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.LicensorAssignment la
--    WHERE la.LicensorAssignmentID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'LicensorAssignment',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS LicensorAssignmentID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_MedicalProvider_Upsert
--    @MedicalProviderID          INT = NULL,
--    @MedicalProviderTypeID      INT,
--    @ProviderName               NVARCHAR(200),
--    @PhoneNumberID              INT = NULL,
--    @AddressID                  INT = NULL,
--    @EmailAddress               NVARCHAR(320) = NULL,
--    @Notes                      NVARCHAR(MAX) = NULL,
--    @ChangedByUserID            INT = NULL,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @RecordID INT, @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    IF @MedicalProviderID IS NULL
--    BEGIN
--        INSERT INTO party.MedicalProvider (MedicalProviderTypeID, ProviderName, PhoneNumberID, AddressID, EmailAddress, Notes, CreatedByUserID)
--        VALUES (@MedicalProviderTypeID, @ProviderName, @PhoneNumberID, @AddressID, @EmailAddress, @Notes, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT mp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.MedicalProvider mp WHERE mp.MedicalProviderID=@MedicalProviderID AND mp.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 52001, 'Medical provider record not found or deleted.', 1;
--        UPDATE party.MedicalProvider
--           SET MedicalProviderTypeID=@MedicalProviderTypeID, ProviderName=@ProviderName, PhoneNumberID=@PhoneNumberID, AddressID=@AddressID,
--               EmailAddress=@EmailAddress, Notes=@Notes, ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE MedicalProviderID=@MedicalProviderID AND IsDeleted=0;
--        SET @RecordID=@MedicalProviderID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT mp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.MedicalProvider mp WHERE mp.MedicalProviderID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'MedicalProvider', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS MedicalProviderID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_Hospital_Upsert
--    @HospitalID                 INT = NULL,
--    @HospitalName               NVARCHAR(200),
--    @MainPhoneNumberID          INT = NULL,
--    @AddressID                  INT = NULL,
--    @Notes                      NVARCHAR(MAX) = NULL,
--    @ChangedByUserID            INT = NULL,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @RecordID INT, @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    IF @HospitalID IS NULL
--    BEGIN
--        INSERT INTO party.Hospital (HospitalName, MainPhoneNumberID, AddressID, Notes, CreatedByUserID)
--        VALUES (@HospitalName, @MainPhoneNumberID, @AddressID, @Notes, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT h.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Hospital h WHERE h.HospitalID=@HospitalID AND h.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 52002, 'Hospital record not found or deleted.', 1;
--        UPDATE party.Hospital
--           SET HospitalName=@HospitalName, MainPhoneNumberID=@MainPhoneNumberID, AddressID=@AddressID, Notes=@Notes,
--               ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE HospitalID=@HospitalID AND IsDeleted=0;
--        SET @RecordID=@HospitalID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT h.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Hospital h WHERE h.HospitalID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'Hospital', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS HospitalID;
--END;

GO


CREATE PROCEDURE doc.usp_ConsentRecord_Upsert
    @ConsentRecordID            INT = NULL,
    @ChildID                    INT,
    @ConsentTypeCode            NVARCHAR(50),
    @SignedByPersonID           INT = NULL,
    @SignedUTC                  DATETIME2(0) = NULL,
    @EffectiveDate              DATE,
    @ExpirationDate             DATE = NULL,
    @DocumentID                 INT = NULL,
    @Notes                      NVARCHAR(MAX) = NULL,
    @ChangedByUserID            INT,
    @ReasonText                 NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @SiteID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = c.SiteID
    FROM child.Child c
    WHERE c.ChildID = @ChildID
      AND c.IsDeleted = 0;

    IF @SiteID IS NULL
    BEGIN
        THROW 50250, 'Child record not found or deleted.', 1;
    END;

    IF @ConsentRecordID IS NULL
    BEGIN
        INSERT INTO doc.ConsentRecord
        (
            ChildID,
            ConsentTypeCode,
            SignedByPersonID,
            SignedUTC,
            EffectiveDate,
            ExpirationDate,
            DocumentID,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @ConsentTypeCode,
            @SignedByPersonID,
            @SignedUTC,
            @EffectiveDate,
            @ExpirationDate,
            @DocumentID,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM doc.ConsentRecord cr
        WHERE cr.ConsentRecordID = @ConsentRecordID
          AND cr.IsDeleted = 0;

        IF @OldValuesJson IS NULL
        BEGIN
            THROW 50251, 'Consent record not found or deleted.', 1;
        END;

        UPDATE doc.ConsentRecord
           SET ChildID = @ChildID,
               ConsentTypeCode = @ConsentTypeCode,
               SignedByPersonID = @SignedByPersonID,
               SignedUTC = @SignedUTC,
               EffectiveDate = @EffectiveDate,
               ExpirationDate = @ExpirationDate,
               DocumentID = @DocumentID,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ConsentRecordID = @ConsentRecordID
           AND IsDeleted = 0;

        SET @RecordID = @ConsentRecordID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM doc.ConsentRecord cr
    WHERE cr.ConsentRecordID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'doc',
        @TableName = N'ConsentRecord',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS ConsentRecordID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE doc.usp_ConsentRecord_Upsert
--    @ConsentRecordID            INT = NULL,
--    @ChildID                    INT,
--    @ConsentTypeCode            NVARCHAR(50),
--    @SignedByPersonID           INT = NULL,
--    @SignedUTC                  DATETIME2(0) = NULL,
--    @EffectiveDate              DATE,
--    @ExpirationDate             DATE = NULL,
--    @DocumentID                 INT = NULL,
--    @Notes                      NVARCHAR(MAX) = NULL,
--    @ChangedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @SiteID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = c.SiteID
--    FROM child.Child c
--    WHERE c.ChildID = @ChildID
--      AND c.IsDeleted = 0;
--
--    IF @SiteID IS NULL
--    BEGIN
--        THROW 50250, 'Child record not found or deleted.', 1;
--    END;
--
--    IF @ConsentRecordID IS NULL
--    BEGIN
--        INSERT INTO doc.ConsentRecord
--        (
--            ChildID,
--            ConsentTypeCode,
--            SignedByPersonID,
--            SignedUTC,
--            EffectiveDate,
--            ExpirationDate,
--            DocumentID,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ChildID,
--            @ConsentTypeCode,
--            @SignedByPersonID,
--            @SignedUTC,
--            @EffectiveDate,
--            @ExpirationDate,
--            @DocumentID,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM doc.ConsentRecord cr
--        WHERE cr.ConsentRecordID = @ConsentRecordID
--          AND cr.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--        BEGIN
--            THROW 50251, 'Consent record not found or deleted.', 1;
--        END;
--
--        UPDATE doc.ConsentRecord
--           SET ChildID = @ChildID,
--               ConsentTypeCode = @ConsentTypeCode,
--               SignedByPersonID = @SignedByPersonID,
--               SignedUTC = @SignedUTC,
--               EffectiveDate = @EffectiveDate,
--               ExpirationDate = @ExpirationDate,
--               DocumentID = @DocumentID,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ConsentRecordID = @ConsentRecordID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @ConsentRecordID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM doc.ConsentRecord cr
--    WHERE cr.ConsentRecordID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'doc',
--        @TableName = N'ConsentRecord',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS ConsentRecordID;
--END;

GO


CREATE PROCEDURE doc.usp_Document_SoftDelete
    @DocumentID                 INT,
    @DeletedByUserID            INT,
    @DeletedReason              NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @OldValuesJson = (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM doc.Document d
    WHERE d.DocumentID = @DocumentID
      AND d.IsDeleted = 0;

    IF @OldValuesJson IS NULL
    BEGIN
        THROW 50252, 'Document record not found or already deleted.', 1;
    END;

    UPDATE doc.Document
       SET IsActive = 0,
           IsDeleted = 1,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE DocumentID = @DocumentID
       AND IsDeleted = 0;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'doc',
        @TableName = N'Document',
        @RecordPrimaryKeyValue = CAST(@DocumentID AS NVARCHAR(128)),
        @ActionTypeCode = N'SOFT_DELETE',
        @ChangedByUserID = @DeletedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @DeletedReason,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM doc.Document d
    WHERE d.DocumentID = @DocumentID;

    SELECT @DocumentID AS DocumentID;
END;
GO

--Syntax Error: Incorrect syntax near '@DocumentID'.
--
--CREATE PROCEDURE doc.usp_Document_SoftDelete
--    @DocumentID                 INT,
--    @DeletedByUserID            INT,
--    @DeletedReason              NVARCHAR(500)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @OldValuesJson = (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM doc.Document d
--    WHERE d.DocumentID = @DocumentID
--      AND d.IsDeleted = 0;
--
--    IF @OldValuesJson IS NULL
--    BEGIN
--        THROW 50252, 'Document record not found or already deleted.', 1;
--    END;
--
--    UPDATE doc.Document
--       SET IsActive = 0,
--           IsDeleted = 1,
--           DeletedUTC = SYSUTCDATETIME(),
--           DeletedByUserID = @DeletedByUserID,
--           DeletedReason = @DeletedReason,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @DeletedByUserID
--     WHERE DocumentID = @DocumentID
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'doc',
--        @TableName = N'Document',
--        @RecordPrimaryKeyValue = CAST(@DocumentID AS NVARCHAR(128)),
--        @ActionTypeCode = N'SOFT_DELETE',
--        @ChangedByUserID = @DeletedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @DeletedReason,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM doc.Document d
--    WHERE d.DocumentID = @DocumentID;
--
--    SELECT @DocumentID AS DocumentID;
--END;

GO


CREATE PROCEDURE doc.usp_EntityDocument_Link
    @DocumentID                 INT,
    @EntitySchemaName           NVARCHAR(128),
    @EntityTableName            NVARCHAR(128),
    @EntityPrimaryKeyValue      NVARCHAR(128),
    @EntityNotes                NVARCHAR(MAX) = NULL,
    @CreatedByUserID            INT,
    @ReasonText                 NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @EntityDocumentID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    INSERT INTO doc.EntityDocument
    (
        DocumentID,
        EntitySchemaName,
        EntityTableName,
        EntityPrimaryKeyValue,
        Notes,
        CreatedByUserID
    )
    VALUES
    (
        @DocumentID,
        @EntitySchemaName,
        @EntityTableName,
        @EntityPrimaryKeyValue,
        @EntityNotes,
        @CreatedByUserID
    );

    SET @EntityDocumentID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'doc',
        @TableName = N'EntityDocument',
        @RecordPrimaryKeyValue = CAST(@EntityDocumentID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = (SELECT ed.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM doc.EntityDocument ed
    WHERE ed.EntityDocumentID = @EntityDocumentID;

    SELECT @EntityDocumentID AS EntityDocumentID;
END;
GO

--Syntax Error: Incorrect syntax near '@EntityDocumentID'.
--
--CREATE PROCEDURE doc.usp_EntityDocument_Link
--    @DocumentID                 INT,
--    @EntitySchemaName           NVARCHAR(128),
--    @EntityTableName            NVARCHAR(128),
--    @EntityPrimaryKeyValue      NVARCHAR(128),
--    @EntityNotes                NVARCHAR(MAX) = NULL,
--    @CreatedByUserID            INT,
--    @ReasonText                 NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @EntityDocumentID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    INSERT INTO doc.EntityDocument
--    (
--        DocumentID,
--        EntitySchemaName,
--        EntityTableName,
--        EntityPrimaryKeyValue,
--        Notes,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @DocumentID,
--        @EntitySchemaName,
--        @EntityTableName,
--        @EntityPrimaryKeyValue,
--        @EntityNotes,
--        @CreatedByUserID
--    );
--
--    SET @EntityDocumentID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'doc',
--        @TableName = N'EntityDocument',
--        @RecordPrimaryKeyValue = CAST(@EntityDocumentID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @NewValuesJson = (SELECT ed.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM doc.EntityDocument ed
--    WHERE ed.EntityDocumentID = @EntityDocumentID;
--
--    SELECT @EntityDocumentID AS EntityDocumentID;
--END;

GO


CREATE PROCEDURE child.usp_GuardianEmailIdentity_Upsert
    @GuardianEmailIdentityID       INT                = NULL,
    @ChildPersonRelationshipID     INT,
    @EmailAddress                  NVARCHAR(320),
    @NormalizedEmailAddress        NVARCHAR(320),
    @EmailVerifiedUTC              DATETIME2(0)       = NULL,
    @VerifiedByInvitationID        INT                = NULL,
    @IdentityStatusCode            NVARCHAR(50),
    @IsPrimaryEmail                BIT,
    @ChangedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RecordID INT;
    DECLARE @ChildID INT;
    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT
        @ChildID = cpr.ChildID,
        @SiteID = c.SiteID
    FROM child.ChildPersonRelationship cpr
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
    WHERE cpr.ChildPersonRelationshipID = @ChildPersonRelationshipID
      AND cpr.IsDeleted = 0
      AND c.IsDeleted = 0;

    IF @ChildID IS NULL
    BEGIN
        THROW 50270, 'Child/guardian relationship not found or deleted.', 1;
    END;

    IF @GuardianEmailIdentityID IS NULL
    BEGIN
        INSERT INTO child.GuardianEmailIdentity
        (
            ChildPersonRelationshipID,
            EmailAddress,
            NormalizedEmailAddress,
            EmailVerifiedUTC,
            VerifiedByInvitationID,
            IdentityStatusCode,
            IsPrimaryEmail,
            CreatedByUserID
        )
        VALUES
        (
            @ChildPersonRelationshipID,
            @EmailAddress,
            @NormalizedEmailAddress,
            @EmailVerifiedUTC,
            @VerifiedByInvitationID,
            @IdentityStatusCode,
            @IsPrimaryEmail,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT gei.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM child.GuardianEmailIdentity gei
        WHERE gei.GuardianEmailIdentityID = @GuardianEmailIdentityID
          AND gei.IsDeleted = 0;

        IF @OldValuesJson IS NULL
        BEGIN
            THROW 50271, 'Guardian email identity record not found or deleted.', 1;
        END;

        UPDATE child.GuardianEmailIdentity
           SET ChildPersonRelationshipID = @ChildPersonRelationshipID,
               EmailAddress = @EmailAddress,
               NormalizedEmailAddress = @NormalizedEmailAddress,
               EmailVerifiedUTC = @EmailVerifiedUTC,
               VerifiedByInvitationID = @VerifiedByInvitationID,
               IdentityStatusCode = @IdentityStatusCode,
               IsPrimaryEmail = @IsPrimaryEmail,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE GuardianEmailIdentityID = @GuardianEmailIdentityID
           AND IsDeleted = 0;

        SET @RecordID = @GuardianEmailIdentityID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT gei.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM child.GuardianEmailIdentity gei
    WHERE gei.GuardianEmailIdentityID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'GuardianEmailIdentity',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS GuardianEmailIdentityID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE child.usp_GuardianEmailIdentity_Upsert
--    @GuardianEmailIdentityID       INT                = NULL,
--    @ChildPersonRelationshipID     INT,
--    @EmailAddress                  NVARCHAR(320),
--    @NormalizedEmailAddress        NVARCHAR(320),
--    @EmailVerifiedUTC              DATETIME2(0)       = NULL,
--    @VerifiedByInvitationID        INT                = NULL,
--    @IdentityStatusCode            NVARCHAR(50),
--    @IsPrimaryEmail                BIT,
--    @ChangedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @RecordID INT;
--    DECLARE @ChildID INT;
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT
--        @ChildID = cpr.ChildID,
--        @SiteID = c.SiteID
--    FROM child.ChildPersonRelationship cpr
--    INNER JOIN child.Child c
--        ON c.ChildID = cpr.ChildID
--    WHERE cpr.ChildPersonRelationshipID = @ChildPersonRelationshipID
--      AND cpr.IsDeleted = 0
--      AND c.IsDeleted = 0;
--
--    IF @ChildID IS NULL
--    BEGIN
--        THROW 50270, 'Child/guardian relationship not found or deleted.', 1;
--    END;
--
--    IF @GuardianEmailIdentityID IS NULL
--    BEGIN
--        INSERT INTO child.GuardianEmailIdentity
--        (
--            ChildPersonRelationshipID,
--            EmailAddress,
--            NormalizedEmailAddress,
--            EmailVerifiedUTC,
--            VerifiedByInvitationID,
--            IdentityStatusCode,
--            IsPrimaryEmail,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ChildPersonRelationshipID,
--            @EmailAddress,
--            @NormalizedEmailAddress,
--            @EmailVerifiedUTC,
--            @VerifiedByInvitationID,
--            @IdentityStatusCode,
--            @IsPrimaryEmail,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT gei.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM child.GuardianEmailIdentity gei
--        WHERE gei.GuardianEmailIdentityID = @GuardianEmailIdentityID
--          AND gei.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--        BEGIN
--            THROW 50271, 'Guardian email identity record not found or deleted.', 1;
--        END;
--
--        UPDATE child.GuardianEmailIdentity
--           SET ChildPersonRelationshipID = @ChildPersonRelationshipID,
--               EmailAddress = @EmailAddress,
--               NormalizedEmailAddress = @NormalizedEmailAddress,
--               EmailVerifiedUTC = @EmailVerifiedUTC,
--               VerifiedByInvitationID = @VerifiedByInvitationID,
--               IdentityStatusCode = @IdentityStatusCode,
--               IsPrimaryEmail = @IsPrimaryEmail,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE GuardianEmailIdentityID = @GuardianEmailIdentityID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @GuardianEmailIdentityID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT gei.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.GuardianEmailIdentity gei
--    WHERE gei.GuardianEmailIdentityID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'GuardianEmailIdentity',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS GuardianEmailIdentityID;
--END;

GO


CREATE PROCEDURE child.usp_GuardianEmailChangeRequest_Create
    @GuardianEmailIdentityID       INT,
    @RequestedEmailAddress         NVARCHAR(320),
    @NormalizedRequestedEmail      NVARCHAR(320),
    @RequestReason                 NVARCHAR(MAX)     = NULL,
    @CreatedByUserID               INT,
    @ReasonText                    NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @GuardianEmailChangeRequestID INT;
    DECLARE @ChildID INT;
    DECLARE @SiteID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT
        @ChildID = cpr.ChildID,
        @SiteID = c.SiteID
    FROM child.GuardianEmailIdentity gei
    INNER JOIN child.ChildPersonRelationship cpr
        ON cpr.ChildPersonRelationshipID = gei.ChildPersonRelationshipID
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
    WHERE gei.GuardianEmailIdentityID = @GuardianEmailIdentityID
      AND gei.IsDeleted = 0
      AND cpr.IsDeleted = 0
      AND c.IsDeleted = 0;

    IF @ChildID IS NULL
    BEGIN
        THROW 50272, 'Guardian email identity record not found or deleted.', 1;
    END;

    INSERT INTO child.GuardianEmailChangeRequest
    (
        GuardianEmailIdentityID,
        RequestedEmailAddress,
        NormalizedRequestedEmail,
        RequestReason,
        CreatedByUserID
    )
    VALUES
    (
        @GuardianEmailIdentityID,
        @RequestedEmailAddress,
        @NormalizedRequestedEmail,
        @RequestReason,
        @CreatedByUserID
    );

    SET @GuardianEmailChangeRequestID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'child',
        @TableName = N'GuardianEmailChangeRequest',
        @RecordPrimaryKeyValue = CAST(@GuardianEmailChangeRequestID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @CreatedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = COALESCE(@ReasonText, @RequestReason),
        @NewValuesJson = (SELECT gecr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM child.GuardianEmailChangeRequest gecr
    WHERE gecr.GuardianEmailChangeRequestID = @GuardianEmailChangeRequestID;

    SELECT @GuardianEmailChangeRequestID AS GuardianEmailChangeRequestID;
END;
GO

--Syntax Error: Incorrect syntax near '@GuardianEmailChangeRequestID'.
--
--CREATE PROCEDURE child.usp_GuardianEmailChangeRequest_Create
--    @GuardianEmailIdentityID       INT,
--    @RequestedEmailAddress         NVARCHAR(320),
--    @NormalizedRequestedEmail      NVARCHAR(320),
--    @RequestReason                 NVARCHAR(MAX)     = NULL,
--    @CreatedByUserID               INT,
--    @ReasonText                    NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @GuardianEmailChangeRequestID INT;
--    DECLARE @ChildID INT;
--    DECLARE @SiteID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT
--        @ChildID = cpr.ChildID,
--        @SiteID = c.SiteID
--    FROM child.GuardianEmailIdentity gei
--    INNER JOIN child.ChildPersonRelationship cpr
--        ON cpr.ChildPersonRelationshipID = gei.ChildPersonRelationshipID
--    INNER JOIN child.Child c
--        ON c.ChildID = cpr.ChildID
--    WHERE gei.GuardianEmailIdentityID = @GuardianEmailIdentityID
--      AND gei.IsDeleted = 0
--      AND cpr.IsDeleted = 0
--      AND c.IsDeleted = 0;
--
--    IF @ChildID IS NULL
--    BEGIN
--        THROW 50272, 'Guardian email identity record not found or deleted.', 1;
--    END;
--
--    INSERT INTO child.GuardianEmailChangeRequest
--    (
--        GuardianEmailIdentityID,
--        RequestedEmailAddress,
--        NormalizedRequestedEmail,
--        RequestReason,
--        CreatedByUserID
--    )
--    VALUES
--    (
--        @GuardianEmailIdentityID,
--        @RequestedEmailAddress,
--        @NormalizedRequestedEmail,
--        @RequestReason,
--        @CreatedByUserID
--    );
--
--    SET @GuardianEmailChangeRequestID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'child',
--        @TableName = N'GuardianEmailChangeRequest',
--        @RecordPrimaryKeyValue = CAST(@GuardianEmailChangeRequestID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @CreatedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = COALESCE(@ReasonText, @RequestReason),
--        @NewValuesJson = (SELECT gecr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM child.GuardianEmailChangeRequest gecr
--    WHERE gecr.GuardianEmailChangeRequestID = @GuardianEmailChangeRequestID;
--
--    SELECT @GuardianEmailChangeRequestID AS GuardianEmailChangeRequestID;
--END;

GO


CREATE PROCEDURE audit.usp_RecoveryRequest_Create
    @TargetSchemaName             NVARCHAR(128),
    @TargetTableName              NVARCHAR(128),
    @TargetPrimaryKeyValue        NVARCHAR(128),
    @SiteID                       INT                = NULL,
    @ChildID                      INT                = NULL,
    @RequestedByUserID            INT,
    @RequestReason                NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RecoveryRequestID BIGINT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    INSERT INTO audit.RecoveryRequest
    (
        TargetSchemaName,
        TargetTableName,
        TargetPrimaryKeyValue,
        SiteID,
        ChildID,
        RequestedByUserID,
        RequestReason
    )
    VALUES
    (
        @TargetSchemaName,
        @TargetTableName,
        @TargetPrimaryKeyValue,
        @SiteID,
        @ChildID,
        @RequestedByUserID,
        @RequestReason
    );

    SET @RecoveryRequestID = SCOPE_IDENTITY();

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'audit',
        @TableName = N'RecoveryRequest',
        @RecordPrimaryKeyValue = CAST(@RecoveryRequestID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @RequestedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @RequestReason,
        @NewValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM audit.RecoveryRequest rr
    WHERE rr.RecoveryRequestID = @RecoveryRequestID;

    SELECT @RecoveryRequestID AS RecoveryRequestID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecoveryRequestID'.
--
--CREATE PROCEDURE audit.usp_RecoveryRequest_Create
--    @TargetSchemaName             NVARCHAR(128),
--    @TargetTableName              NVARCHAR(128),
--    @TargetPrimaryKeyValue        NVARCHAR(128),
--    @SiteID                       INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @RequestedByUserID            INT,
--    @RequestReason                NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @RecoveryRequestID BIGINT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    INSERT INTO audit.RecoveryRequest
--    (
--        TargetSchemaName,
--        TargetTableName,
--        TargetPrimaryKeyValue,
--        SiteID,
--        ChildID,
--        RequestedByUserID,
--        RequestReason
--    )
--    VALUES
--    (
--        @TargetSchemaName,
--        @TargetTableName,
--        @TargetPrimaryKeyValue,
--        @SiteID,
--        @ChildID,
--        @RequestedByUserID,
--        @RequestReason
--    );
--
--    SET @RecoveryRequestID = SCOPE_IDENTITY();
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'audit',
--        @TableName = N'RecoveryRequest',
--        @RecordPrimaryKeyValue = CAST(@RecoveryRequestID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @RequestedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @RequestReason,
--        @NewValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM audit.RecoveryRequest rr
--    WHERE rr.RecoveryRequestID = @RecoveryRequestID;
--
--    SELECT @RecoveryRequestID AS RecoveryRequestID;
--END;

GO


CREATE PROCEDURE audit.usp_RecoveryRequest_Approve
    @RecoveryRequestID            BIGINT,
    @ApprovedByUserID             INT,
    @ApprovalDecisionCode         NVARCHAR(50),
    @ApprovalReason               NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @ChildID INT;
    DECLARE @RecoveryApprovalID BIGINT;
    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT
        @SiteID = rr.SiteID,
        @ChildID = rr.ChildID,
        @OldValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM audit.RecoveryRequest rr
    WHERE rr.RecoveryRequestID = @RecoveryRequestID;

    IF @OldValuesJson IS NULL
    BEGIN
        THROW 50280, 'Recovery request not found.', 1;
    END;

    INSERT INTO audit.RecoveryApproval
    (
        RecoveryRequestID,
        ApprovedByUserID,
        ApprovalDecisionCode,
        ApprovalReason
    )
    VALUES
    (
        @RecoveryRequestID,
        @ApprovedByUserID,
        @ApprovalDecisionCode,
        @ApprovalReason
    );

    SET @RecoveryApprovalID = SCOPE_IDENTITY();

    UPDATE audit.RecoveryRequest
       SET RequestStatusCode = CASE WHEN @ApprovalDecisionCode = N'APPROVED' THEN N'APPROVED' ELSE N'REJECTED' END,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ApprovedByUserID
     WHERE RecoveryRequestID = @RecoveryRequestID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'audit',
        @TableName = N'RecoveryRequest',
        @RecordPrimaryKeyValue = CAST(@RecoveryRequestID AS NVARCHAR(128)),
        @ActionTypeCode = N'UPDATE',
        @ChangedByUserID = @ApprovedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ApprovalReason,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM audit.RecoveryRequest rr
    WHERE rr.RecoveryRequestID = @RecoveryRequestID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'audit',
        @TableName = N'RecoveryApproval',
        @RecordPrimaryKeyValue = CAST(@RecoveryApprovalID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @ApprovedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ApprovalReason,
        @NewValuesJson = (SELECT ra.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM audit.RecoveryApproval ra
    WHERE ra.RecoveryApprovalID = @RecoveryApprovalID;

    SELECT @RecoveryApprovalID AS RecoveryApprovalID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecoveryRequestID'.
--Syntax Error: Incorrect syntax near '@RecoveryApprovalID'.
--
--CREATE PROCEDURE audit.usp_RecoveryRequest_Approve
--    @RecoveryRequestID            BIGINT,
--    @ApprovedByUserID             INT,
--    @ApprovalDecisionCode         NVARCHAR(50),
--    @ApprovalReason               NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @ChildID INT;
--    DECLARE @RecoveryApprovalID BIGINT;
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT
--        @SiteID = rr.SiteID,
--        @ChildID = rr.ChildID,
--        @OldValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM audit.RecoveryRequest rr
--    WHERE rr.RecoveryRequestID = @RecoveryRequestID;
--
--    IF @OldValuesJson IS NULL
--    BEGIN
--        THROW 50280, 'Recovery request not found.', 1;
--    END;
--
--    INSERT INTO audit.RecoveryApproval
--    (
--        RecoveryRequestID,
--        ApprovedByUserID,
--        ApprovalDecisionCode,
--        ApprovalReason
--    )
--    VALUES
--    (
--        @RecoveryRequestID,
--        @ApprovedByUserID,
--        @ApprovalDecisionCode,
--        @ApprovalReason
--    );
--
--    SET @RecoveryApprovalID = SCOPE_IDENTITY();
--
--    UPDATE audit.RecoveryRequest
--       SET RequestStatusCode = CASE WHEN @ApprovalDecisionCode = N'APPROVED' THEN N'APPROVED' ELSE N'REJECTED' END,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ApprovedByUserID
--     WHERE RecoveryRequestID = @RecoveryRequestID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'audit',
--        @TableName = N'RecoveryRequest',
--        @RecordPrimaryKeyValue = CAST(@RecoveryRequestID AS NVARCHAR(128)),
--        @ActionTypeCode = N'UPDATE',
--        @ChangedByUserID = @ApprovedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ApprovalReason,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (SELECT rr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM audit.RecoveryRequest rr
--    WHERE rr.RecoveryRequestID = @RecoveryRequestID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'audit',
--        @TableName = N'RecoveryApproval',
--        @RecordPrimaryKeyValue = CAST(@RecoveryApprovalID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @ApprovedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ApprovalReason,
--        @NewValuesJson = (SELECT ra.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM audit.RecoveryApproval ra
--    WHERE ra.RecoveryApprovalID = @RecoveryApprovalID;
--
--    SELECT @RecoveryApprovalID AS RecoveryApprovalID;
--END;

GO


CREATE PROCEDURE audit.usp_RecoveryExecution_Log
    @RecoveryRequestID            BIGINT,
    @ExecutedByUserID             INT,
    @ExecutionStatusCode          NVARCHAR(50),
    @ExecutionNotes               NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SiteID INT;
    DECLARE @ChildID INT;
    DECLARE @RecoveryExecutionID BIGINT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT
        @SiteID = rr.SiteID,
        @ChildID = rr.ChildID
    FROM audit.RecoveryRequest rr
    WHERE rr.RecoveryRequestID = @RecoveryRequestID;

    IF @SiteID IS NULL AND @ChildID IS NULL
    BEGIN
        IF NOT EXISTS
        (
            SELECT 1
            FROM audit.RecoveryRequest rr
            WHERE rr.RecoveryRequestID = @RecoveryRequestID
        )
        BEGIN
            THROW 50281, 'Recovery request not found.', 1;
        END;
    END;

    INSERT INTO audit.RecoveryExecution
    (
        RecoveryRequestID,
        ExecutedByUserID,
        ExecutionStatusCode,
        ExecutionNotes
    )
    VALUES
    (
        @RecoveryRequestID,
        @ExecutedByUserID,
        @ExecutionStatusCode,
        @ExecutionNotes
    );

    SET @RecoveryExecutionID = SCOPE_IDENTITY();

    UPDATE audit.RecoveryRequest
       SET RequestStatusCode = CASE WHEN @ExecutionStatusCode = N'EXECUTED' THEN N'EXECUTED' ELSE N'EXECUTION_FAILED' END,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ExecutedByUserID
     WHERE RecoveryRequestID = @RecoveryRequestID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'audit',
        @TableName = N'RecoveryExecution',
        @RecordPrimaryKeyValue = CAST(@RecoveryExecutionID AS NVARCHAR(128)),
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @ExecutedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ExecutionNotes,
        @NewValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM audit.RecoveryExecution re
    WHERE re.RecoveryExecutionID = @RecoveryExecutionID;

    SELECT @RecoveryExecutionID AS RecoveryExecutionID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecoveryExecutionID'.
--
--CREATE PROCEDURE audit.usp_RecoveryExecution_Log
--    @RecoveryRequestID            BIGINT,
--    @ExecutedByUserID             INT,
--    @ExecutionStatusCode          NVARCHAR(50),
--    @ExecutionNotes               NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @SiteID INT;
--    DECLARE @ChildID INT;
--    DECLARE @RecoveryExecutionID BIGINT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT
--        @SiteID = rr.SiteID,
--        @ChildID = rr.ChildID
--    FROM audit.RecoveryRequest rr
--    WHERE rr.RecoveryRequestID = @RecoveryRequestID;
--
--    IF @SiteID IS NULL AND @ChildID IS NULL
--    BEGIN
--        IF NOT EXISTS
--        (
--            SELECT 1
--            FROM audit.RecoveryRequest rr
--            WHERE rr.RecoveryRequestID = @RecoveryRequestID
--        )
--        BEGIN
--            THROW 50281, 'Recovery request not found.', 1;
--        END;
--    END;
--
--    INSERT INTO audit.RecoveryExecution
--    (
--        RecoveryRequestID,
--        ExecutedByUserID,
--        ExecutionStatusCode,
--        ExecutionNotes
--    )
--    VALUES
--    (
--        @RecoveryRequestID,
--        @ExecutedByUserID,
--        @ExecutionStatusCode,
--        @ExecutionNotes
--    );
--
--    SET @RecoveryExecutionID = SCOPE_IDENTITY();
--
--    UPDATE audit.RecoveryRequest
--       SET RequestStatusCode = CASE WHEN @ExecutionStatusCode = N'EXECUTED' THEN N'EXECUTED' ELSE N'EXECUTION_FAILED' END,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @ExecutedByUserID
--     WHERE RecoveryRequestID = @RecoveryRequestID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'audit',
--        @TableName = N'RecoveryExecution',
--        @RecordPrimaryKeyValue = CAST(@RecoveryExecutionID AS NVARCHAR(128)),
--        @ActionTypeCode = N'INSERT',
--        @ChangedByUserID = @ExecutedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ExecutionNotes,
--        @NewValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM audit.RecoveryExecution re
--    WHERE re.RecoveryExecutionID = @RecoveryExecutionID;
--
--    SELECT @RecoveryExecutionID AS RecoveryExecutionID;
--END;

GO


CREATE PROCEDURE lic.usp_ComplianceReview_Upsert
    @ComplianceReviewID           INT                = NULL,
    @SiteID                       INT,
    @ReviewTypeCode               NVARCHAR(50),
    @ReviewStatusCode             NVARCHAR(50),
    @ReviewStartUTC               DATETIME2(0),
    @ReviewEndUTC                 DATETIME2(0)       = NULL,
    @ReviewedByUserID             INT                = NULL,
    @ReviewSummary                NVARCHAR(MAX)     = NULL,
    @NextReviewDueDate            DATE               = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RecordID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @ComplianceReviewID IS NULL
    BEGIN
        INSERT INTO lic.ComplianceReview
        (
            SiteID,
            ReviewTypeCode,
            ReviewStatusCode,
            ReviewStartUTC,
            ReviewEndUTC,
            ReviewedByUserID,
            ReviewSummary,
            NextReviewDueDate,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @ReviewTypeCode,
            @ReviewStatusCode,
            @ReviewStartUTC,
            @ReviewEndUTC,
            @ReviewedByUserID,
            @ReviewSummary,
            @NextReviewDueDate,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM lic.ComplianceReview cr
        WHERE cr.ComplianceReviewID = @ComplianceReviewID
          AND cr.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50290, 'Compliance review record not found or deleted.', 1;

        UPDATE lic.ComplianceReview
           SET SiteID = @SiteID,
               ReviewTypeCode = @ReviewTypeCode,
               ReviewStatusCode = @ReviewStatusCode,
               ReviewStartUTC = @ReviewStartUTC,
               ReviewEndUTC = @ReviewEndUTC,
               ReviewedByUserID = @ReviewedByUserID,
               ReviewSummary = @ReviewSummary,
               NextReviewDueDate = @NextReviewDueDate,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ComplianceReviewID = @ComplianceReviewID
           AND IsDeleted = 0;

        SET @RecordID = @ComplianceReviewID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM lic.ComplianceReview cr
    WHERE cr.ComplianceReviewID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'ComplianceReview',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS ComplianceReviewID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_ComplianceReview_Upsert
--    @ComplianceReviewID           INT                = NULL,
--    @SiteID                       INT,
--    @ReviewTypeCode               NVARCHAR(50),
--    @ReviewStatusCode             NVARCHAR(50),
--    @ReviewStartUTC               DATETIME2(0),
--    @ReviewEndUTC                 DATETIME2(0)       = NULL,
--    @ReviewedByUserID             INT                = NULL,
--    @ReviewSummary                NVARCHAR(MAX)     = NULL,
--    @NextReviewDueDate            DATE               = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @RecordID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @ComplianceReviewID IS NULL
--    BEGIN
--        INSERT INTO lic.ComplianceReview
--        (
--            SiteID,
--            ReviewTypeCode,
--            ReviewStatusCode,
--            ReviewStartUTC,
--            ReviewEndUTC,
--            ReviewedByUserID,
--            ReviewSummary,
--            NextReviewDueDate,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @ReviewTypeCode,
--            @ReviewStatusCode,
--            @ReviewStartUTC,
--            @ReviewEndUTC,
--            @ReviewedByUserID,
--            @ReviewSummary,
--            @NextReviewDueDate,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.ComplianceReview cr
--        WHERE cr.ComplianceReviewID = @ComplianceReviewID
--          AND cr.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50290, 'Compliance review record not found or deleted.', 1;
--
--        UPDATE lic.ComplianceReview
--           SET SiteID = @SiteID,
--               ReviewTypeCode = @ReviewTypeCode,
--               ReviewStatusCode = @ReviewStatusCode,
--               ReviewStartUTC = @ReviewStartUTC,
--               ReviewEndUTC = @ReviewEndUTC,
--               ReviewedByUserID = @ReviewedByUserID,
--               ReviewSummary = @ReviewSummary,
--               NextReviewDueDate = @NextReviewDueDate,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ComplianceReviewID = @ComplianceReviewID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @ComplianceReviewID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT cr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.ComplianceReview cr
--    WHERE cr.ComplianceReviewID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'ComplianceReview',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS ComplianceReviewID;
--END;

GO


CREATE PROCEDURE lic.usp_ComplianceFinding_Upsert
    @ComplianceFindingID          INT                = NULL,
    @ComplianceReviewID           INT,
    @RequirementID                INT                = NULL,
    @ChildID                      INT                = NULL,
    @FindingSeverityCode          NVARCHAR(50),
    @FindingStatusCode            NVARCHAR(50),
    @FindingTitle                 NVARCHAR(200),
    @FindingDescription           NVARCHAR(MAX),
    @CorrectiveActionRequired     BIT,
    @CorrectiveActionDueDate      DATE               = NULL,
    @ClosedUTC                    DATETIME2(0)       = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RecordID INT;
    DECLARE @SiteID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @SiteID = cr.SiteID
    FROM lic.ComplianceReview cr
    WHERE cr.ComplianceReviewID = @ComplianceReviewID
      AND cr.IsDeleted = 0;

    IF @SiteID IS NULL
        THROW 50291, 'Compliance review record not found or deleted.', 1;

    IF @ComplianceFindingID IS NULL
    BEGIN
        INSERT INTO lic.ComplianceFinding
        (
            ComplianceReviewID,
            RequirementID,
            ChildID,
            FindingSeverityCode,
            FindingStatusCode,
            FindingTitle,
            FindingDescription,
            CorrectiveActionRequired,
            CorrectiveActionDueDate,
            ClosedUTC,
            CreatedByUserID
        )
        VALUES
        (
            @ComplianceReviewID,
            @RequirementID,
            @ChildID,
            @FindingSeverityCode,
            @FindingStatusCode,
            @FindingTitle,
            @FindingDescription,
            @CorrectiveActionRequired,
            @CorrectiveActionDueDate,
            @ClosedUTC,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT cf.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM lic.ComplianceFinding cf
        WHERE cf.ComplianceFindingID = @ComplianceFindingID
          AND cf.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50292, 'Compliance finding record not found or deleted.', 1;

        UPDATE lic.ComplianceFinding
           SET ComplianceReviewID = @ComplianceReviewID,
               RequirementID = @RequirementID,
               ChildID = @ChildID,
               FindingSeverityCode = @FindingSeverityCode,
               FindingStatusCode = @FindingStatusCode,
               FindingTitle = @FindingTitle,
               FindingDescription = @FindingDescription,
               CorrectiveActionRequired = @CorrectiveActionRequired,
               CorrectiveActionDueDate = @CorrectiveActionDueDate,
               ClosedUTC = @ClosedUTC,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE ComplianceFindingID = @ComplianceFindingID
           AND IsDeleted = 0;

        SET @RecordID = @ComplianceFindingID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT cf.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM lic.ComplianceFinding cf
    WHERE cf.ComplianceFindingID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'ComplianceFinding',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS ComplianceFindingID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_ComplianceFinding_Upsert
--    @ComplianceFindingID          INT                = NULL,
--    @ComplianceReviewID           INT,
--    @RequirementID                INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @FindingSeverityCode          NVARCHAR(50),
--    @FindingStatusCode            NVARCHAR(50),
--    @FindingTitle                 NVARCHAR(200),
--    @FindingDescription           NVARCHAR(MAX),
--    @CorrectiveActionRequired     BIT,
--    @CorrectiveActionDueDate      DATE               = NULL,
--    @ClosedUTC                    DATETIME2(0)       = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @RecordID INT;
--    DECLARE @SiteID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @SiteID = cr.SiteID
--    FROM lic.ComplianceReview cr
--    WHERE cr.ComplianceReviewID = @ComplianceReviewID
--      AND cr.IsDeleted = 0;
--
--    IF @SiteID IS NULL
--        THROW 50291, 'Compliance review record not found or deleted.', 1;
--
--    IF @ComplianceFindingID IS NULL
--    BEGIN
--        INSERT INTO lic.ComplianceFinding
--        (
--            ComplianceReviewID,
--            RequirementID,
--            ChildID,
--            FindingSeverityCode,
--            FindingStatusCode,
--            FindingTitle,
--            FindingDescription,
--            CorrectiveActionRequired,
--            CorrectiveActionDueDate,
--            ClosedUTC,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ComplianceReviewID,
--            @RequirementID,
--            @ChildID,
--            @FindingSeverityCode,
--            @FindingStatusCode,
--            @FindingTitle,
--            @FindingDescription,
--            @CorrectiveActionRequired,
--            @CorrectiveActionDueDate,
--            @ClosedUTC,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT cf.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.ComplianceFinding cf
--        WHERE cf.ComplianceFindingID = @ComplianceFindingID
--          AND cf.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50292, 'Compliance finding record not found or deleted.', 1;
--
--        UPDATE lic.ComplianceFinding
--           SET ComplianceReviewID = @ComplianceReviewID,
--               RequirementID = @RequirementID,
--               ChildID = @ChildID,
--               FindingSeverityCode = @FindingSeverityCode,
--               FindingStatusCode = @FindingStatusCode,
--               FindingTitle = @FindingTitle,
--               FindingDescription = @FindingDescription,
--               CorrectiveActionRequired = @CorrectiveActionRequired,
--               CorrectiveActionDueDate = @CorrectiveActionDueDate,
--               ClosedUTC = @ClosedUTC,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE ComplianceFindingID = @ComplianceFindingID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @ComplianceFindingID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT cf.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.ComplianceFinding cf
--    WHERE cf.ComplianceFindingID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'ComplianceFinding',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS ComplianceFindingID;
--END;

GO


CREATE PROCEDURE lic.usp_FindingResolution_Upsert
    @FindingResolutionID          INT                = NULL,
    @ComplianceFindingID          INT,
    @ResolutionStatusCode         NVARCHAR(50),
    @ResolutionSummary            NVARCHAR(MAX),
    @ResolvedByUserID             INT                = NULL,
    @ResolvedUTC                  DATETIME2(0)       = NULL,
    @VerificationNotes            NVARCHAR(MAX)     = NULL,
    @DocumentID                   INT                = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @RecordID INT;
    DECLARE @SiteID INT;
    DECLARE @ChildID INT;
    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT
        @SiteID = cr.SiteID,
        @ChildID = cf.ChildID
    FROM lic.ComplianceFinding cf
    INNER JOIN lic.ComplianceReview cr
        ON cr.ComplianceReviewID = cf.ComplianceReviewID
    WHERE cf.ComplianceFindingID = @ComplianceFindingID
      AND cf.IsDeleted = 0
      AND cr.IsDeleted = 0;

    IF @SiteID IS NULL AND @ChildID IS NULL
    BEGIN
        IF NOT EXISTS
        (
            SELECT 1
            FROM lic.ComplianceFinding cf
            WHERE cf.ComplianceFindingID = @ComplianceFindingID
              AND cf.IsDeleted = 0
        )
        BEGIN
            THROW 50293, 'Compliance finding record not found or deleted.', 1;
        END;
    END;

    IF @FindingResolutionID IS NULL
    BEGIN
        INSERT INTO lic.FindingResolution
        (
            ComplianceFindingID,
            ResolutionStatusCode,
            ResolutionSummary,
            ResolvedByUserID,
            ResolvedUTC,
            VerificationNotes,
            DocumentID,
            CreatedByUserID
        )
        VALUES
        (
            @ComplianceFindingID,
            @ResolutionStatusCode,
            @ResolutionSummary,
            @ResolvedByUserID,
            @ResolvedUTC,
            @VerificationNotes,
            @DocumentID,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT fr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM lic.FindingResolution fr
        WHERE fr.FindingResolutionID = @FindingResolutionID
          AND fr.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50294, 'Finding resolution record not found or deleted.', 1;

        UPDATE lic.FindingResolution
           SET ComplianceFindingID = @ComplianceFindingID,
               ResolutionStatusCode = @ResolutionStatusCode,
               ResolutionSummary = @ResolutionSummary,
               ResolvedByUserID = @ResolvedByUserID,
               ResolvedUTC = @ResolvedUTC,
               VerificationNotes = @VerificationNotes,
               DocumentID = @DocumentID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE FindingResolutionID = @FindingResolutionID
           AND IsDeleted = 0;

        SET @RecordID = @FindingResolutionID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT fr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM lic.FindingResolution fr
    WHERE fr.FindingResolutionID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'lic',
        @TableName = N'FindingResolution',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @ChildID = @ChildID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS FindingResolutionID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE lic.usp_FindingResolution_Upsert
--    @FindingResolutionID          INT                = NULL,
--    @ComplianceFindingID          INT,
--    @ResolutionStatusCode         NVARCHAR(50),
--    @ResolutionSummary            NVARCHAR(MAX),
--    @ResolvedByUserID             INT                = NULL,
--    @ResolvedUTC                  DATETIME2(0)       = NULL,
--    @VerificationNotes            NVARCHAR(MAX)     = NULL,
--    @DocumentID                   INT                = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @RecordID INT;
--    DECLARE @SiteID INT;
--    DECLARE @ChildID INT;
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT
--        @SiteID = cr.SiteID,
--        @ChildID = cf.ChildID
--    FROM lic.ComplianceFinding cf
--    INNER JOIN lic.ComplianceReview cr
--        ON cr.ComplianceReviewID = cf.ComplianceReviewID
--    WHERE cf.ComplianceFindingID = @ComplianceFindingID
--      AND cf.IsDeleted = 0
--      AND cr.IsDeleted = 0;
--
--    IF @SiteID IS NULL AND @ChildID IS NULL
--    BEGIN
--        IF NOT EXISTS
--        (
--            SELECT 1
--            FROM lic.ComplianceFinding cf
--            WHERE cf.ComplianceFindingID = @ComplianceFindingID
--              AND cf.IsDeleted = 0
--        )
--        BEGIN
--            THROW 50293, 'Compliance finding record not found or deleted.', 1;
--        END;
--    END;
--
--    IF @FindingResolutionID IS NULL
--    BEGIN
--        INSERT INTO lic.FindingResolution
--        (
--            ComplianceFindingID,
--            ResolutionStatusCode,
--            ResolutionSummary,
--            ResolvedByUserID,
--            ResolvedUTC,
--            VerificationNotes,
--            DocumentID,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @ComplianceFindingID,
--            @ResolutionStatusCode,
--            @ResolutionSummary,
--            @ResolvedByUserID,
--            @ResolvedUTC,
--            @VerificationNotes,
--            @DocumentID,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT fr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.FindingResolution fr
--        WHERE fr.FindingResolutionID = @FindingResolutionID
--          AND fr.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50294, 'Finding resolution record not found or deleted.', 1;
--
--        UPDATE lic.FindingResolution
--           SET ComplianceFindingID = @ComplianceFindingID,
--               ResolutionStatusCode = @ResolutionStatusCode,
--               ResolutionSummary = @ResolutionSummary,
--               ResolvedByUserID = @ResolvedByUserID,
--               ResolvedUTC = @ResolvedUTC,
--               VerificationNotes = @VerificationNotes,
--               DocumentID = @DocumentID,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE FindingResolutionID = @FindingResolutionID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @FindingResolutionID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT fr.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.FindingResolution fr
--    WHERE fr.FindingResolutionID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'FindingResolution',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS FindingResolutionID;
--END;

GO


CREATE PROCEDURE party.usp_Address_Upsert
    @AddressID               INT = NULL,
    @CountryCode             NVARCHAR(10),
    @AddressLine1            NVARCHAR(200),
    @AddressLine2            NVARCHAR(200) = NULL,
    @City                    NVARCHAR(100),
    @StateProvinceCode       NVARCHAR(20),
    @PostalCode              NVARCHAR(20),
    @CountyName              NVARCHAR(100) = NULL,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @AddressID IS NULL
    BEGIN
        INSERT INTO party.Address
        (
            CountryCode,
            AddressLine1,
            AddressLine2,
            City,
            StateProvinceCode,
            PostalCode,
            CountyName,
            CreatedByUserID
        )
        VALUES
        (
            @CountryCode,
            @AddressLine1,
            @AddressLine2,
            @City,
            @StateProvinceCode,
            @PostalCode,
            @CountyName,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.Address a
        WHERE a.AddressID = @AddressID
          AND a.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50310, 'Address record not found or deleted.', 1;

        UPDATE party.Address
           SET CountryCode = @CountryCode,
               AddressLine1 = @AddressLine1,
               AddressLine2 = @AddressLine2,
               City = @City,
               StateProvinceCode = @StateProvinceCode,
               PostalCode = @PostalCode,
               CountyName = @CountyName,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE AddressID = @AddressID
           AND IsDeleted = 0;

        SET @RecordID = @AddressID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Address a
    WHERE a.AddressID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Address',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS AddressID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_Address_Upsert
--    @AddressID               INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @AddressLine1            NVARCHAR(200),
--    @AddressLine2            NVARCHAR(200) = NULL,
--    @City                    NVARCHAR(100),
--    @StateProvinceCode       NVARCHAR(20),
--    @PostalCode              NVARCHAR(20),
--    @CountyName              NVARCHAR(100) = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @AddressID IS NULL
--    BEGIN
--        INSERT INTO party.Address
--        (
--            CountryCode,
--            AddressLine1,
--            AddressLine2,
--            City,
--            StateProvinceCode,
--            PostalCode,
--            CountyName,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @CountryCode,
--            @AddressLine1,
--            @AddressLine2,
--            @City,
--            @StateProvinceCode,
--            @PostalCode,
--            @CountyName,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.Address a
--        WHERE a.AddressID = @AddressID
--          AND a.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50310, 'Address record not found or deleted.', 1;
--
--        UPDATE party.Address
--           SET CountryCode = @CountryCode,
--               AddressLine1 = @AddressLine1,
--               AddressLine2 = @AddressLine2,
--               City = @City,
--               StateProvinceCode = @StateProvinceCode,
--               PostalCode = @PostalCode,
--               CountyName = @CountyName,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE AddressID = @AddressID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @AddressID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Address a
--    WHERE a.AddressID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Address',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS AddressID;
--END;

GO


CREATE PROCEDURE party.usp_Address_SoftDelete
    @AddressID               INT,
    @DeletedByUserID         INT = NULL,
    @DeletedReason           NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Address a
    WHERE a.AddressID = @AddressID
      AND a.IsDeleted = 0;

    IF @OldValuesJson IS NULL
        THROW 50311, 'Address record not found or already deleted.', 1;

    UPDATE party.Address
       SET IsActive = 0,
           IsDeleted = 1,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE AddressID = @AddressID
       AND IsDeleted = 0;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Address',
        @RecordPrimaryKeyValue = CAST(@AddressID AS NVARCHAR(128)),
        @ActionTypeCode = N'SOFT_DELETE',
        @ChangedByUserID = @DeletedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @DeletedReason,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.Address a
    WHERE a.AddressID = @AddressID;

    SELECT @AddressID AS AddressID;
END;
GO

--Syntax Error: Incorrect syntax near '@AddressID'.
--
--CREATE PROCEDURE party.usp_Address_SoftDelete
--    @AddressID               INT,
--    @DeletedByUserID         INT = NULL,
--    @DeletedReason           NVARCHAR(500)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @OldValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Address a
--    WHERE a.AddressID = @AddressID
--      AND a.IsDeleted = 0;
--
--    IF @OldValuesJson IS NULL
--        THROW 50311, 'Address record not found or already deleted.', 1;
--
--    UPDATE party.Address
--       SET IsActive = 0,
--           IsDeleted = 1,
--           DeletedUTC = SYSUTCDATETIME(),
--           DeletedByUserID = @DeletedByUserID,
--           DeletedReason = @DeletedReason,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @DeletedByUserID
--     WHERE AddressID = @AddressID
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'Address',
--        @RecordPrimaryKeyValue = CAST(@AddressID AS NVARCHAR(128)),
--        @ActionTypeCode = N'SOFT_DELETE',
--        @ChangedByUserID = @DeletedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @DeletedReason,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.Address a
--    WHERE a.AddressID = @AddressID;
--
--    SELECT @AddressID AS AddressID;
--END;

GO


CREATE PROCEDURE party.usp_PhoneNumber_Upsert
    @PhoneNumberID           INT = NULL,
    @CountryCode             NVARCHAR(10),
    @PhoneNumber             NVARCHAR(30),
    @IsVoice                 BIT,
    @IsSms                   BIT,
    @ChangedByUserID         INT = NULL,
    @ReasonText              NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @PhoneNumberID IS NULL
    BEGIN
        INSERT INTO party.PhoneNumber
        (
            CountryCode,
            PhoneNumber,
            IsVoice,
            IsSms,
            CreatedByUserID
        )
        VALUES
        (
            @CountryCode,
            @PhoneNumber,
            @IsVoice,
            @IsSms,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM party.PhoneNumber p
        WHERE p.PhoneNumberID = @PhoneNumberID
          AND p.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50312, 'Phone number record not found or deleted.', 1;

        UPDATE party.PhoneNumber
           SET CountryCode = @CountryCode,
               PhoneNumber = @PhoneNumber,
               IsVoice = @IsVoice,
               IsSms = @IsSms,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE PhoneNumberID = @PhoneNumberID
           AND IsDeleted = 0;

        SET @RecordID = @PhoneNumberID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.PhoneNumber p
    WHERE p.PhoneNumberID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PhoneNumber',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS PhoneNumberID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE party.usp_PhoneNumber_Upsert
--    @PhoneNumberID           INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @PhoneNumber             NVARCHAR(30),
--    @IsVoice                 BIT,
--    @IsSms                   BIT,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @PhoneNumberID IS NULL
--    BEGIN
--        INSERT INTO party.PhoneNumber
--        (
--            CountryCode,
--            PhoneNumber,
--            IsVoice,
--            IsSms,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @CountryCode,
--            @PhoneNumber,
--            @IsVoice,
--            @IsSms,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM party.PhoneNumber p
--        WHERE p.PhoneNumberID = @PhoneNumberID
--          AND p.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50312, 'Phone number record not found or deleted.', 1;
--
--        UPDATE party.PhoneNumber
--           SET CountryCode = @CountryCode,
--               PhoneNumber = @PhoneNumber,
--               IsVoice = @IsVoice,
--               IsSms = @IsSms,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE PhoneNumberID = @PhoneNumberID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @PhoneNumberID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.PhoneNumber p
--    WHERE p.PhoneNumberID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'PhoneNumber',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS PhoneNumberID;
--END;

GO


CREATE PROCEDURE party.usp_PhoneNumber_SoftDelete
    @PhoneNumberID           INT,
    @DeletedByUserID         INT = NULL,
    @DeletedReason           NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.PhoneNumber p
    WHERE p.PhoneNumberID = @PhoneNumberID
      AND p.IsDeleted = 0;

    IF @OldValuesJson IS NULL
        THROW 50313, 'Phone number record not found or already deleted.', 1;

    UPDATE party.PhoneNumber
       SET IsActive = 0,
           IsDeleted = 1,
           DeletedUTC = SYSUTCDATETIME(),
           DeletedByUserID = @DeletedByUserID,
           DeletedReason = @DeletedReason,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @DeletedByUserID
     WHERE PhoneNumberID = @PhoneNumberID
       AND IsDeleted = 0;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PhoneNumber',
        @RecordPrimaryKeyValue = CAST(@PhoneNumberID AS NVARCHAR(128)),
        @ActionTypeCode = N'SOFT_DELETE',
        @ChangedByUserID = @DeletedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @DeletedReason,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM party.PhoneNumber p
    WHERE p.PhoneNumberID = @PhoneNumberID;

    SELECT @PhoneNumberID AS PhoneNumberID;
END;
GO

--Syntax Error: Incorrect syntax near '@PhoneNumberID'.
--
--CREATE PROCEDURE party.usp_PhoneNumber_SoftDelete
--    @PhoneNumberID           INT,
--    @DeletedByUserID         INT = NULL,
--    @DeletedReason           NVARCHAR(500)
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX);
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    SELECT @OldValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.PhoneNumber p
--    WHERE p.PhoneNumberID = @PhoneNumberID
--      AND p.IsDeleted = 0;
--
--    IF @OldValuesJson IS NULL
--        THROW 50313, 'Phone number record not found or already deleted.', 1;
--
--    UPDATE party.PhoneNumber
--       SET IsActive = 0,
--           IsDeleted = 1,
--           DeletedUTC = SYSUTCDATETIME(),
--           DeletedByUserID = @DeletedByUserID,
--           DeletedReason = @DeletedReason,
--           ModifiedUTC = SYSUTCDATETIME(),
--           ModifiedByUserID = @DeletedByUserID
--     WHERE PhoneNumberID = @PhoneNumberID
--       AND IsDeleted = 0;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'party',
--        @TableName = N'PhoneNumber',
--        @RecordPrimaryKeyValue = CAST(@PhoneNumberID AS NVARCHAR(128)),
--        @ActionTypeCode = N'SOFT_DELETE',
--        @ChangedByUserID = @DeletedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @DeletedReason,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = (SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM party.PhoneNumber p
--    WHERE p.PhoneNumberID = @PhoneNumberID;
--
--    SELECT @PhoneNumberID AS PhoneNumberID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_Address_Upsert
--    @AddressID               INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @AddressLine1            NVARCHAR(200),
--    @AddressLine2            NVARCHAR(200) = NULL,
--    @City                    NVARCHAR(100),
--    @StateProvinceCode       NVARCHAR(20),
--    @PostalCode              NVARCHAR(20),
--    @CountyName              NVARCHAR(100) = NULL,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @RecordID INT, @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    IF @AddressID IS NULL
--    BEGIN
--        INSERT INTO party.Address (CountryCode, AddressLine1, AddressLine2, City, StateProvinceCode, PostalCode, CountyName, CreatedByUserID)
--        VALUES (@CountryCode, @AddressLine1, @AddressLine2, @City, @StateProvinceCode, @PostalCode, @CountyName, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Address a WHERE a.AddressID=@AddressID AND a.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 53001, 'Address record not found or deleted.', 1;
--        UPDATE party.Address
--           SET CountryCode=@CountryCode, AddressLine1=@AddressLine1, AddressLine2=@AddressLine2, City=@City,
--               StateProvinceCode=@StateProvinceCode, PostalCode=@PostalCode, CountyName=@CountyName,
--               ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE AddressID=@AddressID AND IsDeleted=0;
--        SET @RecordID=@AddressID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Address a WHERE a.AddressID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'Address', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS AddressID;
--END;

GO

--Syntax Error: Incorrect syntax near '@AddressID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_Address_SoftDelete
--    @AddressID               INT,
--    @DeletedByUserID         INT = NULL,
--    @DeletedReason           NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX), @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    SELECT @OldValuesJson=(SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Address a WHERE a.AddressID=@AddressID AND a.IsDeleted=0;
--    IF @OldValuesJson IS NULL THROW 53002, 'Address record not found or already deleted.', 1;
--
--    UPDATE party.Address
--       SET IsActive=0, IsDeleted=1, DeletedUTC=SYSUTCDATETIME(), DeletedByUserID=@DeletedByUserID, DeletedReason=@DeletedReason,
--           ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@DeletedByUserID
--     WHERE AddressID=@AddressID AND IsDeleted=0;
--
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'Address', @RecordPrimaryKeyValue=CAST(@AddressID AS NVARCHAR(128)), @ActionTypeCode=N'SOFT_DELETE', @ChangedByUserID=@DeletedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@DeletedReason, @OldValuesJson=@OldValuesJson, @NewValuesJson=(SELECT a.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.Address a WHERE a.AddressID=@AddressID;
--    SELECT @AddressID AS AddressID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_PhoneNumber_Upsert
--    @PhoneNumberID           INT = NULL,
--    @CountryCode             NVARCHAR(10),
--    @PhoneNumber             NVARCHAR(30),
--    @IsVoice                 BIT,
--    @IsSms                   BIT,
--    @ChangedByUserID         INT = NULL,
--    @ReasonText              NVARCHAR(MAX) = NULL
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX)=NULL, @NewValuesJson NVARCHAR(MAX), @ActionTypeCode NVARCHAR(50), @RecordID INT, @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    IF @PhoneNumberID IS NULL
--    BEGIN
--        INSERT INTO party.PhoneNumber (CountryCode, PhoneNumber, IsVoice, IsSms, CreatedByUserID)
--        VALUES (@CountryCode, @PhoneNumber, @IsVoice, @IsSms, @ChangedByUserID);
--        SET @RecordID=SCOPE_IDENTITY(); SET @ActionTypeCode=N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson=(SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.PhoneNumber p WHERE p.PhoneNumberID=@PhoneNumberID AND p.IsDeleted=0;
--        IF @OldValuesJson IS NULL THROW 53003, 'Phone number record not found or deleted.', 1;
--        UPDATE party.PhoneNumber
--           SET CountryCode=@CountryCode, PhoneNumber=@PhoneNumber, IsVoice=@IsVoice, IsSms=@IsSms,
--               ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@ChangedByUserID
--         WHERE PhoneNumberID=@PhoneNumberID AND IsDeleted=0;
--        SET @RecordID=@PhoneNumberID; SET @ActionTypeCode=N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson=(SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.PhoneNumber p WHERE p.PhoneNumberID=@RecordID;
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'PhoneNumber', @RecordPrimaryKeyValue=CAST(@RecordID AS NVARCHAR(128)), @ActionTypeCode=@ActionTypeCode, @ChangedByUserID=@ChangedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@ReasonText, @OldValuesJson=@OldValuesJson, @NewValuesJson=@NewValuesJson;
--    SELECT @RecordID AS PhoneNumberID;
--END;

GO

--Syntax Error: Incorrect syntax near '@PhoneNumberID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE party.usp_PhoneNumber_SoftDelete
--    @PhoneNumberID           INT,
--    @DeletedByUserID         INT = NULL,
--    @DeletedReason           NVARCHAR(MAX)
--AS
--BEGIN
--    SET NOCOUNT ON; SET XACT_ABORT ON;
--    DECLARE @OldValuesJson NVARCHAR(MAX), @CorrelationID UNIQUEIDENTIFIER=NEWID();
--
--    SELECT @OldValuesJson=(SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.PhoneNumber p WHERE p.PhoneNumberID=@PhoneNumberID AND p.IsDeleted=0;
--    IF @OldValuesJson IS NULL THROW 53004, 'Phone number record not found or already deleted.', 1;
--
--    UPDATE party.PhoneNumber
--       SET IsActive=0, IsDeleted=1, DeletedUTC=SYSUTCDATETIME(), DeletedByUserID=@DeletedByUserID, DeletedReason=@DeletedReason,
--           ModifiedUTC=SYSUTCDATETIME(), ModifiedByUserID=@DeletedByUserID
--     WHERE PhoneNumberID=@PhoneNumberID AND IsDeleted=0;
--
--    EXEC audit.usp_WriteAuditLog @SchemaName=N'party', @TableName=N'PhoneNumber', @RecordPrimaryKeyValue=CAST(@PhoneNumberID AS NVARCHAR(128)), @ActionTypeCode=N'SOFT_DELETE', @ChangedByUserID=@DeletedByUserID, @ChangeSourceCode=N'APPLICATION', @CorrelationID=@CorrelationID, @ReasonText=@DeletedReason, @OldValuesJson=@OldValuesJson, @NewValuesJson=(SELECT p.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) FROM party.PhoneNumber p WHERE p.PhoneNumberID=@PhoneNumberID;
--    SELECT @PhoneNumberID AS PhoneNumberID;
--END;

GO


CREATE PROCEDURE ops.usp_CaregiverPresence_Upsert
    @CaregiverPresenceID          INT                = NULL,
    @SiteID                       INT,
    @PersonID                     INT,
    @PresenceRoleCode             NVARCHAR(50),
    @StartDateTimeUTC             DATETIME2(0),
    @EndDateTimeUTC               DATETIME2(0),
    @CountsAsAdultCaregiver       BIT,
    @CountsAsHelper               BIT,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @EndDateTimeUTC <= @StartDateTimeUTC
        THROW 50320, 'Caregiver presence end time must be greater than start time.', 1;

    IF @CaregiverPresenceID IS NULL
    BEGIN
        INSERT INTO ops.CaregiverPresence
        (
            SiteID,
            PersonID,
            PresenceRoleCode,
            StartDateTimeUTC,
            EndDateTimeUTC,
            CountsAsAdultCaregiver,
            CountsAsHelper,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @PersonID,
            @PresenceRoleCode,
            @StartDateTimeUTC,
            @EndDateTimeUTC,
            @CountsAsAdultCaregiver,
            @CountsAsHelper,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT cp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM ops.CaregiverPresence cp
        WHERE cp.CaregiverPresenceID = @CaregiverPresenceID
          AND cp.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50321, 'Caregiver presence record not found or deleted.', 1;

        UPDATE ops.CaregiverPresence
           SET SiteID = @SiteID,
               PersonID = @PersonID,
               PresenceRoleCode = @PresenceRoleCode,
               StartDateTimeUTC = @StartDateTimeUTC,
               EndDateTimeUTC = @EndDateTimeUTC,
               CountsAsAdultCaregiver = @CountsAsAdultCaregiver,
               CountsAsHelper = @CountsAsHelper,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE CaregiverPresenceID = @CaregiverPresenceID
           AND IsDeleted = 0;

        SET @RecordID = @CaregiverPresenceID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SET @NewValuesJson = (SELECT cp.* FROM ops.CaregiverPresence cp WHERE cp.CaregiverPresenceID = @RecordID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'ops',
        @TableName = N'CaregiverPresence',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS CaregiverPresenceID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE ops.usp_CaregiverPresence_Upsert
--    @CaregiverPresenceID          INT                = NULL,
--    @SiteID                       INT,
--    @PersonID                     INT,
--    @PresenceRoleCode             NVARCHAR(50),
--    @StartDateTimeUTC             DATETIME2(0),
--    @EndDateTimeUTC               DATETIME2(0),
--    @CountsAsAdultCaregiver       BIT,
--    @CountsAsHelper               BIT,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @EndDateTimeUTC <= @StartDateTimeUTC
--        THROW 50320, 'Caregiver presence end time must be greater than start time.', 1;
--
--    IF @CaregiverPresenceID IS NULL
--    BEGIN
--        INSERT INTO ops.CaregiverPresence
--        (
--            SiteID,
--            PersonID,
--            PresenceRoleCode,
--            StartDateTimeUTC,
--            EndDateTimeUTC,
--            CountsAsAdultCaregiver,
--            CountsAsHelper,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @PersonID,
--            @PresenceRoleCode,
--            @StartDateTimeUTC,
--            @EndDateTimeUTC,
--            @CountsAsAdultCaregiver,
--            @CountsAsHelper,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT cp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM ops.CaregiverPresence cp
--        WHERE cp.CaregiverPresenceID = @CaregiverPresenceID
--          AND cp.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50321, 'Caregiver presence record not found or deleted.', 1;
--
--        UPDATE ops.CaregiverPresence
--           SET SiteID = @SiteID,
--               PersonID = @PersonID,
--               PresenceRoleCode = @PresenceRoleCode,
--               StartDateTimeUTC = @StartDateTimeUTC,
--               EndDateTimeUTC = @EndDateTimeUTC,
--               CountsAsAdultCaregiver = @CountsAsAdultCaregiver,
--               CountsAsHelper = @CountsAsHelper,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE CaregiverPresenceID = @CaregiverPresenceID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @CaregiverPresenceID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT cp.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM ops.CaregiverPresence cp
--    WHERE cp.CaregiverPresenceID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'ops',
--        @TableName = N'CaregiverPresence',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS CaregiverPresenceID;
--END;

GO


CREATE PROCEDURE ops.usp_CountedNonEnrollmentChild_Upsert
    @CountedNonEnrollmentChildID  INT                = NULL,
    @SiteID                       INT,
    @ChildDisplayName             NVARCHAR(200),
    @DateOfBirth                  DATE,
    @RelationshipToProviderCode   NVARCHAR(50),
    @CountsTowardCapacityFlag     BIT,
    @EffectiveStartDate           DATE,
    @EffectiveEndDate             DATE               = NULL,
    @Notes                        NVARCHAR(MAX)     = NULL,
    @ChangedByUserID              INT                = NULL,
    @ReasonText                   NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @ActionTypeCode NVARCHAR(50);
    DECLARE @RecordID INT;
    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();

    IF @CountedNonEnrollmentChildID IS NULL
    BEGIN
        INSERT INTO ops.CountedNonEnrollmentChild
        (
            SiteID,
            ChildDisplayName,
            DateOfBirth,
            RelationshipToProviderCode,
            CountsTowardCapacityFlag,
            EffectiveStartDate,
            EffectiveEndDate,
            Notes,
            CreatedByUserID
        )
        VALUES
        (
            @SiteID,
            @ChildDisplayName,
            @DateOfBirth,
            @RelationshipToProviderCode,
            @CountsTowardCapacityFlag,
            @EffectiveStartDate,
            @EffectiveEndDate,
            @Notes,
            @ChangedByUserID
        );

        SET @RecordID = SCOPE_IDENTITY();
        SET @ActionTypeCode = N'INSERT';
    END
    ELSE
    BEGIN
        SELECT @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
        FROM ops.CountedNonEnrollmentChild c
        WHERE c.CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
          AND c.IsDeleted = 0;

        IF @OldValuesJson IS NULL
            THROW 50322, 'Counted non-enrollment child record not found or deleted.', 1;

        UPDATE ops.CountedNonEnrollmentChild
           SET SiteID = @SiteID,
               ChildDisplayName = @ChildDisplayName,
               DateOfBirth = @DateOfBirth,
               RelationshipToProviderCode = @RelationshipToProviderCode,
               CountsTowardCapacityFlag = @CountsTowardCapacityFlag,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               Notes = @Notes,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @ChangedByUserID
         WHERE CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
           AND IsDeleted = 0;

        SET @RecordID = @CountedNonEnrollmentChildID;
        SET @ActionTypeCode = N'UPDATE';
    END;

    SELECT @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM ops.CountedNonEnrollmentChild c
    WHERE c.CountedNonEnrollmentChildID = @RecordID;

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'ops',
        @TableName = N'CountedNonEnrollmentChild',
        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
        @ActionTypeCode = @ActionTypeCode,
        @ChangedByUserID = @ChangedByUserID,
        @ChangeSourceCode = N'APPLICATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson;

    SELECT @RecordID AS CountedNonEnrollmentChildID;
END;
GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--
--CREATE PROCEDURE ops.usp_CountedNonEnrollmentChild_Upsert
--    @CountedNonEnrollmentChildID  INT                = NULL,
--    @SiteID                       INT,
--    @ChildDisplayName             NVARCHAR(200),
--    @DateOfBirth                  DATE,
--    @RelationshipToProviderCode   NVARCHAR(50),
--    @CountsTowardCapacityFlag     BIT,
--    @EffectiveStartDate           DATE,
--    @EffectiveEndDate             DATE               = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @CountedNonEnrollmentChildID IS NULL
--    BEGIN
--        INSERT INTO ops.CountedNonEnrollmentChild
--        (
--            SiteID,
--            ChildDisplayName,
--            DateOfBirth,
--            RelationshipToProviderCode,
--            CountsTowardCapacityFlag,
--            EffectiveStartDate,
--            EffectiveEndDate,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @SiteID,
--            @ChildDisplayName,
--            @DateOfBirth,
--            @RelationshipToProviderCode,
--            @CountsTowardCapacityFlag,
--            @EffectiveStartDate,
--            @EffectiveEndDate,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM ops.CountedNonEnrollmentChild c
--        WHERE c.CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
--          AND c.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50322, 'Counted non-enrollment child record not found or deleted.', 1;
--
--        UPDATE ops.CountedNonEnrollmentChild
--           SET SiteID = @SiteID,
--               ChildDisplayName = @ChildDisplayName,
--               DateOfBirth = @DateOfBirth,
--               RelationshipToProviderCode = @RelationshipToProviderCode,
--               CountsTowardCapacityFlag = @CountsTowardCapacityFlag,
--               EffectiveStartDate = @EffectiveStartDate,
--               EffectiveEndDate = @EffectiveEndDate,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE CountedNonEnrollmentChildID = @CountedNonEnrollmentChildID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @CountedNonEnrollmentChildID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT c.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM ops.CountedNonEnrollmentChild c
--    WHERE c.CountedNonEnrollmentChildID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'ops',
--        @TableName = N'CountedNonEnrollmentChild',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS CountedNonEnrollmentChildID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE lic.usp_RequirementStatus_Upsert
--    @RequirementStatusID          INT                = NULL,
--    @RequirementID                INT,
--    @SiteID                       INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @PersonID                     INT                = NULL,
--    @StatusCode                   NVARCHAR(50),
--    @ReviewDueDate                DATE               = NULL,
--    @ReviewedByUserID             INT                = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @RequirementStatusID IS NULL
--    BEGIN
--        INSERT INTO lic.RequirementStatus
--        (
--            RequirementID,
--            SiteID,
--            ChildID,
--            PersonID,
--            StatusCode,
--            ReviewDueDate,
--            ReviewedByUserID,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @RequirementID,
--            @SiteID,
--            @ChildID,
--            @PersonID,
--            @StatusCode,
--            @ReviewDueDate,
--            @ReviewedByUserID,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT rs.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.RequirementStatus rs
--        WHERE rs.RequirementStatusID = @RequirementStatusID
--          AND rs.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50330, 'Requirement status record not found or deleted.', 1;
--
--        UPDATE lic.RequirementStatus
--           SET RequirementID = @RequirementID,
--               SiteID = @SiteID,
--               ChildID = @ChildID,
--               PersonID = @PersonID,
--               StatusCode = @StatusCode,
--               ReviewDueDate = @ReviewDueDate,
--               ReviewedByUserID = @ReviewedByUserID,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE RequirementStatusID = @RequirementStatusID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @RequirementStatusID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT rs.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.RequirementStatus rs
--    WHERE rs.RequirementStatusID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'RequirementStatus',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS RequirementStatusID;
--END;

GO

--Syntax Error: Incorrect syntax near '@RecordID'.
--Syntax Error: An internal parser error occurred.
--
--CREATE OR ALTER PROCEDURE lic.usp_RequirementEvidence_Upsert
--    @RequirementEvidenceID        INT                = NULL,
--    @RequirementID                INT,
--    @SiteID                       INT                = NULL,
--    @ChildID                      INT                = NULL,
--    @PersonID                     INT                = NULL,
--    @DocumentID                   INT                = NULL,
--    @EvidenceTypeCode             NVARCHAR(100),
--    @EvidenceStatusCode           NVARCHAR(50),
--    @EvidenceDate                 DATE               = NULL,
--    @ExpirationDate               DATE               = NULL,
--    @Notes                        NVARCHAR(MAX)     = NULL,
--    @ChangedByUserID              INT                = NULL,
--    @ReasonText                   NVARCHAR(MAX)     = NULL
--AS
--BEGIN
--    SET NOCOUNT ON;
--    SET XACT_ABORT ON;
--
--    DECLARE @OldValuesJson NVARCHAR(MAX) = NULL;
--    DECLARE @NewValuesJson NVARCHAR(MAX);
--    DECLARE @ActionTypeCode NVARCHAR(50);
--    DECLARE @RecordID INT;
--    DECLARE @CorrelationID UNIQUEIDENTIFIER = NEWID();
--
--    IF @RequirementEvidenceID IS NULL
--    BEGIN
--        INSERT INTO lic.RequirementEvidence
--        (
--            RequirementID,
--            SiteID,
--            ChildID,
--            PersonID,
--            DocumentID,
--            EvidenceTypeCode,
--            EvidenceStatusCode,
--            EvidenceDate,
--            ExpirationDate,
--            Notes,
--            CreatedByUserID
--        )
--        VALUES
--        (
--            @RequirementID,
--            @SiteID,
--            @ChildID,
--            @PersonID,
--            @DocumentID,
--            @EvidenceTypeCode,
--            @EvidenceStatusCode,
--            @EvidenceDate,
--            @ExpirationDate,
--            @Notes,
--            @ChangedByUserID
--        );
--
--        SET @RecordID = SCOPE_IDENTITY();
--        SET @ActionTypeCode = N'INSERT';
--    END
--    ELSE
--    BEGIN
--        SELECT @OldValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--        FROM lic.RequirementEvidence re
--        WHERE re.RequirementEvidenceID = @RequirementEvidenceID
--          AND re.IsDeleted = 0;
--
--        IF @OldValuesJson IS NULL
--            THROW 50331, 'Requirement evidence record not found or deleted.', 1;
--
--        UPDATE lic.RequirementEvidence
--           SET RequirementID = @RequirementID,
--               SiteID = @SiteID,
--               ChildID = @ChildID,
--               PersonID = @PersonID,
--               DocumentID = @DocumentID,
--               EvidenceTypeCode = @EvidenceTypeCode,
--               EvidenceStatusCode = @EvidenceStatusCode,
--               EvidenceDate = @EvidenceDate,
--               ExpirationDate = @ExpirationDate,
--               Notes = @Notes,
--               ModifiedUTC = SYSUTCDATETIME(),
--               ModifiedByUserID = @ChangedByUserID
--         WHERE RequirementEvidenceID = @RequirementEvidenceID
--           AND IsDeleted = 0;
--
--        SET @RecordID = @RequirementEvidenceID;
--        SET @ActionTypeCode = N'UPDATE';
--    END;
--
--    SELECT @NewValuesJson = (SELECT re.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
--    FROM lic.RequirementEvidence re
--    WHERE re.RequirementEvidenceID = @RecordID;
--
--    EXEC audit.usp_WriteAuditLog
--        @SchemaName = N'lic',
--        @TableName = N'RequirementEvidence',
--        @RecordPrimaryKeyValue = CAST(@RecordID AS NVARCHAR(128)),
--        @ActionTypeCode = @ActionTypeCode,
--        @ChangedByUserID = @ChangedByUserID,
--        @ChangeSourceCode = N'APPLICATION',
--        @SiteID = @SiteID,
--        @ChildID = @ChildID,
--        @CorrelationID = @CorrelationID,
--        @ReasonText = @ReasonText,
--        @OldValuesJson = @OldValuesJson,
--        @NewValuesJson = @NewValuesJson;
--
--    SELECT @RecordID AS RequirementEvidenceID;
--END;

GO


:r .\DPA DB 00 - Exists and Drops.sql
:r .\DPA DB 01 - Schema Creation.sql
:r .\DPA DB 02 - ref Schema Objects.sql
:r .\DPA DB 03 - lic Schema Objects.sql
:r .\DPA DB 04 - Party Schema Objects.sql
:r .\DPA DB 05 - Child Schema Objects.sql
:r .\DPA DB 06 - doc Schema Objects.sql
:r .\DPA DB 07 - ops Schema Objects.sql
:r .\DPA DB 08 - comm Schema Objects.sql
:r .\DPA DB 09 - audit Schema Objects.sql
:r .\DPA DB 10 - sec Schema Objects.sql
:r .\DPA DB 11 - Function Objects.sql
:r .\DPA DB 12 - audit Stored Procedures.sql
:r .\DPA DB 13 - child Stored Procedures.sql
:r .\DPA DB 14 - doc Stored Procedures.sql
:r .\DPA DB 15 - ops Stored Procedures.sql
:r .\DPA DB 16 - lic Stored Procedures.sql
:r .\DPA DB 17 - comm Stored Procedures.sql
:r .\DPA DB 18 - rpt View Objects.sql
:r .\DPA DB 19 - End Comments and Execution Notes.sql
:r .\DPA DB 20 - Capacity Inputs and Count Engine Revisions.sql
:r .\DPA DB 21 - Licensing Variance and Requirement Evidence.sql
:r .\DPA DB 22 - Messaging Notification and Participant Management.sql
:r .\DPA DB 23 - Party Core CRUD Stored Procedures.sql
:r .\DPA DB 24 - Document and Consent Write Surface.sql
:r .\DPA DB 25 - Child Medical Lookup Stored Procedures.sql
:r .\DPA DB 26 - Code Tables and Business Rule Constraints.sql
:r .\DPA DB 27 - Security Enforcement Scaffold.sql
:r .\DPA DB 28 - Concurrency Controls.sql
:r .\DPA DB 29 - Guardian Email Identity.sql
:r .\DPA DB 30 - Admin Recovery Workflow.sql
:r .\DPA DB 31 - Compliance Review State.sql
:r .\DPA DB 32 - Seed Strategy and Batches.sql
:r .\DPA DB 33 - Canonical Package Decisions.sql
:r .\DPA DB 34 - Address and Phone CRUD.sql
:r .\DPA DB 35 - Code Table FK Finalization.sql
:r .\DPA DB 36 - Staffing and Counted Child Inputs.sql
:r .\DPA DB 37 - Requirement Evidence and Compliance Finalization.sql

PRINT 'DPA database canonical manual-branch build complete.';
GO

--Syntax Error: Incorrect syntax near '\'.
--
--:r .\DPA DB 00 - Exists and Drops.sql
--:r .\DPA DB 01 - Schema Creation.sql
--:r .\DPA DB 02 - ref Schema Objects.sql
--:r .\DPA DB 03 - lic Schema Objects.sql
--:r .\DPA DB 04 - Party Schema Objects.sql
--:r .\DPA DB 05 - Child Schema Objects.sql
--:r .\DPA DB 06 - doc Schema Objects.sql
--:r .\DPA DB 07 - ops Schema Objects.sql
--:r .\DPA DB 08 - comm Schema Objects.sql
--:r .\DPA DB 09 - audit Schema Objects.sql
--:r .\DPA DB 10 - sec Schema Objects.sql
--:r .\DPA DB 11 - Function Objects.sql
--:r .\DPA DB 12 - audit Stored Procedures.sql
--:r .\DPA DB 13 - child Stored Procedures.sql
--:r .\DPA DB 14 - doc Stored Procedures.sql
--:r .\DPA DB 15 - ops Stored Procedures.sql
--:r .\DPA DB 16 - lic Stored Procedures.sql
--:r .\DPA DB 17 - comm Stored Procedures.sql
--:r .\DPA DB 18 - rpt View Objects.sql
--:r .\DPA DB 19 - End Comments and Execution Notes.sql
--:r .\DPA DB 20 - Capacity Inputs and Count Engine Revisions.sql
--:r .\DPA DB 21 - Licensing Variance and Requirement Evidence.sql
--:r .\DPA DB 22 - Messaging Notification and Participant Management.sql
--:r .\DPA DB 23 - Party Core CRUD Stored Procedures.sql
--:r .\DPA DB 24 - Document and Consent Write Surface.sql
--:r .\DPA DB 25 - Child Medical Lookup Stored Procedures.sql
--:r .\DPA DB 26 - Code Tables and Business Rule Constraints.sql
--:r .\DPA DB 27 - Security Enforcement Scaffold.sql
--:r .\DPA DB 28 - Concurrency Controls.sql
--:r .\DPA DB 29 - Guardian Email Identity.sql
--:r .\DPA DB 30 - Admin Recovery Workflow.sql
--:r .\DPA DB 31 - Compliance Review State.sql
--:r .\DPA DB 32 - Seed Strategy and Batches.sql
--:r .\DPA DB 33 - Canonical Package Decisions.sql
--:r .\DPA DB 34 - Address and Phone CRUD.sql
--:r .\DPA DB 35 - Code Table FK Finalization.sql
--:r .\DPA DB 36 - Staffing and Counted Child Inputs.sql
--:r .\DPA DB 37 - Requirement Evidence and Compliance Finalization.sql
--
--PRINT 'DPA database canonical manual-branch build complete.';



GO
