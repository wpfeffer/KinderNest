CREATE TABLE child.ChildAllergyPlan
(
    ChildAllergyPlanID           INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    PhysicianMedicalProviderID   INT                       NULL,
    AllergenSummary              NVARCHAR(MAX)             NOT NULL,
    TriggerDescription           NVARCHAR(MAX)             NULL,
    AvoidanceInstructions        NVARCHAR(MAX)             NULL,
    SymptomInstructions          NVARCHAR(MAX)             NULL,
    TreatmentInstructions        NVARCHAR(MAX)             NULL,
    EffectiveDate                DATE                      NOT NULL,
    ReviewDate                   DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildAllergyPlan_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildAllergyPlan_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildAllergyPlan_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ChildAllergyPlan PRIMARY KEY CLUSTERED (ChildAllergyPlanID),
    CONSTRAINT FK_ChildAllergyPlan_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
ALTER TABLE child.ChildAllergyPlan ADD CONSTRAINT FK_ChildAllergyPlan_PhysicianMedicalProvider FOREIGN KEY (PhysicianMedicalProviderID) REFERENCES party.MedicalProvider (MedicalProviderID);
GO
CREATE INDEX IX_ChildAllergyPlan_PhysicianMedicalProviderID ON child.ChildAllergyPlan (PhysicianMedicalProviderID) WHERE PhysicianMedicalProviderID IS NOT NULL;
GO
