﻿CREATE TABLE child.ChildEnrollment
(
    ChildEnrollmentID            INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    SiteID                       INT                       NOT NULL,
    EnrollmentStartDate          DATE                      NOT NULL,
    EnrollmentEndDate            DATE                      NULL,
    ScheduleSummary              NVARCHAR(MAX)             NULL,
    FinancialArrangementNotes    NVARCHAR(MAX)             NULL,
    EnrollmentStatusCode         NVARCHAR(50)              NOT NULL,
    IsPrimaryEnrollment          BIT                       NOT NULL CONSTRAINT DF_ChildEnrollment_IsPrimary DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildEnrollment_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildEnrollment_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildEnrollment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(MAX)             NULL,
    CONSTRAINT PK_ChildEnrollment PRIMARY KEY CLUSTERED (ChildEnrollmentID),
    CONSTRAINT FK_ChildEnrollment_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ChildEnrollment_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
);
GO
-- Indexes converted to static to avoid IF statements in model files
CREATE INDEX IX_ChildEnrollment_Child ON child.ChildEnrollment (ChildID, EnrollmentStartDate, EnrollmentEndDate, IsDeleted, IsActive);
GO
CREATE UNIQUE INDEX UX_ChildEnrollment_PrimaryActive
    ON child.ChildEnrollment (ChildID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND IsPrimaryEnrollment = 1;
GO
