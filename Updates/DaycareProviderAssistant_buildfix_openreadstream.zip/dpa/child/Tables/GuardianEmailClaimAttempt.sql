﻿CREATE TABLE child.GuardianEmailClaimAttempt
(
    GuardianEmailClaimAttemptID   BIGINT IDENTITY(1,1)     NOT NULL,
    GuardianInvitationID          INT                      NULL,
    GuardianEmailIdentityID       INT                      NULL,
    AttemptEmailAddress           NVARCHAR(320)            NOT NULL,
    AttemptUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_GuardianEmailClaimAttempt_AttemptUTC DEFAULT (SYSUTCDATETIME()),
    AttemptStatusCode             NVARCHAR(50)             NOT NULL,
    FailureReason                 NVARCHAR(MAX)           NULL,
    AttemptedByPortalUserID       INT                      NULL,
    RemoteAddress                 NVARCHAR(100)            NULL,
    UserAgent                     NVARCHAR(MAX)           NULL,
    CorrelationID                 UNIQUEIDENTIFIER         NULL,
    CONSTRAINT PK_GuardianEmailClaimAttempt PRIMARY KEY CLUSTERED (GuardianEmailClaimAttemptID),
    CONSTRAINT FK_GuardianEmailClaimAttempt_GuardianInvitation FOREIGN KEY (GuardianInvitationID) REFERENCES child.GuardianInvitation (GuardianInvitationID),
    CONSTRAINT FK_GuardianEmailClaimAttempt_GuardianEmailIdentity FOREIGN KEY (GuardianEmailIdentityID) REFERENCES child.GuardianEmailIdentity (GuardianEmailIdentityID),
    CONSTRAINT FK_GuardianEmailClaimAttempt_AttemptedByPortalUser FOREIGN KEY (AttemptedByPortalUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_GuardianEmailClaimAttempt_Invitation
    ON child.GuardianEmailClaimAttempt (GuardianInvitationID, AttemptUTC DESC);