﻿CREATE TABLE child.Child
(
    ChildID                      INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    FirstName                    NVARCHAR(100)             NOT NULL,
    MiddleName                   NVARCHAR(100)             NULL,
    LastName                     NVARCHAR(100)             NOT NULL,
    DateOfBirth                  DATE                      NOT NULL,
    ChildAddressID               INT                       NULL,
    SpecialDietNotes             NVARCHAR(MAX)             NULL,
    SpecialNeedsNotes            NVARCHAR(MAX)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Child_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Child_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Child_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(MAX)             NULL,
    CONSTRAINT PK_Child PRIMARY KEY CLUSTERED (ChildID),
    CONSTRAINT FK_Child_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_Child_Address FOREIGN KEY (ChildAddressID) REFERENCES party.Address (AddressID)
);
GO
-- FK_Child_Address is declared inline in CREATE TABLE; remove duplicate ALTER TABLE to avoid duplicate element
GO
CREATE INDEX IX_Child_SiteID ON child.Child (SiteID, IsDeleted, IsActive);
GO
CREATE INDEX IX_Child_DateOfBirth ON child.Child (DateOfBirth, SiteID) INCLUDE (IsDeleted, IsActive);
GO
GO
CREATE INDEX IX_Child_ChildAddressID ON child.Child (ChildAddressID) WHERE ChildAddressID IS NOT NULL;
GO
