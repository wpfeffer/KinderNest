﻿CREATE TABLE child.GuardianInvitation
(
    GuardianInvitationID         INT IDENTITY(1,1)         NOT NULL,
    ChildPersonRelationshipID    INT                       NOT NULL,
    InvitationEmail              NVARCHAR(320)             NOT NULL,
    InvitationTokenHash          VARBINARY(64)             NOT NULL,
    TokenExpiresUTC              DATETIME2(0)              NOT NULL,
    RedeemedUTC                  DATETIME2(0)              NULL,
    RevokedUTC                   DATETIME2(0)              NULL,
    InvitationStatusCode         NVARCHAR(50)              NOT NULL,
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_GuardianInvitation_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_GuardianInvitation PRIMARY KEY CLUSTERED (GuardianInvitationID),
    CONSTRAINT FK_GuardianInvitation_ChildPersonRelationship FOREIGN KEY (ChildPersonRelationshipID) REFERENCES child.ChildPersonRelationship (ChildPersonRelationshipID)
);
GO
CREATE INDEX IX_GuardianInvitation_Relationship ON child.GuardianInvitation (ChildPersonRelationshipID, InvitationStatusCode, TokenExpiresUTC);
GO
