﻿CREATE TABLE child.ChildAttendance
(
    ChildAttendanceID            INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    SiteID                       INT                       NOT NULL,
    AttendanceDateLocal          DATE                      NOT NULL,
    StartDateTimeUTC             DATETIME2(0)              NOT NULL,
    EndDateTimeUTC               DATETIME2(0)              NOT NULL,
    TimeZoneID                   INT                       NOT NULL,
    CorrectionReason             NVARCHAR(MAX)             NULL,
    Notes                        NVARCHAR(MAX)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildAttendance_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildAttendance_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildAttendance_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ChildAttendance PRIMARY KEY CLUSTERED (ChildAttendanceID),
    CONSTRAINT FK_ChildAttendance_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ChildAttendance_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_ChildAttendance_TimeZone FOREIGN KEY (TimeZoneID) REFERENCES ref.TimeZone (TimeZoneID),
    CONSTRAINT CK_ChildAttendance_UTCWindow CHECK (EndDateTimeUTC > StartDateTimeUTC)
);
GO
-- Static indexes (converted from guarded IF NOT EXISTS to avoid T-SQL control flow in model files)
CREATE INDEX IX_ChildAttendance_Child_LocalDate ON child.ChildAttendance (ChildID, AttendanceDateLocal, IsDeleted, IsActive);
GO
CREATE INDEX IX_ChildAttendance_Site_LocalDate ON child.ChildAttendance (SiteID, AttendanceDateLocal, IsDeleted, IsActive);
GO
