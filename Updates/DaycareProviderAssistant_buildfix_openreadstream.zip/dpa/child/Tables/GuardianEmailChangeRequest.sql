﻿CREATE TABLE child.GuardianEmailChangeRequest
(
    GuardianEmailChangeRequestID  INT IDENTITY(1,1)        NOT NULL,
    GuardianEmailIdentityID       INT                      NOT NULL,
    RequestedEmailAddress         NVARCHAR(320)            NOT NULL,
    NormalizedRequestedEmail      NVARCHAR(320)            NOT NULL,
    RequestStatusCode             NVARCHAR(50)             NOT NULL CONSTRAINT DF_GuardianEmailChangeRequest_RequestStatusCode DEFAULT (N'PENDING'),
    RequestReason                 NVARCHAR(MAX)           NULL,
    RequestedUTC                  DATETIME2(0)             NOT NULL CONSTRAINT DF_GuardianEmailChangeRequest_RequestedUTC DEFAULT (SYSUTCDATETIME()),
    ApprovedUTC                   DATETIME2(0)             NULL,
    ApprovedByUserID              INT                      NULL,
    RejectedUTC                   DATETIME2(0)             NULL,
    RejectedByUserID              INT                      NULL,
    RejectionReason               NVARCHAR(MAX)           NULL,
    CreatedByUserID               INT                      NOT NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_GuardianEmailChangeRequest PRIMARY KEY CLUSTERED (GuardianEmailChangeRequestID),
    CONSTRAINT FK_GuardianEmailChangeRequest_GuardianEmailIdentity FOREIGN KEY (GuardianEmailIdentityID) REFERENCES child.GuardianEmailIdentity (GuardianEmailIdentityID),
    CONSTRAINT FK_GuardianEmailChangeRequest_ApprovedByUser FOREIGN KEY (ApprovedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_GuardianEmailChangeRequest_RejectedByUser FOREIGN KEY (RejectedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_GuardianEmailChangeRequest_Identity
    ON child.GuardianEmailChangeRequest (GuardianEmailIdentityID, RequestedUTC DESC);