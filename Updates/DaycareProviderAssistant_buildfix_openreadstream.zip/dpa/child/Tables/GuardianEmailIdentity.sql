﻿CREATE TABLE child.GuardianEmailIdentity
(
    GuardianEmailIdentityID       INT IDENTITY(1,1)        NOT NULL,
    ChildPersonRelationshipID     INT                      NOT NULL,
    EmailAddress                  NVARCHAR(320)            NOT NULL,
    NormalizedEmailAddress        NVARCHAR(320)            NOT NULL,
    EmailVerifiedUTC              DATETIME2(0)             NULL,
    VerifiedByInvitationID        INT                      NULL,
    IdentityStatusCode            NVARCHAR(50)             NOT NULL CONSTRAINT DF_GuardianEmailIdentity_IdentityStatusCode DEFAULT (N'PENDING'),
    IsPrimaryEmail                BIT                      NOT NULL CONSTRAINT DF_GuardianEmailIdentity_IsPrimaryEmail DEFAULT (1),
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_GuardianEmailIdentity_IsActive DEFAULT (1),
    IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_GuardianEmailIdentity_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_GuardianEmailIdentity_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NOT NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    DeletedUTC                    DATETIME2(0)             NULL,
    DeletedByUserID               INT                      NULL,
    DeletedReason                 NVARCHAR(500)            NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_GuardianEmailIdentity PRIMARY KEY CLUSTERED (GuardianEmailIdentityID),
    CONSTRAINT FK_GuardianEmailIdentity_ChildPersonRelationship FOREIGN KEY (ChildPersonRelationshipID) REFERENCES child.ChildPersonRelationship (ChildPersonRelationshipID),
    CONSTRAINT FK_GuardianEmailIdentity_VerifiedByInvitation FOREIGN KEY (VerifiedByInvitationID) REFERENCES child.GuardianInvitation (GuardianInvitationID)
);
GO
CREATE UNIQUE INDEX UX_GuardianEmailIdentity_Relationship_PrimaryActive
    ON child.GuardianEmailIdentity (ChildPersonRelationshipID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND IsPrimaryEmail = 1;
GO
CREATE INDEX IX_GuardianEmailIdentity_NormalizedEmailAddress
    ON child.GuardianEmailIdentity (NormalizedEmailAddress, IsDeleted, IsActive);