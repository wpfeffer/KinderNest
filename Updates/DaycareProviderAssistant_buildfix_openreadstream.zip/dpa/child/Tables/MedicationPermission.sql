﻿CREATE TABLE child.MedicationPermission
(
    MedicationPermissionID       INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    ConsentTypeCode              NVARCHAR(50)              NOT NULL,
    IsApproved                   BIT                       NOT NULL,
    Instructions                 NVARCHAR(MAX)             NULL,
    EffectiveDate                DATE                      NOT NULL,
    ExpirationDate               DATE                      NULL,
    SignedByPersonID             INT                       NULL,
    SignedUTC                    DATETIME2(0)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_MedicationPermission_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_MedicationPermission_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_MedicationPermission_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_MedicationPermission PRIMARY KEY CLUSTERED (MedicationPermissionID),
    CONSTRAINT FK_MedicationPermission_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_MedicationPermission_SignedByPerson FOREIGN KEY (SignedByPersonID) REFERENCES party.Person (PersonID)
);