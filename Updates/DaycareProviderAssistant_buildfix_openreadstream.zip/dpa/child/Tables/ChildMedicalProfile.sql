CREATE TABLE child.ChildMedicalProfile
(
    ChildMedicalProfileID        INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    PrimaryCarePhysicianID       INT                       NULL,
    DentistMedicalProviderID     INT                       NULL,
    HospitalID                   INT                       NULL,
    EmergencyMedicalConsentFlag  BIT                       NOT NULL CONSTRAINT DF_ChildMedicalProfile_EmergencyMedicalConsent DEFAULT (0),
    MedicalNotes                 NVARCHAR(MAX)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildMedicalProfile_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildMedicalProfile_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildMedicalProfile_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ChildMedicalProfile PRIMARY KEY CLUSTERED (ChildMedicalProfileID),
    CONSTRAINT FK_ChildMedicalProfile_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT UQ_ChildMedicalProfile_Child UNIQUE (ChildID)
);
GO
ALTER TABLE child.ChildMedicalProfile ADD CONSTRAINT FK_ChildMedicalProfile_PrimaryCarePhysician FOREIGN KEY (PrimaryCarePhysicianID) REFERENCES party.MedicalProvider (MedicalProviderID);
GO
ALTER TABLE child.ChildMedicalProfile ADD CONSTRAINT FK_ChildMedicalProfile_DentistMedicalProvider FOREIGN KEY (DentistMedicalProviderID) REFERENCES party.MedicalProvider (MedicalProviderID);
GO
ALTER TABLE child.ChildMedicalProfile ADD CONSTRAINT FK_ChildMedicalProfile_Hospital FOREIGN KEY (HospitalID) REFERENCES party.Hospital (HospitalID);
GO
CREATE INDEX IX_ChildMedicalProfile_PrimaryCarePhysicianID ON child.ChildMedicalProfile (PrimaryCarePhysicianID) WHERE PrimaryCarePhysicianID IS NOT NULL;
GO
CREATE INDEX IX_ChildMedicalProfile_DentistMedicalProviderID ON child.ChildMedicalProfile (DentistMedicalProviderID) WHERE DentistMedicalProviderID IS NOT NULL;
GO
CREATE INDEX IX_ChildMedicalProfile_HospitalID ON child.ChildMedicalProfile (HospitalID) WHERE HospitalID IS NOT NULL;
GO
