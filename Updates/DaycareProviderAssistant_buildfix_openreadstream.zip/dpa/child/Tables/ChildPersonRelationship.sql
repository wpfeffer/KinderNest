﻿CREATE TABLE child.ChildPersonRelationship
(
    ChildPersonRelationshipID    INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    PersonID                     INT                       NOT NULL,
    RelationshipTypeCode         NVARCHAR(50)              NOT NULL,
    HasPortalAccess              BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_HasPortalAccess DEFAULT (0),
    CanReceiveAlerts             BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_CanReceiveAlerts DEFAULT (0),
    CanSignPermissions           BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_CanSignPermissions DEFAULT (0),
    IsPrimaryGuardian            BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_IsPrimaryGuardian DEFAULT (0),
    EffectiveStartDate           DATE                      NOT NULL,
    EffectiveEndDate             DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildPersonRelationship_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildPersonRelationship_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ChildPersonRelationship PRIMARY KEY CLUSTERED (ChildPersonRelationshipID),
    CONSTRAINT FK_ChildPersonRelationship_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ChildPersonRelationship_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID)
);
GO
-- Convert guarded index creation to static statements and remove duplicate unique index
CREATE INDEX IX_ChildPersonRelationship_Child ON child.ChildPersonRelationship (ChildID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
CREATE INDEX IX_ChildPersonRelationship_Person ON child.ChildPersonRelationship (PersonID, IsDeleted, IsActive);
GO
CREATE UNIQUE INDEX UX_ChildPersonRelationship_PrimaryGuardianActive
    ON child.ChildPersonRelationship (ChildID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND IsPrimaryGuardian = 1;
GO
