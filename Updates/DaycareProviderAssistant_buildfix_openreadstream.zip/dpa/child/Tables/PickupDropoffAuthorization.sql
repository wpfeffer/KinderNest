﻿CREATE TABLE child.PickupDropoffAuthorization
(
    PickupDropoffAuthorizationID INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    PersonID                     INT                       NOT NULL,
    CanPickup                    BIT                       NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_CanPickup DEFAULT (0),
    CanDropoff                   BIT                       NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_CanDropoff DEFAULT (0),
    IsEmergencyContact           BIT                       NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_IsEmergencyContact DEFAULT (0),
    Notes                        NVARCHAR(MAX)             NULL,
    EffectiveStartDate           DATE                      NOT NULL,
    EffectiveEndDate             DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_PickupDropoffAuthorization_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_PickupDropoffAuthorization PRIMARY KEY CLUSTERED (PickupDropoffAuthorizationID),
    CONSTRAINT FK_PickupDropoffAuthorization_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_PickupDropoffAuthorization_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID)
);
GO
CREATE INDEX IX_PickupDropoffAuthorization_Child ON child.PickupDropoffAuthorization (ChildID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
