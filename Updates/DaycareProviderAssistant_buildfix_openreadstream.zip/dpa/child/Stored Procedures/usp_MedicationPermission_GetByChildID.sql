﻿CREATE PROCEDURE child.usp_MedicationPermission_GetByChildID
    @ChildID                     INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        mp.MedicationPermissionID,
        mp.ChildID,
        mp.ConsentTypeCode,
        mp.IsApproved,
        mp.Instructions,
        mp.EffectiveDate,
        mp.ExpirationDate,
        mp.SignedByPersonID,
        p.FirstName AS SignedByFirstName,
        p.LastName AS SignedByLastName,
        mp.SignedUTC,
        mp.IsActive,
        mp.IsDeleted,
        mp.CreatedUTC,
        mp.CreatedByUserID,
        mp.ModifiedUTC,
        mp.ModifiedByUserID,
        mp.DeletedUTC,
        mp.DeletedByUserID,
        mp.DeletedReason
    FROM child.MedicationPermission mp
    LEFT JOIN party.Person p
        ON p.PersonID = mp.SignedByPersonID
    WHERE mp.ChildID = @ChildID
      AND mp.IsDeleted = 0
    ORDER BY mp.EffectiveDate DESC, mp.MedicationPermissionID DESC;
END;