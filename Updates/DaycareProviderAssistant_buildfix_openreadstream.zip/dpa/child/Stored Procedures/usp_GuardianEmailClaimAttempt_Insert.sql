﻿CREATE PROCEDURE child.usp_GuardianEmailClaimAttempt_Insert
    @GuardianInvitationID          INT                = NULL,
    @GuardianEmailIdentityID       INT                = NULL,
    @AttemptEmailAddress           NVARCHAR(320),
    @AttemptStatusCode             NVARCHAR(50),
    @FailureReason                 NVARCHAR(MAX)     = NULL,
    @AttemptedByPortalUserID       INT                = NULL,
    @RemoteAddress                 NVARCHAR(100)      = NULL,
    @UserAgent                     NVARCHAR(MAX)     = NULL,
    @CorrelationID                 UNIQUEIDENTIFIER   = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO child.GuardianEmailClaimAttempt
    (
        GuardianInvitationID,
        GuardianEmailIdentityID,
        AttemptEmailAddress,
        AttemptStatusCode,
        FailureReason,
        AttemptedByPortalUserID,
        RemoteAddress,
        UserAgent,
        CorrelationID
    )
    VALUES
    (
        @GuardianInvitationID,
        @GuardianEmailIdentityID,
        @AttemptEmailAddress,
        @AttemptStatusCode,
        @FailureReason,
        @AttemptedByPortalUserID,
        @RemoteAddress,
        @UserAgent,
        @CorrelationID
    );

    SELECT SCOPE_IDENTITY() AS GuardianEmailClaimAttemptID;
END;