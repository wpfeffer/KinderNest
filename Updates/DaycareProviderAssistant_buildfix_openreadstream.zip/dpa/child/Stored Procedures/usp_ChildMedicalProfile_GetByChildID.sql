CREATE OR ALTER PROCEDURE child.usp_ChildMedicalProfile_GetByChildID
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        cmp.ChildMedicalProfileID,
        cmp.ChildID,
        cmp.PrimaryCarePhysicianID,
        physician.ProviderName AS PhysicianName,
        physician.PhoneNumberID AS PhysicianPhoneNumberID,
        cmp.DentistMedicalProviderID,
        dentist.ProviderName AS DentistName,
        dentist.PhoneNumberID AS DentistPhoneNumberID,
        cmp.HospitalID,
        hospital.HospitalName,
        hospital.MainPhoneNumberID AS HospitalPhoneNumberID,
        cmp.EmergencyMedicalConsentFlag,
        cmp.MedicalNotes,
        cmp.IsActive,
        cmp.IsDeleted,
        cmp.CreatedUTC,
        cmp.CreatedByUserID,
        cmp.ModifiedUTC,
        cmp.ModifiedByUserID,
        cmp.DeletedUTC,
        cmp.DeletedByUserID,
        cmp.DeletedReason
    FROM child.ChildMedicalProfile cmp
    LEFT JOIN party.MedicalProvider physician ON physician.MedicalProviderID = cmp.PrimaryCarePhysicianID
    LEFT JOIN party.MedicalProvider dentist ON dentist.MedicalProviderID = cmp.DentistMedicalProviderID
    LEFT JOIN party.Hospital hospital ON hospital.HospitalID = cmp.HospitalID
    WHERE cmp.ChildID = @ChildID
      AND cmp.IsDeleted = 0;
END;
GO
