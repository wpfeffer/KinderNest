CREATE OR ALTER PROCEDURE child.usp_ChildAllergyPlan_GetByChildID
    @ChildID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        cap.ChildAllergyPlanID,
        cap.ChildID,
        cap.PhysicianMedicalProviderID,
        physician.ProviderName AS PhysicianName,
        physician.PhoneNumberID AS PhysicianPhoneNumberID,
        cap.AllergenSummary,
        cap.TriggerDescription,
        cap.AvoidanceInstructions,
        cap.SymptomInstructions,
        cap.TreatmentInstructions,
        cap.EffectiveDate,
        cap.ReviewDate,
        cap.IsActive,
        cap.IsDeleted,
        cap.CreatedUTC,
        cap.CreatedByUserID,
        cap.ModifiedUTC,
        cap.ModifiedByUserID,
        cap.DeletedUTC,
        cap.DeletedByUserID,
        cap.DeletedReason
    FROM child.ChildAllergyPlan cap
    LEFT JOIN party.MedicalProvider physician ON physician.MedicalProviderID = cap.PhysicianMedicalProviderID
    WHERE cap.ChildID = @ChildID
      AND cap.IsDeleted = 0
    ORDER BY cap.EffectiveDate DESC, cap.ChildAllergyPlanID DESC;
END;
GO
