﻿CREATE FUNCTION child.fn_CalculateAgeInDays
(
    @DateOfBirth         DATE,
    @EvaluationDateLocal DATE
)
RETURNS INT
AS
BEGIN
    DECLARE @AgeInDays INT;

    SET @AgeInDays = DATEDIFF(DAY, @DateOfBirth, @EvaluationDateLocal);

    RETURN @AgeInDays;
END;