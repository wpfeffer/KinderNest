﻿CREATE PROCEDURE audit.usp_WriteAuditLog
    @SchemaName                 NVARCHAR(128),
    @TableName                  NVARCHAR(128),
    @RecordPrimaryKeyValue      NVARCHAR(128),
    @ActionTypeCode             NVARCHAR(50),
    @ChangedByUserID            INT                 = NULL,
    @ChangeSourceCode           NVARCHAR(50),
    @SiteID                     INT                 = NULL,
    @ChildID                    INT                 = NULL,
    @CorrelationID              UNIQUEIDENTIFIER    = NULL,
    @ReasonText                 NVARCHAR(MAX)      = NULL,
    @OldValuesJson              NVARCHAR(MAX)       = NULL,
    @NewValuesJson              NVARCHAR(MAX)       = NULL,
    @AffectedColumnsJson        NVARCHAR(MAX)       = NULL,
    @SucceededFlag              BIT                 = 1,
    @FailureMessage             NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO audit.AuditLog
    (
        SchemaName,
        TableName,
        RecordPrimaryKeyValue,
        ActionTypeCode,
        ChangedByUserID,
        ChangeSourceCode,
        SiteID,
        ChildID,
        CorrelationID,
        ReasonText,
        OldValuesJson,
        NewValuesJson,
        AffectedColumnsJson,
        SucceededFlag,
        FailureMessage
    )
    VALUES
    (
        @SchemaName,
        @TableName,
        @RecordPrimaryKeyValue,
        @ActionTypeCode,
        @ChangedByUserID,
        @ChangeSourceCode,
        @SiteID,
        @ChildID,
        @CorrelationID,
        @ReasonText,
        @OldValuesJson,
        @NewValuesJson,
        @AffectedColumnsJson,
        @SucceededFlag,
        @FailureMessage
    );
END;