CREATE OR ALTER PROCEDURE audit.usp_WriteAuthenticationEvent
    @AuthenticationEventTypeCode    NVARCHAR(100),
    @AuthenticationResultCode       NVARCHAR(100),
    @PortalUserID                   INT                = NULL,
    @PortalCredentialID             INT                = NULL,
    @LoginSessionID                 BIGINT             = NULL,
    @UserNameAttempted              NVARCHAR(320)      = NULL,
    @FailureReason                  NVARCHAR(MAX)      = NULL,
    @SiteID                         INT                = NULL,
    @RemoteAddress                  NVARCHAR(100)      = NULL,
    @UserAgent                      NVARCHAR(MAX)      = NULL,
    @CorrelationID                  UNIQUEIDENTIFIER   = NULL,
    @Notes                          NVARCHAR(MAX)      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @AuthenticationEventTypeCodeValueID INT;
    DECLARE @AuthenticationResultCodeValueID INT;

    SELECT @AuthenticationEventTypeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationEventType'
      AND cv.CodeValue = @AuthenticationEventTypeCode
      AND cv.IsActive = 1;

    SELECT @AuthenticationResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = @AuthenticationResultCode
      AND cv.IsActive = 1;

    IF @AuthenticationEventTypeCodeValueID IS NULL
    BEGIN
        THROW 50400, 'Authentication event type code was not found in ref.CodeValue.', 1;
    END;

    IF @AuthenticationResultCodeValueID IS NULL
    BEGIN
        THROW 50401, 'Authentication result code was not found in ref.CodeValue.', 1;
    END;

    INSERT INTO audit.AuthenticationEvent
    (
        PortalUserID,
        PortalCredentialID,
        LoginSessionID,
        UserNameAttempted,
        AuthenticationEventTypeCodeValueID,
        AuthenticationResultCodeValueID,
        FailureReason,
        SiteID,
        RemoteAddress,
        UserAgent,
        CorrelationID,
        Notes
    )
    VALUES
    (
        @PortalUserID,
        @PortalCredentialID,
        @LoginSessionID,
        @UserNameAttempted,
        @AuthenticationEventTypeCodeValueID,
        @AuthenticationResultCodeValueID,
        @FailureReason,
        @SiteID,
        @RemoteAddress,
        @UserAgent,
        @CorrelationID,
        @Notes
    );

    SELECT SCOPE_IDENTITY() AS AuthenticationEventID;
END;
GO
