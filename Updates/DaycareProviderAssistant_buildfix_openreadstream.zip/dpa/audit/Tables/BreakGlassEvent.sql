﻿CREATE TABLE audit.BreakGlassEvent
(
    BreakGlassEventID            BIGINT IDENTITY(1,1)      NOT NULL,
    EventUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_BreakGlassEvent_EventUTC DEFAULT (SYSUTCDATETIME()),
    InitiatedByUserID            INT                       NULL,
    ApprovedByUserID             INT                       NULL,
    CaseNumber                   NVARCHAR(100)             NULL,
    ReasonText                   NVARCHAR(MAX)            NOT NULL,
    TargetSchemaName             NVARCHAR(128)             NULL,
    TargetTableName              NVARCHAR(128)             NULL,
    TargetPrimaryKeyValue        NVARCHAR(128)             NULL,
    DecryptionRequiredFlag       BIT                       NOT NULL CONSTRAINT DF_BreakGlassEvent_DecryptionRequiredFlag DEFAULT (0),
    CompletedUTC                 DATETIME2(0)              NULL,
    CompletionStatusCode         NVARCHAR(50)              NOT NULL CONSTRAINT DF_BreakGlassEvent_CompletionStatusCode DEFAULT (N'OPEN'),
    Notes                        NVARCHAR(MAX)            NULL,
    CONSTRAINT PK_BreakGlassEvent PRIMARY KEY CLUSTERED (BreakGlassEventID),
    CONSTRAINT FK_BreakGlassEvent_InitiatedByUser FOREIGN KEY (InitiatedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_BreakGlassEvent_ApprovedByUser FOREIGN KEY (ApprovedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_BreakGlassEvent_Status ON audit.BreakGlassEvent (CompletionStatusCode, EventUTC DESC);