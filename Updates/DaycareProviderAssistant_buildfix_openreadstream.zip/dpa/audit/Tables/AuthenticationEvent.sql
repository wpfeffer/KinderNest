IF OBJECT_ID(N'audit.AuthenticationEvent', N'U') IS NULL
BEGIN
    CREATE TABLE audit.AuthenticationEvent
    (
        AuthenticationEventID          BIGINT IDENTITY(1,1)      NOT NULL,
        EventUTC                       DATETIME2(0)              NOT NULL CONSTRAINT DF_AuthenticationEvent_EventUTC DEFAULT (SYSUTCDATETIME()),
        PortalUserID                   INT                       NULL,
        PortalCredentialID             INT                       NULL,
        LoginSessionID                 BIGINT                    NULL,
        UserNameAttempted              NVARCHAR(320)             NULL,
        AuthenticationEventTypeCodeValueID INT                  NOT NULL,
        AuthenticationResultCodeValueID    INT                  NOT NULL,
        FailureReason                  NVARCHAR(MAX)             NULL,
        SiteID                         INT                       NULL,
        RemoteAddress                  NVARCHAR(100)             NULL,
        UserAgent                      NVARCHAR(MAX)             NULL,
        CorrelationID                  UNIQUEIDENTIFIER          NULL,
        Notes                          NVARCHAR(MAX)             NULL,
        CONSTRAINT PK_AuthenticationEvent PRIMARY KEY CLUSTERED (AuthenticationEventID),
        CONSTRAINT FK_AuthenticationEvent_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
        CONSTRAINT FK_AuthenticationEvent_PortalCredential FOREIGN KEY (PortalCredentialID) REFERENCES sec.PortalCredential (PortalCredentialID),
        CONSTRAINT FK_AuthenticationEvent_LoginSession FOREIGN KEY (LoginSessionID) REFERENCES sec.LoginSession (LoginSessionID),
        CONSTRAINT FK_AuthenticationEvent_AuthenticationEventTypeCodeValue FOREIGN KEY (AuthenticationEventTypeCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_AuthenticationEvent_AuthenticationResultCodeValue FOREIGN KEY (AuthenticationResultCodeValueID) REFERENCES ref.CodeValue (CodeValueID),
        CONSTRAINT FK_AuthenticationEvent_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_PortalUserID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_PortalUserID ON audit.AuthenticationEvent (PortalUserID, EventUTC DESC) WHERE PortalUserID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_PortalCredentialID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_PortalCredentialID ON audit.AuthenticationEvent (PortalCredentialID, EventUTC DESC) WHERE PortalCredentialID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_LoginSessionID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_LoginSessionID ON audit.AuthenticationEvent (LoginSessionID, EventUTC DESC) WHERE LoginSessionID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_EventTypeResult' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_EventTypeResult ON audit.AuthenticationEvent (AuthenticationEventTypeCodeValueID, AuthenticationResultCodeValueID, EventUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_AuthenticationResultCodeValueID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_AuthenticationResultCodeValueID ON audit.AuthenticationEvent (AuthenticationResultCodeValueID, EventUTC DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_SiteID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_SiteID ON audit.AuthenticationEvent (SiteID, EventUTC DESC) WHERE SiteID IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthenticationEvent_CorrelationID' AND object_id = OBJECT_ID(N'audit.AuthenticationEvent'))
    CREATE INDEX IX_AuthenticationEvent_CorrelationID ON audit.AuthenticationEvent (CorrelationID, EventUTC DESC) WHERE CorrelationID IS NOT NULL;
GO
