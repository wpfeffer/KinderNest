﻿CREATE TABLE audit.AuditLog
(
    AuditLogID                   BIGINT IDENTITY(1,1)      NOT NULL,
    EventUTC                     DATETIME2(0)              NOT NULL CONSTRAINT DF_AuditLog_EventUTC DEFAULT (SYSUTCDATETIME()),
    SchemaName                   NVARCHAR(128)             NOT NULL,
    TableName                    NVARCHAR(128)             NOT NULL,
    RecordPrimaryKeyValue        NVARCHAR(128)             NOT NULL,
    ActionTypeCode               NVARCHAR(50)              NOT NULL,
    ChangedByUserID              INT                       NULL,
    ChangeSourceCode             NVARCHAR(50)              NOT NULL,
    SiteID                       INT                       NULL,
    ChildID                      INT                       NULL,
    CorrelationID                UNIQUEIDENTIFIER          NULL,
    ReasonText                   NVARCHAR(MAX)            NULL,
    OldValuesJson                NVARCHAR(MAX)             NULL,
    NewValuesJson                NVARCHAR(MAX)             NULL,
    AffectedColumnsJson          NVARCHAR(MAX)             NULL,
    SucceededFlag                BIT                       NOT NULL CONSTRAINT DF_AuditLog_SucceededFlag DEFAULT (1),
    FailureMessage               NVARCHAR(MAX)            NULL,
    CONSTRAINT PK_AuditLog PRIMARY KEY CLUSTERED (AuditLogID),
    CONSTRAINT FK_AuditLog_ChangedByUser FOREIGN KEY (ChangedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_AuditLog_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_AuditLog_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_AuditLog_SchemaTableRecord ON audit.AuditLog (SchemaName, TableName, RecordPrimaryKeyValue, EventUTC DESC);
GO
CREATE INDEX IX_AuditLog_SiteID ON audit.AuditLog (SiteID, EventUTC DESC);
GO
CREATE INDEX IX_AuditLog_ChildID ON audit.AuditLog (ChildID, EventUTC DESC) WHERE ChildID IS NOT NULL;
GO
CREATE INDEX IX_AuditLog_ChangedByUserID ON audit.AuditLog (ChangedByUserID, EventUTC DESC) WHERE ChangedByUserID IS NOT NULL;