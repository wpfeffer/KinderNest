﻿CREATE TABLE audit.RecoveryApproval
(
    RecoveryApprovalID            BIGINT IDENTITY(1,1)     NOT NULL,
    RecoveryRequestID             BIGINT                   NOT NULL,
    ApprovedByUserID              INT                      NOT NULL,
    ApprovalDecisionCode          NVARCHAR(50)             NOT NULL,
    ApprovalReason                NVARCHAR(MAX)           NULL,
    ApprovedUTC                   DATETIME2(0)             NOT NULL CONSTRAINT DF_RecoveryApproval_ApprovedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_RecoveryApproval PRIMARY KEY CLUSTERED (RecoveryApprovalID),
    CONSTRAINT FK_RecoveryApproval_RecoveryRequest FOREIGN KEY (RecoveryRequestID) REFERENCES audit.RecoveryRequest (RecoveryRequestID),
    CONSTRAINT FK_RecoveryApproval_ApprovedByUser FOREIGN KEY (ApprovedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_RecoveryApproval_RequestID ON audit.RecoveryApproval (RecoveryRequestID, ApprovedUTC DESC);