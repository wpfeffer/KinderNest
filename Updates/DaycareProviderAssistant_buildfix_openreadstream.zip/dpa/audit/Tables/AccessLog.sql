﻿CREATE TABLE audit.AccessLog
(
    AccessLogID                  BIGINT IDENTITY(1,1)      NOT NULL,
    AccessUTC                    DATETIME2(0)              NOT NULL CONSTRAINT DF_AccessLog_AccessUTC DEFAULT (SYSUTCDATETIME()),
    AccessTypeCode               NVARCHAR(50)              NOT NULL,
    AccessedByUserID             INT                       NULL,
    AccessedRoleCode             NVARCHAR(50)              NULL,
    SiteID                       INT                       NULL,
    ChildID                      INT                       NULL,
    AccessScopeCode              NVARCHAR(50)              NOT NULL,
    AccessScopeDetail            NVARCHAR(MAX)            NULL,
    IsProviderNotified           BIT                       NOT NULL CONSTRAINT DF_AccessLog_IsProviderNotified DEFAULT (0),
    ProviderNotificationUTC      DATETIME2(0)              NULL,
    CorrelationID                UNIQUEIDENTIFIER          NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    CONSTRAINT PK_AccessLog PRIMARY KEY CLUSTERED (AccessLogID),
    CONSTRAINT FK_AccessLog_AccessedByUser FOREIGN KEY (AccessedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_AccessLog_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_AccessLog_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_AccessLog_SiteID ON audit.AccessLog (SiteID, AccessUTC DESC);
GO
CREATE INDEX IX_AccessLog_AccessedByUserID ON audit.AccessLog (AccessedByUserID, AccessUTC DESC) WHERE AccessedByUserID IS NOT NULL;
GO
CREATE INDEX IX_AccessLog_ChildID ON audit.AccessLog (ChildID, AccessUTC DESC) WHERE ChildID IS NOT NULL;