﻿CREATE TABLE audit.RecoveryRequest
(
    RecoveryRequestID             BIGINT IDENTITY(1,1)     NOT NULL,
    TargetSchemaName              NVARCHAR(128)            NOT NULL,
    TargetTableName               NVARCHAR(128)            NOT NULL,
    TargetPrimaryKeyValue         NVARCHAR(128)            NOT NULL,
    SiteID                        INT                      NULL,
    ChildID                       INT                      NULL,
    RequestedByUserID             INT                      NOT NULL,
    RequestReason                 NVARCHAR(MAX)           NOT NULL,
    RequestStatusCode             NVARCHAR(50)             NOT NULL CONSTRAINT DF_RecoveryRequest_RequestStatusCode DEFAULT (N'PENDING'),
    RequestedUTC                  DATETIME2(0)             NOT NULL CONSTRAINT DF_RecoveryRequest_RequestedUTC DEFAULT (SYSUTCDATETIME()),
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_RecoveryRequest PRIMARY KEY CLUSTERED (RecoveryRequestID),
    CONSTRAINT FK_RecoveryRequest_RequestedByUser FOREIGN KEY (RequestedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_RecoveryRequest_ModifiedByUser FOREIGN KEY (ModifiedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_RecoveryRequest_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_RecoveryRequest_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_RecoveryRequest_Status ON audit.RecoveryRequest (RequestStatusCode, RequestedUTC DESC);
GO
CREATE INDEX IX_RecoveryRequest_Target ON audit.RecoveryRequest (TargetSchemaName, TargetTableName, TargetPrimaryKeyValue, RequestedUTC DESC);