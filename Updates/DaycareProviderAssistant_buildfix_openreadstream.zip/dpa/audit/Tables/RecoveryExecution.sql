﻿CREATE TABLE audit.RecoveryExecution
(
    RecoveryExecutionID           BIGINT IDENTITY(1,1)     NOT NULL,
    RecoveryRequestID             BIGINT                   NOT NULL,
    ExecutedByUserID              INT                      NOT NULL,
    ExecutionUTC                  DATETIME2(0)             NOT NULL CONSTRAINT DF_RecoveryExecution_ExecutionUTC DEFAULT (SYSUTCDATETIME()),
    ExecutionStatusCode           NVARCHAR(50)             NOT NULL,
    ExecutionNotes                NVARCHAR(MAX)           NULL,
    CONSTRAINT PK_RecoveryExecution PRIMARY KEY CLUSTERED (RecoveryExecutionID),
    CONSTRAINT FK_RecoveryExecution_RecoveryRequest FOREIGN KEY (RecoveryRequestID) REFERENCES audit.RecoveryRequest (RecoveryRequestID),
    CONSTRAINT FK_RecoveryExecution_ExecutedByUser FOREIGN KEY (ExecutedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_RecoveryExecution_RequestID ON audit.RecoveryExecution (RecoveryRequestID, ExecutionUTC DESC);