﻿CREATE TABLE audit.NotificationLog
(
    NotificationLogID            BIGINT IDENTITY(1,1)      NOT NULL,
    NotificationUTC              DATETIME2(0)              NOT NULL CONSTRAINT DF_NotificationLog_NotificationUTC DEFAULT (SYSUTCDATETIME()),
    NotificationTypeCode         NVARCHAR(50)              NOT NULL,
    RecipientUserID              INT                       NULL,
    RecipientEmail               NVARCHAR(320)             NULL,
    RelatedAccessLogID           BIGINT                    NULL,
    RelatedConversationID        INT                       NULL,
    DeliveryStatusCode           NVARCHAR(50)              NOT NULL,
    SubjectLine                  NVARCHAR(500)             NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    CONSTRAINT PK_NotificationLog PRIMARY KEY CLUSTERED (NotificationLogID),
    CONSTRAINT FK_NotificationLog_RecipientUser FOREIGN KEY (RecipientUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_NotificationLog_RelatedAccessLog FOREIGN KEY (RelatedAccessLogID) REFERENCES audit.AccessLog (AccessLogID),
    CONSTRAINT FK_NotificationLog_RelatedConversation FOREIGN KEY (RelatedConversationID) REFERENCES comm.Conversation (ConversationID)
);
GO
CREATE INDEX IX_NotificationLog_RecipientUserID ON audit.NotificationLog (RecipientUserID, NotificationUTC DESC) WHERE RecipientUserID IS NOT NULL;