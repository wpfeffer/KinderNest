﻿CREATE TABLE audit.DataExportLog
(
    DataExportLogID              BIGINT IDENTITY(1,1)      NOT NULL,
    ExportUTC                    DATETIME2(0)              NOT NULL CONSTRAINT DF_DataExportLog_ExportUTC DEFAULT (SYSUTCDATETIME()),
    ExportedByUserID             INT                       NULL,
    ExportTypeCode               NVARCHAR(50)              NOT NULL,
    ScopeCode                    NVARCHAR(50)              NOT NULL,
    SiteID                       INT                       NULL,
    ChildID                      INT                       NULL,
    ExportFormatCode             NVARCHAR(50)              NOT NULL,
    RecordCount                  INT                       NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    CorrelationID                UNIQUEIDENTIFIER          NULL,
    CONSTRAINT PK_DataExportLog PRIMARY KEY CLUSTERED (DataExportLogID),
    CONSTRAINT FK_DataExportLog_ExportedByUser FOREIGN KEY (ExportedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_DataExportLog_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_DataExportLog_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_DataExportLog_SiteID ON audit.DataExportLog (SiteID, ExportUTC DESC) WHERE SiteID IS NOT NULL;