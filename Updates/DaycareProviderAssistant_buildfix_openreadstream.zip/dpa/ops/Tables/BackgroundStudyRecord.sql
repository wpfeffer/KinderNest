﻿CREATE TABLE ops.BackgroundStudyRecord
(
    BackgroundStudyRecordID      INT IDENTITY(1,1)         NOT NULL,
    StaffAssignmentID            INT                       NOT NULL,
    StudyStatusCode              NVARCHAR(50)              NOT NULL,
    SubmittedDate                DATE                      NULL,
    ClearedDate                  DATE                      NULL,
    ExpirationDate               DATE                      NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_BackgroundStudyRecord_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_BackgroundStudyRecord_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_BackgroundStudyRecord_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_BackgroundStudyRecord PRIMARY KEY CLUSTERED (BackgroundStudyRecordID),
    CONSTRAINT FK_BackgroundStudyRecord_StaffAssignment FOREIGN KEY (StaffAssignmentID) REFERENCES ops.StaffAssignment (StaffAssignmentID)
);
GO
CREATE INDEX IX_BackgroundStudyRecord_StaffAssignmentID ON ops.BackgroundStudyRecord (StaffAssignmentID, StudyStatusCode, IsDeleted, IsActive);