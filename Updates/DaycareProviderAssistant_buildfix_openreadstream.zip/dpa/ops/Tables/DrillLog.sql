﻿CREATE TABLE ops.DrillLog
(
    DrillLogID                   INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    DrillTypeCode                NVARCHAR(50)              NOT NULL,
    DrillDateLocal               DATE                      NOT NULL,
    DrillTimeLocal               TIME(0)                   NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_DrillLog_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_DrillLog_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_DrillLog_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_DrillLog PRIMARY KEY CLUSTERED (DrillLogID),
    CONSTRAINT FK_DrillLog_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
);
GO
CREATE INDEX IX_DrillLog_SiteID ON ops.DrillLog (SiteID, DrillDateLocal, IsDeleted, IsActive);