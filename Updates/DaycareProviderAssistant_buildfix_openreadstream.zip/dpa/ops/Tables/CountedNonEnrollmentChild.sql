﻿CREATE TABLE ops.CountedNonEnrollmentChild
    (
        CountedNonEnrollmentChildID   INT IDENTITY(1,1)        NOT NULL,
        SiteID                        INT                      NOT NULL,
        ChildDisplayName              NVARCHAR(200)            NOT NULL,
        DateOfBirth                   DATE                     NOT NULL,
        RelationshipToProviderCode    NVARCHAR(50)             NOT NULL,
        CountsTowardCapacityFlag      BIT                      NOT NULL CONSTRAINT DF_CountedNonEnrollmentChild_Counts DEFAULT (1),
        EffectiveStartDate            DATE                     NOT NULL,
        EffectiveEndDate              DATE                     NULL,
        Notes                         NVARCHAR(MAX)           NULL,
        IsActive                      BIT                      NOT NULL CONSTRAINT DF_CountedNonEnrollmentChild_IsActive DEFAULT (1),
        IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_CountedNonEnrollmentChild_IsDeleted DEFAULT (0),
        CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_CountedNonEnrollmentChild_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CreatedByUserID               INT                      NULL,
        ModifiedUTC                   DATETIME2(0)             NULL,
        ModifiedByUserID              INT                      NULL,
        DeletedUTC                    DATETIME2(0)             NULL,
        DeletedByUserID               INT                      NULL,
        DeletedReason                 NVARCHAR(500)            NULL,
        RowVer                        ROWVERSION               NOT NULL,
        CONSTRAINT PK_CountedNonEnrollmentChild PRIMARY KEY CLUSTERED (CountedNonEnrollmentChildID),
        CONSTRAINT FK_CountedNonEnrollmentChild_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
    );
