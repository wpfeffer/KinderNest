﻿CREATE TABLE ops.IncidentReport
(
    IncidentReportID             INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    ChildID                      INT                       NULL,
    IncidentTypeCode             NVARCHAR(50)              NOT NULL,
    IncidentDateLocal            DATE                      NOT NULL,
    IncidentTimeLocal            TIME(0)                   NULL,
    LocationDescription          NVARCHAR(500)             NULL,
    IncidentSummary              NVARCHAR(MAX)             NOT NULL,
    ActionTaken                  NVARCHAR(MAX)             NULL,
    ReportedToAuthorityUTC       DATETIME2(0)              NULL,
    AuthorityReferenceNumber     NVARCHAR(100)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_IncidentReport_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_IncidentReport_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_IncidentReport_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_IncidentReport PRIMARY KEY CLUSTERED (IncidentReportID),
    CONSTRAINT FK_IncidentReport_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_IncidentReport_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_IncidentReport_SiteID ON ops.IncidentReport (SiteID, IncidentDateLocal, IsDeleted, IsActive);
GO
CREATE INDEX IX_IncidentReport_ChildID ON ops.IncidentReport (ChildID, IncidentDateLocal, IsDeleted, IsActive) WHERE ChildID IS NOT NULL;