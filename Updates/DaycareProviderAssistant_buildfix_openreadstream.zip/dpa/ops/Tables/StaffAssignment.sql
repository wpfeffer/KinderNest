﻿CREATE TABLE ops.StaffAssignment
(
    StaffAssignmentID            INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    PersonID                     INT                       NOT NULL,
    StaffRoleCode                NVARCHAR(50)              NOT NULL,
    EffectiveStartDate           DATE                      NOT NULL,
    EffectiveEndDate             DATE                      NULL,
    AnnualSubstituteHours        DECIMAL(10,2)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_StaffAssignment_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_StaffAssignment_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_StaffAssignment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_StaffAssignment PRIMARY KEY CLUSTERED (StaffAssignmentID),
    CONSTRAINT FK_StaffAssignment_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_StaffAssignment_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID)
);
GO
CREATE INDEX IX_StaffAssignment_SiteID ON ops.StaffAssignment (SiteID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);