﻿CREATE TABLE ops.SafetyInspection
(
    SafetyInspectionID           INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    InspectionTypeCode           NVARCHAR(50)              NOT NULL,
    InspectionDateLocal          DATE                      NOT NULL,
    InspectionResultCode         NVARCHAR(50)              NOT NULL,
    Findings                     NVARCHAR(MAX)            NULL,
    CorrectiveAction             NVARCHAR(MAX)            NULL,
    CorrectiveActionDueDate      DATE                      NULL,
    CompletedDate                DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_SafetyInspection_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_SafetyInspection_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_SafetyInspection_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_SafetyInspection PRIMARY KEY CLUSTERED (SafetyInspectionID),
    CONSTRAINT FK_SafetyInspection_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
);
GO
CREATE INDEX IX_SafetyInspection_SiteID ON ops.SafetyInspection (SiteID, InspectionDateLocal, IsDeleted, IsActive);