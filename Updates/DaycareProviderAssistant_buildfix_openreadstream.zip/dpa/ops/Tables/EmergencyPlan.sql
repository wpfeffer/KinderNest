﻿CREATE TABLE ops.EmergencyPlan
(
    EmergencyPlanID              INT IDENTITY(1,1)         NOT NULL,
    SiteID                       INT                       NOT NULL,
    PlanVersionLabel             NVARCHAR(50)              NULL,
    EffectiveDate                DATE                      NOT NULL,
    ReviewDate                   DATE                      NULL,
    ShelterInPlaceProcedure      NVARCHAR(MAX)             NULL,
    LockdownProcedure            NVARCHAR(MAX)             NULL,
    EvacuationProcedure          NVARCHAR(MAX)             NULL,
    RelocationProcedure          NVARCHAR(MAX)             NULL,
    ParentNotificationProcedure  NVARCHAR(MAX)             NULL,
    ReunificationProcedure       NVARCHAR(MAX)             NULL,
    UtilityContacts              NVARCHAR(MAX)             NULL,
    EmergencyContacts            NVARCHAR(MAX)             NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsCurrent                    BIT                       NOT NULL CONSTRAINT DF_EmergencyPlan_IsCurrent DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_EmergencyPlan_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_EmergencyPlan_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_EmergencyPlan_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_EmergencyPlan PRIMARY KEY CLUSTERED (EmergencyPlanID),
    CONSTRAINT FK_EmergencyPlan_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID)
);
GO
CREATE INDEX IX_EmergencyPlan_SiteID ON ops.EmergencyPlan (SiteID, IsDeleted, IsActive, IsCurrent);