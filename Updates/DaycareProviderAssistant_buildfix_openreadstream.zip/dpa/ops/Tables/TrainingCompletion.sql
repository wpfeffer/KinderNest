﻿CREATE TABLE ops.TrainingCompletion
(
    TrainingCompletionID         INT IDENTITY(1,1)         NOT NULL,
    StaffAssignmentID            INT                       NOT NULL,
    TrainingCode                 NVARCHAR(50)              NOT NULL,
    TrainingTitle                NVARCHAR(200)             NOT NULL,
    CompletionDate               DATE                      NOT NULL,
    ExpirationDate               DATE                      NULL,
    DocumentID                   INT                       NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_TrainingCompletion_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_TrainingCompletion_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_TrainingCompletion_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_TrainingCompletion PRIMARY KEY CLUSTERED (TrainingCompletionID),
    CONSTRAINT FK_TrainingCompletion_StaffAssignment FOREIGN KEY (StaffAssignmentID) REFERENCES ops.StaffAssignment (StaffAssignmentID),
    CONSTRAINT FK_TrainingCompletion_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_TrainingCompletion_StaffAssignmentID ON ops.TrainingCompletion (StaffAssignmentID, CompletionDate, ExpirationDate, IsDeleted, IsActive);