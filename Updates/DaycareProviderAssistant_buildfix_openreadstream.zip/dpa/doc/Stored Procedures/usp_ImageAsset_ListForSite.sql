CREATE OR ALTER PROCEDURE doc.usp_ImageAsset_ListForSite
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ia.ImageAssetID,
        ia.SiteID,
        ia.ImageCategoryCode,
        ia.VisibilityScopeCode,
        ia.OriginalFileName,
        ia.OriginalContentType,
        ia.OriginalLengthBytes,
        ia.EncryptedFileLengthBytes,
        ia.SiteKeyVersion,
        ia.ImageNonce,
        ia.ThumbnailContentType,
        ia.ThumbnailLengthBytes,
        ia.EncryptedThumbnailLengthBytes,
        ia.ThumbnailNonce,
        ia.PixelWidth,
        ia.PixelHeight,
        ia.Caption,
        ia.TakenUTC,
        ia.CreatedUTC,
        ia.IsActive,
        CASE WHEN ia.EncryptedThumbnailRelativePath IS NULL THEN 0 ELSE 1 END AS HasThumbnail,
        subject_summary.SubjectSummary
    FROM doc.ImageAsset ia
    OUTER APPLY
    (
        SELECT STRING_AGG(subject_rows.SubjectLabel, N', ') AS SubjectSummary
        FROM
        (
            SELECT CONCAT(N'Child: ', c.FirstName, N' ', c.LastName) AS SubjectLabel
            FROM doc.ImageAssetSubject ias
            INNER JOIN child.Child c
                ON c.ChildID = ias.ChildID
               AND c.IsDeleted = 0
            WHERE ias.ImageAssetID = ia.ImageAssetID
              AND ias.IsDeleted = 0
              AND ias.IsActive = 1

            UNION ALL

            SELECT CONCAT(N'Person: ', p.FirstName, N' ', p.LastName) AS SubjectLabel
            FROM doc.ImageAssetSubject ias
            INNER JOIN party.Person p
                ON p.PersonID = ias.PersonID
               AND p.IsDeleted = 0
            WHERE ias.ImageAssetID = ia.ImageAssetID
              AND ias.IsDeleted = 0
              AND ias.IsActive = 1
        ) subject_rows
    ) subject_summary
    WHERE ia.SiteID = @SiteID
      AND ia.IsDeleted = 0
      AND ia.IsActive = 1
    ORDER BY COALESCE(ia.TakenUTC, ia.CreatedUTC) DESC, ia.ImageAssetID DESC;
END;
GO
