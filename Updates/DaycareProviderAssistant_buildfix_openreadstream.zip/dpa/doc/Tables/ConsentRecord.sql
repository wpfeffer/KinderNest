﻿CREATE TABLE doc.ConsentRecord
(
    ConsentRecordID              INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    ConsentTypeCode              NVARCHAR(50)              NOT NULL,
    SignedByPersonID             INT                       NULL,
    SignedUTC                    DATETIME2(0)              NULL,
    EffectiveDate                DATE                      NOT NULL,
    ExpirationDate               DATE                      NULL,
    DocumentID                   INT                       NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ConsentRecord_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ConsentRecord_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ConsentRecord_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ConsentRecord PRIMARY KEY CLUSTERED (ConsentRecordID),
    CONSTRAINT FK_ConsentRecord_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ConsentRecord_SignedByPerson FOREIGN KEY (SignedByPersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT FK_ConsentRecord_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_ConsentRecord_ChildID ON doc.ConsentRecord (ChildID, ConsentTypeCode, EffectiveDate, ExpirationDate, IsDeleted, IsActive);