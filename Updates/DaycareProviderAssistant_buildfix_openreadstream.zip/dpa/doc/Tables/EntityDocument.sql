﻿CREATE TABLE doc.EntityDocument
(
    EntityDocumentID             INT IDENTITY(1,1)         NOT NULL,
    DocumentID                   INT                       NOT NULL,
    EntitySchemaName             NVARCHAR(128)             NOT NULL,
    EntityTableName              NVARCHAR(128)             NOT NULL,
    EntityPrimaryKeyValue        NVARCHAR(128)             NOT NULL,
    Notes                        NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_EntityDocument_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_EntityDocument_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_EntityDocument PRIMARY KEY CLUSTERED (EntityDocumentID),
    CONSTRAINT FK_EntityDocument_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_EntityDocument_DocumentID ON doc.EntityDocument (DocumentID, IsActive);
GO
CREATE INDEX IX_EntityDocument_Target ON doc.EntityDocument (EntitySchemaName, EntityTableName, EntityPrimaryKeyValue, IsActive);