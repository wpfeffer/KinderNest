﻿CREATE TABLE doc.Document
(
    DocumentID                   INT IDENTITY(1,1)         NOT NULL,
    DocumentTypeID               INT                       NOT NULL,
    OriginalFileName             NVARCHAR(255)             NOT NULL,
    StoredFileName               NVARCHAR(255)             NOT NULL,
    ContentType                  NVARCHAR(200)             NOT NULL,
    StorageUri                   NVARCHAR(MAX)            NOT NULL,
    FileHashHex                  NVARCHAR(128)             NULL,
    FileSizeBytes                BIGINT                    NULL,
    VersionNumber                INT                       NOT NULL CONSTRAINT DF_Document_VersionNumber DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Document_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Document_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Document_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Document PRIMARY KEY CLUSTERED (DocumentID),
    CONSTRAINT FK_Document_DocumentType FOREIGN KEY (DocumentTypeID) REFERENCES doc.DocumentType (DocumentTypeID)
);
GO
CREATE INDEX IX_Document_DocumentTypeID ON doc.Document (DocumentTypeID, IsDeleted, IsActive);