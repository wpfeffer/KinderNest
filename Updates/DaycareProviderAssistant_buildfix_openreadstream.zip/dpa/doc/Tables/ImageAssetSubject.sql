CREATE TABLE doc.ImageAssetSubject
(
    ImageAssetSubjectID           INT IDENTITY(1,1)         NOT NULL,
    ImageAssetID                  INT                       NOT NULL,
    SubjectTypeCode               NVARCHAR(50)              NOT NULL,
    ChildID                       INT                       NULL,
    PersonID                      INT                       NULL,
    IsPrimarySubject              BIT                       NOT NULL CONSTRAINT DF_ImageAssetSubject_IsPrimarySubject DEFAULT (0),
    SortOrder                     INT                       NOT NULL CONSTRAINT DF_ImageAssetSubject_SortOrder DEFAULT (1),
    IsActive                      BIT                       NOT NULL CONSTRAINT DF_ImageAssetSubject_IsActive DEFAULT (1),
    IsDeleted                     BIT                       NOT NULL CONSTRAINT DF_ImageAssetSubject_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)              NOT NULL CONSTRAINT DF_ImageAssetSubject_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                       NOT NULL,
    ModifiedUTC                   DATETIME2(0)              NULL,
    ModifiedByUserID              INT                       NULL,
    DeletedUTC                    DATETIME2(0)              NULL,
    DeletedByUserID               INT                       NULL,
    DeletedReason                 NVARCHAR(500)             NULL,
    CONSTRAINT PK_ImageAssetSubject PRIMARY KEY CLUSTERED (ImageAssetSubjectID),
    CONSTRAINT FK_ImageAssetSubject_ImageAsset FOREIGN KEY (ImageAssetID) REFERENCES doc.ImageAsset (ImageAssetID),
    CONSTRAINT FK_ImageAssetSubject_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ImageAssetSubject_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT CK_ImageAssetSubject_Target CHECK
    (
        (SubjectTypeCode = N'CHILD' AND ChildID IS NOT NULL AND PersonID IS NULL)
        OR
        (SubjectTypeCode = N'PERSON' AND PersonID IS NOT NULL AND ChildID IS NULL)
    )
);
GO
CREATE UNIQUE INDEX UX_ImageAssetSubject_UniqueTarget
    ON doc.ImageAssetSubject (ImageAssetID, SubjectTypeCode, ChildID, PersonID)
    WHERE IsDeleted = 0;
GO
CREATE INDEX IX_ImageAssetSubject_ImageAssetID
    ON doc.ImageAssetSubject (ImageAssetID, IsDeleted, IsActive, SortOrder);
GO
CREATE INDEX IX_ImageAssetSubject_ChildID
    ON doc.ImageAssetSubject (ChildID, IsDeleted, IsActive)
    WHERE ChildID IS NOT NULL;
GO
CREATE INDEX IX_ImageAssetSubject_PersonID
    ON doc.ImageAssetSubject (PersonID, IsDeleted, IsActive)
    WHERE PersonID IS NOT NULL;
GO
