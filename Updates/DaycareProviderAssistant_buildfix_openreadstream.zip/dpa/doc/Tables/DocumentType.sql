﻿CREATE TABLE doc.DocumentType
(
    DocumentTypeID               INT IDENTITY(1,1)         NOT NULL,
    DocumentTypeCode             NVARCHAR(50)              NOT NULL,
    DocumentTypeName             NVARCHAR(200)             NOT NULL,
    Description                  NVARCHAR(500)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_DocumentType_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_DocumentType_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_DocumentType PRIMARY KEY CLUSTERED (DocumentTypeID),
    CONSTRAINT UQ_DocumentType_Code UNIQUE (DocumentTypeCode)
);