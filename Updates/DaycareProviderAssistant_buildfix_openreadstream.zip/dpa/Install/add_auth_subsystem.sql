:setvar DatabaseName dpa
USE [$(DatabaseName)];
GO
:r "..\CreateSchemas.sql"
GO
:r "..\sec\Tables\PortalCredential.sql"
GO
:r "..\sec\Tables\LoginSession.sql"
GO
:r "..\audit\Tables\AuthenticationEvent.sql"
GO
:r "..\sec\Tables\PasswordResetRequest.sql"
GO
:r "..\sec\Tables\MfaFactor.sql"
GO
:r "..\sec\Tables\PortalCredentialHistory.sql"
GO
:r "..\audit\Stored Procedures\usp_WriteAuthenticationEvent.sql"
GO
:r "..\sec\Stored Procedures\usp_PortalCredential_SetPassword.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginFailure_Record.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginSuccess_Record.sql"
GO
:r "..\sec\Stored Procedures\usp_LoginSession_Revoke.sql"
GO
:r "..\sec\Stored Procedures\usp_PasswordResetRequest_Create.sql"
GO
:r "..\sec\Stored Procedures\usp_PasswordResetRequest_Consume.sql"
GO
:r "..\PostDeploy\SeedData.sql"
GO
