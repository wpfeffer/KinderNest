Use add_auth_subsystem.sql to add or reconcile the native auth subsystem on an existing dpa database.

This revised script is idempotent:
- existing sec/audit auth tables are left in place
- missing indexes are added only if absent
- auth stored procedures use CREATE OR ALTER
- auth reference-code seeding is safe to rerun

If the database was installed from the current master installer, you usually do not need add_auth_subsystem.sql because the auth objects already exist.
