﻿CREATE FUNCTION lic.fn_ValidateFamilyCareCapacity
(
    @SiteID               INT,
    @EvaluationDateLocal  DATE,
    @AdultCaregiverCount  INT,
    @HelperCount          INT
)
RETURNS @Validation TABLE
(
    SiteID                        INT             NOT NULL,
    EvaluationDateLocal           DATE            NOT NULL,
    LicenseClassCode              NVARCHAR(10)    NOT NULL,
    TotalChildren                 INT             NOT NULL,
    UnderSchoolAgeCount           INT             NOT NULL,
    InfantToddlerCount            INT             NOT NULL,
    Under12MonthsCount            INT             NOT NULL,
    NewbornCount                  INT             NOT NULL,
    IsCapacityValid               BIT             NOT NULL,
    ViolationSummary              NVARCHAR(MAX)  NULL
)
AS
BEGIN
    DECLARE
        @LicenseClassCode                          NVARCHAR(10),
        @MaxTotalChildren                          INT,
        @MinAdultCaregiversRequired                INT,
        @MaxUnderSchoolAgeChildren                 INT,
        @MaxInfantToddlerChildren                  INT,
        @MaxUnder12MonthsChildren                  INT,
        @AllowHelperInLieuOfSecondAdult            BIT,
        @MaxInfantToddlerWhenHelperSubstitutes     INT,
        @SingleAdultWithNewbornMaxOtherChildren    INT,
        @SingleAdultWithNewbornMaxUnder12Months    INT,
        @TotalChildren                             INT,
        @UnderSchoolAgeCount                       INT,
        @InfantToddlerCount                        INT,
        @Under12MonthsCount                        INT,
        @NewbornCount                              INT,
        @IsValid                                   BIT,
        @ViolationSummary                          NVARCHAR(MAX);

    SELECT
        @LicenseClassCode = s0.LicenseClassCode,
        @TotalChildren = s0.TotalChildren,
        @UnderSchoolAgeCount = s0.UnderSchoolAgeCount,
        @InfantToddlerCount = s0.InfantToddlerCount,
        @Under12MonthsCount = s0.Under12MonthsCount,
        @NewbornCount = s0.NewbornCount
    FROM lic.fn_GetSiteChildCountSnapshot(@SiteID, @EvaluationDateLocal, @AdultCaregiverCount, @HelperCount) s0;

    SELECT TOP (1)
        @MaxTotalChildren = crs.MaxTotalChildren,
        @MinAdultCaregiversRequired = crs.MinAdultCaregiversRequired,
        @MaxUnderSchoolAgeChildren = crs.MaxUnderSchoolAgeChildren,
        @MaxInfantToddlerChildren = crs.MaxInfantToddlerChildren,
        @MaxUnder12MonthsChildren = crs.MaxUnder12MonthsChildren,
        @AllowHelperInLieuOfSecondAdult = crs.AllowHelperInLieuOfSecondAdult,
        @MaxInfantToddlerWhenHelperSubstitutes = crs.MaxInfantToddlerWhenHelperSubstitutes,
        @SingleAdultWithNewbornMaxOtherChildren = crs.SingleAdultWithNewbornMaxOtherChildren,
        @SingleAdultWithNewbornMaxUnder12Months = crs.SingleAdultWithNewbornMaxUnder12Months
    FROM lic.CapacityRuleSet crs
    INNER JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = crs.LicenseClassID
    WHERE lc.LicenseClassCode = @LicenseClassCode
      AND crs.IsActive = 1
      AND crs.EffectiveStartDate <= @EvaluationDateLocal
      AND (crs.EffectiveEndDate IS NULL OR crs.EffectiveEndDate >= @EvaluationDateLocal)
    ORDER BY crs.EffectiveStartDate DESC;

    SET @IsValid = 1;
    SET @ViolationSummary = N'';

    IF @TotalChildren > ISNULL(@MaxTotalChildren, 2147483647)
    BEGIN
        SET @IsValid = 0;
        SET @ViolationSummary += N'Total children exceed class maximum. ';
    END;

    IF @UnderSchoolAgeCount > ISNULL(@MaxUnderSchoolAgeChildren, 2147483647)
    BEGIN
        SET @IsValid = 0;
        SET @ViolationSummary += N'Under-school-age count exceeds class maximum. ';
    END;

    IF @InfantToddlerCount > ISNULL(@MaxInfantToddlerChildren, 2147483647)
    BEGIN
        SET @IsValid = 0;
        SET @ViolationSummary += N'Infant+toddler count exceeds class maximum. ';
    END;

    IF @Under12MonthsCount > ISNULL(@MaxUnder12MonthsChildren, 2147483647)
    BEGIN
        SET @IsValid = 0;
        SET @ViolationSummary += N'Under-12-month count exceeds class maximum. ';
    END;

    IF @AdultCaregiverCount < @MinAdultCaregiversRequired
    BEGIN
        IF NOT (
            @LicenseClassCode = N'C3'
            AND @AllowHelperInLieuOfSecondAdult = 1
            AND @AdultCaregiverCount = 1
            AND @HelperCount >= 1
            AND @InfantToddlerCount <= ISNULL(@MaxInfantToddlerWhenHelperSubstitutes, 0)
        )
        BEGIN
            SET @IsValid = 0;
            SET @ViolationSummary += N'Adult caregiver minimum not satisfied. ';
        END;
    END;

    IF @AdultCaregiverCount = 1 AND @NewbornCount > 0
    BEGIN
        IF @Under12MonthsCount > ISNULL(@SingleAdultWithNewbornMaxUnder12Months, 1)
        BEGIN
            SET @IsValid = 0;
            SET @ViolationSummary += N'With one adult and a newborn present, under-12-month restriction violated. ';
        END;

        IF (@TotalChildren - @NewbornCount) > ISNULL(@SingleAdultWithNewbornMaxOtherChildren, 2)
        BEGIN
            SET @IsValid = 0;
            SET @ViolationSummary += N'With one adult and a newborn present, other-child count restriction violated. ';
        END;
    END;

    INSERT INTO @Validation
    (
        SiteID,
        EvaluationDateLocal,
        LicenseClassCode,
        TotalChildren,
        UnderSchoolAgeCount,
        InfantToddlerCount,
        Under12MonthsCount,
        NewbornCount,
        IsCapacityValid,
        ViolationSummary
    )
    VALUES
    (
        @SiteID,
        @EvaluationDateLocal,
        @LicenseClassCode,
        ISNULL(@TotalChildren, 0),
        ISNULL(@UnderSchoolAgeCount, 0),
        ISNULL(@InfantToddlerCount, 0),
        ISNULL(@Under12MonthsCount, 0),
        ISNULL(@NewbornCount, 0),
        @IsValid,
        NULLIF(LTRIM(RTRIM(@ViolationSummary)), N'')
    );

    RETURN;
END;