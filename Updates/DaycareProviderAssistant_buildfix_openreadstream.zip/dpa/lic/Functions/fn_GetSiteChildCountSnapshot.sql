﻿CREATE FUNCTION lic.fn_GetSiteChildCountSnapshot
(
    @SiteID               INT,
    @EvaluationDateLocal  DATE,
    @AdultCaregiverCount  INT,
    @HelperCount          INT
)
RETURNS @Snapshot TABLE
(
    SiteID                        INT             NOT NULL,
    EvaluationDateLocal           DATE            NOT NULL,
    LicenseClassCode              NVARCHAR(10)    NOT NULL,
    AdultCaregiverCount           INT             NOT NULL,
    HelperCount                   INT             NOT NULL,
    TotalChildren                 INT             NOT NULL,
    NewbornCount                  INT             NOT NULL,
    InfantCount                   INT             NOT NULL,
    ToddlerCount                  INT             NOT NULL,
    PreschoolCount                INT             NOT NULL,
    SchoolAgeCount                INT             NOT NULL,
    UnderSchoolAgeCount           INT             NOT NULL,
    InfantToddlerCount            INT             NOT NULL,
    Under12MonthsCount            INT             NOT NULL
)
AS
BEGIN
    DECLARE @LicenseClassCode NVARCHAR(10);

    SELECT @LicenseClassCode = lc.LicenseClassCode
    FROM party.Site s
    INNER JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    WHERE s.SiteID = @SiteID
      AND s.IsDeleted = 0;

    ;WITH ActiveChildren AS
    (
        SELECT
            c.ChildID,
            lic.fn_GetFamilyAgeBandCode(@LicenseClassCode, c.DateOfBirth, @EvaluationDateLocal) AS AgeBandCode
        FROM child.Child c
        INNER JOIN child.ChildEnrollment ce
            ON ce.ChildID = c.ChildID
           AND ce.SiteID = c.SiteID
           AND ce.IsDeleted = 0
           AND ce.IsActive = 1
           AND ce.EnrollmentStartDate <= @EvaluationDateLocal
           AND (ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= @EvaluationDateLocal)
        WHERE c.SiteID = @SiteID
          AND c.IsDeleted = 0
          AND c.IsActive = 1
    )
    INSERT INTO @Snapshot
    (
        SiteID,
        EvaluationDateLocal,
        LicenseClassCode,
        AdultCaregiverCount,
        HelperCount,
        TotalChildren,
        NewbornCount,
        InfantCount,
        ToddlerCount,
        PreschoolCount,
        SchoolAgeCount,
        UnderSchoolAgeCount,
        InfantToddlerCount,
        Under12MonthsCount
    )
    SELECT
        @SiteID,
        @EvaluationDateLocal,
        @LicenseClassCode,
        @AdultCaregiverCount,
        @HelperCount,
        COUNT(1) AS TotalChildren,
        SUM(CASE WHEN AgeBandCode = N'NEWBORN' THEN 1 ELSE 0 END) AS NewbornCount,
        SUM(CASE WHEN AgeBandCode = N'INFANT' THEN 1 ELSE 0 END) AS InfantCount,
        SUM(CASE WHEN AgeBandCode = N'TODDLER' THEN 1 ELSE 0 END) AS ToddlerCount,
        SUM(CASE WHEN AgeBandCode = N'PRESCHOOL' THEN 1 ELSE 0 END) AS PreschoolCount,
        SUM(CASE WHEN AgeBandCode = N'SCHOOL_AGE' THEN 1 ELSE 0 END) AS SchoolAgeCount,
        SUM(CASE WHEN AgeBandCode IN (N'NEWBORN', N'INFANT', N'TODDLER', N'PRESCHOOL') THEN 1 ELSE 0 END) AS UnderSchoolAgeCount,
        SUM(CASE WHEN AgeBandCode IN (N'INFANT', N'TODDLER') THEN 1 ELSE 0 END) AS InfantToddlerCount,
        SUM(CASE WHEN AgeBandCode IN (N'NEWBORN', N'INFANT') THEN 1 ELSE 0 END) AS Under12MonthsCount
    FROM ActiveChildren;

    RETURN;
END;