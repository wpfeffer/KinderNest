﻿CREATE FUNCTION lic.fn_GetNextFamilyAgeBandTransitionDate
(
    @LicenseClassCode NVARCHAR(10),
    @DateOfBirth      DATE,
    @CurrentAgeBand   NVARCHAR(20)
)
RETURNS DATE
AS
BEGIN
    DECLARE @NextTransitionDate DATE;

    SET @NextTransitionDate =
        CASE @CurrentAgeBand
            WHEN N'NEWBORN' THEN DATEADD(DAY, 42, @DateOfBirth)
            WHEN N'INFANT' THEN DATEADD(MONTH, 12, @DateOfBirth)
            WHEN N'TODDLER' THEN
                CASE
                    WHEN @LicenseClassCode IN (N'A', N'C1', N'C2', N'C3') THEN DATEADD(MONTH, 24, @DateOfBirth)
                    ELSE DATEADD(MONTH, 30, @DateOfBirth)
                END
            WHEN N'PRESCHOOL' THEN DATEADD(MONTH, 60, @DateOfBirth)
            ELSE NULL
        END;

    RETURN @NextTransitionDate;
END;