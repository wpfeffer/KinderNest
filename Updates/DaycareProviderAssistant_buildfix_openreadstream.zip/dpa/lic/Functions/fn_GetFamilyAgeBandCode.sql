﻿CREATE FUNCTION lic.fn_GetFamilyAgeBandCode
(
    @LicenseClassCode    NVARCHAR(10),
    @DateOfBirth         DATE,
    @EvaluationDateLocal DATE
)
RETURNS NVARCHAR(20)
AS
BEGIN
    DECLARE @AgeInDays INT;
    DECLARE @AgeInMonths INT;
    DECLARE @AgeBandCode NVARCHAR(20);

    SET @AgeInDays = child.fn_CalculateAgeInDays(@DateOfBirth, @EvaluationDateLocal);
    SET @AgeInMonths = DATEDIFF(MONTH, @DateOfBirth, @EvaluationDateLocal)
                     - CASE WHEN DATEADD(MONTH, DATEDIFF(MONTH, @DateOfBirth, @EvaluationDateLocal), @DateOfBirth) > @EvaluationDateLocal THEN 1 ELSE 0 END;

    IF @AgeInDays < 42
        SET @AgeBandCode = N'NEWBORN';
    ELSE IF @AgeInMonths < 12
        SET @AgeBandCode = N'INFANT';
    ELSE IF @LicenseClassCode IN (N'A', N'C1', N'C2', N'C3') AND @AgeInMonths < 24
        SET @AgeBandCode = N'TODDLER';
    ELSE IF @LicenseClassCode IN (N'B1', N'B2', N'D') AND @AgeInMonths < 30
        SET @AgeBandCode = N'TODDLER';
    ELSE IF @AgeInMonths < 60
        SET @AgeBandCode = N'PRESCHOOL';
    ELSE
        SET @AgeBandCode = N'SCHOOL_AGE';

    RETURN @AgeBandCode;
END;