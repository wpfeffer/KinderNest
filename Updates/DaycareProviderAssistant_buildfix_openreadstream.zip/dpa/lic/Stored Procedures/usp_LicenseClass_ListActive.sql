CREATE OR ALTER PROCEDURE lic.usp_LicenseClass_ListActive
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        lc.LicenseClassID,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        lc.LicenseFamilyCode,
        lc.Description,
        lc.IsActive
    FROM lic.LicenseClass lc
    WHERE lc.IsActive = 1
    ORDER BY
        lc.LicenseFamilyCode,
        lc.LicenseClassCode,
        lc.LicenseClassName;
END;
GO
