﻿CREATE PROCEDURE lic.usp_CapacityForecast_Get
    @SiteID                      INT,
    @StartDateLocal              DATE,
    @EndDateLocal                DATE,
    @AdultCaregiverCount         INT,
    @HelperCount                 INT = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF @EndDateLocal < @StartDateLocal
    BEGIN
        THROW 50041, 'End date must be greater than or equal to start date.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.Site s
        WHERE s.SiteID = @SiteID
          AND s.IsDeleted = 0
    )
    BEGIN
        THROW 50042, 'Site record not found or deleted.', 1;
    END;

    ;WITH ForecastDates AS
    (
        SELECT @StartDateLocal AS EvaluationDateLocal
        UNION ALL
        SELECT DATEADD(DAY, 1, EvaluationDateLocal)
        FROM ForecastDates
        WHERE EvaluationDateLocal < @EndDateLocal
    )
    SELECT
        d.EvaluationDateLocal,
        s.LicenseClassCode,
        s.TotalChildren,
        s.NewbornCount,
        s.InfantCount,
        s.ToddlerCount,
        s.PreschoolCount,
        s.SchoolAgeCount,
        s.UnderSchoolAgeCount,
        s.InfantToddlerCount,
        s.Under12MonthsCount,
        v.IsCapacityValid,
        v.ViolationSummary,
        CASE
            WHEN v.IsCapacityValid = 1 THEN N'VALID'
            ELSE N'INVALID'
        END AS CapacityStatusCode
    FROM ForecastDates d
    CROSS APPLY lic.fn_GetSiteChildCountSnapshot(@SiteID, d.EvaluationDateLocal, @AdultCaregiverCount, @HelperCount) s
    CROSS APPLY lic.fn_ValidateFamilyCareCapacity(@SiteID, d.EvaluationDateLocal, @AdultCaregiverCount, @HelperCount) v
    ORDER BY d.EvaluationDateLocal
    OPTION (MAXRECURSION 32767);
END;