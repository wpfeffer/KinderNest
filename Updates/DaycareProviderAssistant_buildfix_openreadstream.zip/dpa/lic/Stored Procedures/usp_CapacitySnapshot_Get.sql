﻿CREATE PROCEDURE lic.usp_CapacitySnapshot_Get
    @SiteID                      INT,
    @EvaluationDateLocal         DATE,
    @AdultCaregiverCount         INT,
    @HelperCount                 INT = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.Site s
        WHERE s.SiteID = @SiteID
          AND s.IsDeleted = 0
    )
    BEGIN
        THROW 50040, 'Site record not found or deleted.', 1;
    END;

    SELECT
        s.SiteID,
        s.EvaluationDateLocal,
        s.LicenseClassCode,
        s.AdultCaregiverCount,
        s.HelperCount,
        s.TotalChildren,
        s.NewbornCount,
        s.InfantCount,
        s.ToddlerCount,
        s.PreschoolCount,
        s.SchoolAgeCount,
        s.UnderSchoolAgeCount,
        s.InfantToddlerCount,
        s.Under12MonthsCount,
        v.IsCapacityValid,
        v.ViolationSummary
    FROM lic.fn_GetSiteChildCountSnapshot(@SiteID, @EvaluationDateLocal, @AdultCaregiverCount, @HelperCount) s
    INNER JOIN lic.fn_ValidateFamilyCareCapacity(@SiteID, @EvaluationDateLocal, @AdultCaregiverCount, @HelperCount) v
        ON v.SiteID = s.SiteID
       AND v.EvaluationDateLocal = s.EvaluationDateLocal;
END;