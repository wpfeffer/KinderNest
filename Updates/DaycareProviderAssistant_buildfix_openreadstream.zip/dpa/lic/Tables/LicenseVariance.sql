﻿CREATE TABLE lic.LicenseVariance
(
    LicenseVarianceID             INT IDENTITY(1,1)        NOT NULL,
    SiteID                        INT                      NOT NULL,
    VarianceCode                  NVARCHAR(50)             NOT NULL,
    VarianceTitle                 NVARCHAR(200)            NOT NULL,
    VarianceDescription           NVARCHAR(MAX)           NULL,
    ApprovalDate                  DATE                     NULL,
    EffectiveStartDate            DATE                     NOT NULL,
    EffectiveEndDate              DATE                     NULL,
    ApprovedByAgencyName          NVARCHAR(200)            NULL,
    AgencyReferenceNumber         NVARCHAR(100)            NULL,
    DocumentID                    INT                      NULL,
    IsCurrent                     BIT                      NOT NULL CONSTRAINT DF_LicenseVariance_IsCurrent DEFAULT (1),
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_LicenseVariance_IsActive DEFAULT (1),
    IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_LicenseVariance_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_LicenseVariance_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    DeletedUTC                    DATETIME2(0)             NULL,
    DeletedByUserID               INT                      NULL,
    DeletedReason                 NVARCHAR(500)            NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_LicenseVariance PRIMARY KEY CLUSTERED (LicenseVarianceID),
    CONSTRAINT FK_LicenseVariance_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_LicenseVariance_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_LicenseVariance_SiteID ON lic.LicenseVariance (SiteID, EffectiveStartDate, EffectiveEndDate, IsDeleted, IsActive);