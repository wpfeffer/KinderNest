﻿CREATE TABLE lic.ComplianceReview
(
    ComplianceReviewID            INT IDENTITY(1,1)        NOT NULL,
    SiteID                        INT                      NOT NULL,
    ReviewTypeCode                NVARCHAR(50)             NOT NULL,
    ReviewStatusCode              NVARCHAR(50)             NOT NULL,
    ReviewStartUTC                DATETIME2(0)             NOT NULL,
    ReviewEndUTC                  DATETIME2(0)             NULL,
    ReviewedByUserID              INT                      NULL,
    ReviewSummary                 NVARCHAR(MAX)           NULL,
    NextReviewDueDate             DATE                     NULL,
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_ComplianceReview_IsActive DEFAULT (1),
    IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_ComplianceReview_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_ComplianceReview_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    DeletedUTC                    DATETIME2(0)             NULL,
    DeletedByUserID               INT                      NULL,
    DeletedReason                 NVARCHAR(500)            NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_ComplianceReview PRIMARY KEY CLUSTERED (ComplianceReviewID),
    CONSTRAINT FK_ComplianceReview_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_ComplianceReview_ReviewedByUser FOREIGN KEY (ReviewedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_ComplianceReview_SiteID
    ON lic.ComplianceReview (SiteID, ReviewStartUTC DESC, IsDeleted, IsActive);