﻿CREATE TABLE lic.CapacityRuleSet
(
    CapacityRuleSetID                    INT IDENTITY(1,1)         NOT NULL,
    LicenseClassID                       INT                       NOT NULL,
    EffectiveStartDate                   DATE                      NOT NULL,
    EffectiveEndDate                     DATE                      NULL,
    MaxTotalChildren                     INT                       NOT NULL,
    MinAdultCaregiversRequired           INT                       NOT NULL,
    MaxUnderSchoolAgeChildren            INT                       NULL,
    MaxInfantToddlerChildren             INT                       NULL,
    MaxUnder12MonthsChildren             INT                       NULL,
    AllowHelperInLieuOfSecondAdult       BIT                       NOT NULL CONSTRAINT DF_CapacityRuleSet_AllowHelper DEFAULT (0),
    MaxInfantToddlerWhenHelperSubstitutes INT                      NULL,
    SingleAdultWithNewbornMaxOtherChildren INT                     NULL,
    SingleAdultWithNewbornMaxUnder12Months INT                     NULL,
    Notes                                NVARCHAR(MAX)            NULL,
    IsActive                             BIT                       NOT NULL CONSTRAINT DF_CapacityRuleSet_IsActive DEFAULT (1),
    CreatedUTC                           DATETIME2(0)              NOT NULL CONSTRAINT DF_CapacityRuleSet_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID                      INT                       NULL,
    ModifiedUTC                          DATETIME2(0)              NULL,
    ModifiedByUserID                     INT                       NULL,
    CONSTRAINT PK_CapacityRuleSet PRIMARY KEY CLUSTERED (CapacityRuleSetID),
    CONSTRAINT FK_CapacityRuleSet_LicenseClass FOREIGN KEY (LicenseClassID) REFERENCES lic.LicenseClass (LicenseClassID)
);
GO
CREATE INDEX IX_CapacityRuleSet_LicenseClassID ON lic.CapacityRuleSet (LicenseClassID, EffectiveStartDate, EffectiveEndDate, IsActive);