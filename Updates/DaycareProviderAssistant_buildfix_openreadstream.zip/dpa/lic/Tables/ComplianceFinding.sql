﻿CREATE TABLE lic.ComplianceFinding
(
    ComplianceFindingID           INT IDENTITY(1,1)        NOT NULL,
    ComplianceReviewID            INT                      NOT NULL,
    RequirementID                 INT                      NULL,
    ChildID                       INT                      NULL,
    FindingSeverityCode           NVARCHAR(50)             NOT NULL,
    FindingStatusCode             NVARCHAR(50)             NOT NULL,
    FindingTitle                  NVARCHAR(200)            NOT NULL,
    FindingDescription            NVARCHAR(MAX)           NOT NULL,
    CorrectiveActionRequired      BIT                      NOT NULL CONSTRAINT DF_ComplianceFinding_CorrectiveActionRequired DEFAULT (1),
    CorrectiveActionDueDate       DATE                     NULL,
    ClosedUTC                     DATETIME2(0)             NULL,
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_ComplianceFinding_IsActive DEFAULT (1),
    IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_ComplianceFinding_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_ComplianceFinding_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    DeletedUTC                    DATETIME2(0)             NULL,
    DeletedByUserID               INT                      NULL,
    DeletedReason                 NVARCHAR(500)            NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_ComplianceFinding PRIMARY KEY CLUSTERED (ComplianceFindingID),
    CONSTRAINT FK_ComplianceFinding_ComplianceReview FOREIGN KEY (ComplianceReviewID) REFERENCES lic.ComplianceReview (ComplianceReviewID),
    CONSTRAINT FK_ComplianceFinding_Requirement FOREIGN KEY (RequirementID) REFERENCES lic.RequirementCatalog (RequirementID),
    CONSTRAINT FK_ComplianceFinding_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_ComplianceFinding_ReviewID
    ON lic.ComplianceFinding (ComplianceReviewID, FindingStatusCode, CorrectiveActionDueDate, IsDeleted, IsActive);
GO
CREATE INDEX IX_ComplianceFinding_ChildID
    ON lic.ComplianceFinding (ChildID, FindingStatusCode, IsDeleted, IsActive)
    WHERE ChildID IS NOT NULL;