﻿CREATE TABLE lic.LicenseClass
(
    LicenseClassID               INT IDENTITY(1,1)         NOT NULL,
    LicenseClassCode             NVARCHAR(10)              NOT NULL,
    LicenseClassName             NVARCHAR(200)             NOT NULL,
    LicenseFamilyCode            NVARCHAR(50)              NOT NULL,
    Description                  NVARCHAR(500)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_LicenseClass_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_LicenseClass_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_LicenseClass PRIMARY KEY CLUSTERED (LicenseClassID),
    CONSTRAINT UQ_LicenseClass_Code UNIQUE (LicenseClassCode)
);