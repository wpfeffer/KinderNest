﻿CREATE TABLE lic.RequirementCatalog
(
    RequirementID                INT IDENTITY(1,1)         NOT NULL,
    RequirementCode              NVARCHAR(50)              NOT NULL,
    RequirementTitle             NVARCHAR(200)             NOT NULL,
    RequirementCategoryCode      NVARCHAR(50)              NOT NULL,
    AppliesToLicenseFamilyCode   NVARCHAR(50)              NULL,
    AppliesToChildFlag           BIT                       NOT NULL CONSTRAINT DF_RequirementCatalog_AppliesToChild DEFAULT (0),
    AppliesToSiteFlag            BIT                       NOT NULL CONSTRAINT DF_RequirementCatalog_AppliesToSite DEFAULT (1),
    Description                  NVARCHAR(MAX)            NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_RequirementCatalog_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_RequirementCatalog_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_RequirementCatalog PRIMARY KEY CLUSTERED (RequirementID),
    CONSTRAINT UQ_RequirementCatalog_Code UNIQUE (RequirementCode)
);
GO
CREATE INDEX IX_RequirementCatalog_Category ON lic.RequirementCatalog (RequirementCategoryCode, IsActive);