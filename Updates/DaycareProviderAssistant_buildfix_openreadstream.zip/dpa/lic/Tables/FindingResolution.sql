﻿CREATE TABLE lic.FindingResolution
(
    FindingResolutionID           INT IDENTITY(1,1)        NOT NULL,
    ComplianceFindingID           INT                      NOT NULL,
    ResolutionStatusCode          NVARCHAR(50)             NOT NULL,
    ResolutionSummary             NVARCHAR(MAX)           NOT NULL,
    ResolvedByUserID              INT                      NULL,
    ResolvedUTC                   DATETIME2(0)             NULL,
    VerificationNotes             NVARCHAR(MAX)           NULL,
    DocumentID                    INT                      NULL,
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_FindingResolution_IsActive DEFAULT (1),
    IsDeleted                     BIT                      NOT NULL CONSTRAINT DF_FindingResolution_IsDeleted DEFAULT (0),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_FindingResolution_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    DeletedUTC                    DATETIME2(0)             NULL,
    DeletedByUserID               INT                      NULL,
    DeletedReason                 NVARCHAR(500)            NULL,
    RowVer                        ROWVERSION               NOT NULL,
    CONSTRAINT PK_FindingResolution PRIMARY KEY CLUSTERED (FindingResolutionID),
    CONSTRAINT FK_FindingResolution_ComplianceFinding FOREIGN KEY (ComplianceFindingID) REFERENCES lic.ComplianceFinding (ComplianceFindingID),
    CONSTRAINT FK_FindingResolution_ResolvedByUser FOREIGN KEY (ResolvedByUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_FindingResolution_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_FindingResolution_FindingID
    ON lic.FindingResolution (ComplianceFindingID, ResolutionStatusCode, IsDeleted, IsActive);