-- Post-deployment patches extracted from ScriptsIgnoredOnImport.sql
-- This script is intended to run after the model is deployed to apply conditional DDL
SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- Ensure schemas exist
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ref')
    EXEC(N'CREATE SCHEMA ref AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'lic')
    EXEC(N'CREATE SCHEMA lic AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'party')
    EXEC(N'CREATE SCHEMA party AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'child')
    EXEC(N'CREATE SCHEMA child AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'doc')
    EXEC(N'CREATE SCHEMA doc AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ops')
    EXEC(N'CREATE SCHEMA ops AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'comm')
    EXEC(N'CREATE SCHEMA comm AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'audit')
    EXEC(N'CREATE SCHEMA audit AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'sec')
    EXEC(N'CREATE SCHEMA sec AUTHORIZATION dbo;');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'rpt')
    EXEC(N'CREATE SCHEMA rpt AUTHORIZATION dbo;');
GO

-- Add columns if missing (safe, idempotent)
IF COL_LENGTH('child.Child', 'ChildAddressID') IS NULL
    ALTER TABLE child.Child ADD ChildAddressID INT NULL;
GO

IF COL_LENGTH('child.ChildMedicalProfile', 'PrimaryCarePhysicianID') IS NULL
    ALTER TABLE child.ChildMedicalProfile ADD PrimaryCarePhysicianID INT NULL;
GO

IF COL_LENGTH('child.ChildMedicalProfile', 'DentistMedicalProviderID') IS NULL
    ALTER TABLE child.ChildMedicalProfile ADD DentistMedicalProviderID INT NULL;
GO

IF COL_LENGTH('child.ChildMedicalProfile', 'HospitalID') IS NULL
    ALTER TABLE child.ChildMedicalProfile ADD HospitalID INT NULL;
GO

IF COL_LENGTH('child.ChildAllergyPlan', 'PhysicianMedicalProviderID') IS NULL
    ALTER TABLE child.ChildAllergyPlan ADD PhysicianMedicalProviderID INT NULL;
GO

-- Drop legacy columns if present
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.Child') AND name = N'AddressLine1')
BEGIN
    ALTER TABLE child.Child DROP COLUMN AddressLine1, AddressLine2, City, StateCode, PostalCode;
END;
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.ChildMedicalProfile') AND name = N'PhysicianName')
BEGIN
    ALTER TABLE child.ChildMedicalProfile DROP COLUMN PhysicianName, PhysicianPhone, DentistName, DentistPhone, HospitalName, HospitalPhone;
END;
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'child.ChildAllergyPlan') AND name = N'PhysicianName')
BEGIN
    ALTER TABLE child.ChildAllergyPlan DROP COLUMN PhysicianName, PhysicianPhone;
END;
GO

-- Index and foreign key guards (kept idempotent). If you need these constraints/indexes applied at deploy-time,
-- uncomment the CREATE/ALTER statements below.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Child_ChildAddressID' AND object_id = OBJECT_ID(N'child.Child'))
BEGIN
    --CREATE INDEX IX_Child_ChildAddressID ON child.Child (ChildAddressID) WHERE ChildAddressID IS NOT NULL;
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ChildMedicalProfile_PrimaryCarePhysicianID' AND object_id = OBJECT_ID(N'child.ChildMedicalProfile'))
BEGIN
    --CREATE INDEX IX_ChildMedicalProfile_PrimaryCarePhysicianID ON child.ChildMedicalProfile (PrimaryCarePhysicianID) WHERE PrimaryCarePhysicianID IS NOT NULL;
END;
GO

-- Place additional post-deploy patches below as needed

GO

-- Seed authentication and authorization reference data
IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'CredentialType', N'PASSWORD', N'Password'),
            (N'CredentialType', N'TOTP', N'Time-based One-Time Password'),
            (N'CredentialType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'CredentialType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'CredentialStatus', N'ACTIVE', N'Active'),
            (N'CredentialStatus', N'LOCKED', N'Locked'),
            (N'CredentialStatus', N'DISABLED', N'Disabled'),
            (N'CredentialStatus', N'RESET_REQUIRED', N'Reset Required'),
            (N'CredentialStatus', N'REVOKED', N'Revoked'),

            (N'HashAlgorithm', N'ARGON2ID', N'Argon2id'),
            (N'HashAlgorithm', N'SCRYPT', N'scrypt'),
            (N'HashAlgorithm', N'ASPNETCORE_IDENTITY_V3', N'ASP.NET Core Identity V3'),
            (N'HashAlgorithm', N'PBKDF2', N'PBKDF2'),

            (N'LoginSessionStatus', N'ACTIVE', N'Active'),
            (N'LoginSessionStatus', N'REVOKED', N'Revoked'),
            (N'LoginSessionStatus', N'EXPIRED', N'Expired'),
            (N'LoginSessionStatus', N'LOGGED_OUT', N'Logged Out'),

            (N'PasswordResetRequestStatus', N'PENDING', N'Pending'),
            (N'PasswordResetRequestStatus', N'CONSUMED', N'Consumed'),
            (N'PasswordResetRequestStatus', N'EXPIRED', N'Expired'),
            (N'PasswordResetRequestStatus', N'REVOKED', N'Revoked'),

            (N'MfaFactorType', N'TOTP', N'Time-based One-Time Password'),
            (N'MfaFactorType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'MfaFactorType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'AuthenticationEventType', N'LOGIN_ATTEMPT', N'Login Attempt'),
            (N'AuthenticationEventType', N'LOGIN_SUCCESS', N'Login Success'),
            (N'AuthenticationEventType', N'LOGIN_FAILED', N'Login Failed'),
            (N'AuthenticationEventType', N'LOGOUT', N'Logout'),
            (N'AuthenticationEventType', N'PASSWORD_CHANGED', N'Password Changed'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_REQUESTED', N'Password Reset Requested'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_COMPLETED', N'Password Reset Completed'),
            (N'AuthenticationEventType', N'MFA_CHALLENGE_ISSUED', N'MFA Challenge Issued'),
            (N'AuthenticationEventType', N'MFA_SUCCESS', N'MFA Success'),
            (N'AuthenticationEventType', N'MFA_FAILED', N'MFA Failed'),
            (N'AuthenticationEventType', N'ACCOUNT_LOCKED', N'Account Locked'),
            (N'AuthenticationEventType', N'ACCOUNT_UNLOCKED', N'Account Unlocked'),

            (N'AuthenticationResult', N'SUCCESS', N'Success'),
            (N'AuthenticationResult', N'FAILURE', N'Failure'),
            (N'AuthenticationResult', N'CHALLENGED', N'Challenged'),
            (N'AuthenticationResult', N'BLOCKED', N'Blocked')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue c
        WHERE c.CodeDomain = v.CodeDomain
          AND c.CodeValue = v.CodeValue
    );
END;
GO

IF OBJECT_ID(N'ref.SeedBatch', N'U') IS NOT NULL
AND NOT EXISTS
(
    SELECT 1
    FROM ref.SeedBatch sb
    WHERE sb.SeedBatchCode = N'AUTH_SECURITY_BASELINE'
)
BEGIN
    INSERT INTO ref.SeedBatch
    (
        SeedBatchCode,
        SeedBatchName,
        SeedBatchDescription,
        TargetSchemaName,
        TargetObjectName,
        BatchVersion,
        IsRequired,
        IsActive
    )
    VALUES
    (
        N'AUTH_SECURITY_BASELINE',
        N'Authentication Security Baseline',
        N'Seeds native authentication and audit reference codes required for portal credential, session, reset, MFA, and authentication event processing.',
        N'sec',
        N'PortalCredential',
        N'1.0.0',
        1,
        1
    );
END;
GO
