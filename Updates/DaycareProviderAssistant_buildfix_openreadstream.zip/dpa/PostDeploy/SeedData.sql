SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'CredentialType', N'PASSWORD', N'Password'),
            (N'CredentialType', N'TOTP', N'Time-based One-Time Password'),
            (N'CredentialType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'CredentialType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'CredentialStatus', N'ACTIVE', N'Active'),
            (N'CredentialStatus', N'LOCKED', N'Locked'),
            (N'CredentialStatus', N'DISABLED', N'Disabled'),
            (N'CredentialStatus', N'RESET_REQUIRED', N'Reset Required'),
            (N'CredentialStatus', N'REVOKED', N'Revoked'),

            (N'HashAlgorithm', N'ARGON2ID', N'Argon2id'),
            (N'HashAlgorithm', N'SCRYPT', N'scrypt'),
            (N'HashAlgorithm', N'ASPNETCORE_IDENTITY_V3', N'ASP.NET Core Identity V3'),
            (N'HashAlgorithm', N'PBKDF2', N'PBKDF2'),

            (N'LoginSessionStatus', N'ACTIVE', N'Active'),
            (N'LoginSessionStatus', N'REVOKED', N'Revoked'),
            (N'LoginSessionStatus', N'EXPIRED', N'Expired'),
            (N'LoginSessionStatus', N'LOGGED_OUT', N'Logged Out'),

            (N'PasswordResetRequestStatus', N'PENDING', N'Pending'),
            (N'PasswordResetRequestStatus', N'CONSUMED', N'Consumed'),
            (N'PasswordResetRequestStatus', N'EXPIRED', N'Expired'),
            (N'PasswordResetRequestStatus', N'REVOKED', N'Revoked'),

            (N'MfaFactorType', N'TOTP', N'Time-based One-Time Password'),
            (N'MfaFactorType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'MfaFactorType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'AuthenticationEventType', N'LOGIN_ATTEMPT', N'Login Attempt'),
            (N'AuthenticationEventType', N'LOGIN_SUCCESS', N'Login Success'),
            (N'AuthenticationEventType', N'LOGIN_FAILED', N'Login Failed'),
            (N'AuthenticationEventType', N'LOGOUT', N'Logout'),
            (N'AuthenticationEventType', N'PASSWORD_CHANGED', N'Password Changed'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_REQUESTED', N'Password Reset Requested'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_COMPLETED', N'Password Reset Completed'),
            (N'AuthenticationEventType', N'MFA_CHALLENGE_ISSUED', N'MFA Challenge Issued'),
            (N'AuthenticationEventType', N'MFA_SUCCESS', N'MFA Success'),
            (N'AuthenticationEventType', N'MFA_FAILED', N'MFA Failed'),
            (N'AuthenticationEventType', N'ACCOUNT_LOCKED', N'Account Locked'),
            (N'AuthenticationEventType', N'ACCOUNT_UNLOCKED', N'Account Unlocked'),

            (N'AuthenticationResult', N'SUCCESS', N'Success'),
            (N'AuthenticationResult', N'FAILURE', N'Failure'),
            (N'AuthenticationResult', N'CHALLENGED', N'Challenged'),
            (N'AuthenticationResult', N'BLOCKED', N'Blocked'),

            (N'AccountStatus', N'ACTIVE', N'Active'),
            (N'AccountStatus', N'PENDING_APPROVAL', N'Pending Approval'),
            (N'AccountStatus', N'INVITED', N'Invited'),
            (N'AccountStatus', N'DISABLED', N'Disabled')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue c
        WHERE c.CodeDomain = v.CodeDomain
          AND c.CodeValue = v.CodeValue
    );
END;
GO

IF OBJECT_ID(N'ref.SeedBatch', N'U') IS NOT NULL
AND NOT EXISTS
(
    SELECT 1
    FROM ref.SeedBatch sb
    WHERE sb.SeedBatchCode = N'AUTH_SECURITY_BASELINE'
)
BEGIN
    INSERT INTO ref.SeedBatch
    (
        SeedBatchCode,
        SeedBatchName,
        SeedBatchDescription,
        TargetSchemaName,
        TargetObjectName,
        BatchVersion,
        IsRequired,
        IsActive
    )
    VALUES
    (
        N'AUTH_SECURITY_BASELINE',
        N'Authentication Security Baseline',
        N'Seeds native authentication and audit reference codes required for portal credential, session, reset, MFA, and authentication event processing.',
        N'sec',
        N'PortalCredential',
        N'1.0.0',
        1,
        1
    );
END;
GO


IF OBJECT_ID(N'ref.Role', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.Role (RoleCode, RoleName, RoleDescription, IsSystemRole)
    SELECT v.RoleCode, v.RoleName, v.RoleDescription, v.IsSystemRole
    FROM
    (
        VALUES
            (N'PROVIDER_OWNER', N'Provider Owner', N'Primary provider account owner.', 1),
            (N'PROVIDER_STAFF', N'Provider Staff', N'Provider-side staff account with limited permissions.', 1),
            (N'GUARDIAN', N'Guardian', N'Parent or guardian portal user.', 1),
            (N'LICENSOR_USER', N'Licensor User', N'County/state licensing staff user.', 1),
            (N'LICENSOR_SUPERVISOR', N'Licensor Supervisor', N'Licensing supervisory user.', 1),
            (N'SUPPORT_ADMIN', N'Support Admin', N'Administrative support user with outbound-only chat initiation.', 1),
            (N'PLATFORM_ADMIN', N'Platform Admin', N'Platform administration user.', 1),
            (N'COMPLIANCE_ADMIN', N'Compliance Admin', N'Administrative user for compliance review and escalation.', 1),
            (N'DATABASE_ADMIN', N'Database Admin', N'Privileged database administrator role.', 1),
            (N'AUDITOR', N'Auditor', N'Read-only auditor role.', 1)
    ) v(RoleCode, RoleName, RoleDescription, IsSystemRole)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.Role r
        WHERE r.RoleCode = v.RoleCode
    );
END;
GO

IF OBJECT_ID(N'ref.TimeZone', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.TimeZone
    (
        TimeZoneCode,
        WindowsTimeZoneName,
        DisplayName,
        UtcOffsetMinutesStandard,
        ObservesDst
    )
    SELECT v.TimeZoneCode, v.WindowsTimeZoneName, v.DisplayName, v.UtcOffsetMinutesStandard, v.ObservesDst
    FROM
    (
        VALUES
            (N'America/Chicago', N'Central Standard Time', N'Central Time (US & Canada)', -360, 1),
            (N'America/New_York', N'Eastern Standard Time', N'Eastern Time (US & Canada)', -300, 1),
            (N'America/Denver', N'Mountain Standard Time', N'Mountain Time (US & Canada)', -420, 1),
            (N'America/Los_Angeles', N'Pacific Standard Time', N'Pacific Time (US & Canada)', -480, 1),
            (N'UTC', N'UTC', N'Coordinated Universal Time', 0, 0)
    ) v(TimeZoneCode, WindowsTimeZoneName, DisplayName, UtcOffsetMinutesStandard, ObservesDst)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.TimeZone tz
        WHERE tz.TimeZoneCode = v.TimeZoneCode
    );
END;
GO

IF OBJECT_ID(N'lic.LicenseClass', N'U') IS NOT NULL
BEGIN
    INSERT INTO lic.LicenseClass
    (
        LicenseClassCode,
        LicenseClassName,
        LicenseFamilyCode,
        Description
    )
    SELECT v.LicenseClassCode, v.LicenseClassName, v.LicenseFamilyCode, v.Description
    FROM
    (
        VALUES
            (N'A', N'Class A Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class A.'),
            (N'B1', N'Class B1 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B1.'),
            (N'B2', N'Class B2 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B2.'),
            (N'C1', N'Class C1 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C1.'),
            (N'C2', N'Class C2 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C2.'),
            (N'C3', N'Class C3 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C3.'),
            (N'D', N'Class D Special Family Child Care', N'FAMILY_CHILD_CARE', N'Special family child care classification.')
    ) v(LicenseClassCode, LicenseClassName, LicenseFamilyCode, Description)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM lic.LicenseClass lc
        WHERE lc.LicenseClassCode = v.LicenseClassCode
    );
END;
GO
