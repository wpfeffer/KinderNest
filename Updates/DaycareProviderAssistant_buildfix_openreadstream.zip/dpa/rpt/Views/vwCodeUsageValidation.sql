﻿/*
    NOTE
    ----
    This package phase keeps most ...Code columns as string columns.
    The central code inventory above is the Phase 1 control point.
    Stored procedures and validation/reporting views should enforce allowed values.
*/

CREATE VIEW rpt.vwCodeUsageValidation
AS
SELECT N'child.ChildPersonRelationship' AS TableName, N'RelationshipTypeCode' AS ColumnName, r.RelationshipTypeCode AS CodeValue
FROM child.ChildPersonRelationship r
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'RelationshipType'
      AND c.CodeValue = r.RelationshipTypeCode
)
UNION ALL
SELECT N'child.ChildEnrollment', N'EnrollmentStatusCode', e.EnrollmentStatusCode
FROM child.ChildEnrollment e
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'EnrollmentStatus'
      AND c.CodeValue = e.EnrollmentStatusCode
)
UNION ALL
SELECT N'child.GuardianInvitation', N'InvitationStatusCode', g.InvitationStatusCode
FROM child.GuardianInvitation g
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'GuardianInvitationStatus'
      AND c.CodeValue = g.InvitationStatusCode
)
UNION ALL
SELECT N'ops.IncidentReport', N'IncidentTypeCode', i.IncidentTypeCode
FROM ops.IncidentReport i
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'IncidentType'
      AND c.CodeValue = i.IncidentTypeCode
)
UNION ALL
SELECT N'comm.Conversation', N'ConversationTypeCode', c0.ConversationTypeCode
FROM comm.Conversation c0
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'ConversationType'
      AND c.CodeValue = c0.ConversationTypeCode
)
UNION ALL
SELECT N'party.PortalUser', N'AccountStatusCode', p.AccountStatusCode
FROM party.PortalUser p
WHERE NOT EXISTS
(
    SELECT 1
    FROM ref.CodeValue c
    WHERE c.CodeDomain = N'AccountStatus'
      AND c.CodeValue = p.AccountStatusCode
);