﻿CREATE VIEW rpt.vwCapacityInputsByDate
AS
SELECT
    cp.SiteID,
    CAST(cp.StartDateTimeUTC AS DATE) AS PresenceDateUTC,
    SUM(CASE WHEN cp.CountsAsAdultCaregiver = 1 THEN 1 ELSE 0 END) AS AdultCaregiverPresenceCount,
    SUM(CASE WHEN cp.CountsAsHelper = 1 THEN 1 ELSE 0 END) AS HelperPresenceCount
FROM ops.CaregiverPresence cp
WHERE cp.IsDeleted = 0
  AND cp.IsActive = 1
GROUP BY cp.SiteID, CAST(cp.StartDateTimeUTC AS DATE);