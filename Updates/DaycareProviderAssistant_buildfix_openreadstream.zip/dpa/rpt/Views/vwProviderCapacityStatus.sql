﻿CREATE VIEW rpt.vwProviderCapacityStatus
AS
SELECT
    s.SiteID,
    p.ProviderID,
    p.ProviderName,
    s.SiteName,
    lc.LicenseClassCode,
    lc.LicenseClassName,
    crs.MaxTotalChildren,
    crs.MinAdultCaregiversRequired,
    crs.MaxUnderSchoolAgeChildren,
    crs.MaxInfantToddlerChildren,
    crs.MaxUnder12MonthsChildren,
    crs.AllowHelperInLieuOfSecondAdult,
    crs.MaxInfantToddlerWhenHelperSubstitutes,
    crs.SingleAdultWithNewbornMaxOtherChildren,
    crs.SingleAdultWithNewbornMaxUnder12Months,
    crs.EffectiveStartDate,
    crs.EffectiveEndDate
FROM party.Site s
INNER JOIN party.Provider p
    ON p.ProviderID = s.ProviderID
INNER JOIN lic.LicenseClass lc
    ON lc.LicenseClassID = s.LicenseClassID
LEFT JOIN lic.CapacityRuleSet crs
    ON crs.LicenseClassID = lc.LicenseClassID
   AND crs.IsActive = 1
WHERE s.IsDeleted = 0
  AND p.IsDeleted = 0;