﻿CREATE VIEW rpt.vwDocumentStatus
AS
SELECT
    d.DocumentID,
    dt.DocumentTypeCode,
    dt.DocumentTypeName,
    d.OriginalFileName,
    d.StoredFileName,
    d.ContentType,
    d.StorageUri,
    d.FileHashHex,
    d.FileSizeBytes,
    d.VersionNumber,
    d.IsActive,
    d.IsDeleted,
    d.CreatedUTC,
    d.CreatedByUserID,
    ed.EntityDocumentID,
    ed.EntitySchemaName,
    ed.EntityTableName,
    ed.EntityPrimaryKeyValue,
    ed.Notes AS EntityNotes
FROM doc.Document d
INNER JOIN doc.DocumentType dt
    ON dt.DocumentTypeID = d.DocumentTypeID
LEFT JOIN doc.EntityDocument ed
    ON ed.DocumentID = d.DocumentID
   AND ed.IsActive = 1
WHERE d.IsDeleted = 0;