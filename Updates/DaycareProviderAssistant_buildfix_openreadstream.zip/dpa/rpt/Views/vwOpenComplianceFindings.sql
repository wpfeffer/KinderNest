﻿CREATE VIEW rpt.vwOpenComplianceFindings
AS
SELECT
    cr.SiteID,
    cr.ComplianceReviewID,
    cf.ComplianceFindingID,
    cf.ChildID,
    cf.RequirementID,
    cf.FindingSeverityCode,
    cf.FindingStatusCode,
    cf.FindingTitle,
    cf.FindingDescription,
    cf.CorrectiveActionRequired,
    cf.CorrectiveActionDueDate,
    fr.FindingResolutionID,
    fr.ResolutionStatusCode,
    fr.ResolutionSummary,
    fr.ResolvedUTC
FROM lic.ComplianceReview cr
INNER JOIN lic.ComplianceFinding cf
    ON cf.ComplianceReviewID = cr.ComplianceReviewID
   AND cf.IsDeleted = 0
   AND cf.IsActive = 1
LEFT JOIN lic.FindingResolution fr
    ON fr.ComplianceFindingID = cf.ComplianceFindingID
   AND fr.IsDeleted = 0
   AND fr.IsActive = 1
WHERE cr.IsDeleted = 0
  AND cr.IsActive = 1
  AND (cf.ClosedUTC IS NULL)
  AND cf.FindingStatusCode NOT IN (N'CLOSED', N'RESOLVED');