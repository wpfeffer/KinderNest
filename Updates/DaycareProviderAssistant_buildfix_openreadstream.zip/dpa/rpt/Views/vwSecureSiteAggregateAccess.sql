﻿CREATE VIEW rpt.vwSecureSiteAggregateAccess
AS
SELECT
    s.SiteID,
    s.SiteName,
    p.ProviderName,
    lc.LicenseClassCode,
    lc.LicenseClassName,
    CASE
        WHEN sec.fn_UserCanAccessSiteAggregate(sec.fn_GetSessionPortalUserID(), s.SiteID) = 1 THEN 1
        ELSE 0
    END AS HasAccess
FROM party.Site s
INNER JOIN party.Provider p
    ON p.ProviderID = s.ProviderID
INNER JOIN lic.LicenseClass lc
    ON lc.LicenseClassID = s.LicenseClassID
WHERE s.IsDeleted = 0
  AND p.IsDeleted = 0;