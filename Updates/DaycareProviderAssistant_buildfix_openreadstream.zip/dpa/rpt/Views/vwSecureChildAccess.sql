CREATE OR ALTER VIEW rpt.vwSecureChildAccess
AS
SELECT
    c.ChildID,
    c.SiteID,
    c.FirstName,
    c.MiddleName,
    c.LastName,
    c.DateOfBirth,
    c.SpecialDietNotes,
    c.SpecialNeedsNotes,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN 1
        ELSE 0
    END AS HasAccess,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN a.AddressLine1
        ELSE N'REDACTED'
    END AS AddressLine1,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN a.AddressLine2
        ELSE NULL
    END AS AddressLine2,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN a.City
        ELSE N'REDACTED'
    END AS City,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN a.StateProvinceCode
        ELSE NULL
    END AS StateCode,
    CASE
        WHEN sec.fn_UserCanAccessChildDetail(sec.fn_GetSessionPortalUserID(), c.ChildID) = 1 THEN a.PostalCode
        ELSE NULL
    END AS PostalCode
FROM child.Child c
LEFT JOIN party.Address a ON a.AddressID = c.ChildAddressID
WHERE c.IsDeleted = 0;
GO
