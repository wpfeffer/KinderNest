﻿CREATE VIEW rpt.vwLicensorAggregateChildCounts
AS
SELECT
    c.SiteID,
    COUNT(1) AS TotalChildren,
    SUM(CASE WHEN DATEDIFF(DAY, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) < 42 THEN 1 ELSE 0 END) AS NewbornCount,
    SUM(CASE WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) < 12
              AND DATEDIFF(DAY, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) >= 42 THEN 1 ELSE 0 END) AS InfantCount,
    SUM(CASE WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) >= 12
              AND DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) < 60 THEN 1 ELSE 0 END) AS UnderSchoolAgeApproxCount,
    SUM(CASE WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS DATE)) >= 60 THEN 1 ELSE 0 END) AS SchoolAgeApproxCount
FROM child.Child c
INNER JOIN child.ChildEnrollment ce
    ON ce.ChildID = c.ChildID
   AND ce.IsDeleted = 0
   AND ce.IsActive = 1
   AND ce.EnrollmentStartDate <= CAST(SYSUTCDATETIME() AS DATE)
   AND (ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= CAST(SYSUTCDATETIME() AS DATE))
WHERE c.IsDeleted = 0
  AND c.IsActive = 1
GROUP BY c.SiteID;