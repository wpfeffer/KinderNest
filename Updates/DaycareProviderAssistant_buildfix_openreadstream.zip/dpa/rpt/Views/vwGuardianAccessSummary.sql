﻿CREATE VIEW rpt.vwGuardianAccessSummary
AS
SELECT
    r.ChildPersonRelationshipID,
    r.ChildID,
    c.SiteID,
    r.PersonID,
    p.FirstName,
    p.LastName,
    p.PrimaryEmail,
    r.RelationshipTypeCode,
    r.HasPortalAccess,
    r.CanReceiveAlerts,
    r.CanSignPermissions,
    r.IsPrimaryGuardian,
    r.EffectiveStartDate,
    r.EffectiveEndDate,
    r.IsActive,
    pu.PortalUserID,
    pu.UserName,
    pu.AccountStatusCode
FROM child.ChildPersonRelationship r
INNER JOIN child.Child c
    ON c.ChildID = r.ChildID
INNER JOIN party.Person p
    ON p.PersonID = r.PersonID
LEFT JOIN party.PortalUser pu
    ON pu.PersonID = p.PersonID
   AND pu.IsDeleted = 0
WHERE r.IsDeleted = 0
  AND c.IsDeleted = 0
  AND p.IsDeleted = 0;