﻿CREATE VIEW rpt.vwActiveChildEnrollmentSummary
AS
SELECT
    c.ChildID,
    c.SiteID,
    ce.ChildEnrollmentID,
    c.FirstName,
    c.MiddleName,
    c.LastName,
    c.DateOfBirth,
    ce.EnrollmentStartDate,
    ce.EnrollmentEndDate,
    ce.EnrollmentStatusCode,
    ce.ScheduleSummary,
    ce.FinancialArrangementNotes,
    c.IsActive AS ChildIsActive,
    ce.IsActive AS EnrollmentIsActive
FROM child.Child c
INNER JOIN child.ChildEnrollment ce
    ON ce.ChildID = c.ChildID
WHERE c.IsDeleted = 0
  AND ce.IsDeleted = 0
  AND c.IsActive = 1
  AND ce.IsActive = 1;