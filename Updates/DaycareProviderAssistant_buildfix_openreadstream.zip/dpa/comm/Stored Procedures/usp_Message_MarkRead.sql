﻿CREATE PROCEDURE comm.usp_Message_MarkRead
    @MessageID                     INT,
    @PortalUserID                  INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM comm.MessageReadReceipt rr
        WHERE rr.MessageID = @MessageID
          AND rr.PortalUserID = @PortalUserID
    )
    BEGIN
        INSERT INTO comm.MessageReadReceipt
        (
            MessageID,
            PortalUserID,
            ReadUTC
        )
        VALUES
        (
            @MessageID,
            @PortalUserID,
            SYSUTCDATETIME()
        );
    END;
END;