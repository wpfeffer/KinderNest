﻿CREATE TABLE comm.EmailOutbox
(
    EmailOutboxID                 BIGINT IDENTITY(1,1)     NOT NULL,
    TemplateCode                  NVARCHAR(50)             NULL,
    ToEmail                       NVARCHAR(320)            NOT NULL,
    CcEmail                       NVARCHAR(MAX)           NULL,
    BccEmail                      NVARCHAR(MAX)           NULL,
    SubjectLine                   NVARCHAR(500)            NOT NULL,
    BodyText                      NVARCHAR(MAX)            NOT NULL,
    RelatedSchemaName             NVARCHAR(128)            NULL,
    RelatedTableName              NVARCHAR(128)            NULL,
    RelatedPrimaryKeyValue        NVARCHAR(128)            NULL,
    QueueStatusCode               NVARCHAR(50)             NOT NULL CONSTRAINT DF_EmailOutbox_QueueStatusCode DEFAULT (N'PENDING'),
    AttemptCount                  INT                      NOT NULL CONSTRAINT DF_EmailOutbox_AttemptCount DEFAULT (0),
    LastAttemptUTC                DATETIME2(0)             NULL,
    SentUTC                       DATETIME2(0)             NULL,
    FailureMessage                NVARCHAR(MAX)           NULL,
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_EmailOutbox_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    CONSTRAINT PK_EmailOutbox PRIMARY KEY CLUSTERED (EmailOutboxID)
);
GO
CREATE INDEX IX_EmailOutbox_QueueStatusCode ON comm.EmailOutbox (QueueStatusCode, CreatedUTC);
GO
CREATE INDEX IX_EmailOutbox_ToEmail ON comm.EmailOutbox (ToEmail, CreatedUTC DESC);