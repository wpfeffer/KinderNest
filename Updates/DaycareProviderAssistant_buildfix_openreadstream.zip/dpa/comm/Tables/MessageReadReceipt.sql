﻿CREATE TABLE comm.MessageReadReceipt
(
    MessageReadReceiptID         INT IDENTITY(1,1)         NOT NULL,
    MessageID                    INT                       NOT NULL,
    PortalUserID                 INT                       NOT NULL,
    ReadUTC                      DATETIME2(0)              NOT NULL,
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_MessageReadReceipt_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_MessageReadReceipt PRIMARY KEY CLUSTERED (MessageReadReceiptID),
    CONSTRAINT FK_MessageReadReceipt_Message FOREIGN KEY (MessageID) REFERENCES comm.Message (MessageID),
    CONSTRAINT FK_MessageReadReceipt_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT UQ_MessageReadReceipt UNIQUE (MessageID, PortalUserID)
);
GO
CREATE INDEX IX_MessageReadReceipt_PortalUserID ON comm.MessageReadReceipt (PortalUserID, ReadUTC DESC);