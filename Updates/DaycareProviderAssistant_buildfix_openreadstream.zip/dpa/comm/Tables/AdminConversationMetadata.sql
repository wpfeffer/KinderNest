﻿CREATE TABLE comm.AdminConversationMetadata
(
    AdminConversationMetadataID  INT IDENTITY(1,1)         NOT NULL,
    ConversationID               INT                       NOT NULL,
    AdminInitiatorUserID         INT                       NOT NULL,
    AdminInitiatorRoleCode       NVARCHAR(50)              NOT NULL,
    ReasonCode                   NVARCHAR(50)              NOT NULL,
    ReasonText                   NVARCHAR(MAX)            NULL,
    ScopeTypeCode                NVARCHAR(50)              NOT NULL,
    ScopeEntityID                NVARCHAR(128)             NULL,
    PriorityCode                 NVARCHAR(50)              NULL,
    RequiresAcknowledgment       BIT                       NOT NULL CONSTRAINT DF_AdminConversationMetadata_RequiresAck DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_AdminConversationMetadata_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_AdminConversationMetadata PRIMARY KEY CLUSTERED (AdminConversationMetadataID),
    CONSTRAINT FK_AdminConversationMetadata_Conversation FOREIGN KEY (ConversationID) REFERENCES comm.Conversation (ConversationID),
    CONSTRAINT FK_AdminConversationMetadata_AdminInitiator FOREIGN KEY (AdminInitiatorUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT UQ_AdminConversationMetadata_Conversation UNIQUE (ConversationID)
);