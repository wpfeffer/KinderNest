﻿CREATE TABLE comm.ConversationParticipantAudit
(
    ConversationParticipantAuditID INT IDENTITY(1,1)       NOT NULL,
    ConversationID                INT                      NOT NULL,
    PortalUserID                  INT                      NOT NULL,
    AuditActionCode               NVARCHAR(50)             NOT NULL,
    ActionUTC                     DATETIME2(0)             NOT NULL CONSTRAINT DF_ConversationParticipantAudit_ActionUTC DEFAULT (SYSUTCDATETIME()),
    ChangedByUserID               INT                      NULL,
    Notes                         NVARCHAR(MAX)           NULL,
    CONSTRAINT PK_ConversationParticipantAudit PRIMARY KEY CLUSTERED (ConversationParticipantAuditID),
    CONSTRAINT FK_ConversationParticipantAudit_Conversation FOREIGN KEY (ConversationID) REFERENCES comm.Conversation (ConversationID),
    CONSTRAINT FK_ConversationParticipantAudit_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_ConversationParticipantAudit_ChangedByUser FOREIGN KEY (ChangedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_ConversationParticipantAudit_ConversationID ON comm.ConversationParticipantAudit (ConversationID, ActionUTC DESC);