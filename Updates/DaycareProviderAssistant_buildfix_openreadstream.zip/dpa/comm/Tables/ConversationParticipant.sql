﻿CREATE TABLE comm.ConversationParticipant
(
    ConversationParticipantID    INT IDENTITY(1,1)         NOT NULL,
    ConversationID               INT                       NOT NULL,
    PortalUserID                 INT                       NOT NULL,
    ParticipantRoleCode          NVARCHAR(50)              NOT NULL,
    CanRead                      BIT                       NOT NULL CONSTRAINT DF_ConversationParticipant_CanRead DEFAULT (1),
    CanPost                      BIT                       NOT NULL CONSTRAINT DF_ConversationParticipant_CanPost DEFAULT (1),
    JoinedUTC                    DATETIME2(0)              NOT NULL CONSTRAINT DF_ConversationParticipant_JoinedUTC DEFAULT (SYSUTCDATETIME()),
    LeftUTC                      DATETIME2(0)              NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ConversationParticipant_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ConversationParticipant_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_ConversationParticipant PRIMARY KEY CLUSTERED (ConversationParticipantID),
    CONSTRAINT FK_ConversationParticipant_Conversation FOREIGN KEY (ConversationID) REFERENCES comm.Conversation (ConversationID),
    CONSTRAINT FK_ConversationParticipant_PortalUser FOREIGN KEY (PortalUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT UQ_ConversationParticipant UNIQUE (ConversationID, PortalUserID)
);
GO
CREATE INDEX IX_ConversationParticipant_ConversationID ON comm.ConversationParticipant (ConversationID, IsActive, PortalUserID);
GO
CREATE INDEX IX_ConversationParticipant_PortalUserID ON comm.ConversationParticipant (PortalUserID, IsActive, ConversationID);