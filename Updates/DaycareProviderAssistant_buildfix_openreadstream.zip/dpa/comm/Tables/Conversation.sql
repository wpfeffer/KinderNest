﻿CREATE TABLE comm.Conversation
(
    ConversationID               INT IDENTITY(1,1)         NOT NULL,
    ConversationTypeCode         NVARCHAR(50)              NOT NULL,
    SiteID                       INT                       NULL,
    ChildID                      INT                       NULL,
    Subject                      NVARCHAR(200)             NULL,
    IsArchived                   BIT                       NOT NULL CONSTRAINT DF_Conversation_IsArchived DEFAULT (0),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Conversation_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Conversation_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Conversation_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Conversation PRIMARY KEY CLUSTERED (ConversationID),
    CONSTRAINT FK_Conversation_Site FOREIGN KEY (SiteID) REFERENCES party.Site (SiteID),
    CONSTRAINT FK_Conversation_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID)
);
GO
CREATE INDEX IX_Conversation_SiteID ON comm.Conversation (SiteID, ConversationTypeCode, IsDeleted, IsActive);
GO
CREATE INDEX IX_Conversation_ChildID ON comm.Conversation (ChildID, ConversationTypeCode, IsDeleted, IsActive) WHERE ChildID IS NOT NULL;