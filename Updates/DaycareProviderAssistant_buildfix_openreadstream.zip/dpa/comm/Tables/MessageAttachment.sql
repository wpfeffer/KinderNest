﻿CREATE TABLE comm.MessageAttachment
(
    MessageAttachmentID          INT IDENTITY(1,1)         NOT NULL,
    MessageID                    INT                       NOT NULL,
    DocumentID                   INT                       NOT NULL,
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_MessageAttachment_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    CONSTRAINT PK_MessageAttachment PRIMARY KEY CLUSTERED (MessageAttachmentID),
    CONSTRAINT FK_MessageAttachment_Message FOREIGN KEY (MessageID) REFERENCES comm.Message (MessageID),
    CONSTRAINT FK_MessageAttachment_Document FOREIGN KEY (DocumentID) REFERENCES doc.Document (DocumentID)
);
GO
CREATE INDEX IX_MessageAttachment_MessageID ON comm.MessageAttachment (MessageID);