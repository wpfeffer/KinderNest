﻿CREATE TABLE comm.Message
(
    MessageID                    INT IDENTITY(1,1)         NOT NULL,
    ConversationID               INT                       NOT NULL,
    SenderUserID                 INT                       NOT NULL,
    MessageBody                  NVARCHAR(MAX)             NOT NULL,
    SentUTC                      DATETIME2(0)              NOT NULL CONSTRAINT DF_Message_SentUTC DEFAULT (SYSUTCDATETIME()),
    IsEdited                     BIT                       NOT NULL CONSTRAINT DF_Message_IsEdited DEFAULT (0),
    EditedUTC                    DATETIME2(0)              NULL,
    SoftDeletedUTC               DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Message_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NOT NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_Message PRIMARY KEY CLUSTERED (MessageID),
    CONSTRAINT FK_Message_Conversation FOREIGN KEY (ConversationID) REFERENCES comm.Conversation (ConversationID),
    CONSTRAINT FK_Message_SenderUser FOREIGN KEY (SenderUserID) REFERENCES party.PortalUser (PortalUserID),
    CONSTRAINT FK_Message_DeletedByUser FOREIGN KEY (DeletedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_Message_ConversationID ON comm.Message (ConversationID, SentUTC DESC);
GO
CREATE INDEX IX_Message_SenderUserID ON comm.Message (SenderUserID, SentUTC DESC);