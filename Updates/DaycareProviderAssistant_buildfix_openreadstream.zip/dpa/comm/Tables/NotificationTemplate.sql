﻿CREATE TABLE comm.NotificationTemplate
(
    NotificationTemplateID        INT IDENTITY(1,1)        NOT NULL,
    TemplateCode                  NVARCHAR(50)             NOT NULL,
    TemplateName                  NVARCHAR(200)            NOT NULL,
    ChannelCode                   NVARCHAR(50)             NOT NULL,
    SubjectTemplate               NVARCHAR(500)            NULL,
    BodyTemplate                  NVARCHAR(MAX)            NOT NULL,
    IsActive                      BIT                      NOT NULL CONSTRAINT DF_NotificationTemplate_IsActive DEFAULT (1),
    CreatedUTC                    DATETIME2(0)             NOT NULL CONSTRAINT DF_NotificationTemplate_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID               INT                      NULL,
    ModifiedUTC                   DATETIME2(0)             NULL,
    ModifiedByUserID              INT                      NULL,
    CONSTRAINT PK_NotificationTemplate PRIMARY KEY CLUSTERED (NotificationTemplateID),
    CONSTRAINT UQ_NotificationTemplate_TemplateCode UNIQUE (TemplateCode)
);