﻿CREATE VIEW ref.vwCodeDomains
AS
SELECT DISTINCT CodeDomain
FROM ref.CodeValue;