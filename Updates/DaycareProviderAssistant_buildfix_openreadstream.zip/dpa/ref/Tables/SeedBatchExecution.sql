﻿CREATE TABLE ref.SeedBatchExecution
(
    SeedBatchExecutionID         BIGINT IDENTITY(1,1)      NOT NULL,
    SeedBatchID                  INT                       NOT NULL,
    ExecutionStatusCode          NVARCHAR(50)              NOT NULL,
    StartedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_SeedBatchExecution_StartedUTC DEFAULT (SYSUTCDATETIME()),
    CompletedUTC                 DATETIME2(0)              NULL,
    ExecutedByUserID             INT                       NULL,
    ExecutionNotes               NVARCHAR(MAX)            NULL,
    RowsAffected                 INT                       NULL,
    CorrelationID                UNIQUEIDENTIFIER          NULL,
    CONSTRAINT PK_SeedBatchExecution PRIMARY KEY CLUSTERED (SeedBatchExecutionID),
    CONSTRAINT FK_SeedBatchExecution_SeedBatch FOREIGN KEY (SeedBatchID) REFERENCES ref.SeedBatch (SeedBatchID),
    CONSTRAINT FK_SeedBatchExecution_ExecutedByUser FOREIGN KEY (ExecutedByUserID) REFERENCES party.PortalUser (PortalUserID)
);
GO
CREATE INDEX IX_SeedBatchExecution_SeedBatchID ON ref.SeedBatchExecution (SeedBatchID, StartedUTC DESC);
GO
CREATE INDEX IX_SeedBatchExecution_Status ON ref.SeedBatchExecution (ExecutionStatusCode, StartedUTC DESC);