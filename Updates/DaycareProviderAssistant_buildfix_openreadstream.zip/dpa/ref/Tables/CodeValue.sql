﻿CREATE TABLE ref.CodeValue
(
    CodeValueID                  INT IDENTITY(1,1)         NOT NULL,
    CodeDomain                   NVARCHAR(100)             NOT NULL,
    CodeValue                    NVARCHAR(100)             NOT NULL,
    CodeName                     NVARCHAR(200)             NOT NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_CodeValue_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_CodeValue_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_CodeValue PRIMARY KEY CLUSTERED (CodeValueID),
    CONSTRAINT UQ_CodeValue UNIQUE (CodeDomain, CodeValue)
);