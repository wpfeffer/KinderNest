﻿CREATE TABLE ref.SeedBatch
(
    SeedBatchID                  INT IDENTITY(1,1)         NOT NULL,
    SeedBatchCode                NVARCHAR(100)             NOT NULL,
    SeedBatchName                NVARCHAR(200)             NOT NULL,
    SeedBatchDescription         NVARCHAR(MAX)            NULL,
    TargetSchemaName             NVARCHAR(128)             NULL,
    TargetObjectName             NVARCHAR(128)             NULL,
    BatchVersion                 NVARCHAR(50)              NOT NULL,
    IsRequired                   BIT                       NOT NULL CONSTRAINT DF_SeedBatch_IsRequired DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_SeedBatch_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_SeedBatch_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    CONSTRAINT PK_SeedBatch PRIMARY KEY CLUSTERED (SeedBatchID),
    CONSTRAINT UQ_SeedBatch_SeedBatchCode UNIQUE (SeedBatchCode)
);
GO
CREATE INDEX IX_SeedBatch_IsActive ON ref.SeedBatch (IsActive, SeedBatchCode);