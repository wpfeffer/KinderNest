﻿CREATE TABLE ref.TimeZone
(
    TimeZoneID                   INT IDENTITY(1,1)         NOT NULL,
    TimeZoneCode                 NVARCHAR(100)             NOT NULL,
    WindowsTimeZoneName          NVARCHAR(200)             NOT NULL,
    DisplayName                  NVARCHAR(200)             NOT NULL,
    UtcOffsetMinutesStandard     INT                       NOT NULL,
    ObservesDst                  BIT                       NOT NULL CONSTRAINT DF_TimeZone_ObservesDst DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_TimeZone_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_TimeZone_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_TimeZone PRIMARY KEY CLUSTERED (TimeZoneID),
    CONSTRAINT UQ_TimeZone_TimeZoneCode UNIQUE (TimeZoneCode),
    CONSTRAINT UQ_TimeZone_WindowsName UNIQUE (WindowsTimeZoneName)
);