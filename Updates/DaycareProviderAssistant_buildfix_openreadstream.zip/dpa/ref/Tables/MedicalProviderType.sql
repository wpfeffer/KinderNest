﻿CREATE TABLE ref.MedicalProviderType
    (
        MedicalProviderTypeID        INT IDENTITY(1,1)     NOT NULL,
        MedicalProviderTypeCode      NVARCHAR(50)          NOT NULL,
        MedicalProviderTypeName      NVARCHAR(200)         NOT NULL,
        IsActive                     BIT                   NOT NULL CONSTRAINT DF_MedicalProviderType_IsActive DEFAULT (1),
        CreatedUTC                   DATETIME2(0)          NOT NULL CONSTRAINT DF_MedicalProviderType_CreatedUTC DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT PK_MedicalProviderType PRIMARY KEY CLUSTERED (MedicalProviderTypeID),
        CONSTRAINT UQ_MedicalProviderType_Code UNIQUE (MedicalProviderTypeCode)
    );