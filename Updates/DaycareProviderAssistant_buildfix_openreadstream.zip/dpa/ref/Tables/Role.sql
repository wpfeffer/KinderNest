﻿CREATE TABLE ref.Role
(
    RoleID                       INT IDENTITY(1,1)         NOT NULL,
    RoleCode                     NVARCHAR(50)              NOT NULL,
    RoleName                     NVARCHAR(200)             NOT NULL,
    RoleDescription              NVARCHAR(500)             NULL,
    IsSystemRole                 BIT                       NOT NULL CONSTRAINT DF_Role_IsSystemRole DEFAULT (1),
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Role_IsActive DEFAULT (1),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Role_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_Role PRIMARY KEY CLUSTERED (RoleID),
    CONSTRAINT UQ_Role_RoleCode UNIQUE (RoleCode)
);