CREATE OR ALTER PROCEDURE ref.usp_TimeZone_ListActive
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        tz.TimeZoneID,
        tz.TimeZoneCode,
        tz.WindowsTimeZoneName,
        tz.DisplayName,
        tz.UtcOffsetMinutesStandard,
        tz.ObservesDst,
        tz.IsActive
    FROM ref.TimeZone tz
    WHERE tz.IsActive = 1
    ORDER BY
        tz.UtcOffsetMinutesStandard,
        tz.DisplayName,
        tz.TimeZoneCode;
END;
GO
