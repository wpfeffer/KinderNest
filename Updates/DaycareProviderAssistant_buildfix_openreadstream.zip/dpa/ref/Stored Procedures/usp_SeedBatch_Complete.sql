﻿CREATE PROCEDURE ref.usp_SeedBatch_Complete
    @SeedBatchExecutionID        BIGINT,
    @ExecutionStatusCode         NVARCHAR(50),
    @RowsAffected                INT                = NULL,
    @ExecutionNotes              NVARCHAR(MAX)     = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    UPDATE ref.SeedBatchExecution
       SET ExecutionStatusCode = @ExecutionStatusCode,
           CompletedUTC = SYSUTCDATETIME(),
           RowsAffected = @RowsAffected,
           ExecutionNotes = COALESCE(@ExecutionNotes, ExecutionNotes)
     WHERE SeedBatchExecutionID = @SeedBatchExecutionID;

    IF @@ROWCOUNT = 0
    BEGIN
        THROW 50301, 'Seed batch execution record not found.', 1;
    END;

    SELECT @SeedBatchExecutionID AS SeedBatchExecutionID;
END;