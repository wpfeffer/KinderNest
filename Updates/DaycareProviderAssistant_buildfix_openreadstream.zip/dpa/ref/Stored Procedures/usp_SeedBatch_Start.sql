﻿CREATE PROCEDURE ref.usp_SeedBatch_Start
    @SeedBatchCode               NVARCHAR(100),
    @ExecutedByUserID            INT                = NULL,
    @ExecutionNotes              NVARCHAR(MAX)     = NULL,
    @CorrelationID               UNIQUEIDENTIFIER   = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SeedBatchID INT;
    DECLARE @SeedBatchExecutionID BIGINT;

    SELECT @SeedBatchID = sb.SeedBatchID
    FROM ref.SeedBatch sb
    WHERE sb.SeedBatchCode = @SeedBatchCode
      AND sb.IsActive = 1;

    IF @SeedBatchID IS NULL
    BEGIN
        THROW 50300, 'Seed batch code not found or inactive.', 1;
    END;

    INSERT INTO ref.SeedBatchExecution
    (
        SeedBatchID,
        ExecutionStatusCode,
        ExecutedByUserID,
        ExecutionNotes,
        CorrelationID
    )
    VALUES
    (
        @SeedBatchID,
        N'STARTED',
        @ExecutedByUserID,
        @ExecutionNotes,
        @CorrelationID
    );

    SET @SeedBatchExecutionID = SCOPE_IDENTITY();

    SELECT @SeedBatchExecutionID AS SeedBatchExecutionID;
END;