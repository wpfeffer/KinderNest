DPA stored procedure batch 2 of 4

Theme:
Portal dashboards, document queues, messaging lists, attendance summary, pickup authorization upsert, and image subject lookup.

Included procedures:
1. ops.usp_GuardianPortal_Dashboard_GetSummary
2. doc.usp_GuardianPortal_Consent_List
3. comm.usp_GuardianPortal_Conversation_List
4. ops.usp_ProviderPortal_Dashboard_GetSummary
5. child.usp_ProviderPortal_Attendance_GetSummary
6. doc.usp_ProviderPortal_DocumentQueue_List
7. comm.usp_ProviderPortal_Conversation_List
8. child.usp_ProviderPortal_PickupAuthorization_Upsert
9. child.usp_SiteImageSubjectChild_List
10. party.usp_SiteImageSubjectAdult_List

All procedures are CREATE OR ALTER and are intended as non-destructive additions to the current migration path.
