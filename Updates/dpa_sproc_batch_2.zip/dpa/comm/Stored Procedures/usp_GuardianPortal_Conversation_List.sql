CREATE OR ALTER PROCEDURE comm.usp_GuardianPortal_Conversation_List
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH MyConversations AS
    (
        SELECT DISTINCT c.ConversationID, c.Subject, c.SiteID, c.ChildID, c.CreatedUTC
        FROM comm.ConversationParticipant cp
        INNER JOIN comm.Conversation c
            ON c.ConversationID = cp.ConversationID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        WHERE cp.PortalUserID = @PortalUserID
          AND cp.IsActive = 1
          AND cp.CanRead = 1
    ),
    LatestMessage AS
    (
        SELECT
            mc.ConversationID,
            m.MessageID,
            m.SenderUserID,
            m.MessageBody,
            m.SentUTC,
            ROW_NUMBER() OVER (PARTITION BY mc.ConversationID ORDER BY m.SentUTC DESC, m.MessageID DESC) AS RowNum
        FROM MyConversations mc
        LEFT JOIN comm.Message m
            ON m.ConversationID = mc.ConversationID
           AND m.SoftDeletedUTC IS NULL
    ),
    CounterpartyAgg AS
    (
        SELECT
            cp.ConversationID,
            STRING_AGG(LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))), N', ') WITHIN GROUP (ORDER BY p.LastName, p.FirstName) AS CounterpartyDisplay
        FROM comm.ConversationParticipant cp
        INNER JOIN party.PortalUser pu
            ON pu.PortalUserID = cp.PortalUserID
           AND pu.IsDeleted = 0
        INNER JOIN party.Person p
            ON p.PersonID = pu.PersonID
           AND p.IsDeleted = 0
        WHERE cp.IsActive = 1
          AND cp.PortalUserID <> @PortalUserID
        GROUP BY cp.ConversationID
    )
    SELECT TOP (50)
        mc.ConversationID,
        Subject = COALESCE(NULLIF(mc.Subject, N''), N'Conversation #' + CONVERT(NVARCHAR(20), mc.ConversationID)),
        CounterpartyDisplay = COALESCE(NULLIF(ca.CounterpartyDisplay, N''), N'No other participants returned'),
        LatestSnippet = COALESCE(LEFT(REPLACE(REPLACE(lm.MessageBody, CHAR(13), N' '), CHAR(10), N' '), 200), N'No messages yet'),
        LatestMessageUTC = lm.SentUTC,
        StatusText = CASE
            WHEN lm.MessageID IS NULL THEN N'Empty'
            WHEN lm.SenderUserID <> @PortalUserID AND mrr.MessageReadReceiptID IS NULL THEN N'Unread'
            WHEN lm.SenderUserID <> @PortalUserID THEN N'Needs reply'
            ELSE N'Reviewed'
        END,
        StatusCssClass = CASE
            WHEN lm.MessageID IS NULL THEN N'info'
            WHEN lm.SenderUserID <> @PortalUserID AND mrr.MessageReadReceiptID IS NULL THEN N'info'
            WHEN lm.SenderUserID <> @PortalUserID THEN N'warning'
            ELSE N'success'
        END,
        SiteName = s.SiteName,
        ChildName = CASE WHEN c.ChildID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))) END
    FROM MyConversations mc
    LEFT JOIN LatestMessage lm
        ON lm.ConversationID = mc.ConversationID
       AND lm.RowNum = 1
    LEFT JOIN comm.MessageReadReceipt mrr
        ON mrr.MessageID = lm.MessageID
       AND mrr.PortalUserID = @PortalUserID
    LEFT JOIN CounterpartyAgg ca
        ON ca.ConversationID = mc.ConversationID
    LEFT JOIN comm.Conversation c
        ON c.ConversationID = mc.ConversationID
    LEFT JOIN party.Site s
        ON s.SiteID = c.SiteID
    LEFT JOIN child.Child ch
        ON ch.ChildID = c.ChildID
    ORDER BY COALESCE(lm.SentUTC, mc.CreatedUTC) DESC, mc.ConversationID DESC;
END;
GO
