CREATE OR ALTER PROCEDURE ops.usp_ProviderPortal_Dashboard_GetSummary
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH CurrentSites AS
    (
        SELECT DISTINCT s.SiteID, s.SiteName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ),
    CurrentChildren AS
    (
        SELECT DISTINCT
            c.ChildID,
            c.SiteID,
            c.FirstName,
            c.LastName
        FROM child.Child c
        INNER JOIN CurrentSites cs
            ON cs.SiteID = c.SiteID
        LEFT JOIN child.ChildEnrollment ce
            ON ce.ChildID = c.ChildID
           AND ce.IsDeleted = 0
           AND ce.IsActive = 1
           AND ce.EnrollmentStartDate <= @Today
           AND (ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= @Today)
        WHERE c.IsDeleted = 0
          AND c.IsActive = 1
          AND (ce.ChildEnrollmentID IS NULL OR ce.ChildEnrollmentID IS NOT NULL)
    ),
    LatestConversationMessage AS
    (
        SELECT
            cp.ConversationID,
            m.MessageID,
            m.SenderUserID,
            m.MessageBody,
            m.SentUTC,
            ROW_NUMBER() OVER (PARTITION BY cp.ConversationID ORDER BY m.SentUTC DESC, m.MessageID DESC) AS RowNum
        FROM comm.ConversationParticipant cp
        INNER JOIN comm.Conversation c
            ON c.ConversationID = cp.ConversationID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        LEFT JOIN comm.Message m
            ON m.ConversationID = c.ConversationID
           AND m.SoftDeletedUTC IS NULL
        WHERE cp.PortalUserID = @PortalUserID
          AND cp.IsActive = 1
          AND cp.CanRead = 1
    ),
    UnreadConversationSet AS
    (
        SELECT DISTINCT lcm.ConversationID
        FROM LatestConversationMessage lcm
        LEFT JOIN comm.MessageReadReceipt mrr
            ON mrr.MessageID = lcm.MessageID
           AND mrr.PortalUserID = @PortalUserID
        WHERE lcm.RowNum = 1
          AND lcm.MessageID IS NOT NULL
          AND lcm.SenderUserID <> @PortalUserID
          AND mrr.MessageReadReceiptID IS NULL
    )
    SELECT
        SiteCount = (SELECT COUNT(1) FROM CurrentSites),
        ActiveChildren = (SELECT COUNT(1) FROM CurrentChildren),
        CheckedInNow =
        (
            SELECT COUNT(DISTINCT ca.ChildID)
            FROM child.ChildAttendance ca
            INNER JOIN CurrentSites cs
                ON cs.SiteID = ca.SiteID
            WHERE ca.IsDeleted = 0
              AND ca.IsActive = 1
              AND ca.StartDateTimeUTC <= SYSUTCDATETIME()
              AND ca.EndDateTimeUTC >= SYSUTCDATETIME()
        ),
        PendingConsents =
        (
            SELECT COUNT(1)
            FROM doc.ConsentRecord cr
            INNER JOIN CurrentChildren cc
                ON cc.ChildID = cr.ChildID
            WHERE cr.IsDeleted = 0
              AND cr.IsActive = 1
              AND cr.SignedUTC IS NULL
              AND (cr.ExpirationDate IS NULL OR cr.ExpirationDate >= @Today)
        ),
        UnreadConversations = (SELECT COUNT(1) FROM UnreadConversationSet);

    ;WITH CurrentSites AS
    (
        SELECT DISTINCT s.SiteID, s.SiteName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ),
    CurrentChildren AS
    (
        SELECT DISTINCT
            c.ChildID,
            c.SiteID,
            ChildDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName)))
        FROM child.Child c
        INNER JOIN CurrentSites cs
            ON cs.SiteID = c.SiteID
        WHERE c.IsDeleted = 0
          AND c.IsActive = 1
    ),
    LatestConversationMessage AS
    (
        SELECT
            cp.ConversationID,
            c.SiteID,
            c.ChildID,
            c.Subject,
            m.MessageID,
            m.SenderUserID,
            m.MessageBody,
            m.SentUTC,
            ROW_NUMBER() OVER (PARTITION BY cp.ConversationID ORDER BY m.SentUTC DESC, m.MessageID DESC) AS RowNum
        FROM comm.ConversationParticipant cp
        INNER JOIN comm.Conversation c
            ON c.ConversationID = cp.ConversationID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        LEFT JOIN comm.Message m
            ON m.ConversationID = c.ConversationID
           AND m.SoftDeletedUTC IS NULL
        WHERE cp.PortalUserID = @PortalUserID
          AND cp.IsActive = 1
          AND cp.CanRead = 1
    )
    SELECT TOP (12)
        Title,
        Detail,
        StatusText,
        StatusCssClass,
        SortDateTimeUTC
    FROM
    (
        SELECT
            Title = N'Consent waiting for signature',
            Detail = CONCAT(cc.ChildDisplayName, N' • ', cr.ConsentTypeCode),
            StatusText = N'Warning',
            StatusCssClass = N'warning',
            SortDateTimeUTC = COALESCE(cr.ModifiedUTC, cr.CreatedUTC)
        FROM doc.ConsentRecord cr
        INNER JOIN CurrentChildren cc
            ON cc.ChildID = cr.ChildID
        WHERE cr.IsDeleted = 0
          AND cr.IsActive = 1
          AND cr.SignedUTC IS NULL
          AND (cr.ExpirationDate IS NULL OR cr.ExpirationDate >= @Today)

        UNION ALL

        SELECT
            Title = N'Unread message',
            Detail = CONCAT(COALESCE(NULLIF(lcm.Subject, N''), N'Conversation'), N' • ', COALESCE(cs.SiteName, N'No site')),
            StatusText = N'Info',
            StatusCssClass = N'info',
            SortDateTimeUTC = lcm.SentUTC
        FROM LatestConversationMessage lcm
        LEFT JOIN CurrentSites cs
            ON cs.SiteID = lcm.SiteID
        LEFT JOIN comm.MessageReadReceipt mrr
            ON mrr.MessageID = lcm.MessageID
           AND mrr.PortalUserID = @PortalUserID
        WHERE lcm.RowNum = 1
          AND lcm.MessageID IS NOT NULL
          AND lcm.SenderUserID <> @PortalUserID
          AND mrr.MessageReadReceiptID IS NULL

        UNION ALL

        SELECT
            Title = N'Compliance finding open',
            Detail = CONCAT(s.SiteName, N' • ', ocf.FindingTitle),
            StatusText = CASE WHEN UPPER(ocf.FindingSeverityCode) IN (N'CRITICAL', N'HIGH') THEN N'Critical' ELSE N'Warning' END,
            StatusCssClass = CASE WHEN UPPER(ocf.FindingSeverityCode) IN (N'CRITICAL', N'HIGH') THEN N'critical' ELSE N'warning' END,
            SortDateTimeUTC = DATEADD(DAY, 0, CAST(COALESCE(ocf.CorrectiveActionDueDate, @Today) AS DATETIME2(0)))
        FROM rpt.vwOpenComplianceFindings ocf
        INNER JOIN party.Site s
            ON s.SiteID = ocf.SiteID
        INNER JOIN CurrentSites cs
            ON cs.SiteID = ocf.SiteID
    ) alerts
    ORDER BY SortDateTimeUTC DESC, Title;
END;
GO
