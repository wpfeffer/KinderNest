CREATE OR ALTER PROCEDURE ops.usp_GuardianPortal_Dashboard_GetSummary
    @PortalUserID INT,
    @PersonID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH CurrentLinks AS
    (
        SELECT DISTINCT
            cpr.ChildID,
            c.SiteID,
            cpr.IsPrimaryGuardian,
            HasPickupAuthorization = CASE
                WHEN cpr.IsPrimaryGuardian = 1 THEN 1
                WHEN EXISTS
                     (
                         SELECT 1
                         FROM child.PickupDropoffAuthorization pda
                         WHERE pda.ChildID = cpr.ChildID
                           AND pda.PersonID = cpr.PersonID
                           AND pda.IsDeleted = 0
                           AND pda.IsActive = 1
                           AND pda.CanPickup = 1
                           AND pda.EffectiveStartDate <= @Today
                           AND (pda.EffectiveEndDate IS NULL OR pda.EffectiveEndDate >= @Today)
                     ) THEN 1
                ELSE 0
            END
        FROM child.ChildPersonRelationship cpr
        INNER JOIN child.Child c
            ON c.ChildID = cpr.ChildID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        WHERE cpr.PersonID = @PersonID
          AND cpr.IsDeleted = 0
          AND cpr.IsActive = 1
          AND cpr.HasPortalAccess = 1
          AND cpr.EffectiveStartDate <= @Today
          AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= @Today)
    ),
    LatestConversationMessage AS
    (
        SELECT
            cp.ConversationID,
            m.MessageID,
            m.SenderUserID,
            m.MessageBody,
            m.SentUTC,
            ROW_NUMBER() OVER (PARTITION BY cp.ConversationID ORDER BY m.SentUTC DESC, m.MessageID DESC) AS RowNum
        FROM comm.ConversationParticipant cp
        INNER JOIN comm.Conversation c
            ON c.ConversationID = cp.ConversationID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        LEFT JOIN comm.Message m
            ON m.ConversationID = c.ConversationID
           AND m.SoftDeletedUTC IS NULL
        WHERE cp.PortalUserID = @PortalUserID
          AND cp.IsActive = 1
          AND cp.CanRead = 1
    ),
    UnreadConversationSet AS
    (
        SELECT DISTINCT lcm.ConversationID
        FROM LatestConversationMessage lcm
        LEFT JOIN comm.MessageReadReceipt mrr
            ON mrr.MessageID = lcm.MessageID
           AND mrr.PortalUserID = @PortalUserID
        WHERE lcm.RowNum = 1
          AND lcm.MessageID IS NOT NULL
          AND lcm.SenderUserID <> @PortalUserID
          AND mrr.MessageReadReceiptID IS NULL
    )
    SELECT
        LinkedChildren = (SELECT COUNT(1) FROM CurrentLinks),
        PendingConsents =
        (
            SELECT COUNT(1)
            FROM doc.ConsentRecord cr
            INNER JOIN CurrentLinks cl
                ON cl.ChildID = cr.ChildID
            WHERE cr.IsDeleted = 0
              AND cr.IsActive = 1
              AND cr.SignedUTC IS NULL
              AND (cr.ExpirationDate IS NULL OR cr.ExpirationDate >= @Today)
        ),
        UnreadMessages = (SELECT COUNT(1) FROM UnreadConversationSet),
        PickupAuthorizations = (SELECT COUNT(1) FROM CurrentLinks WHERE HasPickupAuthorization = 1);

    ;WITH CurrentLinks AS
    (
        SELECT DISTINCT
            cpr.ChildID,
            c.SiteID,
            ChildDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName)))
        FROM child.ChildPersonRelationship cpr
        INNER JOIN child.Child c
            ON c.ChildID = cpr.ChildID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        WHERE cpr.PersonID = @PersonID
          AND cpr.IsDeleted = 0
          AND cpr.IsActive = 1
          AND cpr.HasPortalAccess = 1
          AND cpr.EffectiveStartDate <= @Today
          AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= @Today)
    ),
    LatestConversationMessage AS
    (
        SELECT
            cp.ConversationID,
            c.SiteID,
            c.ChildID,
            c.Subject,
            m.MessageID,
            m.SenderUserID,
            m.SentUTC,
            ROW_NUMBER() OVER (PARTITION BY cp.ConversationID ORDER BY m.SentUTC DESC, m.MessageID DESC) AS RowNum
        FROM comm.ConversationParticipant cp
        INNER JOIN comm.Conversation c
            ON c.ConversationID = cp.ConversationID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        LEFT JOIN comm.Message m
            ON m.ConversationID = c.ConversationID
           AND m.SoftDeletedUTC IS NULL
        WHERE cp.PortalUserID = @PortalUserID
          AND cp.IsActive = 1
          AND cp.CanRead = 1
    )
    SELECT TOP (12)
        Title,
        Detail,
        StatusText,
        StatusCssClass,
        SortDateTimeUTC
    FROM
    (
        SELECT
            Title = N'Document waiting for signature',
            Detail = CONCAT(cl.ChildDisplayName, N' • ', cr.ConsentTypeCode),
            StatusText = N'Pending',
            StatusCssClass = N'pending',
            SortDateTimeUTC = COALESCE(cr.ModifiedUTC, cr.CreatedUTC)
        FROM doc.ConsentRecord cr
        INNER JOIN CurrentLinks cl
            ON cl.ChildID = cr.ChildID
        WHERE cr.IsDeleted = 0
          AND cr.IsActive = 1
          AND cr.SignedUTC IS NULL
          AND (cr.ExpirationDate IS NULL OR cr.ExpirationDate >= @Today)

        UNION ALL

        SELECT
            Title = N'New provider message',
            Detail = COALESCE(NULLIF(lcm.Subject, N''), N'Conversation'),
            StatusText = N'Info',
            StatusCssClass = N'info',
            SortDateTimeUTC = lcm.SentUTC
        FROM LatestConversationMessage lcm
        LEFT JOIN comm.MessageReadReceipt mrr
            ON mrr.MessageID = lcm.MessageID
           AND mrr.PortalUserID = @PortalUserID
        WHERE lcm.RowNum = 1
          AND lcm.MessageID IS NOT NULL
          AND lcm.SenderUserID <> @PortalUserID
          AND mrr.MessageReadReceiptID IS NULL

        UNION ALL

        SELECT
            Title = N'Upcoming consent expiration',
            Detail = CONCAT(cl.ChildDisplayName, N' • ', cr.ConsentTypeCode),
            StatusText = N'Warning',
            StatusCssClass = N'warning',
            SortDateTimeUTC = DATEADD(DAY, 0, CAST(cr.ExpirationDate AS DATETIME2(0)))
        FROM doc.ConsentRecord cr
        INNER JOIN CurrentLinks cl
            ON cl.ChildID = cr.ChildID
        WHERE cr.IsDeleted = 0
          AND cr.IsActive = 1
          AND cr.ExpirationDate BETWEEN @Today AND DATEADD(DAY, 14, @Today)
    ) alerts
    ORDER BY SortDateTimeUTC DESC, Title;
END;
GO
