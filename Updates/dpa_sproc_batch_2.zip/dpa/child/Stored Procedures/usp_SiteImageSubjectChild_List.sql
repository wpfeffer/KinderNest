CREATE OR ALTER PROCEDURE child.usp_SiteImageSubjectChild_List
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.ChildID,
        CONCAT(c.FirstName, N' ', c.LastName) AS DisplayName,
        CONVERT(NVARCHAR(10), c.DateOfBirth, 23) AS Detail
    FROM child.Child c
    WHERE c.SiteID = @SiteID
      AND c.IsDeleted = 0
      AND c.IsActive = 1
    ORDER BY c.LastName, c.FirstName, c.ChildID;
END;
GO
