CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Attendance_GetSummary
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH CurrentSites AS
    (
        SELECT DISTINCT s.SiteID
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ),
    TodayAttendance AS
    (
        SELECT
            ca.ChildAttendanceID,
            ca.ChildID,
            ca.SiteID,
            ca.AttendanceDateLocal,
            ca.StartDateTimeUTC,
            ca.EndDateTimeUTC,
            ca.Notes,
            DurationHours = CAST(DATEDIFF(MINUTE, ca.StartDateTimeUTC, ca.EndDateTimeUTC) AS DECIMAL(10,2)) / 60.0
        FROM child.ChildAttendance ca
        INNER JOIN CurrentSites cs
            ON cs.SiteID = ca.SiteID
        WHERE ca.IsDeleted = 0
          AND ca.IsActive = 1
          AND ca.AttendanceDateLocal = @Today
    )
    SELECT
        CheckedInNow = SUM(CASE WHEN ta.StartDateTimeUTC <= SYSUTCDATETIME() AND ta.EndDateTimeUTC >= SYSUTCDATETIME() THEN 1 ELSE 0 END),
        AttendanceRecordsToday = COUNT(1),
        ChildrenWithAttendanceToday = COUNT(DISTINCT ta.ChildID),
        AverageHoursToday = CAST(ISNULL(AVG(ta.DurationHours), 0) AS DECIMAL(10,2))
    FROM TodayAttendance ta;

    ;WITH CurrentSites AS
    (
        SELECT DISTINCT s.SiteID, s.SiteName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ),
    TodayAttendance AS
    (
        SELECT TOP (25)
            ca.ChildAttendanceID,
            ChildDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName))),
            cs.SiteName,
            ca.AttendanceDateLocal,
            ca.StartDateTimeUTC,
            ca.EndDateTimeUTC,
            DurationHours = CAST(DATEDIFF(MINUTE, ca.StartDateTimeUTC, ca.EndDateTimeUTC) AS DECIMAL(10,2)) / 60.0,
            StatusText = CASE WHEN ca.StartDateTimeUTC <= SYSUTCDATETIME() AND ca.EndDateTimeUTC >= SYSUTCDATETIME() THEN N'Checked in' ELSE N'Closed' END,
            StatusCssClass = CASE WHEN ca.StartDateTimeUTC <= SYSUTCDATETIME() AND ca.EndDateTimeUTC >= SYSUTCDATETIME() THEN N'info' ELSE N'success' END,
            ca.Notes
        FROM child.ChildAttendance ca
        INNER JOIN CurrentSites cs
            ON cs.SiteID = ca.SiteID
        INNER JOIN child.Child c
            ON c.ChildID = ca.ChildID
           AND c.IsDeleted = 0
        WHERE ca.IsDeleted = 0
          AND ca.IsActive = 1
          AND ca.AttendanceDateLocal = @Today
        ORDER BY ca.StartDateTimeUTC DESC, ca.ChildAttendanceID DESC
    )
    SELECT *
    FROM TodayAttendance
    ORDER BY StartDateTimeUTC DESC, ChildAttendanceID DESC;
END;
GO
