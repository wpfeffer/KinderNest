CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_PickupAuthorization_Upsert
    @PortalUserID                    INT,
    @HouseholdID                     INT,
    @PickupDropoffAuthorizationID    INT = NULL,
    @ChildID                         INT,
    @PersonID                        INT = NULL,
    @FirstName                       NVARCHAR(100) = NULL,
    @MiddleName                      NVARCHAR(100) = NULL,
    @LastName                        NVARCHAR(100) = NULL,
    @PrimaryEmail                    NVARCHAR(320) = NULL,
    @HouseholdRoleCodeValueID        INT = NULL,
    @CanPickup                       BIT = 0,
    @CanDropoff                      BIT = 0,
    @IsEmergencyContact              BIT = 0,
    @Notes                           NVARCHAR(MAX) = NULL,
    @EffectiveStartDate              DATE = NULL,
    @EffectiveEndDate                DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @NowUTC DATETIME2(0) = SYSUTCDATETIME();
    DECLARE @Today DATE = CONVERT(date, @NowUTC);
    DECLARE @ProviderID INT;
    DECLARE @ResolvedPersonID INT = @PersonID;

    IF NOT EXISTS
    (
        SELECT 1
        FROM child.ChildHousehold chh
        WHERE chh.HouseholdID = @HouseholdID
          AND chh.ChildID = @ChildID
          AND chh.IsDeleted = 0
          AND chh.IsActive = 1
    )
    BEGIN
        THROW 51040, 'The requested child is not linked to the requested household.', 1;
    END;

    SELECT @ProviderID = h.ProviderID
    FROM party.Household h
    WHERE h.HouseholdID = @HouseholdID
      AND h.IsDeleted = 0
      AND h.IsActive = 1;

    IF @ProviderID IS NULL
        THROW 51041, 'The requested household does not exist.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.ProviderID = @ProviderID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= @NowUTC
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= @NowUTC)
    )
    BEGIN
        THROW 51042, 'The current provider user cannot modify this household.', 1;
    END;

    BEGIN TRANSACTION;

    IF @ResolvedPersonID IS NULL
    BEGIN
        IF NULLIF(LTRIM(RTRIM(@FirstName)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(@LastName)), N'') IS NULL
        BEGIN
            THROW 51043, 'First and last name are required when creating a new pickup/dropoff person.', 1;
        END;

        INSERT INTO party.Person
        (
            FirstName,
            MiddleName,
            LastName,
            PrimaryEmail,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@FirstName)),
            NULLIF(LTRIM(RTRIM(@MiddleName)), N''),
            LTRIM(RTRIM(@LastName)),
            NULLIF(LTRIM(RTRIM(@PrimaryEmail)), N''),
            1,
            0,
            @PortalUserID
        );

        SET @ResolvedPersonID = SCOPE_IDENTITY();

        IF @HouseholdRoleCodeValueID IS NOT NULL
           AND NOT EXISTS
           (
               SELECT 1
               FROM party.HouseholdPerson hp
               WHERE hp.HouseholdID = @HouseholdID
                 AND hp.PersonID = @ResolvedPersonID
                 AND hp.IsDeleted = 0
           )
        BEGIN
            INSERT INTO party.HouseholdPerson
            (
                HouseholdID,
                PersonID,
                HouseholdRoleCodeValueID,
                IsPrimaryContact,
                EffectiveStartDate,
                IsActive,
                IsDeleted,
                CreatedByUserID
            )
            VALUES
            (
                @HouseholdID,
                @ResolvedPersonID,
                @HouseholdRoleCodeValueID,
                0,
                COALESCE(@EffectiveStartDate, @Today),
                1,
                0,
                @PortalUserID
            );
        END;
    END
    ELSE IF @PickupDropoffAuthorizationID IS NULL
         AND @HouseholdRoleCodeValueID IS NOT NULL
         AND NOT EXISTS
         (
             SELECT 1
             FROM party.HouseholdPerson hp
             WHERE hp.HouseholdID = @HouseholdID
               AND hp.PersonID = @ResolvedPersonID
               AND hp.IsDeleted = 0
         )
    BEGIN
        INSERT INTO party.HouseholdPerson
        (
            HouseholdID,
            PersonID,
            HouseholdRoleCodeValueID,
            IsPrimaryContact,
            EffectiveStartDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @HouseholdID,
            @ResolvedPersonID,
            @HouseholdRoleCodeValueID,
            0,
            COALESCE(@EffectiveStartDate, @Today),
            1,
            0,
            @PortalUserID
        );
    END;

    IF @PickupDropoffAuthorizationID IS NULL
    BEGIN
        INSERT INTO child.PickupDropoffAuthorization
        (
            ChildID,
            PersonID,
            CanPickup,
            CanDropoff,
            IsEmergencyContact,
            Notes,
            EffectiveStartDate,
            EffectiveEndDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @ResolvedPersonID,
            @CanPickup,
            @CanDropoff,
            @IsEmergencyContact,
            NULLIF(@Notes, N''),
            COALESCE(@EffectiveStartDate, @Today),
            @EffectiveEndDate,
            1,
            0,
            @PortalUserID
        );

        SET @PickupDropoffAuthorizationID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE pda
        SET
            pda.PersonID = @ResolvedPersonID,
            pda.CanPickup = @CanPickup,
            pda.CanDropoff = @CanDropoff,
            pda.IsEmergencyContact = @IsEmergencyContact,
            pda.Notes = NULLIF(@Notes, N''),
            pda.EffectiveStartDate = COALESCE(@EffectiveStartDate, pda.EffectiveStartDate),
            pda.EffectiveEndDate = @EffectiveEndDate,
            pda.ModifiedUTC = @NowUTC,
            pda.ModifiedByUserID = @PortalUserID
        FROM child.PickupDropoffAuthorization pda
        WHERE pda.PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID
          AND pda.ChildID = @ChildID
          AND pda.IsDeleted = 0;
    END;

    COMMIT TRANSACTION;

    SELECT
        PickupDropoffAuthorizationID = @PickupDropoffAuthorizationID,
        ChildID = @ChildID,
        PersonID = @ResolvedPersonID,
        HouseholdID = @HouseholdID;
END;
GO
