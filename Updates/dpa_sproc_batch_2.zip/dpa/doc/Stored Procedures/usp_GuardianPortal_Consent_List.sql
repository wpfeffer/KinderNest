CREATE OR ALTER PROCEDURE doc.usp_GuardianPortal_Consent_List
    @PersonID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH CurrentLinks AS
    (
        SELECT DISTINCT cpr.ChildID
        FROM child.ChildPersonRelationship cpr
        WHERE cpr.PersonID = @PersonID
          AND cpr.IsDeleted = 0
          AND cpr.IsActive = 1
          AND cpr.HasPortalAccess = 1
          AND cpr.EffectiveStartDate <= @Today
          AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= @Today)
    )
    SELECT TOP (50)
        DocumentName,
        ChildDisplayName,
        StatusText,
        StatusCssClass,
        UpdatedUTC,
        EffectiveDate,
        ExpirationDate
    FROM
    (
        SELECT
            DocumentName = cr.ConsentTypeCode,
            ChildDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName))),
            StatusText = CASE
                WHEN cr.ExpirationDate IS NOT NULL AND cr.ExpirationDate < @Today THEN N'Expired'
                WHEN cr.SignedUTC IS NULL THEN N'Pending signature'
                ELSE N'Complete'
            END,
            StatusCssClass = CASE
                WHEN cr.ExpirationDate IS NOT NULL AND cr.ExpirationDate < @Today THEN N'critical'
                WHEN cr.SignedUTC IS NULL THEN N'warning'
                ELSE N'success'
            END,
            UpdatedUTC = COALESCE(cr.ModifiedUTC, cr.CreatedUTC),
            cr.EffectiveDate,
            cr.ExpirationDate
        FROM doc.ConsentRecord cr
        INNER JOIN CurrentLinks cl
            ON cl.ChildID = cr.ChildID
        INNER JOIN child.Child c
            ON c.ChildID = cr.ChildID
           AND c.IsDeleted = 0
        WHERE cr.IsDeleted = 0
          AND cr.IsActive = 1

        UNION ALL

        SELECT
            DocumentName = COALESCE(dt.DocumentTypeName, d.OriginalFileName),
            ChildDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName))),
            StatusText = N'On file',
            StatusCssClass = N'success',
            UpdatedUTC = COALESCE(d.ModifiedUTC, d.CreatedUTC),
            EffectiveDate = CAST(COALESCE(d.ModifiedUTC, d.CreatedUTC) AS DATE),
            ExpirationDate = CAST(NULL AS DATE)
        FROM doc.Document d
        INNER JOIN doc.EntityDocument ed
            ON ed.DocumentID = d.DocumentID
           AND ed.IsActive = 1
           AND ed.EntitySchemaName = N'child'
           AND ed.EntityTableName = N'Child'
        INNER JOIN child.Child c
            ON c.ChildID = TRY_CONVERT(INT, ed.EntityPrimaryKeyValue)
           AND c.IsDeleted = 0
        INNER JOIN CurrentLinks cl
            ON cl.ChildID = c.ChildID
        LEFT JOIN doc.DocumentType dt
            ON dt.DocumentTypeID = d.DocumentTypeID
        WHERE d.IsDeleted = 0
          AND d.IsActive = 1
    ) consent_queue
    ORDER BY UpdatedUTC DESC, DocumentName;
END;
GO
