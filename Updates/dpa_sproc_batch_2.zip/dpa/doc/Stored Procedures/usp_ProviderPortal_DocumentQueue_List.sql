CREATE OR ALTER PROCEDURE doc.usp_ProviderPortal_DocumentQueue_List
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH CurrentSites AS
    (
        SELECT DISTINCT s.SiteID, s.SiteName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    SELECT TOP (50)
        DocumentName,
        SubjectDisplayName,
        StatusText,
        StatusCssClass,
        UpdatedUTC,
        SiteName
    FROM
    (
        SELECT
            DocumentName = cr.ConsentTypeCode,
            SubjectDisplayName = LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName))),
            StatusText = CASE
                WHEN cr.ExpirationDate IS NOT NULL AND cr.ExpirationDate < @Today THEN N'Expired'
                WHEN cr.SignedUTC IS NULL THEN N'Pending signature'
                ELSE N'Complete'
            END,
            StatusCssClass = CASE
                WHEN cr.ExpirationDate IS NOT NULL AND cr.ExpirationDate < @Today THEN N'critical'
                WHEN cr.SignedUTC IS NULL THEN N'warning'
                ELSE N'success'
            END,
            UpdatedUTC = COALESCE(cr.ModifiedUTC, cr.CreatedUTC),
            cs.SiteName
        FROM doc.ConsentRecord cr
        INNER JOIN child.Child c
            ON c.ChildID = cr.ChildID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        INNER JOIN CurrentSites cs
            ON cs.SiteID = c.SiteID
        WHERE cr.IsDeleted = 0
          AND cr.IsActive = 1

        UNION ALL

        SELECT
            DocumentName = COALESCE(dt.DocumentTypeName, d.OriginalFileName),
            SubjectDisplayName = CASE
                WHEN ed.EntitySchemaName = N'child' AND ed.EntityTableName = N'Child' THEN LTRIM(RTRIM(CONCAT(c.FirstName, N' ', c.LastName)))
                WHEN ed.EntitySchemaName = N'party' AND ed.EntityTableName = N'Site' THEN s2.SiteName
                WHEN ed.EntitySchemaName = N'party' AND ed.EntityTableName = N'Provider' THEN p.ProviderName
                ELSE CONCAT(ed.EntitySchemaName, N'.', ed.EntityTableName, N' #', ed.EntityPrimaryKeyValue)
            END,
            StatusText = N'On file',
            StatusCssClass = N'success',
            UpdatedUTC = COALESCE(d.ModifiedUTC, d.CreatedUTC),
            SiteName = COALESCE(cs2.SiteName, s2.SiteName, N'No site')
        FROM doc.Document d
        LEFT JOIN doc.DocumentType dt
            ON dt.DocumentTypeID = d.DocumentTypeID
        LEFT JOIN doc.EntityDocument ed
            ON ed.DocumentID = d.DocumentID
           AND ed.IsActive = 1
        LEFT JOIN child.Child c
            ON ed.EntitySchemaName = N'child'
           AND ed.EntityTableName = N'Child'
           AND TRY_CONVERT(INT, ed.EntityPrimaryKeyValue) = c.ChildID
        LEFT JOIN CurrentSites cs2
            ON cs2.SiteID = c.SiteID
        LEFT JOIN party.Site s2
            ON ed.EntitySchemaName = N'party'
           AND ed.EntityTableName = N'Site'
           AND TRY_CONVERT(INT, ed.EntityPrimaryKeyValue) = s2.SiteID
        LEFT JOIN CurrentSites csSite
            ON csSite.SiteID = s2.SiteID
        LEFT JOIN party.Provider p
            ON ed.EntitySchemaName = N'party'
           AND ed.EntityTableName = N'Provider'
           AND TRY_CONVERT(INT, ed.EntityPrimaryKeyValue) = p.ProviderID
        WHERE d.IsDeleted = 0
          AND d.IsActive = 1
          AND (
                cs2.SiteID IS NOT NULL
                OR csSite.SiteID IS NOT NULL
                OR EXISTS
                   (
                       SELECT 1
                       FROM party.Site s3
                       INNER JOIN CurrentSites x
                           ON x.SiteID = s3.SiteID
                       WHERE s3.ProviderID = p.ProviderID
                         AND s3.IsDeleted = 0
                   )
              )
    ) queue
    ORDER BY UpdatedUTC DESC, DocumentName;
END;
GO
