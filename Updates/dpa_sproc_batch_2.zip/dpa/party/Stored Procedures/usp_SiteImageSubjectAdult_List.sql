CREATE OR ALTER PROCEDURE party.usp_SiteImageSubjectAdult_List
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    WITH RelatedAdults AS
    (
        SELECT
            cpr.PersonID,
            CONCAT(N'Guardian for ', c.FirstName, N' ', c.LastName) AS RelationshipLabel
        FROM child.ChildPersonRelationship cpr
        INNER JOIN child.Child c
            ON c.ChildID = cpr.ChildID
           AND c.SiteID = @SiteID
           AND c.IsDeleted = 0
        WHERE cpr.IsDeleted = 0
          AND cpr.IsActive = 1

        UNION ALL

        SELECT
            pda.PersonID,
            CONCAT(N'Pickup/dropoff for ', c.FirstName, N' ', c.LastName) AS RelationshipLabel
        FROM child.PickupDropoffAuthorization pda
        INNER JOIN child.Child c
            ON c.ChildID = pda.ChildID
           AND c.SiteID = @SiteID
           AND c.IsDeleted = 0
        WHERE pda.IsDeleted = 0
          AND pda.IsActive = 1
    )
    SELECT
        p.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        STRING_AGG(ra.RelationshipLabel, N', ') AS Detail
    FROM RelatedAdults ra
    INNER JOIN party.Person p
        ON p.PersonID = ra.PersonID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    GROUP BY p.PersonID, p.FirstName, p.LastName
    ORDER BY DisplayName;
END;
GO
