DPA image binary thumbnail parameter overlay

Problem:
- The View button uses data-image-url="/api/images/{id}/binary".
- The endpoint signature requires bool thumbnail from query string.
- Minimal APIs reject the request with:
  Required parameter "bool thumbnail" was not provided from query string.

Fix:
- Provider Photos gallery full-size URLs now include:
  /api/images/{id}/binary?thumbnail=false
- Existing thumbnail URLs already use:
  /api/images/{id}/binary?thumbnail=true
- The binary endpoint is also patched to default thumbnail=false for resilience.
- Photos.razor DisposeAsync now swallows JSDisconnectedException so secondary circuit-disposal noise
  does not obscure the real error during debugging.

Apply:
1. Unzip at repo root.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\patch_image_binary_thumbnail_param.ps1
3. Rebuild and run.
4. Hard refresh /provider/photos.
