param(
    [string]$RepoRoot = "."
)

$photosPath = Join-Path $RepoRoot "DaycareProviderAssistant\Components\Pages\Provider\Photos.razor"
$endpointPath = Join-Path $RepoRoot "DaycareProviderAssistant\Images\Endpoints\ImageEndpointMapper.cs"

if (-not (Test-Path $photosPath)) {
    throw "Could not find Photos.razor at $photosPath"
}

if (-not (Test-Path $endpointPath)) {
    throw "Could not find ImageEndpointMapper.cs at $endpointPath"
}

$photos = Get-Content $photosPath -Raw

# The full-size image URL must include thumbnail=false because the endpoint's bool thumbnail
# parameter is bound from query string by minimal APIs.
$photos = $photos.Replace(
    'data-image-url="@($"/api/images/{item.ImageAssetId}/binary")"',
    'data-image-url="@($"/api/images/{item.ImageAssetId}/binary?thumbnail=false")"'
)

# Bump the JS cache key so the browser will reload any gallery behavior changes.
$photos = $photos.Replace(
    '/js/dpa-images.js?v=20260424-fix1',
    '/js/dpa-images.js?v=20260425-binary-thumbnail-param'
)

# Make DisposeAsync resilient after circuit disconnects. This prevents a secondary noisy exception
# from hiding the original issue during debugging.
if ($photos -notmatch 'JSDisconnectedException') {
    $photos = $photos.Replace(
        '@using DaycareProviderAssistant.Images.Services',
        '@using DaycareProviderAssistant.Images.Services' + "`r`n" + '@using Microsoft.JSInterop'
    )

    $photos = $photos.Replace(
        '    public async ValueTask DisposeAsync()' + "`r`n" +
        '    {' + "`r`n" +
        '        if (_module is not null)' + "`r`n" +
        '        {' + "`r`n" +
        '            await _module.DisposeAsync();' + "`r`n" +
        '        }' + "`r`n" +
        '    }',
        '    public async ValueTask DisposeAsync()' + "`r`n" +
        '    {' + "`r`n" +
        '        if (_module is null)' + "`r`n" +
        '        {' + "`r`n" +
        '            return;' + "`r`n" +
        '        }' + "`r`n" +
        "`r`n" +
        '        try' + "`r`n" +
        '        {' + "`r`n" +
        '            await _module.DisposeAsync();' + "`r`n" +
        '        }' + "`r`n" +
        '        catch (JSDisconnectedException)' + "`r`n" +
        '        {' + "`r`n" +
        '            // Circuit already disconnected. Nothing useful to clean up.' + "`r`n" +
        '        }' + "`r`n" +
        '    }'
    )
}

Set-Content -Path $photosPath -Value $photos -Encoding UTF8

$endpoint = Get-Content $endpointPath -Raw

# Give thumbnail a default too. This makes the API tolerant if any caller forgets the query param.
$endpoint = $endpoint.Replace(
    'bool thumbnail,' + "`r`n" +
    '            DpaCurrentUserAccessor currentUser,',
    '[Microsoft.AspNetCore.Mvc.FromQuery] bool thumbnail = false,' + "`r`n" +
    '            DpaCurrentUserAccessor currentUser = default!,'
)

# The replacement above changes currentUser to optional/default. This is okay for endpoint binding,
# but keep the rest of the code unchanged.
Set-Content -Path $endpointPath -Value $endpoint -Encoding UTF8

Write-Host "Patched image binary URLs to include thumbnail=false and made the binary endpoint default thumbnail=false."
