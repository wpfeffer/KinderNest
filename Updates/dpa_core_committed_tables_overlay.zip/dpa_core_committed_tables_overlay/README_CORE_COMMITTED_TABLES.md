# DPA Core Committed Tables Overlay

This zip contains the first bullet only: core committed tables for provider-family grouping.

Included:
- dpa/party/Tables/Household.sql
- dpa/party/Tables/HouseholdPerson.sql
- dpa/child/Tables/ChildHousehold.sql
- patch notes for dpa.sqlproj and dpa/Install/master_install.sql

Notes:
- all code columns are INT foreign keys to ref.CodeValue, not free-text code columns
- this is an overlay patch, not a full repo snapshot
- this step does NOT include draft tables, views, or onboarding stored procedures yet

Design intent:
- Household is a provider-facing grouping object
- HouseholdPerson groups people under the household using HouseholdRoleCodeValueID -> ref.CodeValue(CodeValueID)
- ChildHousehold links children to households without denormalizing household data into child.Child
