CREATE TABLE child.ChildHousehold
(
    ChildHouseholdID             INT IDENTITY(1,1)         NOT NULL,
    ChildID                      INT                       NOT NULL,
    HouseholdID                  INT                       NOT NULL,
    IsPrimaryHousehold           BIT                       NOT NULL CONSTRAINT DF_ChildHousehold_IsPrimaryHousehold DEFAULT (1),
    EffectiveStartDate           DATE                      NOT NULL,
    EffectiveEndDate             DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_ChildHousehold_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_ChildHousehold_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_ChildHousehold_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_ChildHousehold PRIMARY KEY CLUSTERED (ChildHouseholdID),
    CONSTRAINT FK_ChildHousehold_Child FOREIGN KEY (ChildID) REFERENCES child.Child (ChildID),
    CONSTRAINT FK_ChildHousehold_Household FOREIGN KEY (HouseholdID) REFERENCES party.Household (HouseholdID)
);
GO
CREATE INDEX IX_ChildHousehold_Child ON child.ChildHousehold (ChildID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
CREATE INDEX IX_ChildHousehold_Household ON child.ChildHousehold (HouseholdID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
CREATE UNIQUE INDEX UX_ChildHousehold_PrimaryActive
    ON child.ChildHousehold (ChildID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND IsPrimaryHousehold = 1;
GO
