CREATE TABLE party.HouseholdPerson
(
    HouseholdPersonID            INT IDENTITY(1,1)         NOT NULL,
    HouseholdID                  INT                       NOT NULL,
    PersonID                     INT                       NOT NULL,
    HouseholdRoleCodeValueID     INT                       NOT NULL,
    IsPrimaryContact             BIT                       NOT NULL CONSTRAINT DF_HouseholdPerson_IsPrimaryContact DEFAULT (0),
    EffectiveStartDate           DATE                      NOT NULL,
    EffectiveEndDate             DATE                      NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_HouseholdPerson_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_HouseholdPerson_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_HouseholdPerson_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_HouseholdPerson PRIMARY KEY CLUSTERED (HouseholdPersonID),
    CONSTRAINT FK_HouseholdPerson_Household FOREIGN KEY (HouseholdID) REFERENCES party.Household (HouseholdID),
    CONSTRAINT FK_HouseholdPerson_Person FOREIGN KEY (PersonID) REFERENCES party.Person (PersonID),
    CONSTRAINT FK_HouseholdPerson_HouseholdRoleCodeValue FOREIGN KEY (HouseholdRoleCodeValueID) REFERENCES ref.CodeValue (CodeValueID)
);
GO
CREATE INDEX IX_HouseholdPerson_Household ON party.HouseholdPerson (HouseholdID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
CREATE INDEX IX_HouseholdPerson_Person ON party.HouseholdPerson (PersonID, IsDeleted, IsActive, EffectiveStartDate, EffectiveEndDate);
GO
CREATE INDEX IX_HouseholdPerson_HouseholdRoleCodeValueID ON party.HouseholdPerson (HouseholdRoleCodeValueID);
GO
CREATE UNIQUE INDEX UX_HouseholdPerson_ActiveRole
    ON party.HouseholdPerson (HouseholdID, PersonID, HouseholdRoleCodeValueID)
    WHERE IsDeleted = 0
      AND IsActive = 1
      AND EffectiveEndDate IS NULL;
GO
