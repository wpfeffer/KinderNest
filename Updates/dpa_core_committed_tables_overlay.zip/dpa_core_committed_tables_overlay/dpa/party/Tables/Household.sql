CREATE TABLE party.Household
(
    HouseholdID                  INT IDENTITY(1,1)         NOT NULL,
    ProviderID                   INT                       NOT NULL,
    HouseholdDisplayName         NVARCHAR(200)             NOT NULL,
    PrimaryAddressID             INT                       NULL,
    BillingNotes                 NVARCHAR(MAX)             NULL,
    IsActive                     BIT                       NOT NULL CONSTRAINT DF_Household_IsActive DEFAULT (1),
    IsDeleted                    BIT                       NOT NULL CONSTRAINT DF_Household_IsDeleted DEFAULT (0),
    CreatedUTC                   DATETIME2(0)              NOT NULL CONSTRAINT DF_Household_CreatedUTC DEFAULT (SYSUTCDATETIME()),
    CreatedByUserID              INT                       NULL,
    ModifiedUTC                  DATETIME2(0)              NULL,
    ModifiedByUserID             INT                       NULL,
    DeletedUTC                   DATETIME2(0)              NULL,
    DeletedByUserID              INT                       NULL,
    DeletedReason                NVARCHAR(500)             NULL,
    CONSTRAINT PK_Household PRIMARY KEY CLUSTERED (HouseholdID),
    CONSTRAINT FK_Household_Provider FOREIGN KEY (ProviderID) REFERENCES party.Provider (ProviderID),
    CONSTRAINT FK_Household_PrimaryAddress FOREIGN KEY (PrimaryAddressID) REFERENCES party.Address (AddressID)
);
GO
CREATE INDEX IX_Household_Provider ON party.Household (ProviderID, IsDeleted, IsActive);
GO
CREATE INDEX IX_Household_PrimaryAddressID ON party.Household (PrimaryAddressID) WHERE PrimaryAddressID IS NOT NULL;
GO
CREATE UNIQUE INDEX UX_Household_Provider_DisplayName_Active
    ON party.Household (ProviderID, HouseholdDisplayName)
    WHERE IsDeleted = 0
      AND IsActive = 1;
GO
