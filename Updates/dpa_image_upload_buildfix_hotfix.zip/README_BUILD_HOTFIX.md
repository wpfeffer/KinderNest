This hotfix fixes the init-only Message mutation in AdminProviderApprovalService and removes the missing sec.fn_UserCanAccessChildDetail dependency from image.usp_ImageAsset_ListForGuardian.
