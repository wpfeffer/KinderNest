DPA image upload boolean cast overlay

Problem:
The upload now encrypts and writes files, then the photos page reloads provider gallery data.
The gallery result column HasThumbnail is returned as INT from CASE, while C# reads it with
SqlDataReader.GetBoolean. That throws InvalidCastException.

Fix:
- Cast HasThumbnail to bit in both image gallery stored procedures.
- Make ImageDataReaderHelpers.GetBoolean tolerant of int/byte/long/decimal/string values.

Files replaced:
- DaycareProviderAssistant/Images/Services/ImageDataReaderHelpers.cs
- dpa/image/Stored Procedures/usp_ImageAsset_ListForSite.sql
- dpa/image/Stored Procedures/usp_ImageAsset_ListForGuardian.sql

Manual DB hotfix:
- ManualHotfix/20260425_ImageGallery_HasThumbnail_Bit.sql

Apply:
1. Unzip at repo root and allow overwrite.
2. Rebuild.
3. Publish dpa DB project OR run the manual hotfix SQL against local dpa.
4. Retry upload.
