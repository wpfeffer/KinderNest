CREATE PROCEDURE image.usp_ImageAsset_ListForGuardian
    @PortalUserID INT,
    @ChildID      INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        INNER JOIN child.ChildPersonRelationship cpr
            ON cpr.PersonID = pu.PersonID
           AND cpr.ChildID = @ChildID
           AND cpr.HasPortalAccess = 1
           AND cpr.IsActive = 1
           AND cpr.IsDeleted = 0
           AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
           AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
        INNER JOIN child.Child c
            ON c.ChildID = cpr.ChildID
           AND c.IsDeleted = 0
           AND c.IsActive = 1
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
          AND pu.IsActive = 1
    )
    BEGIN
        RAISERROR(N'The portal user is not allowed to view that child image gallery.', 16, 1);
        RETURN;
    END;

    SELECT
        ia.ImageAssetID,
        ia.SiteID,
        ia.ImageCategoryCode,
        ia.VisibilityScopeCode,
        ia.OriginalFileName,
        ia.OriginalContentType,
        ia.OriginalLengthBytes,
        ia.EncryptedFileLengthBytes,
        ia.SiteKeyVersion,
        ia.ImageNonce,
        ia.ThumbnailContentType,
        ia.ThumbnailLengthBytes,
        ia.EncryptedThumbnailLengthBytes,
        ia.ThumbnailNonce,
        ia.PixelWidth,
        ia.PixelHeight,
        ia.Caption,
        ia.TakenUTC,
        ia.CreatedUTC,
        ia.IsActive,
        CAST(CASE WHEN ia.EncryptedThumbnailRelativePath IS NULL THEN 0 ELSE 1 END AS bit) AS HasThumbnail,
        subject_summary.SubjectSummary
    FROM image.ImageAsset ia
    OUTER APPLY
    (
        SELECT STRING_AGG(subject_rows.SubjectLabel, N', ') AS SubjectSummary
        FROM
        (
            SELECT CONCAT(N'Child: ', c.FirstName, N' ', c.LastName) AS SubjectLabel
            FROM image.ImageAssetSubject ias
            INNER JOIN child.Child c
                ON c.ChildID = ias.ChildID
               AND c.IsDeleted = 0
            WHERE ias.ImageAssetID = ia.ImageAssetID
              AND ias.IsDeleted = 0
              AND ias.IsActive = 1

            UNION ALL

            SELECT CONCAT(N'Person: ', p.FirstName, N' ', p.LastName) AS SubjectLabel
            FROM image.ImageAssetSubject ias
            INNER JOIN party.Person p
                ON p.PersonID = ias.PersonID
               AND p.IsDeleted = 0
            WHERE ias.ImageAssetID = ia.ImageAssetID
              AND ias.IsDeleted = 0
              AND ias.IsActive = 1
        ) subject_rows
    ) subject_summary
    WHERE ia.IsDeleted = 0
      AND ia.IsActive = 1
      AND ia.VisibilityScopeCode IN (N'LINKED_GUARDIANS', N'CHILD_GUARDIANS_ONLY')
      AND EXISTS
      (
          SELECT 1
          FROM image.ImageAssetSubject ias
          WHERE ias.ImageAssetID = ia.ImageAssetID
            AND ias.ChildID = @ChildID
            AND ias.IsDeleted = 0
            AND ias.IsActive = 1
      )
    ORDER BY COALESCE(ia.TakenUTC, ia.CreatedUTC) DESC, ia.ImageAssetID DESC;
END;
GO
