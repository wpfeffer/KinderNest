DPA image View/Download fix overlay

Problem:
- The binary endpoint currently binds `bool thumbnail` as a required query parameter.
- If View or Download uses /api/images/{id}/binary without thumbnail=false, Minimal APIs rejects it before service code runs.
- Depending on which prior overlay landed locally, the page and endpoint may be out of sync.

Fix:
- Replaces ImageEndpointMapper.cs so the binary endpoint reads thumbnail from HttpRequest.Query and defaults to false.
- Adds structured JSON diagnostics for binary endpoint failures.
- Includes a patch script that makes Photos.razor full-size binary URLs explicit:
  /api/images/{id}/binary?thumbnail=false

Apply:
1. Unzip at repo root and allow overwrite.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\patch_provider_photos_binary_urls.ps1
3. Rebuild and run.
4. Hard refresh /provider/photos.

After this:
- Thumbnail previews should use thumbnail=true.
- View and Download should use thumbnail=false.
- If binary retrieval still fails, Network response should contain JSON with detail/exceptionType.
