param(
    [string]$RepoRoot = "."
)

$photosPath = Join-Path $RepoRoot "DaycareProviderAssistant\Components\Pages\Provider\Photos.razor"
if (-not (Test-Path $photosPath)) {
    throw "Could not find Photos.razor at $photosPath"
}

$content = Get-Content $photosPath -Raw

# Full-size binary URL should explicitly request thumbnail=false. The endpoint overlay is tolerant
# without it, but keeping the URL explicit makes diagnostics cleaner.
$content = $content.Replace(
    'data-image-url="@($"/api/images/{item.ImageAssetId}/binary")"',
    'data-image-url="@($"/api/images/{item.ImageAssetId}/binary?thumbnail=false")"'
)

# Bump JS cache key if present.
$content = $content.Replace(
    '/js/dpa-images.js?v=20260424-fix1',
    '/js/dpa-images.js?v=20260425-view-download-fix'
)

$content = $content.Replace(
    '/js/dpa-images.js?v=20260425-binary-thumbnail-param',
    '/js/dpa-images.js?v=20260425-view-download-fix'
)

Set-Content -Path $photosPath -Value $content -Encoding UTF8

Write-Host "Patched Provider Photos binary URLs and JS cache key."
