CREATE OR ALTER PROCEDURE party.usp_AdminSite_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ActiveAssignments AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS ActiveUserCount,
            MAX(CASE WHEN sua.IsPrimaryProviderContact = 1 THEN sua.PortalUserID END) AS PrimaryContactUserID
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.ProviderID,
        s.SiteName,
        pr.ProviderName,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        s.LicenseNumber,
        pu.UserName AS PrimaryContactUserName,
        ISNULL(aa.ActiveUserCount, 0) AS ActiveUserCount,
        s.IsActive,
        s.CreatedUTC
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
    INNER JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    INNER JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN ActiveAssignments aa
        ON aa.SiteID = s.SiteID
    LEFT JOIN party.PortalUser pu
        ON pu.PortalUserID = aa.PrimaryContactUserID
    WHERE s.IsDeleted = 0
      AND pr.IsDeleted = 0
    ORDER BY pr.ProviderName, s.SiteName, s.SiteID;
END;
GO
