CREATE OR ALTER PROCEDURE party.usp_AdminProvider_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH SiteCounts AS
    (
        SELECT
            s.ProviderID,
            COUNT(*) AS SiteCount,
            SUM(CASE WHEN s.IsDeleted = 0 AND s.IsActive = 1 THEN 1 ELSE 0 END) AS ActiveSiteCount
        FROM party.Site s
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    ),
    PrimaryContacts AS
    (
        SELECT
            s.ProviderID,
            MIN(pu.UserName) AS PrimaryContactUserName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
        INNER JOIN party.PortalUser pu
            ON pu.PortalUserID = sua.PortalUserID
        WHERE sua.IsActive = 1
          AND sua.IsPrimaryProviderContact = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
          AND s.IsDeleted = 0
          AND pu.IsDeleted = 0
        GROUP BY s.ProviderID
    )
    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        CASE
            WHEN lp.PersonID IS NULL THEN NULL
            ELSE LTRIM(RTRIM(CONCAT(lp.FirstName, N' ', lp.LastName)))
        END AS LicenseHolderDisplayName,
        pr.BusinessEmail,
        pc.PrimaryContactUserName,
        ISNULL(sc.SiteCount, 0) AS SiteCount,
        ISNULL(sc.ActiveSiteCount, 0) AS ActiveSiteCount,
        pr.IsActive,
        pr.CreatedUTC
    FROM party.Provider pr
    LEFT JOIN party.Person lp
        ON lp.PersonID = pr.LicenseHolderPersonID
    LEFT JOIN SiteCounts sc
        ON sc.ProviderID = pr.ProviderID
    LEFT JOIN PrimaryContacts pc
        ON pc.ProviderID = pr.ProviderID
    WHERE pr.IsDeleted = 0
    ORDER BY pr.ProviderName, pr.ProviderID;
END;
GO
