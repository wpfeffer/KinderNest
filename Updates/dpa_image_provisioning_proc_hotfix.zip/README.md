This hotfix adds the two image storage provisioning procedures required by
DaycareProviderAssistant.Images.Services.ImageStorageProvisioningService:

- image.usp_ImageStorageProvisioningTarget_ListByPortalUser
- image.usp_ImageStorageContext_GetBySite

It also includes patch stubs for:
- dpa/dpa.sqlproj
- dpa/Install/master_install.sql
