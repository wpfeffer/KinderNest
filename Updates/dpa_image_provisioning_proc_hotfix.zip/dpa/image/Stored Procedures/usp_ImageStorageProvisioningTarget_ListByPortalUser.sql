CREATE OR ALTER PROCEDURE image.usp_ImageStorageProvisioningTarget_ListByPortalUser
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT DISTINCT
        s.ProviderID,
        s.SiteID,
        s.SiteName,
        p.ProviderName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    INNER JOIN party.Provider p
        ON p.ProviderID = s.ProviderID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
      AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ORDER BY p.ProviderName, s.SiteName, s.SiteID;
END;
GO
