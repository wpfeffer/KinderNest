CREATE OR ALTER PROCEDURE image.usp_ImageStorageContext_GetBySite
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
        s.ProviderID,
        s.SiteID,
        s.SiteName,
        p.ProviderName
    FROM party.Site s
    INNER JOIN party.Provider p
        ON p.ProviderID = s.ProviderID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE s.SiteID = @SiteID
      AND s.IsDeleted = 0
      AND s.IsActive = 1;
END;
GO
