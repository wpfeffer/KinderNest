using System.Data;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Portal.Services;
using DaycareProviderAssistant.Provider.Models;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Portal.Services.PortalDataReaderHelpers;

namespace DaycareProviderAssistant.Provider.Services;

public sealed class ProviderPortalService : IProviderPortalService
{
    private const string DashboardProcedureName = "ops.usp_ProviderPortal_Dashboard_GetSummary";
    private const string ChildrenProcedureName = "child.usp_ProviderPortal_Child_List";
    private const string AttendanceProcedureName = "child.usp_ProviderPortal_Attendance_GetSummary";
    private const string DocumentsProcedureName = "doc.usp_ProviderPortal_DocumentQueue_List";
    private const string MessagesProcedureName = "comm.usp_ProviderPortal_Conversation_List";
    private const string FamilyOnboardProcedureName = "child.usp_ProviderPortal_Family_Onboard";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<ProviderPortalService> _logger;

    public ProviderPortalService(ISqlConnectionFactory connectionFactory, ILogger<ProviderPortalService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<ProviderDashboardSummaryDto> GetDashboardSummaryAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var summary = new ProviderDashboardSummaryDto();
        var alerts = new List<ProviderAlertDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = CreatePortalUserCommand(connection, DashboardProcedureName, portalUserId);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                summary = new ProviderDashboardSummaryDto
                {
                    SiteCount = GetInt32(reader, "SiteCount"),
                    ActiveChildren = GetInt32(reader, "ActiveChildren"),
                    CheckedInNow = GetInt32(reader, "CheckedInNow"),
                    PendingConsents = GetInt32(reader, "PendingConsents"),
                    UnreadConversations = GetInt32(reader, "UnreadConversations")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    alerts.Add(new ProviderAlertDto
                    {
                        Title = GetString(reader, "Title"),
                        Detail = GetString(reader, "Detail"),
                        StatusText = GetString(reader, "StatusText"),
                        StatusCssClass = GetString(reader, "StatusCssClass")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider dashboard summary failed while executing {ProcedureName}.", DashboardProcedureName);
            throw;
        }

        return new ProviderDashboardSummaryDto
        {
            SiteCount = summary.SiteCount,
            ActiveChildren = summary.ActiveChildren,
            CheckedInNow = summary.CheckedInNow,
            PendingConsents = summary.PendingConsents,
            UnreadConversations = summary.UnreadConversations,
            Alerts = alerts
        };
    }

    public async Task<IReadOnlyList<ProviderChildListItemDto>> GetChildrenAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var results = new List<ProviderChildListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = CreatePortalUserCommand(connection, ChildrenProcedureName, portalUserId);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new ProviderChildListItemDto
                {
                    ChildId = GetInt32(reader, "ChildID"),
                    ChildDisplayName = GetString(reader, "ChildDisplayName"),
                    DateOfBirth = GetDateOnly(reader, "DateOfBirth"),
                    AgeGroup = GetString(reader, "AgeGroup"),
                    PrimaryGuardianName = GetNullableString(reader, "PrimaryGuardianName"),
                    AllergyPlanStatusText = GetString(reader, "AllergyPlanStatusText"),
                    AllergyPlanStatusCssClass = GetString(reader, "AllergyPlanStatusCssClass"),
                    DocumentStatusText = GetString(reader, "DocumentStatusText"),
                    DocumentStatusCssClass = GetString(reader, "DocumentStatusCssClass"),
                    EnrollmentStatusCode = GetString(reader, "EnrollmentStatusCode"),
                    SiteName = GetString(reader, "SiteName")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider child list failed while executing {ProcedureName}.", ChildrenProcedureName);
            throw;
        }

        return results;
    }

    public async Task<ProviderAttendanceSummaryDto> GetAttendanceSummaryAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var summary = new ProviderAttendanceSummaryDto();
        var records = new List<ProviderAttendanceRecordDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = CreatePortalUserCommand(connection, AttendanceProcedureName, portalUserId);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                summary = new ProviderAttendanceSummaryDto
                {
                    CheckedInNow = GetInt32(reader, "CheckedInNow"),
                    AttendanceRecordsToday = GetInt32(reader, "AttendanceRecordsToday"),
                    ChildrenWithAttendanceToday = GetInt32(reader, "ChildrenWithAttendanceToday"),
                    AverageHoursToday = GetDecimal(reader, "AverageHoursToday")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    records.Add(new ProviderAttendanceRecordDto
                    {
                        ChildAttendanceId = GetInt32(reader, "ChildAttendanceID"),
                        ChildDisplayName = GetString(reader, "ChildDisplayName"),
                        SiteName = GetString(reader, "SiteName"),
                        AttendanceDateLocal = GetDateOnly(reader, "AttendanceDateLocal"),
                        StartUtc = GetDateTime(reader, "StartDateTimeUTC"),
                        EndUtc = GetDateTime(reader, "EndDateTimeUTC"),
                        DurationHours = GetDecimal(reader, "DurationHours"),
                        StatusText = GetString(reader, "StatusText"),
                        StatusCssClass = GetString(reader, "StatusCssClass"),
                        Notes = GetNullableString(reader, "Notes")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider attendance summary failed while executing {ProcedureName}.", AttendanceProcedureName);
            throw;
        }

        return new ProviderAttendanceSummaryDto
        {
            CheckedInNow = summary.CheckedInNow,
            AttendanceRecordsToday = summary.AttendanceRecordsToday,
            ChildrenWithAttendanceToday = summary.ChildrenWithAttendanceToday,
            AverageHoursToday = summary.AverageHoursToday,
            RecentRecords = records
        };
    }

    public async Task<IReadOnlyList<ProviderDocumentQueueItemDto>> GetDocumentsAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var results = new List<ProviderDocumentQueueItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = CreatePortalUserCommand(connection, DocumentsProcedureName, portalUserId);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new ProviderDocumentQueueItemDto
                {
                    DocumentName = GetString(reader, "DocumentName"),
                    SubjectDisplayName = GetString(reader, "SubjectDisplayName"),
                    StatusText = GetString(reader, "StatusText"),
                    StatusCssClass = GetString(reader, "StatusCssClass"),
                    UpdatedUtc = GetDateTime(reader, "UpdatedUTC"),
                    SiteName = GetString(reader, "SiteName")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider document queue failed while executing {ProcedureName}.", DocumentsProcedureName);
            throw;
        }

        return results;
    }

    public async Task<IReadOnlyList<ProviderConversationListItemDto>> GetMessagesAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var results = new List<ProviderConversationListItemDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = CreatePortalUserCommand(connection, MessagesProcedureName, portalUserId);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new ProviderConversationListItemDto
                {
                    ConversationId = GetInt32(reader, "ConversationID"),
                    Subject = GetString(reader, "Subject"),
                    CounterpartyDisplay = GetString(reader, "CounterpartyDisplay"),
                    LatestSnippet = GetString(reader, "LatestSnippet"),
                    LatestMessageUtc = GetNullableDateTime(reader, "LatestMessageUTC"),
                    StatusText = GetString(reader, "StatusText"),
                    StatusCssClass = GetString(reader, "StatusCssClass"),
                    SiteName = GetNullableString(reader, "SiteName"),
                    ChildName = GetNullableString(reader, "ChildName")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider conversations failed while executing {ProcedureName}.", MessagesProcedureName);
            throw;
        }

        return results;
    }

    public async Task<IReadOnlyList<ProviderFamilySiteOptionDto>> GetFamilyEnrollmentSitesAsync(int portalUserId, CancellationToken cancellationToken = default)
    {
        var results = new List<ProviderFamilySiteOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT DISTINCT
                s.SiteID,
                s.SiteName,
                pr.ProviderName
            FROM party.SiteUserAssignment sua
            INNER JOIN party.Site s
                ON s.SiteID = sua.SiteID
               AND s.IsDeleted = 0
               AND s.IsActive = 1
            INNER JOIN party.Provider pr
                ON pr.ProviderID = s.ProviderID
               AND pr.IsDeleted = 0
               AND pr.IsActive = 1
            WHERE sua.PortalUserID = @PortalUserID
              AND sua.IsActive = 1
              AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
              AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
            ORDER BY pr.ProviderName, s.SiteName;
            """;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new ProviderFamilySiteOptionDto
            {
                SiteId = GetInt32(reader, "SiteID"),
                SiteName = GetString(reader, "SiteName"),
                ProviderName = GetString(reader, "ProviderName")
            });
        }

        return results;
    }

    public async Task<ProviderFamilyOnboardingOutcome> EnrollFamilyAsync(int portalUserId, ProviderFamilyOnboardingRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        if (!request.SiteId.HasValue)
        {
            return new ProviderFamilyOnboardingOutcome
            {
                Succeeded = false,
                ErrorMessage = "Choose a site before enrolling the family."
            };
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyOnboardProcedureName;

        AddParameter(command, "@PortalUserID", SqlDbType.Int, portalUserId);
        AddParameter(command, "@SiteID", SqlDbType.Int, request.SiteId.Value);
        AddParameter(command, "@ChildFirstName", SqlDbType.NVarChar, 100, request.ChildFirstName.Trim());
        AddNullableStringParameter(command, "@ChildMiddleName", SqlDbType.NVarChar, 100, request.ChildMiddleName);
        AddParameter(command, "@ChildLastName", SqlDbType.NVarChar, 100, request.ChildLastName.Trim());
        AddParameter(command, "@DateOfBirth", SqlDbType.Date, request.DateOfBirth!.Value.ToDateTime(TimeOnly.MinValue));
        AddParameter(command, "@EnrollmentStartDate", SqlDbType.Date, request.EnrollmentStartDate!.Value.ToDateTime(TimeOnly.MinValue));
        AddNullableStringParameter(command, "@SpecialDietNotes", SqlDbType.NVarChar, -1, request.SpecialDietNotes);
        AddNullableStringParameter(command, "@SpecialNeedsNotes", SqlDbType.NVarChar, -1, request.SpecialNeedsNotes);
        AddNullableStringParameter(command, "@ScheduleSummary", SqlDbType.NVarChar, -1, request.ScheduleSummary);
        AddNullableStringParameter(command, "@FinancialArrangementNotes", SqlDbType.NVarChar, -1, request.FinancialArrangementNotes);
        AddParameter(command, "@PrimaryGuardianFirstName", SqlDbType.NVarChar, 100, request.PrimaryGuardianFirstName.Trim());
        AddNullableStringParameter(command, "@PrimaryGuardianMiddleName", SqlDbType.NVarChar, 100, request.PrimaryGuardianMiddleName);
        AddParameter(command, "@PrimaryGuardianLastName", SqlDbType.NVarChar, 100, request.PrimaryGuardianLastName.Trim());
        AddNullableStringParameter(command, "@PrimaryGuardianEmail", SqlDbType.NVarChar, 320, request.PrimaryGuardianEmail);
        AddNullableStringParameter(command, "@SecondaryGuardianFirstName", SqlDbType.NVarChar, 100, request.SecondaryGuardianFirstName);
        AddNullableStringParameter(command, "@SecondaryGuardianMiddleName", SqlDbType.NVarChar, 100, request.SecondaryGuardianMiddleName);
        AddNullableStringParameter(command, "@SecondaryGuardianLastName", SqlDbType.NVarChar, 100, request.SecondaryGuardianLastName);
        AddNullableStringParameter(command, "@SecondaryGuardianEmail", SqlDbType.NVarChar, 320, request.SecondaryGuardianEmail);
        AddNullableStringParameter(command, "@PickupContactFirstName", SqlDbType.NVarChar, 100, request.PickupContactFirstName);
        AddNullableStringParameter(command, "@PickupContactMiddleName", SqlDbType.NVarChar, 100, request.PickupContactMiddleName);
        AddNullableStringParameter(command, "@PickupContactLastName", SqlDbType.NVarChar, 100, request.PickupContactLastName);
        AddNullableStringParameter(command, "@PickupContactEmail", SqlDbType.NVarChar, 320, request.PickupContactEmail);
        AddParameter(command, "@PickupCanPickup", SqlDbType.Bit, request.PickupCanPickup);
        AddParameter(command, "@PickupCanDropoff", SqlDbType.Bit, request.PickupCanDropoff);
        AddParameter(command, "@PickupIsEmergencyContact", SqlDbType.Bit, request.PickupIsEmergencyContact);
        AddNullableStringParameter(command, "@PickupNotes", SqlDbType.NVarChar, -1, request.PickupNotes);

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (await reader.ReadAsync(cancellationToken))
            {
                return new ProviderFamilyOnboardingOutcome
                {
                    Succeeded = true,
                    ChildId = GetInt32(reader, "ChildID"),
                    SiteId = GetInt32(reader, "SiteID"),
                    ChildDisplayName = GetString(reader, "ChildDisplayName"),
                    SiteName = GetString(reader, "SiteName")
                };
            }

            return new ProviderFamilyOnboardingOutcome
            {
                Succeeded = false,
                ErrorMessage = "The family enrollment stored procedure returned no result row."
            };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider family onboarding failed while executing {ProcedureName}.", FamilyOnboardProcedureName);
            return new ProviderFamilyOnboardingOutcome
            {
                Succeeded = false,
                ErrorMessage = ex.Message
            };
        }
    }

    private static SqlCommand CreatePortalUserCommand(SqlConnection connection, string procedureName, int portalUserId)
    {
        var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = procedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });
        return command;
    }

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, object value)
        => command.Parameters.Add(new SqlParameter(name, dbType) { Value = value });

    private static void AddParameter(SqlCommand command, string name, SqlDbType dbType, int size, object value)
        => command.Parameters.Add(new SqlParameter(name, dbType, size) { Value = value });

    private static void AddNullableStringParameter(SqlCommand command, string name, SqlDbType dbType, int size, string? value)
        => command.Parameters.Add(new SqlParameter(name, dbType, size) { Value = string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim() });
}
