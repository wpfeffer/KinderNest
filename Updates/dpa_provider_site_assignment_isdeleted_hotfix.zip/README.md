This hotfix removes `sua.IsDeleted = 0` from ProviderPortalService.GetFamilyEnrollmentSitesAsync because party.SiteUserAssignment does not have an IsDeleted column.
