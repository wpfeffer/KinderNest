CREATE OR ALTER PROCEDURE party.usp_GuardianPortal_Profile_Get
    @PortalUserID INT,
    @PersonID     INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pu.PortalUserID,
        p.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        LinkedChildCount =
            (
                SELECT COUNT(DISTINCT cpr.ChildID)
                FROM child.ChildPersonRelationship cpr
                WHERE cpr.PersonID = @PersonID
                  AND cpr.HasPortalAccess = 1
                  AND cpr.IsDeleted = 0
                  AND cpr.IsActive = 1
            ),
        PickupAuthorizationCount =
            (
                SELECT COUNT_BIG(1)
                FROM child.PickupDropoffAuthorization pda
                WHERE pda.PersonID = @PersonID
                  AND pda.IsDeleted = 0
                  AND pda.IsActive = 1
            ),
        PendingEmailChangeCount =
            (
                SELECT COUNT_BIG(1)
                FROM child.GuardianEmailChangeRequest gecr
                WHERE gecr.CreatedByUserID = @PortalUserID
                  AND gecr.RequestStatusCode = N'PENDING'
            )
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE pu.PortalUserID = @PortalUserID
      AND pu.PersonID = @PersonID
      AND pu.IsDeleted = 0
      AND pu.IsActive = 1;

    SELECT
        c.ChildID,
        CONCAT(c.FirstName, N' ', c.LastName) AS ChildDisplayName,
        s.SiteName,
        cpr.RelationshipTypeCode,
        cpr.HasPortalAccess,
        cpr.CanReceiveAlerts,
        cpr.CanSignPermissions,
        cpr.IsPrimaryGuardian,
        cpr.EffectiveStartDate,
        cpr.EffectiveEndDate
    FROM child.ChildPersonRelationship cpr
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
       AND c.IsDeleted = 0
       AND c.IsActive = 1
    INNER JOIN party.Site s
        ON s.SiteID = c.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    WHERE cpr.PersonID = @PersonID
      AND cpr.IsDeleted = 0
      AND cpr.IsActive = 1
    ORDER BY c.LastName, c.FirstName, c.ChildID;
END;
GO
