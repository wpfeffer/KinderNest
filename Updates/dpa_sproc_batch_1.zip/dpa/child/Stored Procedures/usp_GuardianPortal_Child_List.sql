CREATE OR ALTER PROCEDURE child.usp_GuardianPortal_Child_List
    @PersonID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH DocumentCounts AS
    (
        SELECT
            cpr.ChildID,
            PendingCount =
                SUM(CASE WHEN gi.RedeemedUTC IS NULL AND gi.RevokedUTC IS NULL AND gi.TokenExpiresUTC >= SYSUTCDATETIME() THEN 1 ELSE 0 END)
        FROM child.ChildPersonRelationship cpr
        LEFT JOIN child.GuardianInvitation gi
            ON gi.ChildPersonRelationshipID = cpr.ChildPersonRelationshipID
        WHERE cpr.PersonID = @PersonID
          AND cpr.IsDeleted = 0
          AND cpr.IsActive = 1
        GROUP BY cpr.ChildID
    ),
    PickupCounts AS
    (
        SELECT
            pda.ChildID,
            PickupCount = COUNT_BIG(1)
        FROM child.PickupDropoffAuthorization pda
        WHERE pda.IsDeleted = 0
          AND pda.IsActive = 1
          AND pda.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
          AND (pda.EffectiveEndDate IS NULL OR pda.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
        GROUP BY pda.ChildID
    )
    SELECT
        c.ChildID,
        CONCAT(c.FirstName, N' ', c.LastName) AS ChildDisplayName,
        s.SiteName,
        cpr.RelationshipTypeCode,
        cpr.IsPrimaryGuardian,
        PickupStatusText =
            CASE WHEN ISNULL(pc.PickupCount, 0) > 0 THEN N'Authorized contacts on file' ELSE N'No pickup contacts on file' END,
        PickupStatusCssClass =
            CASE WHEN ISNULL(pc.PickupCount, 0) > 0 THEN N'status-good' ELSE N'status-warning' END,
        DocumentStatusText =
            CASE WHEN ISNULL(dc.PendingCount, 0) > 0 THEN N'Pending guardian actions' ELSE N'Current' END,
        DocumentStatusCssClass =
            CASE WHEN ISNULL(dc.PendingCount, 0) > 0 THEN N'status-warning' ELSE N'status-good' END,
        AgeGroup =
            CASE
                WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 16 THEN N'Infant'
                WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 33 THEN N'Toddler'
                WHEN DATEDIFF(YEAR, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 5 THEN N'Preschool'
                ELSE N'School age'
            END
    FROM child.ChildPersonRelationship cpr
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
       AND c.IsDeleted = 0
       AND c.IsActive = 1
    INNER JOIN party.Site s
        ON s.SiteID = c.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    LEFT JOIN DocumentCounts dc
        ON dc.ChildID = c.ChildID
    LEFT JOIN PickupCounts pc
        ON pc.ChildID = c.ChildID
    WHERE cpr.PersonID = @PersonID
      AND cpr.HasPortalAccess = 1
      AND cpr.IsDeleted = 0
      AND cpr.IsActive = 1
      AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
      AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
    ORDER BY c.LastName, c.FirstName, c.ChildID;
END;
GO
