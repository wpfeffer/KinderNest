CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Guardian_Upsert
    @PortalUserID             INT,
    @HouseholdID              INT,
    @HouseholdPersonID        INT = NULL,
    @ChildID                  INT = NULL,
    @FirstName                NVARCHAR(100),
    @MiddleName               NVARCHAR(100) = NULL,
    @LastName                 NVARCHAR(100),
    @PrimaryEmail             NVARCHAR(320) = NULL,
    @HouseholdRoleCodeValueID INT,
    @RelationshipTypeCode     NVARCHAR(50) = N'GUARDIAN',
    @HasPortalAccess          BIT = 0,
    @CanReceiveAlerts         BIT = 1,
    @CanSignPermissions       BIT = 1,
    @IsPrimaryGuardian        BIT = 0,
    @IsPrimaryContact         BIT = 0,
    @EffectiveStartDate       DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ProviderID INT;
    DECLARE @PersonID INT;
    DECLARE @StartDate DATE = COALESCE(@EffectiveStartDate, CAST(SYSUTCDATETIME() AS date));

    SELECT @ProviderID = h.ProviderID
    FROM party.Household h
    WHERE h.HouseholdID = @HouseholdID
      AND h.IsDeleted = 0
      AND h.IsActive = 1;

    IF @ProviderID IS NULL
        THROW 51030, 'The requested household does not exist.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.ProviderID = @ProviderID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    )
        THROW 51031, 'The current provider user cannot modify this household.', 1;

    BEGIN TRANSACTION;

    IF @HouseholdPersonID IS NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName, MiddleName, LastName, PrimaryEmail, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@FirstName)),
            NULLIF(LTRIM(RTRIM(@MiddleName)), N''),
            LTRIM(RTRIM(@LastName)),
            NULLIF(LTRIM(RTRIM(@PrimaryEmail)), N''),
            1, 0, @PortalUserID
        );

        SET @PersonID = SCOPE_IDENTITY();

        INSERT INTO party.HouseholdPerson
        (
            HouseholdID, PersonID, HouseholdRoleCodeValueID, IsPrimaryContact, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @HouseholdID, @PersonID, @HouseholdRoleCodeValueID, @IsPrimaryContact, @StartDate, 1, 0, @PortalUserID
        );

        SET @HouseholdPersonID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        SELECT @PersonID = hp.PersonID
        FROM party.HouseholdPerson hp
        WHERE hp.HouseholdPersonID = @HouseholdPersonID
          AND hp.HouseholdID = @HouseholdID
          AND hp.IsDeleted = 0;

        IF @PersonID IS NULL
            THROW 51032, 'The requested household person does not exist.', 1;

        UPDATE party.Person
           SET FirstName = LTRIM(RTRIM(@FirstName)),
               MiddleName = NULLIF(LTRIM(RTRIM(@MiddleName)), N''),
               LastName = LTRIM(RTRIM(@LastName)),
               PrimaryEmail = NULLIF(LTRIM(RTRIM(@PrimaryEmail)), N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @PortalUserID
         WHERE PersonID = @PersonID;

        UPDATE party.HouseholdPerson
           SET HouseholdRoleCodeValueID = @HouseholdRoleCodeValueID,
               IsPrimaryContact = @IsPrimaryContact,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @PortalUserID
         WHERE HouseholdPersonID = @HouseholdPersonID;
    END;

    IF @ChildID IS NOT NULL
       AND EXISTS
       (
           SELECT 1
           FROM child.ChildHousehold chh
           WHERE chh.HouseholdID = @HouseholdID
             AND chh.ChildID = @ChildID
             AND chh.IsDeleted = 0
             AND chh.IsActive = 1
       )
    BEGIN
        IF EXISTS
        (
            SELECT 1
            FROM child.ChildPersonRelationship cpr
            WHERE cpr.ChildID = @ChildID
              AND cpr.PersonID = @PersonID
              AND cpr.IsDeleted = 0
        )
        BEGIN
            UPDATE child.ChildPersonRelationship
               SET RelationshipTypeCode = @RelationshipTypeCode,
                   HasPortalAccess = @HasPortalAccess,
                   CanReceiveAlerts = @CanReceiveAlerts,
                   CanSignPermissions = @CanSignPermissions,
                   IsPrimaryGuardian = @IsPrimaryGuardian,
                   ModifiedUTC = SYSUTCDATETIME(),
                   ModifiedByUserID = @PortalUserID
             WHERE ChildID = @ChildID
               AND PersonID = @PersonID
               AND IsDeleted = 0;
        END
        ELSE
        BEGIN
            INSERT INTO child.ChildPersonRelationship
            (
                ChildID, PersonID, RelationshipTypeCode, HasPortalAccess, CanReceiveAlerts,
                CanSignPermissions, IsPrimaryGuardian, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
            )
            VALUES
            (
                @ChildID, @PersonID, @RelationshipTypeCode, @HasPortalAccess, @CanReceiveAlerts,
                @CanSignPermissions, @IsPrimaryGuardian, @StartDate, 1, 0, @PortalUserID
            );
        END;
    END;

    COMMIT TRANSACTION;

    SELECT
        HouseholdPersonID = @HouseholdPersonID,
        PersonID = @PersonID,
        HouseholdID = @HouseholdID,
        ChildID = @ChildID;
END;
GO
