CREATE OR ALTER PROCEDURE child.usp_GuardianAccessibleChild_List
    @PersonID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT DISTINCT
        c.ChildID,
        c.SiteID,
        CONCAT(c.FirstName, N' ', c.LastName) AS ChildName,
        s.SiteName
    FROM child.ChildPersonRelationship cpr
    INNER JOIN child.Child c
        ON c.ChildID = cpr.ChildID
       AND c.IsDeleted = 0
       AND c.IsActive = 1
    INNER JOIN party.Site s
        ON s.SiteID = c.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    WHERE cpr.PersonID = @PersonID
      AND cpr.HasPortalAccess = 1
      AND cpr.IsDeleted = 0
      AND cpr.IsActive = 1
      AND cpr.EffectiveStartDate <= CAST(SYSUTCDATETIME() AS date)
      AND (cpr.EffectiveEndDate IS NULL OR cpr.EffectiveEndDate >= CAST(SYSUTCDATETIME() AS date))
    ORDER BY ChildName, s.SiteName, c.ChildID;
END;
GO
