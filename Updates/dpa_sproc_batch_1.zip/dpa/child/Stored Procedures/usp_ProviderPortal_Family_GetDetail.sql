CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_GetDetail
    @PortalUserID INT,
    @HouseholdID  INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        INNER JOIN party.Household h
            ON h.ProviderID = s.ProviderID
           AND h.HouseholdID = @HouseholdID
           AND h.IsDeleted = 0
           AND h.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 51020, 'The current provider user cannot access the requested household.', 1;
    END;

    SELECT
        h.HouseholdID,
        h.ProviderID,
        pr.ProviderName,
        h.HouseholdDisplayName,
        h.PrimaryAddressID,
        a.AddressLine1,
        a.AddressLine2,
        a.City,
        a.StateProvinceCode,
        a.PostalCode,
        ChildCount = COUNT(DISTINCT chh.ChildID),
        ActiveEnrollmentCount = COUNT(DISTINCT CASE WHEN ce.IsDeleted = 0 AND ce.IsActive = 1 AND ce.IsPrimaryEnrollment = 1 THEN ce.ChildEnrollmentID END),
        GuardianCount = COUNT(DISTINCT CASE WHEN cv.CodeValue IN (N'PRIMARY_GUARDIAN', N'SECONDARY_GUARDIAN', N'GUARDIAN') THEN hp.PersonID END),
        PrimaryContactPersonID = MAX(CASE WHEN hp.IsPrimaryContact = 1 THEN hp.PersonID END),
        PrimaryContactDisplayName = MAX(CASE WHEN hp.IsPrimaryContact = 1 THEN CONCAT(p.FirstName, N' ', p.LastName) END),
        PrimaryContactEmail = MAX(CASE WHEN hp.IsPrimaryContact = 1 THEN p.PrimaryEmail END),
        h.CreatedUTC,
        h.ModifiedUTC
    FROM party.Household h
    INNER JOIN party.Provider pr
        ON pr.ProviderID = h.ProviderID
       AND pr.IsDeleted = 0
       AND pr.IsActive = 1
    LEFT JOIN party.Address a
        ON a.AddressID = h.PrimaryAddressID
       AND a.IsDeleted = 0
       AND a.IsActive = 1
    LEFT JOIN child.ChildHousehold chh
        ON chh.HouseholdID = h.HouseholdID
       AND chh.IsDeleted = 0
       AND chh.IsActive = 1
    LEFT JOIN child.ChildEnrollment ce
        ON ce.ChildID = chh.ChildID
       AND ce.IsDeleted = 0
       AND ce.IsActive = 1
       AND ce.IsPrimaryEnrollment = 1
    LEFT JOIN party.HouseholdPerson hp
        ON hp.HouseholdID = h.HouseholdID
       AND hp.IsDeleted = 0
       AND hp.IsActive = 1
    LEFT JOIN ref.CodeValue cv
        ON cv.CodeValueID = hp.HouseholdRoleCodeValueID
    LEFT JOIN party.Person p
        ON p.PersonID = hp.PersonID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE h.HouseholdID = @HouseholdID
      AND h.IsDeleted = 0
      AND h.IsActive = 1
    GROUP BY
        h.HouseholdID, h.ProviderID, pr.ProviderName, h.HouseholdDisplayName, h.PrimaryAddressID,
        a.AddressLine1, a.AddressLine2, a.City, a.StateProvinceCode, a.PostalCode, h.CreatedUTC, h.ModifiedUTC;

    SELECT
        chh.ChildHouseholdID,
        c.ChildID,
        c.SiteID,
        s.SiteName,
        CONCAT(c.FirstName, N' ', c.LastName) AS ChildDisplayName,
        c.FirstName,
        c.MiddleName,
        c.LastName,
        c.DateOfBirth,
        c.SpecialDietNotes,
        c.SpecialNeedsNotes,
        ce.ChildEnrollmentID,
        ce.EnrollmentStartDate,
        ce.EnrollmentEndDate,
        ce.ScheduleSummary,
        ce.FinancialArrangementNotes,
        ce.EnrollmentStatusCode,
        chh.IsPrimaryHousehold,
        ChildHouseholdIsActive = chh.IsActive,
        c.CreatedUTC,
        c.ModifiedUTC
    FROM child.ChildHousehold chh
    INNER JOIN child.Child c
        ON c.ChildID = chh.ChildID
       AND c.IsDeleted = 0
    INNER JOIN party.Site s
        ON s.SiteID = c.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    LEFT JOIN child.ChildEnrollment ce
        ON ce.ChildID = c.ChildID
       AND ce.IsDeleted = 0
       AND ce.IsActive = 1
       AND ce.IsPrimaryEnrollment = 1
    WHERE chh.HouseholdID = @HouseholdID
      AND chh.IsDeleted = 0
    ORDER BY c.LastName, c.FirstName, c.ChildID;

    SELECT
        hp.HouseholdPersonID,
        hp.PersonID,
        PersonDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        p.FirstName,
        p.MiddleName,
        p.LastName,
        p.DateOfBirth,
        p.PrimaryEmail,
        hp.HouseholdRoleCodeValueID,
        HouseholdRoleCodeDomain = cv.CodeDomain,
        HouseholdRoleCode = cv.CodeValue,
        HouseholdRoleCodeName = cv.CodeName,
        hp.IsPrimaryContact,
        hp.EffectiveStartDate,
        hp.EffectiveEndDate,
        HouseholdPersonIsActive = hp.IsActive,
        p.CreatedUTC,
        p.ModifiedUTC
    FROM party.HouseholdPerson hp
    INNER JOIN party.Person p
        ON p.PersonID = hp.PersonID
       AND p.IsDeleted = 0
    INNER JOIN ref.CodeValue cv
        ON cv.CodeValueID = hp.HouseholdRoleCodeValueID
    WHERE hp.HouseholdID = @HouseholdID
      AND hp.IsDeleted = 0
    ORDER BY hp.IsPrimaryContact DESC, p.LastName, p.FirstName, hp.HouseholdPersonID;

    SELECT
        pda.PickupDropoffAuthorizationID,
        pda.ChildID,
        ChildDisplayName = CONCAT(c.FirstName, N' ', c.LastName),
        pda.PersonID,
        AuthorizedPersonDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        p.PrimaryEmail,
        pda.CanPickup,
        pda.CanDropoff,
        pda.IsEmergencyContact,
        pda.Notes,
        pda.EffectiveStartDate,
        pda.EffectiveEndDate,
        pda.IsActive,
        pda.CreatedUTC,
        pda.ModifiedUTC
    FROM child.PickupDropoffAuthorization pda
    INNER JOIN child.Child c
        ON c.ChildID = pda.ChildID
       AND c.IsDeleted = 0
    INNER JOIN child.ChildHousehold chh
        ON chh.ChildID = pda.ChildID
       AND chh.HouseholdID = @HouseholdID
       AND chh.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pda.PersonID
       AND p.IsDeleted = 0
    WHERE pda.IsDeleted = 0
    ORDER BY c.LastName, c.FirstName, p.LastName, p.FirstName, pda.PickupDropoffAuthorizationID;
END;
GO
