CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Child_List
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH AllowedSites AS
    (
        SELECT DISTINCT sua.SiteID
        FROM party.SiteUserAssignment sua
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
    ),
    PrimaryGuardian AS
    (
        SELECT
            cpr.ChildID,
            CONCAT(p.FirstName, N' ', p.LastName) AS PrimaryGuardianName,
            rn = ROW_NUMBER() OVER
            (
                PARTITION BY cpr.ChildID
                ORDER BY CASE WHEN cpr.IsPrimaryGuardian = 1 THEN 0 ELSE 1 END, cpr.ChildPersonRelationshipID
            )
        FROM child.ChildPersonRelationship cpr
        INNER JOIN party.Person p
            ON p.PersonID = cpr.PersonID
           AND p.IsDeleted = 0
           AND p.IsActive = 1
        WHERE cpr.IsDeleted = 0
          AND cpr.IsActive = 1
    )
    SELECT
        c.ChildID,
        CONCAT(c.FirstName, N' ', c.LastName) AS ChildDisplayName,
        c.DateOfBirth,
        AgeGroup =
            CASE
                WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 16 THEN N'Infant'
                WHEN DATEDIFF(MONTH, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 33 THEN N'Toddler'
                WHEN DATEDIFF(YEAR, c.DateOfBirth, CAST(SYSUTCDATETIME() AS date)) < 5 THEN N'Preschool'
                ELSE N'School age'
            END,
        pg.PrimaryGuardianName,
        AllergyPlanStatusText = CASE WHEN NULLIF(LTRIM(RTRIM(c.SpecialDietNotes)), N'') IS NULL THEN N'No allergy/diet plan recorded' ELSE N'Plan on file' END,
        AllergyPlanStatusCssClass = CASE WHEN NULLIF(LTRIM(RTRIM(c.SpecialDietNotes)), N'') IS NULL THEN N'status-warning' ELSE N'status-good' END,
        DocumentStatusText = CASE WHEN ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= CAST(SYSUTCDATETIME() AS date) THEN N'Current' ELSE N'Enrollment ended' END,
        DocumentStatusCssClass = CASE WHEN ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= CAST(SYSUTCDATETIME() AS date) THEN N'status-good' ELSE N'status-warning' END,
        ce.EnrollmentStatusCode,
        s.SiteName
    FROM child.Child c
    INNER JOIN AllowedSites al
        ON al.SiteID = c.SiteID
    INNER JOIN party.Site s
        ON s.SiteID = c.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    LEFT JOIN child.ChildEnrollment ce
        ON ce.ChildID = c.ChildID
       AND ce.IsDeleted = 0
       AND ce.IsActive = 1
       AND ce.IsPrimaryEnrollment = 1
    LEFT JOIN PrimaryGuardian pg
        ON pg.ChildID = c.ChildID
       AND pg.rn = 1
    WHERE c.IsDeleted = 0
      AND c.IsActive = 1
    ORDER BY s.SiteName, c.LastName, c.FirstName, c.ChildID;
END;
GO
