CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_List
    @PortalUserID INT,
    @SiteID       INT = NULL,
    @SearchTerm   NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH AllowedProviders AS
    (
        SELECT DISTINCT s.ProviderID
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME())
          AND (@SiteID IS NULL OR sua.SiteID = @SiteID)
    ),
    ChildCounts AS
    (
        SELECT
            chh.HouseholdID,
            ChildCount = COUNT(DISTINCT chh.ChildID)
        FROM child.ChildHousehold chh
        WHERE chh.IsDeleted = 0
          AND chh.IsActive = 1
        GROUP BY chh.HouseholdID
    ),
    ActiveEnrollments AS
    (
        SELECT
            chh.HouseholdID,
            ActiveEnrollmentCount = COUNT(DISTINCT ce.ChildEnrollmentID)
        FROM child.ChildHousehold chh
        INNER JOIN child.ChildEnrollment ce
            ON ce.ChildID = chh.ChildID
           AND ce.IsDeleted = 0
           AND ce.IsActive = 1
           AND ce.IsPrimaryEnrollment = 1
           AND (ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= CAST(SYSUTCDATETIME() AS date))
        WHERE chh.IsDeleted = 0
          AND chh.IsActive = 1
        GROUP BY chh.HouseholdID
    ),
    GuardianCounts AS
    (
        SELECT
            hp.HouseholdID,
            GuardianCount = COUNT(DISTINCT hp.PersonID)
        FROM party.HouseholdPerson hp
        INNER JOIN ref.CodeValue cv
            ON cv.CodeValueID = hp.HouseholdRoleCodeValueID
           AND cv.CodeDomain = N'HouseholdRole'
           AND cv.CodeValue IN (N'PRIMARY_GUARDIAN', N'SECONDARY_GUARDIAN', N'GUARDIAN')
        WHERE hp.IsDeleted = 0
          AND hp.IsActive = 1
        GROUP BY hp.HouseholdID
    ),
    PrimaryContact AS
    (
        SELECT
            hp.HouseholdID,
            hp.PersonID,
            CONCAT(p.FirstName, N' ', p.LastName) AS PrimaryContactDisplayName,
            p.PrimaryEmail,
            rn = ROW_NUMBER() OVER
            (
                PARTITION BY hp.HouseholdID
                ORDER BY CASE WHEN hp.IsPrimaryContact = 1 THEN 0 ELSE 1 END, hp.HouseholdPersonID
            )
        FROM party.HouseholdPerson hp
        INNER JOIN party.Person p
            ON p.PersonID = hp.PersonID
           AND p.IsDeleted = 0
           AND p.IsActive = 1
        WHERE hp.IsDeleted = 0
          AND hp.IsActive = 1
    )
    SELECT
        h.HouseholdID,
        h.ProviderID,
        pr.ProviderName,
        h.HouseholdDisplayName,
        pc.PersonID AS PrimaryContactPersonID,
        pc.PrimaryContactDisplayName,
        pc.PrimaryEmail AS PrimaryContactEmail,
        ISNULL(cc.ChildCount, 0) AS ChildCount,
        ISNULL(ae.ActiveEnrollmentCount, 0) AS ActiveEnrollmentCount,
        ISNULL(gc.GuardianCount, 0) AS GuardianCount,
        a.AddressLine1,
        a.AddressLine2,
        a.City,
        a.StateProvinceCode,
        a.PostalCode,
        h.CreatedUTC,
        h.ModifiedUTC
    FROM party.Household h
    INNER JOIN AllowedProviders ap
        ON ap.ProviderID = h.ProviderID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = h.ProviderID
       AND pr.IsDeleted = 0
       AND pr.IsActive = 1
    LEFT JOIN party.Address a
        ON a.AddressID = h.PrimaryAddressID
       AND a.IsDeleted = 0
       AND a.IsActive = 1
    LEFT JOIN ChildCounts cc
        ON cc.HouseholdID = h.HouseholdID
    LEFT JOIN ActiveEnrollments ae
        ON ae.HouseholdID = h.HouseholdID
    LEFT JOIN GuardianCounts gc
        ON gc.HouseholdID = h.HouseholdID
    LEFT JOIN PrimaryContact pc
        ON pc.HouseholdID = h.HouseholdID
       AND pc.rn = 1
    WHERE h.IsDeleted = 0
      AND h.IsActive = 1
      AND
      (
          @SearchTerm IS NULL
          OR h.HouseholdDisplayName LIKE N'%' + @SearchTerm + N'%'
          OR pc.PrimaryContactDisplayName LIKE N'%' + @SearchTerm + N'%'
          OR pc.PrimaryEmail LIKE N'%' + @SearchTerm + N'%'
          OR a.City LIKE N'%' + @SearchTerm + N'%'
          OR a.PostalCode LIKE N'%' + @SearchTerm + N'%'
      )
    ORDER BY h.HouseholdDisplayName, pc.PrimaryContactDisplayName, h.HouseholdID;
END;
GO
