CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Family_Onboard
    @PortalUserID                INT,
    @SiteID                      INT,
    @ChildFirstName              NVARCHAR(100),
    @ChildMiddleName             NVARCHAR(100) = NULL,
    @ChildLastName               NVARCHAR(100),
    @DateOfBirth                 DATE,
    @EnrollmentStartDate         DATE,
    @SpecialDietNotes            NVARCHAR(MAX) = NULL,
    @SpecialNeedsNotes           NVARCHAR(MAX) = NULL,
    @ScheduleSummary             NVARCHAR(MAX) = NULL,
    @FinancialArrangementNotes   NVARCHAR(MAX) = NULL,
    @PrimaryGuardianFirstName    NVARCHAR(100),
    @PrimaryGuardianMiddleName   NVARCHAR(100) = NULL,
    @PrimaryGuardianLastName     NVARCHAR(100),
    @PrimaryGuardianEmail        NVARCHAR(320) = NULL,
    @SecondaryGuardianFirstName  NVARCHAR(100) = NULL,
    @SecondaryGuardianMiddleName NVARCHAR(100) = NULL,
    @SecondaryGuardianLastName   NVARCHAR(100) = NULL,
    @SecondaryGuardianEmail      NVARCHAR(320) = NULL,
    @PickupContactFirstName      NVARCHAR(100) = NULL,
    @PickupContactMiddleName     NVARCHAR(100) = NULL,
    @PickupContactLastName       NVARCHAR(100) = NULL,
    @PickupContactEmail          NVARCHAR(320) = NULL,
    @PickupCanPickup             BIT = 0,
    @PickupCanDropoff            BIT = 0,
    @PickupIsEmergencyContact    BIT = 0,
    @PickupNotes                 NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ProviderID INT;
    DECLARE @SiteName NVARCHAR(200);
    DECLARE @PrimaryGuardianRoleCodeValueID INT;
    DECLARE @SecondaryGuardianRoleCodeValueID INT;
    DECLARE @PickupRoleCodeValueID INT;
    DECLARE @Today DATE = CAST(SYSUTCDATETIME() AS date);

    DECLARE @HouseholdID INT;
    DECLARE @ChildID INT;
    DECLARE @PrimaryGuardianPersonID INT;
    DECLARE @SecondaryGuardianPersonID INT = NULL;
    DECLARE @PickupPersonID INT = NULL;

    SELECT
        @ProviderID = s.ProviderID,
        @SiteName = s.SiteName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.SiteID = @SiteID
      AND sua.IsActive = 1
      AND sua.EffectiveStartUTC <= SYSUTCDATETIME()
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME());

    IF @ProviderID IS NULL
        THROW 51001, 'The provider portal user is not assigned to the requested site.', 1;

    SELECT @PrimaryGuardianRoleCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue = N'PRIMARY_GUARDIAN'
      AND cv.IsActive = 1;

    SELECT @SecondaryGuardianRoleCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue = N'SECONDARY_GUARDIAN'
      AND cv.IsActive = 1;

    SELECT TOP (1) @PickupRoleCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'HouseholdRole'
      AND cv.CodeValue IN (N'AUTHORIZED_PICKUP_CONTACT', N'PICKUP_CONTACT')
      AND cv.IsActive = 1
    ORDER BY CASE WHEN cv.CodeValue = N'AUTHORIZED_PICKUP_CONTACT' THEN 0 ELSE 1 END;

    BEGIN TRANSACTION;

    INSERT INTO party.Person
    (
        FirstName, MiddleName, LastName, PrimaryEmail, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        LTRIM(RTRIM(@PrimaryGuardianFirstName)),
        NULLIF(LTRIM(RTRIM(@PrimaryGuardianMiddleName)), N''),
        LTRIM(RTRIM(@PrimaryGuardianLastName)),
        NULLIF(LTRIM(RTRIM(@PrimaryGuardianEmail)), N''),
        1, 0, @PortalUserID
    );

    SET @PrimaryGuardianPersonID = SCOPE_IDENTITY();

    INSERT INTO party.Household
    (
        ProviderID, HouseholdDisplayName, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @ProviderID,
        LEFT(CONCAT(LTRIM(RTRIM(@PrimaryGuardianLastName)), N' household'), 200),
        1, 0, @PortalUserID
    );

    SET @HouseholdID = SCOPE_IDENTITY();

    INSERT INTO party.HouseholdPerson
    (
        HouseholdID, PersonID, HouseholdRoleCodeValueID, IsPrimaryContact, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @HouseholdID, @PrimaryGuardianPersonID, @PrimaryGuardianRoleCodeValueID, 1, @Today, 1, 0, @PortalUserID
    );

    IF NULLIF(LTRIM(RTRIM(@SecondaryGuardianFirstName)), N'') IS NOT NULL
       AND NULLIF(LTRIM(RTRIM(@SecondaryGuardianLastName)), N'') IS NOT NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName, MiddleName, LastName, PrimaryEmail, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@SecondaryGuardianFirstName)),
            NULLIF(LTRIM(RTRIM(@SecondaryGuardianMiddleName)), N''),
            LTRIM(RTRIM(@SecondaryGuardianLastName)),
            NULLIF(LTRIM(RTRIM(@SecondaryGuardianEmail)), N''),
            1, 0, @PortalUserID
        );

        SET @SecondaryGuardianPersonID = SCOPE_IDENTITY();

        INSERT INTO party.HouseholdPerson
        (
            HouseholdID, PersonID, HouseholdRoleCodeValueID, IsPrimaryContact, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @HouseholdID, @SecondaryGuardianPersonID, @SecondaryGuardianRoleCodeValueID, 0, @Today, 1, 0, @PortalUserID
        );
    END;

    INSERT INTO child.Child
    (
        SiteID, FirstName, MiddleName, LastName, DateOfBirth, SpecialDietNotes, SpecialNeedsNotes, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        LTRIM(RTRIM(@ChildFirstName)),
        NULLIF(LTRIM(RTRIM(@ChildMiddleName)), N''),
        LTRIM(RTRIM(@ChildLastName)),
        @DateOfBirth,
        NULLIF(@SpecialDietNotes, N''),
        NULLIF(@SpecialNeedsNotes, N''),
        1, 0, @PortalUserID
    );

    SET @ChildID = SCOPE_IDENTITY();

    INSERT INTO child.ChildHousehold
    (
        ChildID, HouseholdID, IsPrimaryHousehold, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @ChildID, @HouseholdID, 1, @EnrollmentStartDate, 1, 0, @PortalUserID
    );

    INSERT INTO child.ChildEnrollment
    (
        ChildID, SiteID, EnrollmentStartDate, ScheduleSummary, FinancialArrangementNotes, EnrollmentStatusCode,
        IsPrimaryEnrollment, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @ChildID, @SiteID, @EnrollmentStartDate, NULLIF(@ScheduleSummary, N''), NULLIF(@FinancialArrangementNotes, N''),
        N'ACTIVE', 1, 1, 0, @PortalUserID
    );

    INSERT INTO child.ChildPersonRelationship
    (
        ChildID, PersonID, RelationshipTypeCode, HasPortalAccess, CanReceiveAlerts, CanSignPermissions,
        IsPrimaryGuardian, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @ChildID, @PrimaryGuardianPersonID, N'GUARDIAN',
        CASE WHEN NULLIF(LTRIM(RTRIM(@PrimaryGuardianEmail)), N'') IS NULL THEN 0 ELSE 1 END,
        1, 1, 1, @EnrollmentStartDate, 1, 0, @PortalUserID
    );

    IF @SecondaryGuardianPersonID IS NOT NULL
    BEGIN
        INSERT INTO child.ChildPersonRelationship
        (
            ChildID, PersonID, RelationshipTypeCode, HasPortalAccess, CanReceiveAlerts, CanSignPermissions,
            IsPrimaryGuardian, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ChildID, @SecondaryGuardianPersonID, N'GUARDIAN',
            CASE WHEN NULLIF(LTRIM(RTRIM(@SecondaryGuardianEmail)), N'') IS NULL THEN 0 ELSE 1 END,
            1, 1, 0, @EnrollmentStartDate, 1, 0, @PortalUserID
        );
    END;

    IF NULLIF(LTRIM(RTRIM(@PickupContactFirstName)), N'') IS NOT NULL
       AND NULLIF(LTRIM(RTRIM(@PickupContactLastName)), N'') IS NOT NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName, MiddleName, LastName, PrimaryEmail, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@PickupContactFirstName)),
            NULLIF(LTRIM(RTRIM(@PickupContactMiddleName)), N''),
            LTRIM(RTRIM(@PickupContactLastName)),
            NULLIF(LTRIM(RTRIM(@PickupContactEmail)), N''),
            1, 0, @PortalUserID
        );

        SET @PickupPersonID = SCOPE_IDENTITY();

        IF @PickupRoleCodeValueID IS NOT NULL
        BEGIN
            INSERT INTO party.HouseholdPerson
            (
                HouseholdID, PersonID, HouseholdRoleCodeValueID, IsPrimaryContact, EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
            )
            VALUES
            (
                @HouseholdID, @PickupPersonID, @PickupRoleCodeValueID, 0, @EnrollmentStartDate, 1, 0, @PortalUserID
            );
        END;

        INSERT INTO child.PickupDropoffAuthorization
        (
            ChildID, PersonID, CanPickup, CanDropoff, IsEmergencyContact, Notes,
            EffectiveStartDate, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ChildID, @PickupPersonID, @PickupCanPickup, @PickupCanDropoff, @PickupIsEmergencyContact,
            NULLIF(@PickupNotes, N''), @EnrollmentStartDate, 1, 0, @PortalUserID
        );
    END;

    COMMIT TRANSACTION;

    SELECT
        ChildID = @ChildID,
        SiteID = @SiteID,
        ChildDisplayName = CONCAT(@ChildFirstName, N' ', @ChildLastName),
        SiteName = @SiteName;
END;
GO
