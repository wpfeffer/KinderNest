DPA stored procedure batch 1 of 4

Theme:
Core portal identity, guardian access, family onboarding, and family detail reads.

Included procedures:
1. party.usp_PortalUserAssignedSite_List
2. child.usp_GuardianAccessibleChild_List
3. child.usp_GuardianAccess_CheckSite
4. child.usp_GuardianPortal_Child_List
5. party.usp_GuardianPortal_Profile_Get
6. child.usp_ProviderPortal_Child_List
7. child.usp_ProviderPortal_Family_List
8. child.usp_ProviderPortal_Family_GetDetail
9. child.usp_ProviderPortal_Family_Onboard
10. child.usp_ProviderPortal_Guardian_Upsert

All procedures are written as CREATE OR ALTER and avoid destructive object drops.
