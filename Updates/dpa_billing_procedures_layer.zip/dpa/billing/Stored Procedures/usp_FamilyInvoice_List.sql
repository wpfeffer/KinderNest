CREATE OR ALTER PROCEDURE billing.usp_FamilyInvoice_List
    @FamilyBillingAccountID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        fi.FamilyInvoiceID, fi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        fi.BillingPeriodStartUTC, fi.BillingPeriodEndUTC, fi.IssuedUTC, fi.DueUTC,
        fi.SentUTC, fi.SubtotalAmount, fi.TaxAmount, fi.TotalAmount, fi.BalanceAmount
    FROM billing.FamilyInvoice fi
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = fi.InvoiceStatusCodeValueID
    WHERE fi.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fi.IsDeleted = 0
    ORDER BY fi.IssuedUTC DESC, fi.FamilyInvoiceID DESC;
END;
GO
