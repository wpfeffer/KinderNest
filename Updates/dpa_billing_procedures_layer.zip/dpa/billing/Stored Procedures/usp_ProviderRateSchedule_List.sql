CREATE OR ALTER PROCEDURE billing.usp_ProviderRateSchedule_List
    @ProviderID INT,
    @SiteID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        prs.ProviderRateScheduleID, prs.ProviderID, prs.SiteID, SiteName = s.SiteName,
        prs.RateName, RateTypeCode = rtc.CodeValue, RateTypeName = rtc.CodeName,
        BillingFrequencyCode = bfc.CodeValue, BillingFrequencyName = bfc.CodeName,
        prs.StandardAmount, prs.StandardQuantityDecimal, prs.AppliesPerChild, prs.TaxableFlag,
        prs.EffectiveStartDate, prs.EffectiveEndDate, prs.Notes, prs.IsActive
    FROM billing.ProviderRateSchedule prs
    INNER JOIN ref.CodeValue rtc ON rtc.CodeValueID = prs.RateTypeCodeValueID
    LEFT JOIN ref.CodeValue bfc ON bfc.CodeValueID = prs.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s ON s.SiteID = prs.SiteID AND s.IsDeleted = 0
    WHERE prs.ProviderID = @ProviderID
      AND prs.IsDeleted = 0
      AND (@SiteID IS NULL OR prs.SiteID = @SiteID OR prs.SiteID IS NULL)
    ORDER BY prs.EffectiveStartDate DESC, prs.RateName, prs.ProviderRateScheduleID;
END;
GO
