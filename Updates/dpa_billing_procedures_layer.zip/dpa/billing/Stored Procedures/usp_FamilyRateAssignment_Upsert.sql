CREATE OR ALTER PROCEDURE billing.usp_FamilyRateAssignment_Upsert
    @FamilyRateAssignmentID     INT = NULL,
    @FamilyBillingAccountID     INT,
    @ChildID                    INT = NULL,
    @ProviderRateScheduleID     INT,
    @OverrideAmount             DECIMAL(18,2) = NULL,
    @EffectiveStartDate         DATE,
    @EffectiveEndDate           DATE = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    IF @FamilyRateAssignmentID IS NULL
    BEGIN
        INSERT INTO billing.FamilyRateAssignment
        (
            FamilyBillingAccountID, ChildID, ProviderRateScheduleID, OverrideAmount,
            EffectiveStartDate, EffectiveEndDate, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @FamilyBillingAccountID, @ChildID, @ProviderRateScheduleID, @OverrideAmount,
            @EffectiveStartDate, @EffectiveEndDate, 1, 0, @CreatedByUserID
        );
        SET @FamilyRateAssignmentID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.FamilyRateAssignment
           SET ChildID = @ChildID,
               ProviderRateScheduleID = @ProviderRateScheduleID,
               OverrideAmount = @OverrideAmount,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyRateAssignmentID = @FamilyRateAssignmentID
           AND FamilyBillingAccountID = @FamilyBillingAccountID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT FamilyRateAssignmentID = @FamilyRateAssignmentID;
END;
GO
