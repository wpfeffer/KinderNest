CREATE OR ALTER PROCEDURE billing.usp_FamilyInvoice_GetDetail
    @FamilyInvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        fi.FamilyInvoiceID, fi.FamilyBillingAccountID, fba.ProviderID, pr.ProviderName,
        fba.HouseholdID, h.HouseholdDisplayName,
        fi.InvoiceNumber, InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        fi.BillingPeriodStartUTC, fi.BillingPeriodEndUTC, fi.IssuedUTC, fi.DueUTC,
        fi.SentUTC, fi.SubtotalAmount, fi.TaxAmount, fi.TotalAmount, fi.BalanceAmount,
        fi.PaidUTC, fi.Notes
    FROM billing.FamilyInvoice fi
    INNER JOIN billing.FamilyBillingAccount fba ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID AND fba.IsDeleted = 0
    INNER JOIN party.Provider pr ON pr.ProviderID = fba.ProviderID AND pr.IsDeleted = 0
    INNER JOIN party.Household h ON h.HouseholdID = fba.HouseholdID AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = fi.InvoiceStatusCodeValueID
    WHERE fi.FamilyInvoiceID = @FamilyInvoiceID AND fi.IsDeleted = 0;

    SELECT
        fil.FamilyInvoiceLineID, LineTypeCode = lt.CodeValue, LineTypeName = lt.CodeName,
        fil.Description, fil.QuantityDecimal, fil.UnitPriceAmount, fil.LineAmount,
        fil.FamilyChargeID, fil.RelatedChildID,
        ChildDisplayName = CASE WHEN ch.ChildID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))) END
    FROM billing.FamilyInvoiceLine fil
    INNER JOIN ref.CodeValue lt ON lt.CodeValueID = fil.LineTypeCodeValueID
    LEFT JOIN child.Child ch ON ch.ChildID = fil.RelatedChildID AND ch.IsDeleted = 0
    WHERE fil.FamilyInvoiceID = @FamilyInvoiceID AND fil.IsDeleted = 0
    ORDER BY fil.FamilyInvoiceLineID;

    SELECT
        p.PaymentID, PaymentStatusCode = pst.CodeValue, PaymentStatusName = pst.CodeName,
        PaymentScopeCode = psc.CodeValue, p.PaymentUTC, p.Amount, p.CurrencyCode,
        p.ProcessorFeeAmount, p.ExternalTransactionReference
    FROM billing.Payment p
    INNER JOIN ref.CodeValue pst ON pst.CodeValueID = p.PaymentStatusCodeValueID
    INNER JOIN ref.CodeValue psc ON psc.CodeValueID = p.PaymentScopeCodeValueID
    WHERE p.FamilyInvoiceID = @FamilyInvoiceID AND p.IsDeleted = 0
    ORDER BY p.PaymentUTC DESC, p.PaymentID DESC;
END;
GO
