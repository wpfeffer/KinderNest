CREATE OR ALTER PROCEDURE billing.usp_ProviderRateSchedule_Upsert
    @ProviderRateScheduleID         INT = NULL,
    @ProviderID                     INT,
    @SiteID                         INT = NULL,
    @RateName                       NVARCHAR(200),
    @RateTypeCodeValueID            INT,
    @BillingFrequencyCodeValueID    INT = NULL,
    @StandardAmount                 DECIMAL(18,2),
    @StandardQuantityDecimal        DECIMAL(18,4) = 1.0000,
    @AppliesPerChild                BIT = 1,
    @TaxableFlag                    BIT = 0,
    @EffectiveStartDate             DATE,
    @EffectiveEndDate               DATE = NULL,
    @Notes                          NVARCHAR(1000) = NULL,
    @CreatedByUserID                INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    IF @ProviderRateScheduleID IS NULL
    BEGIN
        INSERT INTO billing.ProviderRateSchedule
        (
            ProviderID, SiteID, RateName, RateTypeCodeValueID, BillingFrequencyCodeValueID,
            StandardAmount, StandardQuantityDecimal, AppliesPerChild, TaxableFlag,
            EffectiveStartDate, EffectiveEndDate, Notes, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderID, @SiteID, @RateName, @RateTypeCodeValueID, @BillingFrequencyCodeValueID,
            @StandardAmount, @StandardQuantityDecimal, @AppliesPerChild, @TaxableFlag,
            @EffectiveStartDate, @EffectiveEndDate, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
        );
        SET @ProviderRateScheduleID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.ProviderRateSchedule
           SET SiteID = @SiteID,
               RateName = @RateName,
               RateTypeCodeValueID = @RateTypeCodeValueID,
               BillingFrequencyCodeValueID = @BillingFrequencyCodeValueID,
               StandardAmount = @StandardAmount,
               StandardQuantityDecimal = @StandardQuantityDecimal,
               AppliesPerChild = @AppliesPerChild,
               TaxableFlag = @TaxableFlag,
               EffectiveStartDate = @EffectiveStartDate,
               EffectiveEndDate = @EffectiveEndDate,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderRateScheduleID = @ProviderRateScheduleID
           AND ProviderID = @ProviderID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT ProviderRateScheduleID = @ProviderRateScheduleID;
END;
GO
