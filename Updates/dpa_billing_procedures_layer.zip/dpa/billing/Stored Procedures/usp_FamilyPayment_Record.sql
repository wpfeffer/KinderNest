CREATE OR ALTER PROCEDURE billing.usp_FamilyPayment_Record
    @BillingProviderAccountID      INT,
    @FamilyBillingAccountID        INT,
    @FamilyInvoiceID               INT = NULL,
    @PaymentMethodTokenID          INT = NULL,
    @PaymentStatusCodeValueID      INT = NULL,
    @ExternalTransactionReference  NVARCHAR(200) = NULL,
    @PaymentUTC                    DATETIME2(0) = NULL,
    @Amount                        DECIMAL(18,2),
    @CurrencyCode                  NCHAR(3) = N'USD',
    @ProcessorFeeAmount            DECIMAL(18,2) = NULL,
    @Notes                         NVARCHAR(1000) = NULL,
    @CreatedByUserID               INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @PaymentScopeCodeValueID INT, @PaymentID INT, @InvoiceBalance DECIMAL(18,2);
    IF @PaymentUTC IS NULL SET @PaymentUTC = SYSUTCDATETIME();
    IF @PaymentStatusCodeValueID IS NULL
    BEGIN
        SELECT @PaymentStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'PaymentStatus' AND cv.CodeValue = N'SETTLED';
    END;
    SELECT @PaymentScopeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PaymentScope' AND cv.CodeValue = N'FAMILY_PROVIDER';

    BEGIN TRANSACTION;
    INSERT INTO billing.Payment
    (
        PaymentScopeCodeValueID, PaymentStatusCodeValueID, BillingProviderAccountID,
        FamilyBillingAccountID, FamilyInvoiceID, PaymentMethodTokenID, ExternalTransactionReference,
        PaymentUTC, Amount, CurrencyCode, ProcessorFeeAmount, Notes, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @PaymentScopeCodeValueID, @PaymentStatusCodeValueID, @BillingProviderAccountID,
        @FamilyBillingAccountID, @FamilyInvoiceID, @PaymentMethodTokenID, NULLIF(@ExternalTransactionReference, N''),
        @PaymentUTC, @Amount, @CurrencyCode, @ProcessorFeeAmount, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
    );
    SET @PaymentID = CONVERT(INT, SCOPE_IDENTITY());

    IF @FamilyInvoiceID IS NOT NULL
    BEGIN
        SELECT @InvoiceBalance = fi.TotalAmount - ISNULL((SELECT SUM(p.Amount) FROM billing.Payment p WHERE p.FamilyInvoiceID = fi.FamilyInvoiceID AND p.IsDeleted = 0 AND p.IsActive = 1), 0.00)
        FROM billing.FamilyInvoice fi
        WHERE fi.FamilyInvoiceID = @FamilyInvoiceID AND fi.IsDeleted = 0;

        UPDATE billing.FamilyInvoice
           SET BalanceAmount = CASE WHEN @InvoiceBalance < 0 THEN 0 ELSE @InvoiceBalance END,
               PaidUTC = CASE WHEN @InvoiceBalance <= 0 THEN @PaymentUTC ELSE PaidUTC END,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyInvoiceID = @FamilyInvoiceID AND IsDeleted = 0;
    END;

    UPDATE fba
       SET CurrentBalanceAmount = ISNULL((SELECT SUM(fi.BalanceAmount) FROM billing.FamilyInvoice fi WHERE fi.FamilyBillingAccountID = fba.FamilyBillingAccountID AND fi.IsDeleted = 0 AND fi.IsActive = 1), 0.00),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @CreatedByUserID
    FROM billing.FamilyBillingAccount fba
    WHERE fba.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fba.IsDeleted = 0;

    COMMIT TRANSACTION;
    SELECT PaymentID = @PaymentID;
END;
GO
