CREATE OR ALTER PROCEDURE billing.usp_ProviderPayment_Record
    @BillingProviderAccountID      INT,
    @ProviderID                    INT,
    @ProviderInvoiceID             INT = NULL,
    @PaymentMethodTokenID          INT = NULL,
    @PaymentStatusCodeValueID      INT = NULL,
    @ExternalTransactionReference  NVARCHAR(200) = NULL,
    @PaymentUTC                    DATETIME2(0) = NULL,
    @Amount                        DECIMAL(18,2),
    @CurrencyCode                  NCHAR(3) = N'USD',
    @ProcessorFeeAmount            DECIMAL(18,2) = NULL,
    @Notes                         NVARCHAR(1000) = NULL,
    @CreatedByUserID               INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @PaymentScopeCodeValueID INT, @PaymentID INT, @InvoiceBalance DECIMAL(18,2);
    IF @PaymentUTC IS NULL SET @PaymentUTC = SYSUTCDATETIME();
    IF @PaymentStatusCodeValueID IS NULL
    BEGIN
        SELECT @PaymentStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'PaymentStatus' AND cv.CodeValue = N'SETTLED';
    END;
    SELECT @PaymentScopeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'PaymentScope' AND cv.CodeValue = N'PROVIDER_PLATFORM';

    BEGIN TRANSACTION;
    INSERT INTO billing.Payment
    (
        PaymentScopeCodeValueID, PaymentStatusCodeValueID, BillingProviderAccountID,
        ProviderID, ProviderInvoiceID, PaymentMethodTokenID, ExternalTransactionReference,
        PaymentUTC, Amount, CurrencyCode, ProcessorFeeAmount, Notes, IsActive, IsDeleted, CreatedByUserID
    )
    VALUES
    (
        @PaymentScopeCodeValueID, @PaymentStatusCodeValueID, @BillingProviderAccountID,
        @ProviderID, @ProviderInvoiceID, @PaymentMethodTokenID, NULLIF(@ExternalTransactionReference, N''),
        @PaymentUTC, @Amount, @CurrencyCode, @ProcessorFeeAmount, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
    );
    SET @PaymentID = CONVERT(INT, SCOPE_IDENTITY());

    IF @ProviderInvoiceID IS NOT NULL
    BEGIN
        SELECT @InvoiceBalance = pi.TotalAmount - ISNULL((SELECT SUM(p.Amount) FROM billing.Payment p WHERE p.ProviderInvoiceID = pi.ProviderInvoiceID AND p.IsDeleted = 0 AND p.IsActive = 1), 0.00)
        FROM billing.ProviderInvoice pi
        WHERE pi.ProviderInvoiceID = @ProviderInvoiceID AND pi.IsDeleted = 0;

        UPDATE billing.ProviderInvoice
           SET BalanceAmount = CASE WHEN @InvoiceBalance < 0 THEN 0 ELSE @InvoiceBalance END,
               PaidUTC = CASE WHEN @InvoiceBalance <= 0 THEN @PaymentUTC ELSE PaidUTC END,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderInvoiceID = @ProviderInvoiceID AND IsDeleted = 0;
    END;

    COMMIT TRANSACTION;
    SELECT PaymentID = @PaymentID;
END;
GO
