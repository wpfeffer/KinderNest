CREATE OR ALTER PROCEDURE billing.usp_ProviderPlan_List
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        pp.ProviderPlanID, pp.PlanCode, pp.PlanName,
        PlanTypeCode = pt.CodeValue, PlanTypeName = pt.CodeName,
        BillingFrequencyCode = bf.CodeValue, BillingFrequencyName = bf.CodeName,
        pp.BasePriceAmount, pp.IncludedChildrenCount, pp.IncludedImageStorageBytes,
        pp.IncludedUsersCount, pp.OverageImageStoragePricePerGb, pp.OverageChildPriceAmount,
        pp.EffectiveStartUTC, pp.EffectiveEndUTC, pp.IsPublic, pp.IsActive
    FROM billing.ProviderPlan pp
    INNER JOIN ref.CodeValue pt ON pt.CodeValueID = pp.PlanTypeCodeValueID
    INNER JOIN ref.CodeValue bf ON bf.CodeValueID = pp.BillingFrequencyCodeValueID
    WHERE pp.IsDeleted = 0
    ORDER BY pp.IsPublic DESC, pp.IsActive DESC, pp.PlanName, pp.ProviderPlanID;
END;
GO
