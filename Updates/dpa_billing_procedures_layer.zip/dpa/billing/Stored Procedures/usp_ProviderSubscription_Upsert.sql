CREATE OR ALTER PROCEDURE billing.usp_ProviderSubscription_Upsert
    @ProviderSubscriptionID        INT = NULL,
    @ProviderID                    INT,
    @ProviderPlanID                INT,
    @BillingProviderAccountID      INT = NULL,
    @SubscriptionStatusCodeValueID INT = NULL,
    @SubscriptionStartUTC          DATETIME2(0),
    @SubscriptionEndUTC            DATETIME2(0) = NULL,
    @NextBillingDateUTC            DATETIME2(0) = NULL,
    @AutoRenewEnabled              BIT = 0,
    @BillingContactPersonID        INT = NULL,
    @Notes                         NVARCHAR(1000) = NULL,
    @CreatedByUserID               INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @SubscriptionStatusCodeValueID IS NULL
    BEGIN
        SELECT @SubscriptionStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'BillingSubscriptionStatus' AND cv.CodeValue = N'ACTIVE';
    END;

    IF NOT EXISTS (SELECT 1 FROM party.Provider pr WHERE pr.ProviderID = @ProviderID AND pr.IsDeleted = 0)
        THROW 54001, 'Provider not found for subscription upsert.', 1;

    IF NOT EXISTS (SELECT 1 FROM billing.ProviderPlan pp WHERE pp.ProviderPlanID = @ProviderPlanID AND pp.IsDeleted = 0)
        THROW 54002, 'Provider plan not found for subscription upsert.', 1;

    IF @BillingProviderAccountID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM billing.BillingProviderAccount bpa
           WHERE bpa.BillingProviderAccountID = @BillingProviderAccountID
             AND (bpa.ProviderID IS NULL OR bpa.ProviderID = @ProviderID)
             AND bpa.IsDeleted = 0
       )
        THROW 54003, 'Billing provider account is invalid for this provider.', 1;

    BEGIN TRANSACTION;

    IF @ProviderSubscriptionID IS NULL
    BEGIN
        INSERT INTO billing.ProviderSubscription
        (
            ProviderID, ProviderPlanID, BillingProviderAccountID, SubscriptionStatusCodeValueID,
            SubscriptionStartUTC, SubscriptionEndUTC, NextBillingDateUTC, AutoRenewEnabled,
            BillingContactPersonID, Notes, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderID, @ProviderPlanID, @BillingProviderAccountID, @SubscriptionStatusCodeValueID,
            @SubscriptionStartUTC, @SubscriptionEndUTC, @NextBillingDateUTC, @AutoRenewEnabled,
            @BillingContactPersonID, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
        );
        SET @ProviderSubscriptionID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.ProviderSubscription
           SET ProviderPlanID = @ProviderPlanID,
               BillingProviderAccountID = @BillingProviderAccountID,
               SubscriptionStatusCodeValueID = @SubscriptionStatusCodeValueID,
               SubscriptionStartUTC = @SubscriptionStartUTC,
               SubscriptionEndUTC = @SubscriptionEndUTC,
               NextBillingDateUTC = @NextBillingDateUTC,
               AutoRenewEnabled = @AutoRenewEnabled,
               BillingContactPersonID = @BillingContactPersonID,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderSubscriptionID = @ProviderSubscriptionID
           AND ProviderID = @ProviderID
           AND IsDeleted = 0;
    END;

    COMMIT TRANSACTION;
    SELECT ProviderSubscriptionID = @ProviderSubscriptionID;
END;
GO
