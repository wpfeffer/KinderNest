CREATE OR ALTER PROCEDURE billing.usp_ProviderInvoice_GetDetail
    @ProviderInvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        pi.ProviderInvoiceID, pi.ProviderID, pr.ProviderName,
        pi.ProviderSubscriptionID, pi.BillingProviderAccountID,
        BillingProviderAccountDisplayName = bpa.DisplayName,
        pi.InvoiceNumber, InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        pi.BillingPeriodStartUTC, pi.BillingPeriodEndUTC, pi.IssuedUTC, pi.DueUTC,
        pi.SubtotalAmount, pi.TaxAmount, pi.TotalAmount, pi.BalanceAmount, pi.PaidUTC, pi.Notes
    FROM billing.ProviderInvoice pi
    INNER JOIN party.Provider pr ON pr.ProviderID = pi.ProviderID AND pr.IsDeleted = 0
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = pi.InvoiceStatusCodeValueID
    LEFT JOIN billing.BillingProviderAccount bpa ON bpa.BillingProviderAccountID = pi.BillingProviderAccountID AND bpa.IsDeleted = 0
    WHERE pi.ProviderInvoiceID = @ProviderInvoiceID AND pi.IsDeleted = 0;

    SELECT
        pil.ProviderInvoiceLineID, LineTypeCode = lt.CodeValue, LineTypeName = lt.CodeName,
        pil.Description, pil.QuantityDecimal, pil.UnitPriceAmount, pil.LineAmount,
        pil.ProviderUsageSnapshotID, pil.RelatedSiteID, RelatedSiteName = s.SiteName
    FROM billing.ProviderInvoiceLine pil
    INNER JOIN ref.CodeValue lt ON lt.CodeValueID = pil.LineTypeCodeValueID
    LEFT JOIN party.Site s ON s.SiteID = pil.RelatedSiteID AND s.IsDeleted = 0
    WHERE pil.ProviderInvoiceID = @ProviderInvoiceID AND pil.IsDeleted = 0
    ORDER BY pil.ProviderInvoiceLineID;

    SELECT
        p.PaymentID, PaymentStatusCode = pst.CodeValue, PaymentStatusName = pst.CodeName,
        PaymentScopeCode = psc.CodeValue, p.PaymentUTC, p.Amount, p.CurrencyCode,
        p.ProcessorFeeAmount, p.ExternalTransactionReference
    FROM billing.Payment p
    INNER JOIN ref.CodeValue pst ON pst.CodeValueID = p.PaymentStatusCodeValueID
    INNER JOIN ref.CodeValue psc ON psc.CodeValueID = p.PaymentScopeCodeValueID
    WHERE p.ProviderInvoiceID = @ProviderInvoiceID AND p.IsDeleted = 0
    ORDER BY p.PaymentUTC DESC, p.PaymentID DESC;
END;
GO
