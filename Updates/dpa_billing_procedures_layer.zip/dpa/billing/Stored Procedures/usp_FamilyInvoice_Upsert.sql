CREATE OR ALTER PROCEDURE billing.usp_FamilyInvoice_Upsert
    @FamilyInvoiceID            INT = NULL,
    @FamilyBillingAccountID     INT,
    @InvoiceStatusCodeValueID   INT = NULL,
    @InvoiceNumber              NVARCHAR(50) = NULL,
    @BillingPeriodStartUTC      DATETIME2(0),
    @BillingPeriodEndUTC        DATETIME2(0),
    @DueUTC                     DATETIME2(0) = NULL,
    @SentUTC                    DATETIME2(0) = NULL,
    @SubtotalAmount             DECIMAL(18,2) = 0.00,
    @TaxAmount                  DECIMAL(18,2) = 0.00,
    @TotalAmount                DECIMAL(18,2) = 0.00,
    @BalanceAmount              DECIMAL(18,2) = 0.00,
    @Notes                      NVARCHAR(1000) = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @HouseholdID INT;
    IF @InvoiceStatusCodeValueID IS NULL
    BEGIN
        SELECT @InvoiceStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'InvoiceStatus' AND cv.CodeValue = N'DRAFT';
    END;
    SELECT @HouseholdID = fba.HouseholdID
    FROM billing.FamilyBillingAccount fba
    WHERE fba.FamilyBillingAccountID = @FamilyBillingAccountID AND fba.IsDeleted = 0;
    IF NULLIF(@InvoiceNumber, N'') IS NULL
    BEGIN
        SET @InvoiceNumber = CONCAT(N'FINV-', @HouseholdID, N'-', CONVERT(NVARCHAR(8), CONVERT(DATE, SYSUTCDATETIME()), 112), N'-', RIGHT(CONVERT(NVARCHAR(20), ABS(CHECKSUM(NEWID()))), 6));
    END;

    BEGIN TRANSACTION;
    IF @FamilyInvoiceID IS NULL
    BEGIN
        INSERT INTO billing.FamilyInvoice
        (
            FamilyBillingAccountID, InvoiceStatusCodeValueID, InvoiceNumber,
            BillingPeriodStartUTC, BillingPeriodEndUTC, DueUTC, SentUTC,
            SubtotalAmount, TaxAmount, TotalAmount, BalanceAmount, Notes,
            IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @FamilyBillingAccountID, @InvoiceStatusCodeValueID, @InvoiceNumber,
            @BillingPeriodStartUTC, @BillingPeriodEndUTC, @DueUTC, @SentUTC,
            @SubtotalAmount, @TaxAmount, @TotalAmount, @BalanceAmount, NULLIF(@Notes, N''),
            1, 0, @CreatedByUserID
        );
        SET @FamilyInvoiceID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.FamilyInvoice
           SET InvoiceStatusCodeValueID = @InvoiceStatusCodeValueID,
               InvoiceNumber = @InvoiceNumber,
               BillingPeriodStartUTC = @BillingPeriodStartUTC,
               BillingPeriodEndUTC = @BillingPeriodEndUTC,
               DueUTC = @DueUTC,
               SentUTC = @SentUTC,
               SubtotalAmount = @SubtotalAmount,
               TaxAmount = @TaxAmount,
               TotalAmount = @TotalAmount,
               BalanceAmount = @BalanceAmount,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyInvoiceID = @FamilyInvoiceID
           AND FamilyBillingAccountID = @FamilyBillingAccountID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT FamilyInvoiceID = @FamilyInvoiceID, InvoiceNumber = @InvoiceNumber;
END;
GO
