CREATE OR ALTER PROCEDURE billing.usp_FamilyInvoiceLine_Upsert
    @FamilyInvoiceLineID        INT = NULL,
    @FamilyInvoiceID            INT,
    @FamilyChargeID             INT = NULL,
    @LineTypeCodeValueID        INT,
    @Description                NVARCHAR(500),
    @QuantityDecimal            DECIMAL(18,4),
    @UnitPriceAmount            DECIMAL(18,2),
    @LineAmount                 DECIMAL(18,2),
    @RelatedChildID             INT = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @CurrentSubtotal DECIMAL(18,2), @CurrentTax DECIMAL(18,2);
    BEGIN TRANSACTION;
    IF @FamilyInvoiceLineID IS NULL
    BEGIN
        INSERT INTO billing.FamilyInvoiceLine
        (
            FamilyInvoiceID, FamilyChargeID, LineTypeCodeValueID, Description,
            QuantityDecimal, UnitPriceAmount, LineAmount, RelatedChildID,
            IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @FamilyInvoiceID, @FamilyChargeID, @LineTypeCodeValueID, @Description,
            @QuantityDecimal, @UnitPriceAmount, @LineAmount, @RelatedChildID,
            1, 0, @CreatedByUserID
        );
        SET @FamilyInvoiceLineID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.FamilyInvoiceLine
           SET FamilyChargeID = @FamilyChargeID,
               LineTypeCodeValueID = @LineTypeCodeValueID,
               Description = @Description,
               QuantityDecimal = @QuantityDecimal,
               UnitPriceAmount = @UnitPriceAmount,
               LineAmount = @LineAmount,
               RelatedChildID = @RelatedChildID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyInvoiceLineID = @FamilyInvoiceLineID
           AND FamilyInvoiceID = @FamilyInvoiceID
           AND IsDeleted = 0;
    END;

    IF @FamilyChargeID IS NOT NULL
    BEGIN
        UPDATE billing.FamilyCharge
           SET FamilyInvoiceLineID = @FamilyInvoiceLineID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyChargeID = @FamilyChargeID
           AND IsDeleted = 0;
    END;

    SELECT @CurrentSubtotal = ISNULL(SUM(fil.LineAmount), 0.00)
    FROM billing.FamilyInvoiceLine fil
    WHERE fil.FamilyInvoiceID = @FamilyInvoiceID AND fil.IsDeleted = 0;

    SELECT @CurrentTax = fi.TaxAmount
    FROM billing.FamilyInvoice fi
    WHERE fi.FamilyInvoiceID = @FamilyInvoiceID AND fi.IsDeleted = 0;

    UPDATE billing.FamilyInvoice
       SET SubtotalAmount = @CurrentSubtotal,
           TotalAmount = @CurrentSubtotal + ISNULL(@CurrentTax, 0.00),
           BalanceAmount = @CurrentSubtotal + ISNULL(@CurrentTax, 0.00) -
                           ISNULL((SELECT SUM(p.Amount) FROM billing.Payment p WHERE p.FamilyInvoiceID = @FamilyInvoiceID AND p.IsDeleted = 0 AND p.IsActive = 1), 0.00),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @CreatedByUserID
     WHERE FamilyInvoiceID = @FamilyInvoiceID AND IsDeleted = 0;

    COMMIT TRANSACTION;
    SELECT FamilyInvoiceLineID = @FamilyInvoiceLineID;
END;
GO
