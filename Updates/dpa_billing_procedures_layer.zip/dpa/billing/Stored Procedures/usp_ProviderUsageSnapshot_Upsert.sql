CREATE OR ALTER PROCEDURE billing.usp_ProviderUsageSnapshot_Upsert
    @ProviderUsageSnapshotID     INT = NULL,
    @ProviderID                  INT,
    @SiteID                      INT = NULL,
    @ProviderSubscriptionID      INT = NULL,
    @UsageMetricTypeCodeValueID  INT,
    @MeasurementStartUTC         DATETIME2(0),
    @MeasurementEndUTC           DATETIME2(0),
    @QuantityDecimal             DECIMAL(18,4),
    @ByteCount                   BIGINT = NULL,
    @SourceProcedureName         NVARCHAR(200) = NULL,
    @IsBilled                    BIT = 0,
    @CreatedByUserID             INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    IF @ProviderUsageSnapshotID IS NULL
    BEGIN
        INSERT INTO billing.ProviderUsageSnapshot
        (
            ProviderID, SiteID, ProviderSubscriptionID, UsageMetricTypeCodeValueID,
            MeasurementStartUTC, MeasurementEndUTC, QuantityDecimal, ByteCount,
            SourceProcedureName, IsBilled, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderID, @SiteID, @ProviderSubscriptionID, @UsageMetricTypeCodeValueID,
            @MeasurementStartUTC, @MeasurementEndUTC, @QuantityDecimal, @ByteCount,
            NULLIF(@SourceProcedureName, N''), @IsBilled, 1, 0, @CreatedByUserID
        );
        SET @ProviderUsageSnapshotID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.ProviderUsageSnapshot
           SET SiteID = @SiteID,
               ProviderSubscriptionID = @ProviderSubscriptionID,
               UsageMetricTypeCodeValueID = @UsageMetricTypeCodeValueID,
               MeasurementStartUTC = @MeasurementStartUTC,
               MeasurementEndUTC = @MeasurementEndUTC,
               QuantityDecimal = @QuantityDecimal,
               ByteCount = @ByteCount,
               SourceProcedureName = NULLIF(@SourceProcedureName, N''),
               IsBilled = @IsBilled,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderUsageSnapshotID = @ProviderUsageSnapshotID
           AND ProviderID = @ProviderID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT ProviderUsageSnapshotID = @ProviderUsageSnapshotID;
END;
GO
