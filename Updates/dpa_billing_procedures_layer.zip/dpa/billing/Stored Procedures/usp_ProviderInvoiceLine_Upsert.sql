CREATE OR ALTER PROCEDURE billing.usp_ProviderInvoiceLine_Upsert
    @ProviderInvoiceLineID      INT = NULL,
    @ProviderInvoiceID          INT,
    @LineTypeCodeValueID        INT,
    @Description                NVARCHAR(500),
    @QuantityDecimal            DECIMAL(18,4),
    @UnitPriceAmount            DECIMAL(18,2),
    @LineAmount                 DECIMAL(18,2),
    @ProviderUsageSnapshotID    INT = NULL,
    @RelatedSiteID              INT = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @CurrentSubtotal DECIMAL(18,2), @CurrentTax DECIMAL(18,2);
    BEGIN TRANSACTION;
    IF @ProviderInvoiceLineID IS NULL
    BEGIN
        INSERT INTO billing.ProviderInvoiceLine
        (
            ProviderInvoiceID, LineTypeCodeValueID, Description, QuantityDecimal,
            UnitPriceAmount, LineAmount, ProviderUsageSnapshotID, RelatedSiteID,
            IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderInvoiceID, @LineTypeCodeValueID, @Description, @QuantityDecimal,
            @UnitPriceAmount, @LineAmount, @ProviderUsageSnapshotID, @RelatedSiteID,
            1, 0, @CreatedByUserID
        );
        SET @ProviderInvoiceLineID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.ProviderInvoiceLine
           SET LineTypeCodeValueID = @LineTypeCodeValueID,
               Description = @Description,
               QuantityDecimal = @QuantityDecimal,
               UnitPriceAmount = @UnitPriceAmount,
               LineAmount = @LineAmount,
               ProviderUsageSnapshotID = @ProviderUsageSnapshotID,
               RelatedSiteID = @RelatedSiteID,
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderInvoiceLineID = @ProviderInvoiceLineID
           AND ProviderInvoiceID = @ProviderInvoiceID
           AND IsDeleted = 0;
    END;

    SELECT @CurrentSubtotal = ISNULL(SUM(pil.LineAmount), 0.00)
    FROM billing.ProviderInvoiceLine pil
    WHERE pil.ProviderInvoiceID = @ProviderInvoiceID AND pil.IsDeleted = 0;

    SELECT @CurrentTax = pi.TaxAmount
    FROM billing.ProviderInvoice pi
    WHERE pi.ProviderInvoiceID = @ProviderInvoiceID AND pi.IsDeleted = 0;

    UPDATE billing.ProviderInvoice
       SET SubtotalAmount = @CurrentSubtotal,
           TotalAmount = @CurrentSubtotal + ISNULL(@CurrentTax, 0.00),
           BalanceAmount = @CurrentSubtotal + ISNULL(@CurrentTax, 0.00) -
                           ISNULL((SELECT SUM(p.Amount) FROM billing.Payment p WHERE p.ProviderInvoiceID = @ProviderInvoiceID AND p.IsDeleted = 0 AND p.IsActive = 1), 0.00),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @CreatedByUserID
     WHERE ProviderInvoiceID = @ProviderInvoiceID AND IsDeleted = 0;

    COMMIT TRANSACTION;
    SELECT ProviderInvoiceLineID = @ProviderInvoiceLineID;
END;
GO
