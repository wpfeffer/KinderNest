CREATE OR ALTER PROCEDURE billing.usp_ProviderInvoice_Upsert
    @ProviderInvoiceID          INT = NULL,
    @ProviderID                 INT,
    @ProviderSubscriptionID     INT = NULL,
    @BillingProviderAccountID   INT = NULL,
    @InvoiceStatusCodeValueID   INT = NULL,
    @InvoiceNumber              NVARCHAR(50) = NULL,
    @BillingPeriodStartUTC      DATETIME2(0),
    @BillingPeriodEndUTC        DATETIME2(0),
    @DueUTC                     DATETIME2(0) = NULL,
    @SubtotalAmount             DECIMAL(18,2) = 0.00,
    @TaxAmount                  DECIMAL(18,2) = 0.00,
    @TotalAmount                DECIMAL(18,2) = 0.00,
    @BalanceAmount              DECIMAL(18,2) = 0.00,
    @Notes                      NVARCHAR(1000) = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @InvoiceStatusCodeValueID IS NULL
    BEGIN
        SELECT @InvoiceStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'InvoiceStatus' AND cv.CodeValue = N'DRAFT';
    END;
    IF NULLIF(@InvoiceNumber, N'') IS NULL
    BEGIN
        SET @InvoiceNumber = CONCAT(N'PINV-', @ProviderID, N'-', CONVERT(NVARCHAR(8), CONVERT(DATE, SYSUTCDATETIME()), 112), N'-', RIGHT(CONVERT(NVARCHAR(20), ABS(CHECKSUM(NEWID()))), 6));
    END;
    BEGIN TRANSACTION;
    IF @ProviderInvoiceID IS NULL
    BEGIN
        INSERT INTO billing.ProviderInvoice
        (
            ProviderID, ProviderSubscriptionID, BillingProviderAccountID, InvoiceStatusCodeValueID,
            InvoiceNumber, BillingPeriodStartUTC, BillingPeriodEndUTC, DueUTC,
            SubtotalAmount, TaxAmount, TotalAmount, BalanceAmount, Notes,
            IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderID, @ProviderSubscriptionID, @BillingProviderAccountID, @InvoiceStatusCodeValueID,
            @InvoiceNumber, @BillingPeriodStartUTC, @BillingPeriodEndUTC, @DueUTC,
            @SubtotalAmount, @TaxAmount, @TotalAmount, @BalanceAmount, NULLIF(@Notes, N''),
            1, 0, @CreatedByUserID
        );
        SET @ProviderInvoiceID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.ProviderInvoice
           SET ProviderSubscriptionID = @ProviderSubscriptionID,
               BillingProviderAccountID = @BillingProviderAccountID,
               InvoiceStatusCodeValueID = @InvoiceStatusCodeValueID,
               InvoiceNumber = @InvoiceNumber,
               BillingPeriodStartUTC = @BillingPeriodStartUTC,
               BillingPeriodEndUTC = @BillingPeriodEndUTC,
               DueUTC = @DueUTC,
               SubtotalAmount = @SubtotalAmount,
               TaxAmount = @TaxAmount,
               TotalAmount = @TotalAmount,
               BalanceAmount = @BalanceAmount,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE ProviderInvoiceID = @ProviderInvoiceID
           AND ProviderID = @ProviderID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT ProviderInvoiceID = @ProviderInvoiceID, InvoiceNumber = @InvoiceNumber;
END;
GO
