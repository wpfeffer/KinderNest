CREATE OR ALTER PROCEDURE billing.usp_FamilyBillingAccount_GetByHousehold
    @HouseholdID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1)
        fba.FamilyBillingAccountID, fba.ProviderID, pr.ProviderName, fba.HouseholdID,
        h.HouseholdDisplayName, fba.SiteID, s.SiteName,
        AccountStatusCode = acs.CodeValue, AccountStatusName = acs.CodeName,
        BillingFrequencyCode = bf.CodeValue, BillingFrequencyName = bf.CodeName,
        fba.BillingDayOfMonth, fba.PrimaryBillingContactPersonID,
        BillingContactDisplayName = CASE WHEN p.PersonID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))) END,
        fba.BillingEmail, fba.CurrentBalanceAmount, fba.CreditLimitAmount, fba.LateFeeGraceDays,
        fba.Notes, fba.IsActive
    FROM billing.FamilyBillingAccount fba
    INNER JOIN party.Provider pr ON pr.ProviderID = fba.ProviderID AND pr.IsDeleted = 0
    INNER JOIN party.Household h ON h.HouseholdID = fba.HouseholdID AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue acs ON acs.CodeValueID = fba.AccountStatusCodeValueID
    INNER JOIN ref.CodeValue bf ON bf.CodeValueID = fba.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s ON s.SiteID = fba.SiteID AND s.IsDeleted = 0
    LEFT JOIN party.Person p ON p.PersonID = fba.PrimaryBillingContactPersonID AND p.IsDeleted = 0
    WHERE fba.HouseholdID = @HouseholdID AND fba.IsDeleted = 0
    ORDER BY fba.CreatedUTC DESC, fba.FamilyBillingAccountID DESC;

    SELECT TOP (25)
        fi.FamilyInvoiceID, fi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        fi.IssuedUTC, fi.DueUTC, fi.TotalAmount, fi.BalanceAmount
    FROM billing.FamilyInvoice fi
    INNER JOIN billing.FamilyBillingAccount fba
        ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID
       AND fba.HouseholdID = @HouseholdID AND fba.IsDeleted = 0
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = fi.InvoiceStatusCodeValueID
    WHERE fi.IsDeleted = 0
    ORDER BY fi.IssuedUTC DESC, fi.FamilyInvoiceID DESC;
END;
GO
