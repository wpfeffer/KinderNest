CREATE OR ALTER PROCEDURE billing.usp_ProviderInvoice_List
    @ProviderID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        pi.ProviderInvoiceID, pi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        pi.BillingPeriodStartUTC, pi.BillingPeriodEndUTC, pi.IssuedUTC, pi.DueUTC,
        pi.SubtotalAmount, pi.TaxAmount, pi.TotalAmount, pi.BalanceAmount,
        BillingProviderAccountDisplayName = bpa.DisplayName
    FROM billing.ProviderInvoice pi
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = pi.InvoiceStatusCodeValueID
    LEFT JOIN billing.BillingProviderAccount bpa ON bpa.BillingProviderAccountID = pi.BillingProviderAccountID AND bpa.IsDeleted = 0
    WHERE pi.ProviderID = @ProviderID AND pi.IsDeleted = 0
    ORDER BY pi.IssuedUTC DESC, pi.ProviderInvoiceID DESC;
END;
GO
