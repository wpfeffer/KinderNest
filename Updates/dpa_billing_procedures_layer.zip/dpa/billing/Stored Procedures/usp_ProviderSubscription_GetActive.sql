CREATE OR ALTER PROCEDURE billing.usp_ProviderSubscription_GetActive
    @ProviderID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1)
        ps.ProviderSubscriptionID, ps.ProviderID, pr.ProviderName,
        ps.ProviderPlanID, pp.PlanCode, pp.PlanName,
        ps.BillingProviderAccountID, bpa.DisplayName AS BillingProviderAccountDisplayName,
        SubscriptionStatusCode = ss.CodeValue, SubscriptionStatusName = ss.CodeName,
        BillingFrequencyCode = bf.CodeValue, BillingFrequencyName = bf.CodeName,
        ps.SubscriptionStartUTC, ps.SubscriptionEndUTC, ps.NextBillingDateUTC,
        ps.AutoRenewEnabled, ps.BillingContactPersonID,
        BillingContactDisplayName = CASE WHEN bc.PersonID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(bc.FirstName, N' ', bc.LastName))) END,
        pp.BasePriceAmount, pp.IncludedChildrenCount, pp.IncludedImageStorageBytes,
        pp.IncludedUsersCount, pp.OverageImageStoragePricePerGb, pp.OverageChildPriceAmount,
        ps.Notes, ps.IsActive
    FROM billing.ProviderSubscription ps
    INNER JOIN party.Provider pr ON pr.ProviderID = ps.ProviderID AND pr.IsDeleted = 0
    INNER JOIN billing.ProviderPlan pp ON pp.ProviderPlanID = ps.ProviderPlanID AND pp.IsDeleted = 0
    INNER JOIN ref.CodeValue ss ON ss.CodeValueID = ps.SubscriptionStatusCodeValueID
    INNER JOIN ref.CodeValue bf ON bf.CodeValueID = pp.BillingFrequencyCodeValueID
    LEFT JOIN billing.BillingProviderAccount bpa ON bpa.BillingProviderAccountID = ps.BillingProviderAccountID AND bpa.IsDeleted = 0
    LEFT JOIN party.Person bc ON bc.PersonID = ps.BillingContactPersonID AND bc.IsDeleted = 0
    WHERE ps.ProviderID = @ProviderID AND ps.IsDeleted = 0 AND ps.IsActive = 1
    ORDER BY ps.SubscriptionStartUTC DESC, ps.ProviderSubscriptionID DESC;

    SELECT TOP (12)
        pus.ProviderUsageSnapshotID, MetricCode = mt.CodeValue, MetricName = mt.CodeName,
        pus.MeasurementStartUTC, pus.MeasurementEndUTC, pus.QuantityDecimal, pus.ByteCount,
        pus.IsBilled, pus.CreatedUTC
    FROM billing.ProviderUsageSnapshot pus
    INNER JOIN ref.CodeValue mt ON mt.CodeValueID = pus.UsageMetricTypeCodeValueID
    WHERE pus.ProviderID = @ProviderID AND pus.IsDeleted = 0 AND pus.IsActive = 1
    ORDER BY pus.MeasurementEndUTC DESC, pus.ProviderUsageSnapshotID DESC;

    SELECT TOP (12)
        pi.ProviderInvoiceID, pi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue, InvoiceStatusName = ist.CodeName,
        pi.BillingPeriodStartUTC, pi.BillingPeriodEndUTC, pi.IssuedUTC, pi.DueUTC,
        pi.TotalAmount, pi.BalanceAmount
    FROM billing.ProviderInvoice pi
    INNER JOIN ref.CodeValue ist ON ist.CodeValueID = pi.InvoiceStatusCodeValueID
    WHERE pi.ProviderID = @ProviderID AND pi.IsDeleted = 0 AND pi.IsActive = 1
    ORDER BY pi.IssuedUTC DESC, pi.ProviderInvoiceID DESC;
END;
GO
