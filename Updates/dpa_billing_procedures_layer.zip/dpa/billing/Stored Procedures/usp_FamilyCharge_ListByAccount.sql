CREATE OR ALTER PROCEDURE billing.usp_FamilyCharge_ListByAccount
    @FamilyBillingAccountID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        fc.FamilyChargeID, ChargeTypeCode = ctc.CodeValue, ChargeTypeName = ctc.CodeName,
        ChargeStatusCode = csc.CodeValue, ChargeStatusName = csc.CodeName,
        fc.ServiceDate, fc.Description, fc.QuantityDecimal, fc.UnitPriceAmount,
        fc.ChargeAmount, fc.TaxAmount, fc.DiscountAmount, fc.FamilyInvoiceLineID,
        fc.ChildID,
        ChildDisplayName = CASE WHEN ch.ChildID IS NULL THEN NULL ELSE LTRIM(RTRIM(CONCAT(ch.FirstName, N' ', ch.LastName))) END,
        fc.Notes
    FROM billing.FamilyCharge fc
    INNER JOIN ref.CodeValue ctc ON ctc.CodeValueID = fc.ChargeTypeCodeValueID
    INNER JOIN ref.CodeValue csc ON csc.CodeValueID = fc.ChargeStatusCodeValueID
    LEFT JOIN child.Child ch ON ch.ChildID = fc.ChildID AND ch.IsDeleted = 0
    WHERE fc.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fc.IsDeleted = 0
    ORDER BY fc.ServiceDate DESC, fc.FamilyChargeID DESC;
END;
GO
