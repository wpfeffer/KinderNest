CREATE OR ALTER PROCEDURE billing.usp_FamilyBillingAccount_Upsert
    @FamilyBillingAccountID           INT = NULL,
    @ProviderID                       INT,
    @HouseholdID                      INT,
    @SiteID                           INT = NULL,
    @AccountStatusCodeValueID         INT = NULL,
    @BillingFrequencyCodeValueID      INT = NULL,
    @BillingDayOfMonth                TINYINT = NULL,
    @PrimaryBillingContactPersonID    INT = NULL,
    @BillingEmail                     NVARCHAR(320) = NULL,
    @CurrentBalanceAmount             DECIMAL(18,2) = 0.00,
    @CreditLimitAmount                DECIMAL(18,2) = NULL,
    @LateFeeGraceDays                 INT = NULL,
    @Notes                            NVARCHAR(1000) = NULL,
    @CreatedByUserID                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @HouseholdProviderID INT;
    SELECT @HouseholdProviderID = h.ProviderID
    FROM party.Household h
    WHERE h.HouseholdID = @HouseholdID AND h.IsDeleted = 0;
    IF @HouseholdProviderID IS NULL OR @HouseholdProviderID <> @ProviderID
        THROW 54101, 'Household does not belong to the specified provider.', 1;
    IF @AccountStatusCodeValueID IS NULL
    BEGIN
        SELECT @AccountStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'FamilyBillingAccountStatus' AND cv.CodeValue = N'ACTIVE';
    END;
    IF @BillingFrequencyCodeValueID IS NULL
    BEGIN
        SELECT @BillingFrequencyCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'BillingFrequency' AND cv.CodeValue = N'MONTHLY';
    END;

    BEGIN TRANSACTION;
    IF @FamilyBillingAccountID IS NULL
    BEGIN
        INSERT INTO billing.FamilyBillingAccount
        (
            ProviderID, HouseholdID, SiteID, AccountStatusCodeValueID, BillingFrequencyCodeValueID,
            BillingDayOfMonth, PrimaryBillingContactPersonID, BillingEmail, CurrentBalanceAmount,
            CreditLimitAmount, LateFeeGraceDays, Notes, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @ProviderID, @HouseholdID, @SiteID, @AccountStatusCodeValueID, @BillingFrequencyCodeValueID,
            @BillingDayOfMonth, @PrimaryBillingContactPersonID, NULLIF(@BillingEmail, N''), @CurrentBalanceAmount,
            @CreditLimitAmount, @LateFeeGraceDays, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
        );
        SET @FamilyBillingAccountID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.FamilyBillingAccount
           SET SiteID = @SiteID,
               AccountStatusCodeValueID = @AccountStatusCodeValueID,
               BillingFrequencyCodeValueID = @BillingFrequencyCodeValueID,
               BillingDayOfMonth = @BillingDayOfMonth,
               PrimaryBillingContactPersonID = @PrimaryBillingContactPersonID,
               BillingEmail = NULLIF(@BillingEmail, N''),
               CurrentBalanceAmount = @CurrentBalanceAmount,
               CreditLimitAmount = @CreditLimitAmount,
               LateFeeGraceDays = @LateFeeGraceDays,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyBillingAccountID = @FamilyBillingAccountID
           AND ProviderID = @ProviderID
           AND HouseholdID = @HouseholdID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT FamilyBillingAccountID = @FamilyBillingAccountID;
END;
GO
