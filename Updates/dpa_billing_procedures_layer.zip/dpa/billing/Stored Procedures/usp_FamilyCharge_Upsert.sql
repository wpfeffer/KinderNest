CREATE OR ALTER PROCEDURE billing.usp_FamilyCharge_Upsert
    @FamilyChargeID             INT = NULL,
    @FamilyBillingAccountID     INT,
    @ChildID                    INT = NULL,
    @ChargeTypeCodeValueID      INT,
    @ChargeStatusCodeValueID    INT = NULL,
    @ServiceDate                DATE,
    @Description                NVARCHAR(500),
    @QuantityDecimal            DECIMAL(18,4),
    @UnitPriceAmount            DECIMAL(18,2),
    @ChargeAmount               DECIMAL(18,2),
    @TaxAmount                  DECIMAL(18,2) = 0.00,
    @DiscountAmount             DECIMAL(18,2) = 0.00,
    @Notes                      NVARCHAR(1000) = NULL,
    @CreatedByUserID            INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @ChargeStatusCodeValueID IS NULL
    BEGIN
        SELECT @ChargeStatusCodeValueID = cv.CodeValueID
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'FamilyChargeStatus' AND cv.CodeValue = N'PENDING';
    END;
    BEGIN TRANSACTION;
    IF @FamilyChargeID IS NULL
    BEGIN
        INSERT INTO billing.FamilyCharge
        (
            FamilyBillingAccountID, ChildID, ChargeTypeCodeValueID, ChargeStatusCodeValueID,
            ServiceDate, Description, QuantityDecimal, UnitPriceAmount, ChargeAmount, TaxAmount,
            DiscountAmount, Notes, IsActive, IsDeleted, CreatedByUserID
        )
        VALUES
        (
            @FamilyBillingAccountID, @ChildID, @ChargeTypeCodeValueID, @ChargeStatusCodeValueID,
            @ServiceDate, @Description, @QuantityDecimal, @UnitPriceAmount, @ChargeAmount, @TaxAmount,
            @DiscountAmount, NULLIF(@Notes, N''), 1, 0, @CreatedByUserID
        );
        SET @FamilyChargeID = CONVERT(INT, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE billing.FamilyCharge
           SET ChildID = @ChildID,
               ChargeTypeCodeValueID = @ChargeTypeCodeValueID,
               ChargeStatusCodeValueID = @ChargeStatusCodeValueID,
               ServiceDate = @ServiceDate,
               Description = @Description,
               QuantityDecimal = @QuantityDecimal,
               UnitPriceAmount = @UnitPriceAmount,
               ChargeAmount = @ChargeAmount,
               TaxAmount = @TaxAmount,
               DiscountAmount = @DiscountAmount,
               Notes = NULLIF(@Notes, N''),
               ModifiedUTC = SYSUTCDATETIME(),
               ModifiedByUserID = @CreatedByUserID
         WHERE FamilyChargeID = @FamilyChargeID
           AND FamilyBillingAccountID = @FamilyBillingAccountID
           AND IsDeleted = 0;
    END;
    COMMIT TRANSACTION;
    SELECT FamilyChargeID = @FamilyChargeID;
END;
GO
