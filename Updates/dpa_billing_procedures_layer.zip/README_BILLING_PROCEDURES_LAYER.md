This pack writes the next billing layer on top of the billing schema foundation.

Scope covered:
- provider plan/subscription reads and upserts
- provider usage snapshot upsert
- provider invoice list/detail/upsert
- provider invoice line upsert
- provider payment record
- family billing account read/upsert
- provider rate schedule list/upsert
- family rate assignment upsert
- family charge list/upsert
- family invoice list/detail/upsert
- family invoice line upsert
- family payment record

Important:
- all procedures are CREATE OR ALTER
- this assumes the billing schema foundation has already been applied
- this is still database/service layer work, not the billing UI layer
- payment procs record payment rows and update invoice/account balances, but they do not call external processors or webhooks
