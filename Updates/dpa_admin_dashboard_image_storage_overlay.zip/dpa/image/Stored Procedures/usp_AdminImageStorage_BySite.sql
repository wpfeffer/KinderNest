CREATE OR ALTER PROCEDURE image.usp_AdminImageStorage_BySite
    @WarningThresholdBytes BIGINT = 5368709120,
    @BillingThresholdBytes BIGINT = 21474836480
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        s.SiteID,
        s.ProviderID,
        pr.ProviderName,
        s.SiteName,
        ActiveImageCount = COUNT(ia.ImageAssetID),
        HeadshotImageCount = SUM(CASE WHEN ia.ImageCategoryCode IN (N'CHILD_HEADSHOT', N'PERSON_HEADSHOT') THEN 1 ELSE 0 END),
        DiaryImageCount = SUM(CASE WHEN ia.ImageCategoryCode = N'CHILD_DIARY' THEN 1 ELSE 0 END),
        EncryptedFileBytes = SUM(ISNULL(ia.EncryptedFileLengthBytes, 0)),
        EncryptedThumbnailBytes = SUM(ISNULL(ia.EncryptedThumbnailLengthBytes, 0)),
        TotalBytes = SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)),
        TotalMegabytes = CAST(SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)) / 1048576.0 AS DECIMAL(18, 2)),
        WarningThresholdBytes = @WarningThresholdBytes,
        BillingThresholdBytes = @BillingThresholdBytes,
        IsOverWarningThreshold = CAST(CASE
            WHEN SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)) >= @WarningThresholdBytes THEN 1
            ELSE 0
        END AS bit),
        IsOverBillingThreshold = CAST(CASE
            WHEN SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)) >= @BillingThresholdBytes THEN 1
            ELSE 0
        END AS bit)
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN image.ImageAsset ia
        ON ia.SiteID = s.SiteID
       AND ia.IsDeleted = 0
       AND ia.IsActive = 1
    WHERE s.IsDeleted = 0
      AND s.IsActive = 1
    GROUP BY
        s.SiteID,
        s.ProviderID,
        pr.ProviderName,
        s.SiteName
    ORDER BY
        SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)) DESC,
        pr.ProviderName,
        s.SiteName,
        s.SiteID;
END;
GO
