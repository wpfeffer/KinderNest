CREATE OR ALTER PROCEDURE ops.usp_AdminDashboard_GetSummary
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER',
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ImageStorageWarningThresholdBytes BIGINT = 5368709120,
    @ImageStorageBillingThresholdBytes BIGINT = 21474836480
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @FailureResultCodeValueID INT;
    DECLARE @BlockedResultCodeValueID INT;
    DECLARE @LockedCredentialStatusCodeValueID INT;

    SELECT @FailureResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'FAILURE'
      AND cv.IsActive = 1;

    SELECT @BlockedResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'BLOCKED'
      AND cv.IsActive = 1;

    SELECT @LockedCredentialStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    ),
    ImageSiteRollup AS
    (
        SELECT
            s.SiteID,
            TotalBytes = SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0)),
            ActiveImageCount = COUNT(ia.ImageAssetID)
        FROM party.Site s
        LEFT JOIN image.ImageAsset ia
            ON ia.SiteID = s.SiteID
           AND ia.IsDeleted = 0
           AND ia.IsActive = 1
        WHERE s.IsDeleted = 0
          AND s.IsActive = 1
        GROUP BY s.SiteID
    )
    SELECT
        PendingProviderApprovals =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
              AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
        ),
        ActiveProviders =
        (
            SELECT COUNT(1)
            FROM party.Provider pr
            WHERE pr.IsActive = 1
              AND pr.IsDeleted = 0
        ),
        ActiveSites =
        (
            SELECT COUNT(1)
            FROM party.Site s
            WHERE s.IsActive = 1
              AND s.IsDeleted = 0
        ),
        ActiveUsers =
        (
            SELECT COUNT(1)
            FROM party.PortalUser pu
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
        ),
        LockedAccounts =
        (
            SELECT COUNT(1)
            FROM sec.PortalCredential pc
            WHERE pc.IsActive = 1
              AND pc.IsDeleted = 0
              AND (
                    (@LockedCredentialStatusCodeValueID IS NOT NULL AND pc.CredentialStatusCodeValueID = @LockedCredentialStatusCodeValueID)
                    OR (pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME())
                  )
        ),
        FailedLoginsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuthenticationEvent ae
            WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
              AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
        ),
        RecentRegistrationsLast7Days =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsDeleted = 0
              AND pu.CreatedUTC >= DATEADD(DAY, -7, SYSUTCDATETIME())
        ),
        AuditEventsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuditLog al
            WHERE al.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
        ),
        TotalActiveImages =
        (
            SELECT ISNULL(SUM(isr.ActiveImageCount), 0)
            FROM ImageSiteRollup isr
        ),
        TotalImageStorageBytes =
        (
            SELECT ISNULL(SUM(isr.TotalBytes), 0)
            FROM ImageSiteRollup isr
        ),
        SitesWithImages =
        (
            SELECT COUNT(1)
            FROM ImageSiteRollup isr
            WHERE isr.ActiveImageCount > 0
        ),
        SitesOverImageStorageWarningThreshold =
        (
            SELECT COUNT(1)
            FROM ImageSiteRollup isr
            WHERE isr.TotalBytes >= @ImageStorageWarningThresholdBytes
        ),
        SitesOverImageStorageBillingThreshold =
        (
            SELECT COUNT(1)
            FROM ImageSiteRollup isr
            WHERE isr.TotalBytes >= @ImageStorageBillingThresholdBytes
        );

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    )
    SELECT TOP (10)
        pu.PortalUserID,
        reg.ProviderID,
        reg.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        pu.UserName,
        PrimaryEmail = ISNULL(p.PrimaryEmail, N''),
        ProviderName = ISNULL(reg.ProviderName, N''),
        reg.BusinessEmail,
        SiteName = ISNULL(reg.SiteName, N''),
        reg.LicenseNumber,
        LicenseClassCode = ISNULL(reg.LicenseClassCode, N''),
        LicenseClassName = ISNULL(reg.LicenseClassName, N''),
        pu.AccountStatusCode
    FROM ProviderOwnerUsers pou
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = pou.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    OUTER APPLY
    (
        SELECT TOP (1)
            s.SiteID,
            pr.ProviderID,
            pr.ProviderName,
            pr.BusinessEmail,
            s.SiteName,
            s.LicenseNumber,
            lc.LicenseClassCode,
            lc.LicenseClassName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
        INNER JOIN party.Provider pr
            ON pr.ProviderID = s.ProviderID
           AND pr.IsDeleted = 0
        INNER JOIN lic.LicenseClass lc
            ON lc.LicenseClassID = s.LicenseClassID
        WHERE sua.PortalUserID = pu.PortalUserID
          AND sua.IsActive = 1
        ORDER BY sua.IsPrimaryProviderContact DESC,
                 sua.EffectiveStartUTC DESC,
                 sua.SiteUserAssignmentID DESC
    ) reg
    ORDER BY pu.CreatedUTC DESC,
             pu.PortalUserID DESC;

    SELECT TOP (10)
        ae.AuthenticationEventID,
        ae.EventUTC,
        UserNameAttempted = COALESCE(ae.UserNameAttempted, pu.UserName, N''),
        AuthenticationEventTypeCode = et.CodeValue,
        AuthenticationResultCode = ar.CodeValue,
        ae.FailureReason,
        ae.RemoteAddress,
        SiteName = s.SiteName
    FROM audit.AuthenticationEvent ae
    LEFT JOIN party.PortalUser pu
        ON pu.PortalUserID = ae.PortalUserID
    LEFT JOIN ref.CodeValue et
        ON et.CodeValueID = ae.AuthenticationEventTypeCodeValueID
    LEFT JOIN ref.CodeValue ar
        ON ar.CodeValueID = ae.AuthenticationResultCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = ae.SiteID
    WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
      AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
    ORDER BY ae.EventUTC DESC,
             ae.AuthenticationEventID DESC;

    SELECT TOP (10)
        al.AuditLogID,
        al.EventUTC,
        al.SchemaName,
        al.TableName,
        al.ActionTypeCode,
        ActorUserName = actor.UserName,
        al.RecordPrimaryKeyValue,
        al.ReasonText,
        al.SucceededFlag
    FROM audit.AuditLog al
    LEFT JOIN party.PortalUser actor
        ON actor.PortalUserID = al.ChangedByUserID
    ORDER BY al.EventUTC DESC,
             al.AuditLogID DESC;

    EXEC image.usp_AdminImageStorage_BySite
        @WarningThresholdBytes = @ImageStorageWarningThresholdBytes,
        @BillingThresholdBytes = @ImageStorageBillingThresholdBytes;
END;
GO
