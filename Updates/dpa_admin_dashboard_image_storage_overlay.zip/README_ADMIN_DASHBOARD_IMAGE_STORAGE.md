This overlay adds image storage telemetry to the admin dashboard.

Included database changes:
- new procedure: image.usp_AdminImageStorage_BySite
- updated procedure: ops.usp_AdminDashboard_GetSummary

Included web changes:
- updated AdminDashboardCountsDto
- new AdminImageStorageSiteDto
- updated AdminDashboardSummaryDto
- updated AdminDashboardService to read the new dashboard result set
- updated AdminPortal.razor to render storage stats and per-site image storage usage

Threshold behavior:
- warning threshold default: 5 GB
- billing threshold default: 20 GB

These thresholds are metering only. They do not implement billing. They only expose the operational data you said you want on the admin dashboard before deciding whether to charge for storage later.
