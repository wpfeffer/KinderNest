using System.Data;
using DaycareProviderAssistant.Admin.Models;
using DaycareProviderAssistant.Auth.Services;
using Microsoft.Data.SqlClient;

namespace DaycareProviderAssistant.Admin.Services;

public sealed class AdminDashboardService : IAdminDashboardService
{
    private const string DashboardSummaryProcedure = "ops.usp_AdminDashboard_GetSummary";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<AdminDashboardService> _logger;

    public AdminDashboardService(
        ISqlConnectionFactory connectionFactory,
        ILogger<AdminDashboardService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<AdminDashboardSummaryDto> GetSummaryAsync(CancellationToken cancellationToken = default)
    {
        var registrations = new List<RecentProviderRegistrationDto>();
        var failedLogins = new List<RecentFailedLoginDto>();
        var auditEvents = new List<RecentAuditEventDto>();
        var imageStorageBySite = new List<AdminImageStorageSiteDto>();
        var counts = new AdminDashboardCountsDto();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = DashboardSummaryProcedure;

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (await reader.ReadAsync(cancellationToken))
            {
                counts = new AdminDashboardCountsDto
                {
                    PendingProviderApprovals = GetInt32(reader, "PendingProviderApprovals"),
                    ActiveProviders = GetInt32(reader, "ActiveProviders"),
                    ActiveSites = GetInt32(reader, "ActiveSites"),
                    ActiveUsers = GetInt32(reader, "ActiveUsers"),
                    LockedAccounts = GetInt32(reader, "LockedAccounts"),
                    FailedLoginsLast24Hours = GetInt32(reader, "FailedLoginsLast24Hours"),
                    RecentRegistrationsLast7Days = GetInt32(reader, "RecentRegistrationsLast7Days"),
                    AuditEventsLast24Hours = GetInt32(reader, "AuditEventsLast24Hours"),
                    TotalActiveImages = GetInt32(reader, "TotalActiveImages"),
                    TotalImageStorageBytes = GetInt64(reader, "TotalImageStorageBytes"),
                    SitesWithImages = GetInt32(reader, "SitesWithImages"),
                    SitesOverImageStorageWarningThreshold = GetInt32(reader, "SitesOverImageStorageWarningThreshold"),
                    SitesOverImageStorageBillingThreshold = GetInt32(reader, "SitesOverImageStorageBillingThreshold")
                };
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    registrations.Add(new RecentProviderRegistrationDto
                    {
                        PortalUserId = GetInt32(reader, "PortalUserID"),
                        ProviderId = GetNullableInt32(reader, "ProviderID"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SubmittedUtc = GetDateTime(reader, "SubmittedUTC"),
                        RegistrantDisplayName = GetString(reader, "RegistrantDisplayName"),
                        UserName = GetString(reader, "UserName"),
                        PrimaryEmail = GetString(reader, "PrimaryEmail"),
                        ProviderName = GetString(reader, "ProviderName"),
                        BusinessEmail = GetNullableString(reader, "BusinessEmail"),
                        SiteName = GetString(reader, "SiteName"),
                        LicenseNumber = GetNullableString(reader, "LicenseNumber"),
                        LicenseClassCode = GetString(reader, "LicenseClassCode"),
                        LicenseClassName = GetString(reader, "LicenseClassName"),
                        AccountStatusCode = GetString(reader, "AccountStatusCode")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    failedLogins.Add(new RecentFailedLoginDto
                    {
                        AuthenticationEventId = GetInt64(reader, "AuthenticationEventID"),
                        EventUtc = GetDateTime(reader, "EventUTC"),
                        UserNameAttempted = GetString(reader, "UserNameAttempted"),
                        AuthenticationEventTypeCode = GetString(reader, "AuthenticationEventTypeCode"),
                        AuthenticationResultCode = GetString(reader, "AuthenticationResultCode"),
                        FailureReason = GetNullableString(reader, "FailureReason"),
                        RemoteAddress = GetNullableString(reader, "RemoteAddress"),
                        SiteName = GetNullableString(reader, "SiteName")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    auditEvents.Add(new RecentAuditEventDto
                    {
                        AuditLogId = GetInt64(reader, "AuditLogID"),
                        EventUtc = GetDateTime(reader, "EventUTC"),
                        SchemaName = GetString(reader, "SchemaName"),
                        TableName = GetString(reader, "TableName"),
                        ActionTypeCode = GetString(reader, "ActionTypeCode"),
                        ActorUserName = GetNullableString(reader, "ActorUserName"),
                        RecordPrimaryKeyValue = GetString(reader, "RecordPrimaryKeyValue"),
                        ReasonText = GetNullableString(reader, "ReasonText"),
                        SucceededFlag = GetBoolean(reader, "SucceededFlag")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    imageStorageBySite.Add(new AdminImageStorageSiteDto
                    {
                        SiteId = GetInt32(reader, "SiteID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        SiteName = GetString(reader, "SiteName"),
                        ActiveImageCount = GetInt32(reader, "ActiveImageCount"),
                        HeadshotImageCount = GetInt32(reader, "HeadshotImageCount"),
                        DiaryImageCount = GetInt32(reader, "DiaryImageCount"),
                        EncryptedFileBytes = GetInt64(reader, "EncryptedFileBytes"),
                        EncryptedThumbnailBytes = GetInt64(reader, "EncryptedThumbnailBytes"),
                        TotalBytes = GetInt64(reader, "TotalBytes"),
                        TotalMegabytes = GetDecimal(reader, "TotalMegabytes"),
                        WarningThresholdBytes = GetInt64(reader, "WarningThresholdBytes"),
                        BillingThresholdBytes = GetInt64(reader, "BillingThresholdBytes"),
                        IsOverWarningThreshold = GetBoolean(reader, "IsOverWarningThreshold"),
                        IsOverBillingThreshold = GetBoolean(reader, "IsOverBillingThreshold")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Admin dashboard summary failed while executing {ProcedureName}.", DashboardSummaryProcedure);
            throw;
        }

        return new AdminDashboardSummaryDto
        {
            Counts = counts,
            RecentRegistrations = registrations,
            RecentFailedLogins = failedLogins,
            RecentAuditEvents = auditEvents,
            ImageStorageBySite = imageStorageBySite
        };
    }

    private static int GetInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
    }

    private static int? GetNullableInt32(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    private static long GetInt64(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0L : reader.GetInt64(ordinal);
    }

    private static decimal GetDecimal(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? 0m : reader.GetDecimal(ordinal);
    }

    private static string GetString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
    }

    private static string? GetNullableString(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static DateTime GetDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? DateTime.MinValue : reader.GetDateTime(ordinal);
    }

    private static bool GetBoolean(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return !reader.IsDBNull(ordinal) && reader.GetBoolean(ordinal);
    }
}
