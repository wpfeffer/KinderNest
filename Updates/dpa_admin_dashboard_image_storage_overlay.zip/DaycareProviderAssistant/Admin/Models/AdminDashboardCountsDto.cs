namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminDashboardCountsDto
{
    public int PendingProviderApprovals { get; init; }
    public int ActiveProviders { get; init; }
    public int ActiveSites { get; init; }
    public int ActiveUsers { get; init; }
    public int LockedAccounts { get; init; }
    public int FailedLoginsLast24Hours { get; init; }
    public int RecentRegistrationsLast7Days { get; init; }
    public int AuditEventsLast24Hours { get; init; }
    public int TotalActiveImages { get; init; }
    public long TotalImageStorageBytes { get; init; }
    public int SitesWithImages { get; init; }
    public int SitesOverImageStorageWarningThreshold { get; init; }
    public int SitesOverImageStorageBillingThreshold { get; init; }
}
