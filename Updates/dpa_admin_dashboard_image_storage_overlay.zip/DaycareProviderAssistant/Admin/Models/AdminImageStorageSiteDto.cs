namespace DaycareProviderAssistant.Admin.Models;

public sealed class AdminImageStorageSiteDto
{
    public int SiteId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
    public int ActiveImageCount { get; init; }
    public int HeadshotImageCount { get; init; }
    public int DiaryImageCount { get; init; }
    public long EncryptedFileBytes { get; init; }
    public long EncryptedThumbnailBytes { get; init; }
    public long TotalBytes { get; init; }
    public decimal TotalMegabytes { get; init; }
    public long WarningThresholdBytes { get; init; }
    public long BillingThresholdBytes { get; init; }
    public bool IsOverWarningThreshold { get; init; }
    public bool IsOverBillingThreshold { get; init; }
}
