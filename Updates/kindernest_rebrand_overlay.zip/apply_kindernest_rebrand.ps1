param(
    [string]$RepoRoot = ".",
    [switch]$FullRename,
    [switch]$RenameDatabase
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path $RepoRoot).Path

$excludeDirs = @(".git",".vs","bin","obj","images","node_modules","packages","TestResults",".idea",".vscode")
$exts = @(".cs",".razor",".cshtml",".json",".sql",".sqlproj",".csproj",".sln",".slnx",".md",".txt",".ps1",".cmd",".bat",".xml",".config",".css",".js",".ts",".html",".yml",".yaml",".props",".targets",".editorconfig",".gitignore")

function IsExcluded($path) {
    $relative = $path.Substring($root.Length).TrimStart('\','/')
    $parts = $relative.Split([char[]]@('\','/'), [System.StringSplitOptions]::RemoveEmptyEntries)
    foreach ($part in $parts) {
        if ($excludeDirs -contains $part) { return $true }
    }
    return $false
}

function TextFiles {
    Get-ChildItem -LiteralPath $root -Recurse -File |
        Where-Object { -not (IsExcluded $_.FullName) -and ($exts -contains $_.Extension.ToLowerInvariant()) }
}

$pairs = @(
    @("https://www.dpachild.com","https://kindernest.kids"),
    @("http://www.dpachild.com","https://kindernest.kids"),
    @("https://dpachild.com","https://kindernest.kids"),
    @("http://dpachild.com","https://kindernest.kids"),
    @("www.dpachild.com","kindernest.kids"),
    @("dpachild.com","kindernest.kids"),
    @("Daycare Provider Assistant","Kinder Nest"),
    @("DAYCARE PROVIDER ASSISTANT","KINDER NEST"),
    @("daycare provider assistant","kinder nest"),
    @("DaycareProviderAssistant","KinderNest"),
    @("DAYCAREPROVIDERASSISTANT","KINDERNEST"),
    @("DPA","KN"),
    @("Dpa","Kn"),
    @("dpa_","kn_")
)

if ($RenameDatabase) {
    $pairs += @(
        @("Database=dpa;","Database=kn;"),
        @("Database=dpa","Database=kn"),
        @("[dpa]","[kn]"),
        @("`"dpa`"","`"kn`""),
        @("'dpa'","'kn'")
    )
}

$changed = New-Object System.Collections.Generic.List[string]

foreach ($file in TextFiles) {
    $content = Get-Content -LiteralPath $file.FullName -Raw
    $updated = $content
    foreach ($pair in $pairs) {
        $updated = $updated.Replace($pair[0], $pair[1])
    }
    if ($updated -ne $content) {
        Set-Content -LiteralPath $file.FullName -Value $updated -Encoding UTF8
        $changed.Add($file.FullName.Substring($root.Length).TrimStart('\','/'))
    }
}

# Make the web assembly/root namespace KinderNest without requiring an immediate folder rename.
$csprojCandidates = @(
    "DaycareProviderAssistant\DaycareProviderAssistant.csproj",
    "DaycareProviderAssistant\KinderNest.csproj",
    "KinderNest\KinderNest.csproj"
)
foreach ($candidate in $csprojCandidates) {
    $csprojPath = Join-Path $root $candidate
    if (Test-Path -LiteralPath $csprojPath) {
        $csproj = Get-Content -LiteralPath $csprojPath -Raw
        if ($csproj -notmatch "<RootNamespace>") {
            $csproj = $csproj.Replace("<Nullable>enable</Nullable>", "<Nullable>enable</Nullable>`r`n    <RootNamespace>KinderNest</RootNamespace>")
        }
        if ($csproj -notmatch "<AssemblyName>") {
            $csproj = $csproj.Replace("<RootNamespace>KinderNest</RootNamespace>", "<RootNamespace>KinderNest</RootNamespace>`r`n    <AssemblyName>KinderNest</AssemblyName>")
        }
        Set-Content -LiteralPath $csprojPath -Value $csproj -Encoding UTF8
        $changed.Add($candidate)
    }
}

if ($FullRename) {
    function RenameIfExists($oldRel, $newRel) {
        $oldPath = Join-Path $root $oldRel
        $newPath = Join-Path $root $newRel
        if (Test-Path -LiteralPath $oldPath) {
            $parent = Split-Path -Parent $newPath
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent | Out-Null }
            if (-not (Test-Path -LiteralPath $newPath)) {
                Move-Item -LiteralPath $oldPath -Destination $newPath
                Write-Host "Renamed $oldRel -> $newRel"
            }
        }
    }

    RenameIfExists "DaycareProviderAssistant\DaycareProviderAssistant.csproj" "DaycareProviderAssistant\KinderNest.csproj"
    RenameIfExists "DaycareProviderAssistant.slnx" "KinderNest.slnx"
    RenameIfExists "DPATests\DPATests.csproj" "DPATests\KNTests.csproj"
    if ($RenameDatabase) { RenameIfExists "dpa\dpa.sqlproj" "dpa\kn.sqlproj" }

    $pathPairs = @(
        @("DaycareProviderAssistant/DaycareProviderAssistant.csproj","DaycareProviderAssistant/KinderNest.csproj"),
        @("DPATests/DPATests.csproj","DPATests/KNTests.csproj")
    )
    if ($RenameDatabase) { $pathPairs += @(@("dpa/dpa.sqlproj","dpa/kn.sqlproj")) }

    foreach ($file in TextFiles) {
        $content = Get-Content -LiteralPath $file.FullName -Raw
        $updated = $content
        foreach ($pair in $pathPairs) { $updated = $updated.Replace($pair[0], $pair[1]) }
        if ($updated -ne $content) {
            Set-Content -LiteralPath $file.FullName -Value $updated -Encoding UTF8
            $changed.Add($file.FullName.Substring($root.Length).TrimStart('\','/'))
        }
    }
}

$changed | Sort-Object -Unique | Set-Content -LiteralPath (Join-Path $root "KinderNest_Rebrand_Report.txt") -Encoding UTF8

$leftoverPattern = "DaycareProviderAssistant|Daycare Provider Assistant|DPA|Dpa|dpachild\.com|dpa_"
$leftovers = New-Object System.Collections.Generic.List[string]
foreach ($file in TextFiles) {
    $matches = Select-String -LiteralPath $file.FullName -Pattern $leftoverPattern -AllMatches -ErrorAction SilentlyContinue
    foreach ($match in $matches) {
        $leftovers.Add(("{0}:{1}: {2}" -f $file.FullName.Substring($root.Length).TrimStart('\','/'), $match.LineNumber, $match.Line.Trim()))
    }
}
$leftovers | Set-Content -LiteralPath (Join-Path $root "KinderNest_Rebrand_Leftovers.txt") -Encoding UTF8

Write-Host "Kinder Nest rebrand pass complete."
Write-Host "Changed file report: KinderNest_Rebrand_Report.txt"
Write-Host "Leftover report: KinderNest_Rebrand_Leftovers.txt"
Write-Host "Rebuild, inspect leftovers, then commit."
