param([string]$RepoRoot = ".")
$root = (Resolve-Path $RepoRoot).Path
$patterns = "DaycareProviderAssistant|Daycare Provider Assistant|DPA|Dpa|dpachild\.com|dpa_"
$excludeDirs = @(".git",".vs","bin","obj","images","node_modules","packages","TestResults")
$exts = @(".cs",".razor",".json",".sql",".sqlproj",".csproj",".sln",".slnx",".md",".txt",".ps1",".xml",".config",".css",".js",".html",".yml",".yaml",".props",".targets")
function IsExcluded($path) {
    $relative = $path.Substring($root.Length).TrimStart('\','/')
    foreach ($part in $relative.Split([char[]]@('\','/'), [System.StringSplitOptions]::RemoveEmptyEntries)) {
        if ($excludeDirs -contains $part) { return $true }
    }
    return $false
}
Get-ChildItem -LiteralPath $root -Recurse -File |
    Where-Object { -not (IsExcluded $_.FullName) -and ($exts -contains $_.Extension.ToLowerInvariant()) } |
    Select-String -Pattern $patterns
