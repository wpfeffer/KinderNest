# Kinder Nest rebrand overlay

This migrates text references from DaycareProviderAssistant / Daycare Provider Assistant / DPA / Dpa to KinderNest / Kinder Nest / KN / Kn.

## Naming rules

- `Daycare Provider Assistant` -> `Kinder Nest` for user-facing product text
- `DaycareProviderAssistant` -> `KinderNest` for namespaces and assembly identifiers
- `DPA` -> `KN`
- `Dpa` -> `Kn`
- `dpa_` -> `kn_`
- `dpachild.com` -> `kindernest.kids`

## Apply

From the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply_kindernest_rebrand.ps1
```

For a fuller project-file rename pass:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply_kindernest_rebrand.ps1 -FullRename
```

To also migrate obvious database-name references from `dpa` to `kn`:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply_kindernest_rebrand.ps1 -FullRename -RenameDatabase
```

## Reports

The script writes:

- `KinderNest_Rebrand_Report.txt`
- `KinderNest_Rebrand_Leftovers.txt`

Create a git branch before running this. Rebuild immediately afterward.
