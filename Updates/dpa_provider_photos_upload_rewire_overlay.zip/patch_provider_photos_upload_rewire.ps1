param(
    [string]$RepoRoot = "."
)

$photosPath = Join-Path $RepoRoot "DaycareProviderAssistant\Components\Pages\Provider\Photos.razor"
if (-not (Test-Path $photosPath)) {
    throw "Could not find Photos.razor at $photosPath"
}

$content = Get-Content $photosPath -Raw

$content = $content.Replace(
    'if (!firstRender || Workspace is null)',
    'if (Workspace is null)'
)

$content = $content.Replace(
    '_module = await JS.InvokeAsync<IJSObjectReference>("import", "/js/dpa-images.js");',
    'if (_module is not null)' + "`r`n" +
    '        {' + "`r`n" +
    '            await _module.DisposeAsync();' + "`r`n" +
    '            _module = null;' + "`r`n" +
    '        }' + "`r`n" + "`r`n" +
    '        _module = await JS.InvokeAsync<IJSObjectReference>("import", $"/js/dpa-images.js?v={Guid.NewGuid():N}");'
)

Set-Content -Path $photosPath -Value $content -Encoding UTF8

Write-Host "Patched Provider Photos module import to rewire upload controls and cache-bust dpa-images.js."
