DPA Provider Photos upload rewire overlay

What this fixes:
- Replaces dpa-images.js with a clean, diagnostic-heavy version.
- Adds console logs when the module loads and when Encrypt and upload is clicked.
- Patches Photos.razor so the JS module is imported with a cache-busting query string.
- Patches Photos.razor so upload wiring runs after render whenever Workspace exists, not only on first render.

Apply:
1. Unzip at the repository root and allow overwrite.
2. Run:
   powershell -ExecutionPolicy Bypass -File .\patch_provider_photos_upload_rewire.ps1
3. Rebuild and run.
4. Open DevTools Console and go to /provider/photos.
5. You should see: DPA encrypted image module loaded.
6. Click Encrypt and upload. You should see: Encrypt and upload clicked.

If you do not see those messages, the browser is still loading an older script or the Photos page is not running OnAfterRender JS initialization.
