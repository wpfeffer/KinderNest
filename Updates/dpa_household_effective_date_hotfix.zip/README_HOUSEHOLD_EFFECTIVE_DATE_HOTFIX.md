# Household Effective Date Hotfix

This hotfix corrects the column-name mismatch introduced between:
- bullet 1 committed tables, which use `EffectiveStartDate` / `EffectiveEndDate`
- bullets 3 and 4, which incorrectly referenced `EffectiveStartUTC` / `EffectiveEndUTC` on the new household tables

## Why you saw those errors
The new household tables were created with date-based effective columns:
- `party.HouseholdPerson.EffectiveStartDate`
- `party.HouseholdPerson.EffectiveEndDate`
- `child.ChildHousehold.EffectiveStartDate`
- `child.ChildHousehold.EffectiveEndDate`

But several reporting views and onboarding procedures mistakenly referenced UTC column names that do not exist on those tables.

Once the first provider-household views failed to create, dependent objects such as `rpt.vwProviderFamilyDetail` also failed.

## Included corrected files
### Views
- `dpa/rpt/Views/vwProviderHouseholdSummary.sql`
- `dpa/rpt/Views/vwProviderHouseholdPersonDetail.sql`
- `dpa/rpt/Views/vwProviderHouseholdPickupAuthorizationDetail.sql`
- `dpa/rpt/Views/vwProviderFamilyDetail.sql`

### Procedures
- `dpa/child/Stored Procedures/usp_ProviderPortal_Family_Onboard.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_Family_GetDetail.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_Guardian_Upsert.sql`
- `dpa/child/Stored Procedures/usp_ProviderPortal_PickupAuthorization_Upsert.sql`

## Apply order
1. Replace the files in your repo with these corrected versions
2. Re-run `master_install.sql`

No GitHub push was performed for this package.
