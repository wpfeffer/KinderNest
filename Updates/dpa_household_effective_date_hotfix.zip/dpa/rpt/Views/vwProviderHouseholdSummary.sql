CREATE OR ALTER VIEW rpt.vwProviderHouseholdSummary
AS
WITH ChildCounts AS
(
    SELECT
        chh.HouseholdID,
        COUNT(DISTINCT chh.ChildID) AS ChildCount
    FROM child.ChildHousehold chh
    WHERE chh.IsDeleted = 0
      AND chh.IsActive = 1
      AND (chh.EffectiveStartDate IS NULL OR chh.EffectiveStartDate <= CONVERT(date, SYSUTCDATETIME()))
      AND (chh.EffectiveEndDate IS NULL OR chh.EffectiveEndDate >= CONVERT(date, SYSUTCDATETIME()))
    GROUP BY chh.HouseholdID
),
ActiveEnrollmentCounts AS
(
    SELECT
        chh.HouseholdID,
        COUNT(DISTINCT ce.ChildEnrollmentID) AS ActiveEnrollmentCount
    FROM child.ChildHousehold chh
    INNER JOIN child.ChildEnrollment ce
        ON ce.ChildID = chh.ChildID
       AND ce.IsDeleted = 0
       AND ce.IsActive = 1
       AND ce.IsPrimaryEnrollment = 1
       AND (ce.EnrollmentEndDate IS NULL OR ce.EnrollmentEndDate >= CONVERT(date, SYSUTCDATETIME()))
    WHERE chh.IsDeleted = 0
      AND chh.IsActive = 1
      AND (chh.EffectiveStartDate IS NULL OR chh.EffectiveStartDate <= CONVERT(date, SYSUTCDATETIME()))
      AND (chh.EffectiveEndDate IS NULL OR chh.EffectiveEndDate >= CONVERT(date, SYSUTCDATETIME()))
    GROUP BY chh.HouseholdID
),
GuardianCounts AS
(
    SELECT
        hp.HouseholdID,
        COUNT(DISTINCT hp.PersonID) AS GuardianCount
    FROM party.HouseholdPerson hp
    INNER JOIN ref.CodeValue cv
        ON cv.CodeValueID = hp.HouseholdRoleCodeValueID
       AND cv.CodeDomain = N'HouseholdRole'
       AND cv.CodeValue IN (N'PRIMARY_GUARDIAN', N'SECONDARY_GUARDIAN', N'GUARDIAN')
    WHERE hp.IsDeleted = 0
      AND hp.IsActive = 1
      AND (hp.EffectiveStartDate IS NULL OR hp.EffectiveStartDate <= CONVERT(date, SYSUTCDATETIME()))
      AND (hp.EffectiveEndDate IS NULL OR hp.EffectiveEndDate >= CONVERT(date, SYSUTCDATETIME()))
    GROUP BY hp.HouseholdID
),
PrimaryContact AS
(
    SELECT
        hp.HouseholdID,
        p.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS PrimaryContactDisplayName,
        p.PrimaryEmail,
        ROW_NUMBER() OVER
        (
            PARTITION BY hp.HouseholdID
            ORDER BY
                CASE WHEN hp.IsPrimaryContact = 1 THEN 0 ELSE 1 END,
                p.LastName,
                p.FirstName,
                p.PersonID
        ) AS RowNum
    FROM party.HouseholdPerson hp
    INNER JOIN party.Person p
        ON p.PersonID = hp.PersonID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE hp.IsDeleted = 0
      AND hp.IsActive = 1
      AND (hp.EffectiveStartDate IS NULL OR hp.EffectiveStartDate <= CONVERT(date, SYSUTCDATETIME()))
      AND (hp.EffectiveEndDate IS NULL OR hp.EffectiveEndDate >= CONVERT(date, SYSUTCDATETIME()))
)
SELECT
    h.HouseholdID,
    h.ProviderID,
    pr.ProviderName,
    h.HouseholdDisplayName,
    h.PrimaryAddressID,
    a.AddressLine1,
    a.AddressLine2,
    a.City,
    a.StateProvinceCode,
    a.PostalCode,
    ISNULL(cc.ChildCount, 0) AS ChildCount,
    ISNULL(aec.ActiveEnrollmentCount, 0) AS ActiveEnrollmentCount,
    ISNULL(gc.GuardianCount, 0) AS GuardianCount,
    pc.PersonID AS PrimaryContactPersonID,
    pc.PrimaryContactDisplayName,
    pc.PrimaryEmail AS PrimaryContactEmail,
    h.IsActive,
    h.IsDeleted,
    h.CreatedUTC,
    h.ModifiedUTC
FROM party.Household h
INNER JOIN party.Provider pr
    ON pr.ProviderID = h.ProviderID
   AND pr.IsDeleted = 0
LEFT JOIN party.Address a
    ON a.AddressID = h.PrimaryAddressID
   AND a.IsDeleted = 0
   AND a.IsActive = 1
LEFT JOIN ChildCounts cc
    ON cc.HouseholdID = h.HouseholdID
LEFT JOIN ActiveEnrollmentCounts aec
    ON aec.HouseholdID = h.HouseholdID
LEFT JOIN GuardianCounts gc
    ON gc.HouseholdID = h.HouseholdID
LEFT JOIN PrimaryContact pc
    ON pc.HouseholdID = h.HouseholdID
   AND pc.RowNum = 1
WHERE h.IsDeleted = 0;
GO
