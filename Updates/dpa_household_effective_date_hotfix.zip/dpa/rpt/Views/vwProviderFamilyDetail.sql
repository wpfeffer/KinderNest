CREATE OR ALTER VIEW rpt.vwProviderFamilyDetail
AS
SELECT
    hs.HouseholdID,
    hs.ProviderID,
    hs.ProviderName,
    hs.HouseholdDisplayName,
    hs.ChildCount,
    hs.ActiveEnrollmentCount,
    hs.GuardianCount,
    hs.PrimaryContactPersonID,
    hs.PrimaryContactDisplayName,
    hs.PrimaryContactEmail,
    hc.ChildHouseholdID,
    hc.ChildID,
    hc.SiteID,
    hc.SiteName,
    hc.ChildDisplayName,
    hc.DateOfBirth,
    hc.EnrollmentStartDate,
    hc.EnrollmentEndDate,
    hc.EnrollmentStatusCode,
    hp.HouseholdPersonID,
    hp.PersonID,
    hp.PersonDisplayName,
    hp.HouseholdRoleCodeValueID,
    hp.HouseholdRoleCode,
    hp.HouseholdRoleCodeName,
    hp.IsPrimaryContact
FROM rpt.vwProviderHouseholdSummary hs
LEFT JOIN rpt.vwProviderHouseholdChildDetail hc
    ON hc.HouseholdID = hs.HouseholdID
LEFT JOIN rpt.vwProviderHouseholdPersonDetail hp
    ON hp.HouseholdID = hs.HouseholdID;
GO
