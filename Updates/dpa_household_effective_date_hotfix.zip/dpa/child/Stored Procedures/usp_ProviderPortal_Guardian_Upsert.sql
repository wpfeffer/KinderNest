CREATE OR ALTER PROCEDURE child.usp_ProviderPortal_Guardian_Upsert
    @PortalUserID                    INT,
    @HouseholdID                     INT,
    @HouseholdPersonID               INT = NULL,
    @ChildID                         INT = NULL,
    @FirstName                       NVARCHAR(100),
    @MiddleName                      NVARCHAR(100) = NULL,
    @LastName                        NVARCHAR(100),
    @PrimaryEmail                    NVARCHAR(320) = NULL,
    @HouseholdRoleCodeValueID        INT,
    @RelationshipTypeCode            NVARCHAR(50) = N'GUARDIAN',
    @HasPortalAccess                 BIT = 0,
    @CanReceiveAlerts                BIT = 1,
    @CanSignPermissions              BIT = 1,
    @IsPrimaryGuardian               BIT = 0,
    @IsPrimaryContact                BIT = 0,
    @EffectiveStartDate              DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @NowUTC DATETIME2(0) = SYSUTCDATETIME();
    DECLARE @Today DATE = CONVERT(date, @NowUTC);
    DECLARE @PersonID INT;
    DECLARE @ProviderID INT;

    IF NULLIF(LTRIM(RTRIM(@FirstName)), N'') IS NULL
        THROW 51030, 'Guardian first name is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@LastName)), N'') IS NULL
        THROW 51031, 'Guardian last name is required.', 1;

    SELECT @ProviderID = h.ProviderID
    FROM party.Household h
    WHERE h.HouseholdID = @HouseholdID
      AND h.IsDeleted = 0
      AND h.IsActive = 1;

    IF @ProviderID IS NULL
        THROW 51032, 'The requested household does not exist.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.ProviderID = @ProviderID
           AND s.IsDeleted = 0
           AND s.IsActive = 1
        WHERE sua.PortalUserID = @PortalUserID
          AND sua.IsActive = 1
          AND sua.EffectiveStartUTC <= @NowUTC
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= @NowUTC)
    )
    BEGIN
        THROW 51033, 'The current provider user cannot modify this household.', 1;
    END;

    BEGIN TRANSACTION;

    IF @HouseholdPersonID IS NULL
    BEGIN
        INSERT INTO party.Person
        (
            FirstName,
            MiddleName,
            LastName,
            PrimaryEmail,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            LTRIM(RTRIM(@FirstName)),
            NULLIF(LTRIM(RTRIM(@MiddleName)), N''),
            LTRIM(RTRIM(@LastName)),
            NULLIF(LTRIM(RTRIM(@PrimaryEmail)), N''),
            1,
            0,
            @PortalUserID
        );

        SET @PersonID = SCOPE_IDENTITY();

        INSERT INTO party.HouseholdPerson
        (
            HouseholdID,
            PersonID,
            HouseholdRoleCodeValueID,
            IsPrimaryContact,
            EffectiveStartDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @HouseholdID,
            @PersonID,
            @HouseholdRoleCodeValueID,
            @IsPrimaryContact,
            COALESCE(@EffectiveStartDate, @Today),
            1,
            0,
            @PortalUserID
        );

        SET @HouseholdPersonID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        SELECT @PersonID = hp.PersonID
        FROM party.HouseholdPerson hp
        WHERE hp.HouseholdPersonID = @HouseholdPersonID
          AND hp.HouseholdID = @HouseholdID
          AND hp.IsDeleted = 0;

        IF @PersonID IS NULL
            THROW 51034, 'The requested household person does not exist.', 1;

        UPDATE p
        SET
            p.FirstName = LTRIM(RTRIM(@FirstName)),
            p.MiddleName = NULLIF(LTRIM(RTRIM(@MiddleName)), N''),
            p.LastName = LTRIM(RTRIM(@LastName)),
            p.PrimaryEmail = NULLIF(LTRIM(RTRIM(@PrimaryEmail)), N''),
            p.ModifiedUTC = @NowUTC,
            p.ModifiedByUserID = @PortalUserID
        FROM party.Person p
        WHERE p.PersonID = @PersonID;

        UPDATE hp
        SET
            hp.HouseholdRoleCodeValueID = @HouseholdRoleCodeValueID,
            hp.IsPrimaryContact = @IsPrimaryContact,
            hp.ModifiedUTC = @NowUTC,
            hp.ModifiedByUserID = @PortalUserID
        FROM party.HouseholdPerson hp
        WHERE hp.HouseholdPersonID = @HouseholdPersonID;
    END;

    IF @ChildID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM child.ChildHousehold chh
           WHERE chh.HouseholdID = @HouseholdID
             AND chh.ChildID = @ChildID
             AND chh.IsDeleted = 0
             AND chh.IsActive = 1
       )
    BEGIN
        THROW 51035, 'The requested child is not linked to the requested household.', 1;
    END;

    IF @ChildID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM child.ChildPersonRelationship cpr
           WHERE cpr.ChildID = @ChildID
             AND cpr.PersonID = @PersonID
             AND cpr.IsDeleted = 0
       )
    BEGIN
        INSERT INTO child.ChildPersonRelationship
        (
            ChildID,
            PersonID,
            RelationshipTypeCode,
            HasPortalAccess,
            CanReceiveAlerts,
            CanSignPermissions,
            IsPrimaryGuardian,
            EffectiveStartDate,
            IsActive,
            IsDeleted,
            CreatedByUserID
        )
        VALUES
        (
            @ChildID,
            @PersonID,
            @RelationshipTypeCode,
            @HasPortalAccess,
            @CanReceiveAlerts,
            @CanSignPermissions,
            @IsPrimaryGuardian,
            COALESCE(@EffectiveStartDate, @Today),
            1,
            0,
            @PortalUserID
        );
    END
    ELSE IF @ChildID IS NOT NULL
    BEGIN
        UPDATE cpr
        SET
            cpr.RelationshipTypeCode = @RelationshipTypeCode,
            cpr.HasPortalAccess = @HasPortalAccess,
            cpr.CanReceiveAlerts = @CanReceiveAlerts,
            cpr.CanSignPermissions = @CanSignPermissions,
            cpr.IsPrimaryGuardian = @IsPrimaryGuardian,
            cpr.ModifiedUTC = @NowUTC,
            cpr.ModifiedByUserID = @PortalUserID
        FROM child.ChildPersonRelationship cpr
        WHERE cpr.ChildID = @ChildID
          AND cpr.PersonID = @PersonID
          AND cpr.IsDeleted = 0;
    END;

    COMMIT TRANSACTION;

    SELECT
        HouseholdPersonID = @HouseholdPersonID,
        PersonID = @PersonID,
        HouseholdID = @HouseholdID,
        ChildID = @ChildID;
END;
GO
