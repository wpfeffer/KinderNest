DPA currentization bundle

What this bundle updates
- Provider self-registration UI and backend wiring
- Provider registration lookup procedures and registration procedure
- Account status / role / time zone / license class seed data
- Admin dashboard and provider approvals
- Admin users/providers/sites list pages
- Admin user/provider/site detail pages
- Required rejection reason support for provider rejection

Apply order
1. Merge the dpa folder into your database project.
2. Merge the DaycareProviderAssistant folder into your website project.
3. Publish the database project or apply the SQL patch file.
4. Delete bin and obj from the website project.
5. Rebuild the Visual Studio solution.

Notes
- appsettings.json in this bundle includes currentization changes under DpaAuth.
- party.PortalUser adds RejectionReason NVARCHAR(MAX).
- Admin provider/site list procedures were aligned with the current app-side DTO expectations.
