SET NOCOUNT ON;
GO

IF COL_LENGTH(N'party.PortalUser', N'RejectionReason') IS NULL
BEGIN
    ALTER TABLE party.PortalUser ADD RejectionReason NVARCHAR(MAX) NULL;
END;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'ref.CodeValue', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.CodeValue (CodeDomain, CodeValue, CodeName)
    SELECT v.CodeDomain, v.CodeValue, v.CodeName
    FROM
    (
        VALUES
            (N'CredentialType', N'PASSWORD', N'Password'),
            (N'CredentialType', N'TOTP', N'Time-based One-Time Password'),
            (N'CredentialType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'CredentialType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'CredentialStatus', N'ACTIVE', N'Active'),
            (N'CredentialStatus', N'LOCKED', N'Locked'),
            (N'CredentialStatus', N'DISABLED', N'Disabled'),
            (N'CredentialStatus', N'RESET_REQUIRED', N'Reset Required'),
            (N'CredentialStatus', N'REVOKED', N'Revoked'),

            (N'HashAlgorithm', N'ARGON2ID', N'Argon2id'),
            (N'HashAlgorithm', N'SCRYPT', N'scrypt'),
            (N'HashAlgorithm', N'ASPNETCORE_IDENTITY_V3', N'ASP.NET Core Identity V3'),
            (N'HashAlgorithm', N'PBKDF2', N'PBKDF2'),

            (N'LoginSessionStatus', N'ACTIVE', N'Active'),
            (N'LoginSessionStatus', N'REVOKED', N'Revoked'),
            (N'LoginSessionStatus', N'EXPIRED', N'Expired'),
            (N'LoginSessionStatus', N'LOGGED_OUT', N'Logged Out'),

            (N'PasswordResetRequestStatus', N'PENDING', N'Pending'),
            (N'PasswordResetRequestStatus', N'CONSUMED', N'Consumed'),
            (N'PasswordResetRequestStatus', N'EXPIRED', N'Expired'),
            (N'PasswordResetRequestStatus', N'REVOKED', N'Revoked'),

            (N'MfaFactorType', N'TOTP', N'Time-based One-Time Password'),
            (N'MfaFactorType', N'EMAIL_OTP', N'Email One-Time Password'),
            (N'MfaFactorType', N'SMS_OTP', N'SMS One-Time Password'),

            (N'AuthenticationEventType', N'LOGIN_ATTEMPT', N'Login Attempt'),
            (N'AuthenticationEventType', N'LOGIN_SUCCESS', N'Login Success'),
            (N'AuthenticationEventType', N'LOGIN_FAILED', N'Login Failed'),
            (N'AuthenticationEventType', N'LOGOUT', N'Logout'),
            (N'AuthenticationEventType', N'PASSWORD_CHANGED', N'Password Changed'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_REQUESTED', N'Password Reset Requested'),
            (N'AuthenticationEventType', N'PASSWORD_RESET_COMPLETED', N'Password Reset Completed'),
            (N'AuthenticationEventType', N'MFA_CHALLENGE_ISSUED', N'MFA Challenge Issued'),
            (N'AuthenticationEventType', N'MFA_SUCCESS', N'MFA Success'),
            (N'AuthenticationEventType', N'MFA_FAILED', N'MFA Failed'),
            (N'AuthenticationEventType', N'ACCOUNT_LOCKED', N'Account Locked'),
            (N'AuthenticationEventType', N'ACCOUNT_UNLOCKED', N'Account Unlocked'),

            (N'AuthenticationResult', N'SUCCESS', N'Success'),
            (N'AuthenticationResult', N'FAILURE', N'Failure'),
            (N'AuthenticationResult', N'CHALLENGED', N'Challenged'),
            (N'AuthenticationResult', N'BLOCKED', N'Blocked'),

            (N'AccountStatus', N'ACTIVE', N'Active'),
            (N'AccountStatus', N'PENDING_APPROVAL', N'Pending Approval'),
            (N'AccountStatus', N'INVITED', N'Invited'),
            (N'AccountStatus', N'DISABLED', N'Disabled')
    ) v(CodeDomain, CodeValue, CodeName)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue c
        WHERE c.CodeDomain = v.CodeDomain
          AND c.CodeValue = v.CodeValue
    );
END;
GO

IF OBJECT_ID(N'ref.SeedBatch', N'U') IS NOT NULL
AND NOT EXISTS
(
    SELECT 1
    FROM ref.SeedBatch sb
    WHERE sb.SeedBatchCode = N'AUTH_SECURITY_BASELINE'
)
BEGIN
    INSERT INTO ref.SeedBatch
    (
        SeedBatchCode,
        SeedBatchName,
        SeedBatchDescription,
        TargetSchemaName,
        TargetObjectName,
        BatchVersion,
        IsRequired,
        IsActive
    )
    VALUES
    (
        N'AUTH_SECURITY_BASELINE',
        N'Authentication Security Baseline',
        N'Seeds native authentication and audit reference codes required for portal credential, session, reset, MFA, and authentication event processing.',
        N'sec',
        N'PortalCredential',
        N'1.0.0',
        1,
        1
    );
END;
GO


IF OBJECT_ID(N'ref.Role', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.Role (RoleCode, RoleName, RoleDescription, IsSystemRole)
    SELECT v.RoleCode, v.RoleName, v.RoleDescription, v.IsSystemRole
    FROM
    (
        VALUES
            (N'PROVIDER_OWNER', N'Provider Owner', N'Primary provider account owner.', 1),
            (N'PROVIDER_STAFF', N'Provider Staff', N'Provider-side staff account with limited permissions.', 1),
            (N'GUARDIAN', N'Guardian', N'Parent or guardian portal user.', 1),
            (N'LICENSOR_USER', N'Licensor User', N'County/state licensing staff user.', 1),
            (N'LICENSOR_SUPERVISOR', N'Licensor Supervisor', N'Licensing supervisory user.', 1),
            (N'SUPPORT_ADMIN', N'Support Admin', N'Administrative support user with outbound-only chat initiation.', 1),
            (N'PLATFORM_ADMIN', N'Platform Admin', N'Platform administration user.', 1),
            (N'COMPLIANCE_ADMIN', N'Compliance Admin', N'Administrative user for compliance review and escalation.', 1),
            (N'DATABASE_ADMIN', N'Database Admin', N'Privileged database administrator role.', 1),
            (N'AUDITOR', N'Auditor', N'Read-only auditor role.', 1)
    ) v(RoleCode, RoleName, RoleDescription, IsSystemRole)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.Role r
        WHERE r.RoleCode = v.RoleCode
    );
END;
GO

IF OBJECT_ID(N'ref.TimeZone', N'U') IS NOT NULL
BEGIN
    INSERT INTO ref.TimeZone
    (
        TimeZoneCode,
        WindowsTimeZoneName,
        DisplayName,
        UtcOffsetMinutesStandard,
        ObservesDst
    )
    SELECT v.TimeZoneCode, v.WindowsTimeZoneName, v.DisplayName, v.UtcOffsetMinutesStandard, v.ObservesDst
    FROM
    (
        VALUES
            (N'America/Chicago', N'Central Standard Time', N'Central Time (US & Canada)', -360, 1),
            (N'America/New_York', N'Eastern Standard Time', N'Eastern Time (US & Canada)', -300, 1),
            (N'America/Denver', N'Mountain Standard Time', N'Mountain Time (US & Canada)', -420, 1),
            (N'America/Los_Angeles', N'Pacific Standard Time', N'Pacific Time (US & Canada)', -480, 1),
            (N'UTC', N'UTC', N'Coordinated Universal Time', 0, 0)
    ) v(TimeZoneCode, WindowsTimeZoneName, DisplayName, UtcOffsetMinutesStandard, ObservesDst)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM ref.TimeZone tz
        WHERE tz.TimeZoneCode = v.TimeZoneCode
    );
END;
GO

IF OBJECT_ID(N'lic.LicenseClass', N'U') IS NOT NULL
BEGIN
    INSERT INTO lic.LicenseClass
    (
        LicenseClassCode,
        LicenseClassName,
        LicenseFamilyCode,
        Description
    )
    SELECT v.LicenseClassCode, v.LicenseClassName, v.LicenseFamilyCode, v.Description
    FROM
    (
        VALUES
            (N'A', N'Class A Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class A.'),
            (N'B1', N'Class B1 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B1.'),
            (N'B2', N'Class B2 Family Child Care', N'FAMILY_CHILD_CARE', N'Family child care license class B2.'),
            (N'C1', N'Class C1 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C1.'),
            (N'C2', N'Class C2 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C2.'),
            (N'C3', N'Class C3 Group Family Child Care', N'GROUP_FAMILY_CHILD_CARE', N'Group family child care license class C3.'),
            (N'D', N'Class D Special Family Child Care', N'FAMILY_CHILD_CARE', N'Special family child care classification.')
    ) v(LicenseClassCode, LicenseClassName, LicenseFamilyCode, Description)
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM lic.LicenseClass lc
        WHERE lc.LicenseClassCode = v.LicenseClassCode
    );
END;
GO


CREATE OR ALTER PROCEDURE ref.usp_TimeZone_ListActive
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        tz.TimeZoneID,
        tz.TimeZoneCode,
        tz.WindowsTimeZoneName,
        tz.DisplayName,
        tz.UtcOffsetMinutesStandard,
        tz.ObservesDst,
        tz.IsActive
    FROM ref.TimeZone tz
    WHERE tz.IsActive = 1
    ORDER BY
        tz.UtcOffsetMinutesStandard,
        tz.DisplayName,
        tz.TimeZoneCode;
END;
GO



CREATE OR ALTER PROCEDURE lic.usp_LicenseClass_ListActive
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        lc.LicenseClassID,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        lc.LicenseFamilyCode,
        lc.Description,
        lc.IsActive
    FROM lic.LicenseClass lc
    WHERE lc.IsActive = 1
    ORDER BY
        lc.LicenseFamilyCode,
        lc.LicenseClassCode,
        lc.LicenseClassName;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_SelfRegister
    @FirstName                         NVARCHAR(100),
    @LastName                          NVARCHAR(100),
    @PrimaryEmail                      NVARCHAR(320),
    @UserName                          NVARCHAR(320),
    @NormalizedUserName                NVARCHAR(320),
    @ProviderName                      NVARCHAR(200),
    @LegalEntityName                   NVARCHAR(200),
    @BusinessEmail                     NVARCHAR(320),
    @SiteName                          NVARCHAR(200),
    @LicenseNumber                     NVARCHAR(100) = NULL,
    @LicenseClassCode                  NVARCHAR(10),
    @TimeZoneCode                      NVARCHAR(100),
    @PasswordHash                      NVARCHAR(1000),
    @HashAlgorithmCode                 NVARCHAR(100),
    @ProviderOwnerRoleCode             NVARCHAR(50),
    @PendingApprovalAccountStatusCode  NVARCHAR(50),
    @RemoteAddress                     NVARCHAR(64) = NULL,
    @UserAgent                         NVARCHAR(512) = NULL,
    @CorrelationID                     UNIQUEIDENTIFIER = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PortalUserID INT;
    DECLARE @PersonID INT;
    DECLARE @ProviderID INT;
    DECLARE @SiteID INT;
    DECLARE @PortalUserRoleID INT;
    DECLARE @SiteUserAssignmentID INT;
    DECLARE @RoleID INT;
    DECLARE @LicenseClassID INT;
    DECLARE @TimeZoneID INT;
    DECLARE @ReasonText NVARCHAR(MAX) = N'Self-service provider registration.';

    DECLARE @HashVersion INT = 1;
    DECLARE @MustChangePassword BIT = 0;
    DECLARE @AuthenticationEventTypeCode NVARCHAR(100) = N'PASSWORD_CHANGED';
    DECLARE @PasswordNotes NVARCHAR(4000) = N'Password established during provider self-registration.';

    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @NewValuesJson NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SELECT @RoleID = r.RoleID
    FROM ref.Role r
    WHERE r.RoleCode = @ProviderOwnerRoleCode
      AND r.IsActive = 1;

    IF @RoleID IS NULL
    BEGIN
        THROW 50500, 'Provider owner role was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM ref.CodeValue cv
        WHERE cv.CodeDomain = N'AccountStatus'
          AND cv.CodeValue = @PendingApprovalAccountStatusCode
          AND cv.IsActive = 1
    )
    BEGIN
        THROW 50501, 'Pending approval account status code was not found.', 1;
    END;

    SELECT @LicenseClassID = lc.LicenseClassID
    FROM lic.LicenseClass lc
    WHERE lc.LicenseClassCode = @LicenseClassCode
      AND lc.IsActive = 1;

    IF @LicenseClassID IS NULL
    BEGIN
        THROW 50502, 'License class code was not found.', 1;
    END;

    SELECT @TimeZoneID = tz.TimeZoneID
    FROM ref.TimeZone tz
    WHERE tz.TimeZoneCode = @TimeZoneCode
      AND tz.IsActive = 1;

    IF @TimeZoneID IS NULL
    BEGIN
        THROW 50503, 'Time zone code was not found.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.NormalizedUserName = @NormalizedUserName
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50504, 'That username is already registered.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM party.Person p
        WHERE UPPER(ISNULL(p.PrimaryEmail, N'')) = UPPER(@PrimaryEmail)
          AND p.IsDeleted = 0
    )
    BEGIN
        THROW 50505, 'That email is already registered.', 1;
    END;

    BEGIN TRANSACTION;

    INSERT INTO party.Person
    (
        FirstName,
        LastName,
        PrimaryEmail,
        IsActive,
        IsDeleted
    )
    VALUES
    (
        @FirstName,
        @LastName,
        @PrimaryEmail,
        1,
        0
    );

    SET @PersonID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUser
    (
        PersonID,
        UserName,
        NormalizedUserName,
        AccountStatusCode,
        MFAEnabled,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @PersonID,
        @UserName,
        @NormalizedUserName,
        @PendingApprovalAccountStatusCode,
        0,
        1,
        0,
        NULL
    );

    SET @PortalUserID = SCOPE_IDENTITY();

    INSERT INTO party.Provider
    (
        ProviderName,
        LegalEntityName,
        LicenseHolderPersonID,
        BusinessEmail,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ProviderName,
        @LegalEntityName,
        @PersonID,
        @BusinessEmail,
        1,
        0,
        @PortalUserID
    );

    SET @ProviderID = SCOPE_IDENTITY();

    INSERT INTO party.Site
    (
        ProviderID,
        SiteName,
        LicenseNumber,
        LicenseClassID,
        TimeZoneID,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @ProviderID,
        @SiteName,
        @LicenseNumber,
        @LicenseClassID,
        @TimeZoneID,
        1,
        0,
        @PortalUserID
    );

    SET @SiteID = SCOPE_IDENTITY();

    INSERT INTO party.PortalUserRole
    (
        PortalUserID,
        RoleID,
        EffectiveStartUTC,
        IsActive,
        CreatedByUserID
    )
    VALUES
    (
        @PortalUserID,
        @RoleID,
        SYSUTCDATETIME(),
        1,
        @PortalUserID
    );

    SET @PortalUserRoleID = SCOPE_IDENTITY();

    INSERT INTO party.SiteUserAssignment
    (
        SiteID,
        PortalUserID,
        AssignmentTypeCode,
        IsPrimaryProviderContact,
        EffectiveStartUTC,
        IsActive,
        CreatedByUserID
    )
    VALUES
    (
        @SiteID,
        @PortalUserID,
        @ProviderOwnerRoleCode,
        1,
        SYSUTCDATETIME(),
        1,
        @PortalUserID
    );

    SET @SiteUserAssignmentID = SCOPE_IDENTITY();

    EXEC sec.usp_PortalCredential_SetPassword
        @PortalUserID = @PortalUserID,
        @PasswordHash = @PasswordHash,
        @HashAlgorithmCode = @HashAlgorithmCode,
        @HashVersion = @HashVersion,
        @MustChangePassword = @MustChangePassword,
        @ChangedByUserID = @PortalUserID,
        @AuthenticationEventTypeCode = @AuthenticationEventTypeCode,
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @Notes = @PasswordNotes;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PersonID);
    SELECT @NewValuesJson = (SELECT p.* FROM party.Person p WHERE p.PersonID = @PersonID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Person',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);
    SELECT @NewValuesJson = (SELECT pu.* FROM party.PortalUser pu WHERE pu.PortalUserID = @PortalUserID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @ProviderID);
    SELECT @NewValuesJson = (SELECT pr.* FROM party.Provider pr WHERE pr.ProviderID = @ProviderID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Provider',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @SiteID);
    SELECT @NewValuesJson = (SELECT s.* FROM party.Site s WHERE s.SiteID = @SiteID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'Site',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @SiteID = @SiteID,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserRoleID);
    SELECT @NewValuesJson = (SELECT pur.* FROM party.PortalUserRole pur WHERE pur.PortalUserRoleID = @PortalUserRoleID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUserRole',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @SiteUserAssignmentID);
    SELECT @NewValuesJson = (SELECT sua.* FROM party.SiteUserAssignment sua WHERE sua.SiteUserAssignmentID = @SiteUserAssignmentID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'SiteUserAssignment',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'INSERT',
        @ChangedByUserID = @PortalUserID,
        @ChangeSourceCode = N'SELF_REGISTRATION',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @ReasonText,
        @NewValuesJson = @NewValuesJson;

    COMMIT TRANSACTION;

    SELECT
        @PortalUserID AS PortalUserID,
        @ProviderID AS ProviderID,
        @SiteID AS SiteID,
        @PendingApprovalAccountStatusCode AS AccountStatusCode;
END;
GO




CREATE OR ALTER PROCEDURE ops.usp_AdminDashboard_GetSummary
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER',
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @FailureResultCodeValueID INT;
    DECLARE @BlockedResultCodeValueID INT;
    DECLARE @LockedCredentialStatusCodeValueID INT;

    SELECT @FailureResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'FAILURE'
      AND cv.IsActive = 1;

    SELECT @BlockedResultCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'AuthenticationResult'
      AND cv.CodeValue = N'BLOCKED'
      AND cv.IsActive = 1;

    SELECT @LockedCredentialStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'CredentialStatus'
      AND cv.CodeValue = N'LOCKED'
      AND cv.IsActive = 1;

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    )
    SELECT
        PendingProviderApprovals =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
              AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
        ),
        ActiveProviders =
        (
            SELECT COUNT(1)
            FROM party.Provider pr
            WHERE pr.IsActive = 1
              AND pr.IsDeleted = 0
        ),
        ActiveSites =
        (
            SELECT COUNT(1)
            FROM party.Site s
            WHERE s.IsActive = 1
              AND s.IsDeleted = 0
        ),
        ActiveUsers =
        (
            SELECT COUNT(1)
            FROM party.PortalUser pu
            WHERE pu.IsActive = 1
              AND pu.IsDeleted = 0
        ),
        LockedAccounts =
        (
            SELECT COUNT(1)
            FROM sec.PortalCredential pc
            WHERE pc.IsActive = 1
              AND pc.IsDeleted = 0
              AND (
                    (@LockedCredentialStatusCodeValueID IS NOT NULL AND pc.CredentialStatusCodeValueID = @LockedCredentialStatusCodeValueID)
                    OR (pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC >= SYSUTCDATETIME())
                  )
        ),
        FailedLoginsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuthenticationEvent ae
            WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
              AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
        ),
        RecentRegistrationsLast7Days =
        (
            SELECT COUNT(1)
            FROM ProviderOwnerUsers pou
            INNER JOIN party.PortalUser pu ON pu.PortalUserID = pou.PortalUserID
            WHERE pu.IsDeleted = 0
              AND pu.CreatedUTC >= DATEADD(DAY, -7, SYSUTCDATETIME())
        ),
        AuditEventsLast24Hours =
        (
            SELECT COUNT(1)
            FROM audit.AuditLog al
            WHERE al.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
        );

    ;WITH ProviderOwnerUsers AS
    (
        SELECT DISTINCT pu.PortalUserID
        FROM party.PortalUser pu
        INNER JOIN party.PortalUserRole pur
            ON pur.PortalUserID = pu.PortalUserID
           AND pur.IsActive = 1
           AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
           AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pu.IsDeleted = 0
    )
    SELECT TOP (10)
        pu.PortalUserID,
        reg.ProviderID,
        reg.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(p.FirstName, N' ', p.LastName),
        pu.UserName,
        PrimaryEmail = ISNULL(p.PrimaryEmail, N''),
        ProviderName = ISNULL(reg.ProviderName, N''),
        reg.BusinessEmail,
        SiteName = ISNULL(reg.SiteName, N''),
        reg.LicenseNumber,
        LicenseClassCode = ISNULL(reg.LicenseClassCode, N''),
        LicenseClassName = ISNULL(reg.LicenseClassName, N''),
        pu.AccountStatusCode
    FROM ProviderOwnerUsers pou
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = pou.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    OUTER APPLY
    (
        SELECT TOP (1)
            s.SiteID,
            pr.ProviderID,
            pr.ProviderName,
            pr.BusinessEmail,
            s.SiteName,
            s.LicenseNumber,
            lc.LicenseClassCode,
            lc.LicenseClassName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
           AND s.IsDeleted = 0
        INNER JOIN party.Provider pr
            ON pr.ProviderID = s.ProviderID
           AND pr.IsDeleted = 0
        INNER JOIN lic.LicenseClass lc
            ON lc.LicenseClassID = s.LicenseClassID
        WHERE sua.PortalUserID = pu.PortalUserID
          AND sua.IsActive = 1
        ORDER BY sua.IsPrimaryProviderContact DESC,
                 sua.EffectiveStartUTC DESC,
                 sua.SiteUserAssignmentID DESC
    ) reg
    ORDER BY pu.CreatedUTC DESC,
             pu.PortalUserID DESC;

    SELECT TOP (10)
        ae.AuthenticationEventID,
        ae.EventUTC,
        UserNameAttempted = COALESCE(ae.UserNameAttempted, pu.UserName, N''),
        AuthenticationEventTypeCode = et.CodeValue,
        AuthenticationResultCode = ar.CodeValue,
        ae.FailureReason,
        ae.RemoteAddress,
        SiteName = s.SiteName
    FROM audit.AuthenticationEvent ae
    LEFT JOIN party.PortalUser pu
        ON pu.PortalUserID = ae.PortalUserID
    LEFT JOIN ref.CodeValue et
        ON et.CodeValueID = ae.AuthenticationEventTypeCodeValueID
    LEFT JOIN ref.CodeValue ar
        ON ar.CodeValueID = ae.AuthenticationResultCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = ae.SiteID
    WHERE ae.EventUTC >= DATEADD(HOUR, -24, SYSUTCDATETIME())
      AND ae.AuthenticationResultCodeValueID IN (@FailureResultCodeValueID, @BlockedResultCodeValueID)
    ORDER BY ae.EventUTC DESC,
             ae.AuthenticationEventID DESC;

    SELECT TOP (10)
        al.AuditLogID,
        al.EventUTC,
        al.SchemaName,
        al.TableName,
        al.ActionTypeCode,
        ActorUserName = actor.UserName,
        al.RecordPrimaryKeyValue,
        al.ReasonText,
        al.SucceededFlag
    FROM audit.AuditLog al
    LEFT JOIN party.PortalUser actor
        ON actor.PortalUserID = al.ChangedByUserID
    ORDER BY al.EventUTC DESC,
             al.AuditLogID DESC;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminPendingProvider_List
    @PendingApprovalAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pu.PortalUserID,
        p.ProviderID,
        s.SiteID,
        SubmittedUTC = pu.CreatedUTC,
        RegistrantDisplayName = CONCAT(prsn.FirstName, N' ', prsn.LastName),
        pu.UserName,
        PrimaryEmail = prsn.PrimaryEmail,
        p.ProviderName,
        p.BusinessEmail,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        LicenseClassName = lc.LicenseClassName,
        pu.AccountStatusCode
    FROM party.PortalUser pu
    INNER JOIN party.Person prsn
        ON prsn.PersonID = pu.PersonID
       AND prsn.IsDeleted = 0
       AND prsn.IsActive = 1
    INNER JOIN party.PortalUserRole pur
        ON pur.PortalUserID = pu.PortalUserID
       AND pur.IsActive = 1
       AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
       AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
       AND r.RoleCode = @ProviderOwnerRoleCode
       AND r.IsActive = 1
    LEFT JOIN party.SiteUserAssignment sua
        ON sua.PortalUserID = pu.PortalUserID
       AND sua.IsActive = 1
    LEFT JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
    LEFT JOIN party.Provider p
        ON p.ProviderID = s.ProviderID
       AND p.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
       AND lc.IsActive = 1
    WHERE pu.IsDeleted = 0
      AND pu.IsActive = 1
      AND pu.AccountStatusCode = @PendingApprovalAccountStatusCode
    ORDER BY pu.CreatedUTC ASC,
             pu.PortalUserID ASC;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Approve
    @PortalUserID INT,
    @ApprovedByUserID INT,
    @ReasonText NVARCHAR(MAX) = NULL,
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @ApprovedAccountStatusCode NVARCHAR(50) = N'ACTIVE',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration approved.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = COALESCE(NULLIF(LTRIM(RTRIM(@ReasonText)), N''), N'Provider registration approved from admin portal.');

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50700, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50701, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @ApprovedAccountStatusCode,
           RejectionReason = NULL,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @ApprovedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50702, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'APPROVE_PROVIDER_REGISTRATION',
        @ChangedByUserID = @ApprovedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","RejectionReason","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @ApprovedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_ProviderOwner_Reject
    @PortalUserID INT,
    @RejectedByUserID INT,
    @ReasonText NVARCHAR(MAX),
    @CorrelationID UNIQUEIDENTIFIER = NULL,
    @ExpectedPendingAccountStatusCode NVARCHAR(50) = N'PENDING_APPROVAL',
    @RejectedAccountStatusCode NVARCHAR(50) = N'REJECTED',
    @ProviderOwnerRoleCode NVARCHAR(50) = N'PROVIDER_OWNER'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OldValuesJson NVARCHAR(MAX);
    DECLARE @NewValuesJson NVARCHAR(MAX);
    DECLARE @RecordPrimaryKeyValue NVARCHAR(128);
    DECLARE @SiteID INT;
    DECLARE @StatusMessage NVARCHAR(200) = N'Provider registration rejected.';
    DECLARE @EffectiveReasonText NVARCHAR(MAX);

    IF @CorrelationID IS NULL
    BEGIN
        SET @CorrelationID = NEWID();
    END;

    SET @EffectiveReasonText = NULLIF(LTRIM(RTRIM(@ReasonText)), N'');

    IF @EffectiveReasonText IS NULL
    BEGIN
        THROW 50709, 'A rejection reason is required.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
          AND pu.IsDeleted = 0
    )
    BEGIN
        THROW 50710, 'Portal user was not found.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
           AND r.RoleCode = @ProviderOwnerRoleCode
           AND r.IsActive = 1
        WHERE pur.PortalUserID = @PortalUserID
          AND pur.IsActive = 1
          AND pur.EffectiveStartUTC <= SYSUTCDATETIME()
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC >= SYSUTCDATETIME())
    )
    BEGIN
        THROW 50711, 'Portal user is not a provider owner registration candidate.', 1;
    END;

    SELECT TOP (1) @SiteID = sua.SiteID
    FROM party.SiteUserAssignment sua
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
    ORDER BY sua.IsPrimaryProviderContact DESC,
             sua.EffectiveStartUTC DESC,
             sua.SiteUserAssignmentID DESC;

    SELECT @OldValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    BEGIN TRANSACTION;

    UPDATE party.PortalUser
       SET AccountStatusCode = @RejectedAccountStatusCode,
           RejectionReason = @EffectiveReasonText,
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @RejectedByUserID
     WHERE PortalUserID = @PortalUserID
       AND IsDeleted = 0
       AND AccountStatusCode = @ExpectedPendingAccountStatusCode;

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50712, 'Provider registration is not currently pending approval.', 1;
    END;

    SELECT @NewValuesJson =
    (
        SELECT pu.*
        FROM party.PortalUser pu
        WHERE pu.PortalUserID = @PortalUserID
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    SET @RecordPrimaryKeyValue = CONVERT(NVARCHAR(128), @PortalUserID);

    EXEC audit.usp_WriteAuditLog
        @SchemaName = N'party',
        @TableName = N'PortalUser',
        @RecordPrimaryKeyValue = @RecordPrimaryKeyValue,
        @ActionTypeCode = N'REJECT_PROVIDER_REGISTRATION',
        @ChangedByUserID = @RejectedByUserID,
        @ChangeSourceCode = N'ADMIN_PORTAL',
        @SiteID = @SiteID,
        @CorrelationID = @CorrelationID,
        @ReasonText = @EffectiveReasonText,
        @OldValuesJson = @OldValuesJson,
        @NewValuesJson = @NewValuesJson,
        @AffectedColumnsJson = N'["AccountStatusCode","RejectionReason","ModifiedUTC","ModifiedByUserID"]',
        @SucceededFlag = 1,
        @FailureMessage = NULL;

    COMMIT TRANSACTION;

    SELECT
        PortalUserID = @PortalUserID,
        AccountStatusCode = @RejectedAccountStatusCode,
        ModifiedUTC = SYSUTCDATETIME(),
        StatusMessage = @StatusMessage;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ActiveRoles AS
    (
        SELECT
            pur.PortalUserID,
            r.RoleCode
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND (pur.EffectiveStartUTC IS NULL OR pur.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (pur.EffectiveEndUTC IS NULL OR pur.EffectiveEndUTC > SYSUTCDATETIME())
          AND r.IsActive = 1
    ),
    RoleAgg AS
    (
        SELECT
            ar.PortalUserID,
            STRING_AGG(ar.RoleCode, N', ') WITHIN GROUP (ORDER BY ar.RoleCode) AS RoleCodes
        FROM ActiveRoles ar
        GROUP BY ar.PortalUserID
    ),
    SiteAgg AS
    (
        SELECT
            sua.PortalUserID,
            COUNT(DISTINCT sua.SiteID) AS SiteCount
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
        WHERE sua.IsActive = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
          AND s.IsDeleted = 0
        GROUP BY sua.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE WHEN pc.LockoutEndUTC IS NOT NULL AND pc.LockoutEndUTC > SYSUTCDATETIME() THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsLocked,
        pc.LockoutEndUTC,
        pu.LastLoginUTC,
        ISNULL(ra.RoleCodes, N'') AS RoleCodes,
        ISNULL(sa.SiteCount, 0) AS SiteCount,
        pu.IsActive
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    OUTER APPLY
    (
        SELECT TOP (1)
            c.LockoutEndUTC
        FROM sec.PortalCredential c
        WHERE c.PortalUserID = pu.PortalUserID
          AND c.IsDeleted = 0
          AND c.IsActive = 1
          AND c.IsPrimary = 1
        ORDER BY c.PortalCredentialID DESC
    ) pc
    LEFT JOIN RoleAgg ra
        ON ra.PortalUserID = pu.PortalUserID
    LEFT JOIN SiteAgg sa
        ON sa.PortalUserID = pu.PortalUserID
    WHERE pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY p.LastName, p.FirstName, pu.UserName;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminPortalUser_GetDetail
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH CredentialSnapshot AS
    (
        SELECT
            c.PortalUserID,
            c.LockoutEndUTC,
            ROW_NUMBER() OVER (PARTITION BY c.PortalUserID ORDER BY c.IsPrimary DESC, c.PortalCredentialID DESC) AS rn
        FROM sec.PortalCredential c
        WHERE c.IsDeleted = 0
    ),
    SessionSnapshot AS
    (
        SELECT
            ls.PortalUserID,
            MAX(ls.SessionStartedUTC) AS LastLoginUTC
        FROM sec.LoginSession ls
        GROUP BY ls.PortalUserID
    )
    SELECT
        pu.PortalUserID,
        pu.PersonID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        pu.MFAEnabled,
        CASE
            WHEN cs.LockoutEndUTC IS NOT NULL
             AND cs.LockoutEndUTC >= SYSUTCDATETIME() THEN CAST(1 AS bit)
            ELSE CAST(0 AS bit)
        END AS IsLocked,
        cs.LockoutEndUTC,
        ss.LastLoginUTC,
        pu.IsActive,
        pu.RejectionReason
    FROM party.PortalUser pu
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN CredentialSnapshot cs
        ON cs.PortalUserID = pu.PortalUserID
       AND cs.rn = 1
    LEFT JOIN SessionSnapshot ss
        ON ss.PortalUserID = pu.PortalUserID
    WHERE pu.PortalUserID = @PortalUserID
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0;

    SELECT
        r.RoleCode,
        r.RoleName,
        pur.EffectiveStartUTC,
        pur.EffectiveEndUTC,
        pur.IsActive
    FROM party.PortalUserRole pur
    INNER JOIN ref.Role r
        ON r.RoleID = pur.RoleID
    WHERE pur.PortalUserID = @PortalUserID
    ORDER BY pur.EffectiveStartUTC DESC, r.RoleCode;

    SELECT
        sua.SiteID,
        s.SiteName,
        pr.ProviderName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
    WHERE sua.PortalUserID = @PortalUserID
      AND s.IsDeleted = 0
      AND pr.IsDeleted = 0
    ORDER BY sua.EffectiveStartUTC DESC, s.SiteName;

    SELECT TOP (10)
        ls.LoginSessionID,
        statusCv.CodeValue AS SessionStatusCode,
        ls.SessionStartedUTC AS StartedUTC,
        ls.LastSeenUTC,
        ls.RevokedUTC,
        ls.RemoteAddress,
        ls.UserAgent
    FROM sec.LoginSession ls
    LEFT JOIN ref.CodeValue statusCv
        ON statusCv.CodeValueID = ls.SessionStatusCodeValueID
    WHERE ls.PortalUserID = @PortalUserID
    ORDER BY ls.SessionStartedUTC DESC, ls.LoginSessionID DESC;
END;
GO




CREATE OR ALTER PROCEDURE party.usp_AdminProvider_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH SiteCounts AS
    (
        SELECT
            s.ProviderID,
            COUNT(*) AS SiteCount,
            SUM(CASE WHEN s.IsDeleted = 0 AND s.IsActive = 1 THEN 1 ELSE 0 END) AS ActiveSiteCount
        FROM party.Site s
        WHERE s.IsDeleted = 0
        GROUP BY s.ProviderID
    ),
    PrimaryContacts AS
    (
        SELECT
            s.ProviderID,
            MIN(pu.UserName) AS PrimaryContactUserName
        FROM party.SiteUserAssignment sua
        INNER JOIN party.Site s
            ON s.SiteID = sua.SiteID
        INNER JOIN party.PortalUser pu
            ON pu.PortalUserID = sua.PortalUserID
        WHERE sua.IsActive = 1
          AND sua.IsPrimaryProviderContact = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
          AND s.IsDeleted = 0
          AND pu.IsDeleted = 0
        GROUP BY s.ProviderID
    )
    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        CASE
            WHEN lp.PersonID IS NULL THEN NULL
            ELSE LTRIM(RTRIM(CONCAT(lp.FirstName, N' ', lp.LastName)))
        END AS OwnerDisplayName,
        pr.BusinessEmail,
        pc.PrimaryContactUserName,
        ISNULL(sc.SiteCount, 0) AS SiteCount,
        ISNULL(sc.ActiveSiteCount, 0) AS ActiveSiteCount,
        pr.IsActive,
        pr.CreatedUTC
    FROM party.Provider pr
    LEFT JOIN party.Person lp
        ON lp.PersonID = pr.LicenseHolderPersonID
    LEFT JOIN SiteCounts sc
        ON sc.ProviderID = pr.ProviderID
    LEFT JOIN PrimaryContacts pc
        ON pc.ProviderID = pr.ProviderID
    WHERE pr.IsDeleted = 0
    ORDER BY pr.ProviderName, pr.ProviderID;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminProvider_GetDetail
    @ProviderID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pr.ProviderID,
        pr.ProviderName,
        pr.LegalEntityName,
        pr.BusinessEmail,
        CONCAT(lp.FirstName, N' ', lp.LastName) AS LicenseHolderDisplayName,
        pr.IsActive
    FROM party.Provider pr
    LEFT JOIN party.Person lp
        ON lp.PersonID = pr.LicenseHolderPersonID
    WHERE pr.ProviderID = @ProviderID
      AND pr.IsDeleted = 0;

    ;WITH RoleSnapshot AS
    (
        SELECT
            pur.PortalUserID,
            STRING_AGG(r.RoleCode, N', ') WITHIN GROUP (ORDER BY r.RoleCode) AS RoleCodes
        FROM party.PortalUserRole pur
        INNER JOIN ref.Role r
            ON r.RoleID = pur.RoleID
        WHERE pur.IsActive = 1
          AND pur.EffectiveEndUTC IS NULL
          AND r.IsActive = 1
        GROUP BY pur.PortalUserID
    )
    SELECT DISTINCT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        p.PrimaryEmail,
        pu.AccountStatusCode,
        ISNULL(rs.RoleCodes, N'') AS RoleCodes,
        sua.IsPrimaryProviderContact,
        pu.IsActive
    FROM party.Site s
    INNER JOIN party.SiteUserAssignment sua
        ON sua.SiteID = s.SiteID
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
    LEFT JOIN RoleSnapshot rs
        ON rs.PortalUserID = pu.PortalUserID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
      AND pu.IsDeleted = 0
      AND p.IsDeleted = 0
    ORDER BY DisplayName, pu.UserName;

    ;WITH AssignmentCounts AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS AssignedUserCount
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND sua.EffectiveEndUTC IS NULL
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        ISNULL(ac.AssignedUserCount, 0) AS AssignedUserCount,
        s.IsActive
    FROM party.Site s
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN AssignmentCounts ac
        ON ac.SiteID = s.SiteID
    WHERE s.ProviderID = @ProviderID
      AND s.IsDeleted = 0
    ORDER BY s.SiteName;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminSite_List
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ActiveAssignments AS
    (
        SELECT
            sua.SiteID,
            COUNT(*) AS ActiveUserCount,
            MAX(CASE WHEN sua.IsPrimaryProviderContact = 1 THEN sua.PortalUserID END) AS PrimaryContactUserID
        FROM party.SiteUserAssignment sua
        WHERE sua.IsActive = 1
          AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
          AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC > SYSUTCDATETIME())
        GROUP BY sua.SiteID
    )
    SELECT
        s.SiteID,
        s.ProviderID,
        s.SiteName,
        pr.ProviderName,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        s.LicenseNumber,
        pu.UserName AS PrimaryContactUserName,
        ISNULL(aa.ActiveUserCount, 0) AS AssignedUserCount,
        s.IsActive,
        s.CreatedUTC
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
    INNER JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    INNER JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    LEFT JOIN ActiveAssignments aa
        ON aa.SiteID = s.SiteID
    LEFT JOIN party.PortalUser pu
        ON pu.PortalUserID = aa.PrimaryContactUserID
    WHERE s.IsDeleted = 0
      AND pr.IsDeleted = 0
    ORDER BY pr.ProviderName, s.SiteName, s.SiteID;
END;
GO



CREATE OR ALTER PROCEDURE party.usp_AdminSite_GetDetail
    @SiteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        s.SiteID,
        s.ProviderID,
        pr.ProviderName,
        s.SiteName,
        s.LicenseNumber,
        lc.LicenseClassCode,
        lc.LicenseClassName,
        tz.TimeZoneCode,
        tz.DisplayName AS TimeZoneDisplayName,
        s.IsActive
    FROM party.Site s
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    LEFT JOIN lic.LicenseClass lc
        ON lc.LicenseClassID = s.LicenseClassID
    LEFT JOIN ref.TimeZone tz
        ON tz.TimeZoneID = s.TimeZoneID
    WHERE s.SiteID = @SiteID
      AND s.IsDeleted = 0;

    SELECT
        pu.PortalUserID,
        CONCAT(p.FirstName, N' ', p.LastName) AS DisplayName,
        pu.UserName,
        sua.AssignmentTypeCode,
        sua.IsPrimaryProviderContact,
        sua.EffectiveStartUTC,
        sua.EffectiveEndUTC,
        sua.IsActive
    FROM party.SiteUserAssignment sua
    INNER JOIN party.PortalUser pu
        ON pu.PortalUserID = sua.PortalUserID
       AND pu.IsDeleted = 0
    INNER JOIN party.Person p
        ON p.PersonID = pu.PersonID
       AND p.IsDeleted = 0
    WHERE sua.SiteID = @SiteID
    ORDER BY sua.EffectiveStartUTC DESC, DisplayName;
END;
GO

