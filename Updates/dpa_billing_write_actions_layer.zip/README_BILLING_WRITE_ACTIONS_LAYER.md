This overlay adds the billing write-actions layer for the provider portal.

What it covers:
- provider rate schedule maintenance
- family billing account maintenance
- charge entry
- invoice generation from pending charges
- payment posting screens

Included stored procedures:
- billing.usp_BillingCodeValue_List
- billing.usp_ProviderBillingWriteContext_Get
- billing.usp_FamilyInvoice_GenerateFromPendingCharges

Included C#:
- provider billing write models
- IProviderBillingWriteService
- ProviderBillingWriteService

Included Razor pages:
- /provider/billing/rates/manage
- /provider/billing/families/manage
- /provider/billing/charges/new
- /provider/billing/invoices/generate
- /provider/billing/payments/post

Important:
- all procedures are CREATE OR ALTER
- this assumes the billing schema foundation and billing procedures layer already exist
- payment posting records payment rows and updates balances, but still does not call external processors
- invoice generation consumes pending family charges and rolls them into a family invoice
