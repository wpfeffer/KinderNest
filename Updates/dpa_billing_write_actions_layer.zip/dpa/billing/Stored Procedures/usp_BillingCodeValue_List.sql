CREATE OR ALTER PROCEDURE billing.usp_BillingCodeValue_List
    @CodeDomain NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        cv.CodeValueID,
        cv.CodeDomain,
        cv.CodeValue,
        cv.CodeName
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = @CodeDomain
      AND cv.IsActive = 1
    ORDER BY cv.CodeName, cv.CodeValue;
END;
GO
