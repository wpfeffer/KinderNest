CREATE OR ALTER PROCEDURE billing.usp_FamilyInvoice_GenerateFromPendingCharges
    @FamilyBillingAccountID      INT,
    @BillingPeriodStartUTC       DATETIME2(0),
    @BillingPeriodEndUTC         DATETIME2(0),
    @DueUTC                      DATETIME2(0) = NULL,
    @CreateAsDraft               BIT = 0,
    @Notes                       NVARCHAR(1000) = NULL,
    @CreatedByUserID             INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @HouseholdID INT;
    DECLARE @InvoiceStatusCodeValueID INT;
    DECLARE @PendingChargeStatusCodeValueID INT;
    DECLARE @InvoicedChargeStatusCodeValueID INT;
    DECLARE @TuitionLineTypeCodeValueID INT;
    DECLARE @FeeLineTypeCodeValueID INT;
    DECLARE @DiscountLineTypeCodeValueID INT;
    DECLARE @FamilyInvoiceID INT;
    DECLARE @InvoiceNumber NVARCHAR(50);
    DECLARE @SubtotalAmount DECIMAL(18,2);
    DECLARE @TaxAmount DECIMAL(18,2);
    DECLARE @TotalAmount DECIMAL(18,2);

    SELECT @HouseholdID = fba.HouseholdID
    FROM billing.FamilyBillingAccount fba
    WHERE fba.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fba.IsDeleted = 0
      AND fba.IsActive = 1;

    IF @HouseholdID IS NULL
    BEGIN
        THROW 54201, 'Family billing account not found for invoice generation.', 1;
    END;

    SELECT @InvoiceStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceStatus'
      AND cv.CodeValue = CASE WHEN @CreateAsDraft = 1 THEN N'DRAFT' ELSE N'ISSUED' END;

    SELECT @PendingChargeStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'FamilyChargeStatus'
      AND cv.CodeValue = N'PENDING';

    SELECT @InvoicedChargeStatusCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'FamilyChargeStatus'
      AND cv.CodeValue = N'INVOICED';

    SELECT @TuitionLineTypeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceLineType'
      AND cv.CodeValue = N'TUITION';

    SELECT @FeeLineTypeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceLineType'
      AND cv.CodeValue = N'FEE';

    SELECT @DiscountLineTypeCodeValueID = cv.CodeValueID
    FROM ref.CodeValue cv
    WHERE cv.CodeDomain = N'InvoiceLineType'
      AND cv.CodeValue = N'DISCOUNT';

    IF NOT EXISTS
    (
        SELECT 1
        FROM billing.FamilyCharge fc
        WHERE fc.FamilyBillingAccountID = @FamilyBillingAccountID
          AND fc.IsDeleted = 0
          AND fc.IsActive = 1
          AND fc.FamilyInvoiceLineID IS NULL
          AND fc.ChargeStatusCodeValueID = @PendingChargeStatusCodeValueID
          AND fc.ServiceDate >= CONVERT(date, @BillingPeriodStartUTC)
          AND fc.ServiceDate <= CONVERT(date, @BillingPeriodEndUTC)
    )
    BEGIN
        THROW 54202, 'No pending charges were found for the selected billing period.', 1;
    END;

    SELECT
        @SubtotalAmount = SUM(CASE WHEN fc.ChargeAmount - fc.DiscountAmount < 0 THEN 0 ELSE fc.ChargeAmount - fc.DiscountAmount END),
        @TaxAmount = SUM(fc.TaxAmount)
    FROM billing.FamilyCharge fc
    WHERE fc.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fc.IsDeleted = 0
      AND fc.IsActive = 1
      AND fc.FamilyInvoiceLineID IS NULL
      AND fc.ChargeStatusCodeValueID = @PendingChargeStatusCodeValueID
      AND fc.ServiceDate >= CONVERT(date, @BillingPeriodStartUTC)
      AND fc.ServiceDate <= CONVERT(date, @BillingPeriodEndUTC);

    SET @SubtotalAmount = ISNULL(@SubtotalAmount, 0.00);
    SET @TaxAmount = ISNULL(@TaxAmount, 0.00);
    SET @TotalAmount = @SubtotalAmount + @TaxAmount;

    SET @InvoiceNumber = CONCAT(
        N'FINV-',
        @HouseholdID,
        N'-',
        CONVERT(NVARCHAR(8), CONVERT(date, SYSUTCDATETIME()), 112),
        N'-',
        RIGHT(CONVERT(NVARCHAR(20), ABS(CHECKSUM(NEWID()))), 6)
    );

    BEGIN TRANSACTION;

    INSERT INTO billing.FamilyInvoice
    (
        FamilyBillingAccountID,
        InvoiceStatusCodeValueID,
        InvoiceNumber,
        BillingPeriodStartUTC,
        BillingPeriodEndUTC,
        DueUTC,
        SubtotalAmount,
        TaxAmount,
        TotalAmount,
        BalanceAmount,
        Notes,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    VALUES
    (
        @FamilyBillingAccountID,
        @InvoiceStatusCodeValueID,
        @InvoiceNumber,
        @BillingPeriodStartUTC,
        @BillingPeriodEndUTC,
        @DueUTC,
        @SubtotalAmount,
        @TaxAmount,
        @TotalAmount,
        @TotalAmount,
        NULLIF(@Notes, N''),
        1,
        0,
        @CreatedByUserID
    );

    SET @FamilyInvoiceID = CONVERT(INT, SCOPE_IDENTITY());

    INSERT INTO billing.FamilyInvoiceLine
    (
        FamilyInvoiceID,
        FamilyChargeID,
        LineTypeCodeValueID,
        Description,
        QuantityDecimal,
        UnitPriceAmount,
        LineAmount,
        RelatedChildID,
        IsActive,
        IsDeleted,
        CreatedByUserID
    )
    SELECT
        @FamilyInvoiceID,
        fc.FamilyChargeID,
        CASE
            WHEN ctype.CodeValue = N'TUITION' THEN ISNULL(@TuitionLineTypeCodeValueID, @FeeLineTypeCodeValueID)
            WHEN ctype.CodeValue = N'DISCOUNT' THEN ISNULL(@DiscountLineTypeCodeValueID, @FeeLineTypeCodeValueID)
            ELSE @FeeLineTypeCodeValueID
        END,
        fc.Description,
        fc.QuantityDecimal,
        fc.UnitPriceAmount,
        CASE WHEN fc.ChargeAmount - fc.DiscountAmount < 0 THEN 0 ELSE fc.ChargeAmount - fc.DiscountAmount END,
        fc.ChildID,
        1,
        0,
        @CreatedByUserID
    FROM billing.FamilyCharge fc
    INNER JOIN ref.CodeValue ctype
        ON ctype.CodeValueID = fc.ChargeTypeCodeValueID
    WHERE fc.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fc.IsDeleted = 0
      AND fc.IsActive = 1
      AND fc.FamilyInvoiceLineID IS NULL
      AND fc.ChargeStatusCodeValueID = @PendingChargeStatusCodeValueID
      AND fc.ServiceDate >= CONVERT(date, @BillingPeriodStartUTC)
      AND fc.ServiceDate <= CONVERT(date, @BillingPeriodEndUTC);

    UPDATE fc
       SET fc.FamilyInvoiceLineID = fil.FamilyInvoiceLineID,
           fc.ChargeStatusCodeValueID = @InvoicedChargeStatusCodeValueID,
           fc.ModifiedUTC = SYSUTCDATETIME(),
           fc.ModifiedByUserID = @CreatedByUserID
    FROM billing.FamilyCharge fc
    INNER JOIN billing.FamilyInvoiceLine fil
        ON fil.FamilyChargeID = fc.FamilyChargeID
       AND fil.FamilyInvoiceID = @FamilyInvoiceID
       AND fil.IsDeleted = 0
    WHERE fc.IsDeleted = 0;

    UPDATE fba
       SET CurrentBalanceAmount =
           ISNULL(
               (
                   SELECT SUM(fi.BalanceAmount)
                   FROM billing.FamilyInvoice fi
                   WHERE fi.FamilyBillingAccountID = fba.FamilyBillingAccountID
                     AND fi.IsDeleted = 0
                     AND fi.IsActive = 1
               ),
               0.00
           ),
           ModifiedUTC = SYSUTCDATETIME(),
           ModifiedByUserID = @CreatedByUserID
    FROM billing.FamilyBillingAccount fba
    WHERE fba.FamilyBillingAccountID = @FamilyBillingAccountID
      AND fba.IsDeleted = 0;

    COMMIT TRANSACTION;

    SELECT
        FamilyInvoiceID = @FamilyInvoiceID,
        InvoiceNumber = @InvoiceNumber,
        SubtotalAmount = @SubtotalAmount,
        TaxAmount = @TaxAmount,
        TotalAmount = @TotalAmount;
END;
GO
