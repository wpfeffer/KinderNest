using System.Data;
using DaycareProviderAssistant.Auth.Services;
using DaycareProviderAssistant.Billing.Models;
using Microsoft.Data.SqlClient;
using static DaycareProviderAssistant.Portal.Services.PortalDataReaderHelpers;

namespace DaycareProviderAssistant.Billing.Services;

public sealed class ProviderBillingWriteService : IProviderBillingWriteService
{
    private const string ContextProcedureName = "billing.usp_ProviderBillingWriteContext_Get";
    private const string CodeListProcedureName = "billing.usp_BillingCodeValue_List";
    private const string RateScheduleUpsertProcedureName = "billing.usp_ProviderRateSchedule_Upsert";
    private const string FamilyBillingAccountUpsertProcedureName = "billing.usp_FamilyBillingAccount_Upsert";
    private const string FamilyChargeUpsertProcedureName = "billing.usp_FamilyCharge_Upsert";
    private const string FamilyInvoiceGenerateProcedureName = "billing.usp_FamilyInvoice_GenerateFromPendingCharges";
    private const string FamilyPaymentRecordProcedureName = "billing.usp_FamilyPayment_Record";
    private const string FamilyInvoiceListProcedureName = "billing.usp_FamilyInvoice_List";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<ProviderBillingWriteService> _logger;

    public ProviderBillingWriteService(ISqlConnectionFactory connectionFactory, ILogger<ProviderBillingWriteService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<ProviderBillingWriteContextDto> GetWriteContextAsync(int portalUserId, int? familyBillingAccountId = null, CancellationToken cancellationToken = default)
    {
        var providers = new List<ProviderBillingWriteProviderDto>();
        var sites = new List<ProviderBillingWriteSiteDto>();
        var households = new List<ProviderBillingWriteHouseholdDto>();
        var familyAccounts = new List<ProviderBillingWriteFamilyAccountDto>();
        var rateSchedules = new List<ProviderBillingWriteRateScheduleDto>();
        var processorAccounts = new List<ProviderBillingProcessorAccountDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = ContextProcedureName;
        command.Parameters.Add(new SqlParameter("@PortalUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                providers.Add(new ProviderBillingWriteProviderDto
                {
                    ProviderId = GetInt32(reader, "ProviderID"),
                    ProviderName = GetString(reader, "ProviderName")
                });
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    sites.Add(new ProviderBillingWriteSiteDto
                    {
                        SiteId = GetInt32(reader, "SiteID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        SiteName = GetString(reader, "SiteName")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    households.Add(new ProviderBillingWriteHouseholdDto
                    {
                        HouseholdId = GetInt32(reader, "HouseholdID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        ProviderName = GetString(reader, "ProviderName"),
                        HouseholdDisplayName = GetString(reader, "HouseholdDisplayName"),
                        PrimaryContactPersonId = GetNullableInt32(reader, "PrimaryContactPersonID"),
                        PrimaryContactDisplayName = GetNullableString(reader, "PrimaryContactDisplayName"),
                        PrimaryContactEmail = GetNullableString(reader, "PrimaryContactEmail")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    familyAccounts.Add(new ProviderBillingWriteFamilyAccountDto
                    {
                        FamilyBillingAccountId = GetInt32(reader, "FamilyBillingAccountID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        HouseholdId = GetInt32(reader, "HouseholdID"),
                        HouseholdDisplayName = GetString(reader, "HouseholdDisplayName"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SiteName = GetNullableString(reader, "SiteName"),
                        AccountStatusCodeValueId = GetInt32(reader, "AccountStatusCodeValueID"),
                        AccountStatusCode = GetString(reader, "AccountStatusCode"),
                        BillingFrequencyCodeValueId = GetInt32(reader, "BillingFrequencyCodeValueID"),
                        BillingFrequencyCode = GetString(reader, "BillingFrequencyCode"),
                        BillingDayOfMonth = GetNullableByte(reader, "BillingDayOfMonth"),
                        PrimaryBillingContactPersonId = GetNullableInt32(reader, "PrimaryBillingContactPersonID"),
                        BillingContactDisplayName = GetNullableString(reader, "BillingContactDisplayName"),
                        BillingEmail = GetNullableString(reader, "BillingEmail"),
                        CurrentBalanceAmount = GetDecimal(reader, "CurrentBalanceAmount"),
                        CreditLimitAmount = GetNullableDecimal(reader, "CreditLimitAmount"),
                        LateFeeGraceDays = GetNullableInt32(reader, "LateFeeGraceDays"),
                        Notes = GetNullableString(reader, "Notes"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    rateSchedules.Add(new ProviderBillingWriteRateScheduleDto
                    {
                        ProviderRateScheduleId = GetInt32(reader, "ProviderRateScheduleID"),
                        ProviderId = GetInt32(reader, "ProviderID"),
                        SiteId = GetNullableInt32(reader, "SiteID"),
                        SiteName = GetNullableString(reader, "SiteName"),
                        RateName = GetString(reader, "RateName"),
                        RateTypeCodeValueId = GetInt32(reader, "RateTypeCodeValueID"),
                        RateTypeCode = GetString(reader, "RateTypeCode"),
                        BillingFrequencyCodeValueId = GetNullableInt32(reader, "BillingFrequencyCodeValueID"),
                        BillingFrequencyCode = GetNullableString(reader, "BillingFrequencyCode"),
                        StandardAmount = GetDecimal(reader, "StandardAmount"),
                        StandardQuantityDecimal = GetDecimal(reader, "StandardQuantityDecimal"),
                        AppliesPerChild = GetBoolean(reader, "AppliesPerChild"),
                        TaxableFlag = GetBoolean(reader, "TaxableFlag"),
                        EffectiveStartDate = GetDateOnly(reader, "EffectiveStartDate"),
                        EffectiveEndDate = GetNullableDateOnly(reader, "EffectiveEndDate"),
                        Notes = GetNullableString(reader, "Notes"),
                        IsActive = GetBoolean(reader, "IsActive")
                    });
                }
            }

            if (await reader.NextResultAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken))
                {
                    processorAccounts.Add(new ProviderBillingProcessorAccountDto
                    {
                        BillingProviderAccountId = GetInt32(reader, "BillingProviderAccountID"),
                        ProviderId = GetNullableInt32(reader, "ProviderID"),
                        DisplayName = GetString(reader, "DisplayName"),
                        AccountUseTypeCodeValueId = GetInt32(reader, "AccountUseTypeCodeValueID"),
                        AccountUseTypeCode = GetString(reader, "AccountUseTypeCode"),
                        ProcessorTypeCodeValueId = GetInt32(reader, "ProcessorTypeCodeValueID"),
                        ProcessorTypeCode = GetString(reader, "ProcessorTypeCode"),
                        ProcessorTypeName = GetString(reader, "ProcessorTypeName"),
                        SettlementCurrencyCode = GetString(reader, "SettlementCurrencyCode"),
                        IsPrimary = GetBoolean(reader, "IsPrimary"),
                        MerchantAccountReference = GetNullableString(reader, "MerchantAccountReference"),
                        ExternalAccountReference = GetNullableString(reader, "ExternalAccountReference")
                    });
                }
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Provider billing write context failed while executing {ProcedureName}.", ContextProcedureName);
            throw;
        }

        var providerRateTypes = await GetCodeOptionsAsync("ProviderRateType", cancellationToken);
        var billingFrequencies = await GetCodeOptionsAsync("BillingFrequency", cancellationToken);
        var familyBillingStatuses = await GetCodeOptionsAsync("FamilyBillingAccountStatus", cancellationToken);
        var familyChargeTypes = await GetCodeOptionsAsync("FamilyChargeType", cancellationToken);
        var openInvoices = familyBillingAccountId.HasValue
            ? await GetOpenInvoicesAsync(familyBillingAccountId.Value, cancellationToken)
            : Array.Empty<FamilyInvoiceOptionDto>();

        return new ProviderBillingWriteContextDto
        {
            Providers = providers,
            Sites = sites,
            Households = households,
            FamilyAccounts = familyAccounts,
            RateSchedules = rateSchedules,
            ProcessorAccounts = processorAccounts,
            ProviderRateTypes = providerRateTypes,
            BillingFrequencies = billingFrequencies,
            FamilyBillingAccountStatuses = familyBillingStatuses,
            FamilyChargeTypes = familyChargeTypes,
            OpenInvoices = openInvoices
        };
    }

    public async Task<BillingWriteOutcomeDto> SaveRateScheduleAsync(int portalUserId, ProviderRateScheduleEditRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var context = await GetWriteContextAsync(portalUserId, null, cancellationToken);
        var provider = context.Providers.FirstOrDefault();
        if (provider is null)
        {
            return Failed("No accessible provider scope was found for the current portal user.");
        }

        if (request.SiteId.HasValue && !context.Sites.Any(x => x.SiteId == request.SiteId.Value && x.ProviderId == provider.ProviderId))
        {
            return Failed("The selected site is not accessible to the current provider user.");
        }

        if (!request.RateTypeCodeValueId.HasValue || !context.ProviderRateTypes.Any(x => x.CodeValueId == request.RateTypeCodeValueId.Value))
        {
            return Failed("Choose a valid rate type.");
        }

        if (request.BillingFrequencyCodeValueId.HasValue && !context.BillingFrequencies.Any(x => x.CodeValueId == request.BillingFrequencyCodeValueId.Value))
        {
            return Failed("Choose a valid billing frequency.");
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = RateScheduleUpsertProcedureName;
        command.Parameters.Add(new SqlParameter("@ProviderRateScheduleID", SqlDbType.Int) { Value = (object?)request.ProviderRateScheduleId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@ProviderID", SqlDbType.Int) { Value = provider.ProviderId });
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = (object?)request.SiteId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@RateName", SqlDbType.NVarChar, 200) { Value = request.RateName.Trim() });
        command.Parameters.Add(new SqlParameter("@RateTypeCodeValueID", SqlDbType.Int) { Value = request.RateTypeCodeValueId!.Value });
        command.Parameters.Add(new SqlParameter("@BillingFrequencyCodeValueID", SqlDbType.Int) { Value = (object?)request.BillingFrequencyCodeValueId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@StandardAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.StandardAmount });
        command.Parameters.Add(new SqlParameter("@StandardQuantityDecimal", SqlDbType.Decimal) { Precision = 18, Scale = 4, Value = request.StandardQuantityDecimal });
        command.Parameters.Add(new SqlParameter("@AppliesPerChild", SqlDbType.Bit) { Value = request.AppliesPerChild });
        command.Parameters.Add(new SqlParameter("@TaxableFlag", SqlDbType.Bit) { Value = request.TaxableFlag });
        command.Parameters.Add(new SqlParameter("@EffectiveStartDate", SqlDbType.Date) { Value = request.EffectiveStartDate!.Value.ToDateTime(TimeOnly.MinValue) });
        command.Parameters.Add(new SqlParameter("@EffectiveEndDate", SqlDbType.Date) { Value = request.EffectiveEndDate.HasValue ? request.EffectiveEndDate.Value.ToDateTime(TimeOnly.MinValue) : DBNull.Value });
        command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 1000) { Value = string.IsNullOrWhiteSpace(request.Notes) ? DBNull.Value : request.Notes.Trim() });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var entityId = await reader.ReadAsync(cancellationToken) ? GetInt32(reader, "ProviderRateScheduleID") : 0;
            return new BillingWriteOutcomeDto { Succeeded = true, Message = "Rate schedule saved.", EntityId = entityId > 0 ? entityId : null };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Rate schedule upsert failed while executing {ProcedureName}.", RateScheduleUpsertProcedureName);
            return Failed(ex.Message);
        }
    }

    public async Task<BillingWriteOutcomeDto> SaveFamilyBillingAccountAsync(int portalUserId, FamilyBillingAccountEditRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var context = await GetWriteContextAsync(portalUserId, null, cancellationToken);
        var provider = context.Providers.FirstOrDefault();
        if (provider is null)
        {
            return Failed("No accessible provider scope was found for the current portal user.");
        }

        if (!request.HouseholdId.HasValue || !context.Households.Any(x => x.HouseholdId == request.HouseholdId.Value && x.ProviderId == provider.ProviderId))
        {
            return Failed("Choose a valid household before saving the billing account.");
        }

        if (request.SiteId.HasValue && !context.Sites.Any(x => x.SiteId == request.SiteId.Value && x.ProviderId == provider.ProviderId))
        {
            return Failed("The selected site is not accessible to the current provider user.");
        }

        if (!request.AccountStatusCodeValueId.HasValue || !context.FamilyBillingAccountStatuses.Any(x => x.CodeValueId == request.AccountStatusCodeValueId.Value))
        {
            return Failed("Choose a valid billing account status.");
        }

        if (!request.BillingFrequencyCodeValueId.HasValue || !context.BillingFrequencies.Any(x => x.CodeValueId == request.BillingFrequencyCodeValueId.Value))
        {
            return Failed("Choose a valid billing frequency.");
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyBillingAccountUpsertProcedureName;
        command.Parameters.Add(new SqlParameter("@FamilyBillingAccountID", SqlDbType.Int) { Value = (object?)request.FamilyBillingAccountId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@ProviderID", SqlDbType.Int) { Value = provider.ProviderId });
        command.Parameters.Add(new SqlParameter("@HouseholdID", SqlDbType.Int) { Value = request.HouseholdId!.Value });
        command.Parameters.Add(new SqlParameter("@SiteID", SqlDbType.Int) { Value = (object?)request.SiteId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@AccountStatusCodeValueID", SqlDbType.Int) { Value = request.AccountStatusCodeValueId!.Value });
        command.Parameters.Add(new SqlParameter("@BillingFrequencyCodeValueID", SqlDbType.Int) { Value = request.BillingFrequencyCodeValueId!.Value });
        command.Parameters.Add(new SqlParameter("@BillingDayOfMonth", SqlDbType.TinyInt) { Value = (object?)request.BillingDayOfMonth ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@PrimaryBillingContactPersonID", SqlDbType.Int) { Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@BillingEmail", SqlDbType.NVarChar, 320) { Value = string.IsNullOrWhiteSpace(request.BillingEmail) ? DBNull.Value : request.BillingEmail.Trim() });
        command.Parameters.Add(new SqlParameter("@CurrentBalanceAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.CurrentBalanceAmount });
        command.Parameters.Add(new SqlParameter("@CreditLimitAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = (object?)request.CreditLimitAmount ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@LateFeeGraceDays", SqlDbType.Int) { Value = (object?)request.LateFeeGraceDays ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 1000) { Value = string.IsNullOrWhiteSpace(request.Notes) ? DBNull.Value : request.Notes.Trim() });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var entityId = await reader.ReadAsync(cancellationToken) ? GetInt32(reader, "FamilyBillingAccountID") : 0;
            return new BillingWriteOutcomeDto { Succeeded = true, Message = "Family billing account saved.", EntityId = entityId > 0 ? entityId : null };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Family billing account upsert failed while executing {ProcedureName}.", FamilyBillingAccountUpsertProcedureName);
            return Failed(ex.Message);
        }
    }

    public async Task<BillingWriteOutcomeDto> SaveChargeAsync(int portalUserId, FamilyChargeEntryRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var context = await GetWriteContextAsync(portalUserId, request.FamilyBillingAccountId, cancellationToken);

        if (!request.FamilyBillingAccountId.HasValue || !context.FamilyAccounts.Any(x => x.FamilyBillingAccountId == request.FamilyBillingAccountId.Value))
        {
            return Failed("Choose a valid family billing account.");
        }

        if (!request.ChargeTypeCodeValueId.HasValue || !context.FamilyChargeTypes.Any(x => x.CodeValueId == request.ChargeTypeCodeValueId.Value))
        {
            return Failed("Choose a valid charge type.");
        }

        var pendingStatusCodeValueId = await GetCodeValueIdAsync("FamilyChargeStatus", "PENDING", cancellationToken);
        if (!pendingStatusCodeValueId.HasValue)
        {
            return Failed("The pending family charge status could not be resolved.");
        }

        var calculatedChargeAmount = Math.Round(request.QuantityDecimal * request.UnitPriceAmount, 2, MidpointRounding.AwayFromZero);

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyChargeUpsertProcedureName;
        command.Parameters.Add(new SqlParameter("@FamilyChargeID", SqlDbType.Int) { Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@FamilyBillingAccountID", SqlDbType.Int) { Value = request.FamilyBillingAccountId!.Value });
        command.Parameters.Add(new SqlParameter("@ChildID", SqlDbType.Int) { Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@ChargeTypeCodeValueID", SqlDbType.Int) { Value = request.ChargeTypeCodeValueId!.Value });
        command.Parameters.Add(new SqlParameter("@ChargeStatusCodeValueID", SqlDbType.Int) { Value = pendingStatusCodeValueId.Value });
        command.Parameters.Add(new SqlParameter("@ServiceDate", SqlDbType.Date) { Value = request.ServiceDate!.Value.ToDateTime(TimeOnly.MinValue) });
        command.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar, 500) { Value = request.Description.Trim() });
        command.Parameters.Add(new SqlParameter("@QuantityDecimal", SqlDbType.Decimal) { Precision = 18, Scale = 4, Value = request.QuantityDecimal });
        command.Parameters.Add(new SqlParameter("@UnitPriceAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.UnitPriceAmount });
        command.Parameters.Add(new SqlParameter("@ChargeAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = calculatedChargeAmount });
        command.Parameters.Add(new SqlParameter("@TaxAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.TaxAmount });
        command.Parameters.Add(new SqlParameter("@DiscountAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.DiscountAmount });
        command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 1000) { Value = string.IsNullOrWhiteSpace(request.Notes) ? DBNull.Value : request.Notes.Trim() });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var entityId = await reader.ReadAsync(cancellationToken) ? GetInt32(reader, "FamilyChargeID") : 0;
            return new BillingWriteOutcomeDto { Succeeded = true, Message = "Charge saved.", EntityId = entityId > 0 ? entityId : null };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Family charge upsert failed while executing {ProcedureName}.", FamilyChargeUpsertProcedureName);
            return Failed(ex.Message);
        }
    }

    public async Task<BillingWriteOutcomeDto> GenerateInvoiceAsync(int portalUserId, FamilyInvoiceGenerationRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var context = await GetWriteContextAsync(portalUserId, request.FamilyBillingAccountId, cancellationToken);

        if (!request.FamilyBillingAccountId.HasValue || !context.FamilyAccounts.Any(x => x.FamilyBillingAccountId == request.FamilyBillingAccountId.Value))
        {
            return Failed("Choose a valid family billing account.");
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyInvoiceGenerateProcedureName;
        command.Parameters.Add(new SqlParameter("@FamilyBillingAccountID", SqlDbType.Int) { Value = request.FamilyBillingAccountId!.Value });
        command.Parameters.Add(new SqlParameter("@BillingPeriodStartUTC", SqlDbType.DateTime2) { Value = request.BillingPeriodStartUtc!.Value });
        command.Parameters.Add(new SqlParameter("@BillingPeriodEndUTC", SqlDbType.DateTime2) { Value = request.BillingPeriodEndUtc!.Value });
        command.Parameters.Add(new SqlParameter("@DueUTC", SqlDbType.DateTime2) { Value = (object?)request.DueUtc ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@CreateAsDraft", SqlDbType.Bit) { Value = request.CreateAsDraft });
        command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 1000) { Value = string.IsNullOrWhiteSpace(request.Notes) ? DBNull.Value : request.Notes.Trim() });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (await reader.ReadAsync(cancellationToken))
            {
                return new BillingWriteOutcomeDto
                {
                    Succeeded = true,
                    Message = "Invoice generated from pending charges.",
                    EntityId = GetInt32(reader, "FamilyInvoiceID"),
                    EntityNumber = GetString(reader, "InvoiceNumber")
                };
            }

            return Failed("The invoice generation procedure returned no result.");
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Family invoice generation failed while executing {ProcedureName}.", FamilyInvoiceGenerateProcedureName);
            return Failed(ex.Message);
        }
    }

    public async Task<BillingWriteOutcomeDto> PostPaymentAsync(int portalUserId, FamilyPaymentPostRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var context = await GetWriteContextAsync(portalUserId, request.FamilyBillingAccountId, cancellationToken);

        if (!request.FamilyBillingAccountId.HasValue || !context.FamilyAccounts.Any(x => x.FamilyBillingAccountId == request.FamilyBillingAccountId.Value))
        {
            return Failed("Choose a valid family billing account.");
        }

        if (!request.BillingProviderAccountId.HasValue || !context.ProcessorAccounts.Any(x => x.BillingProviderAccountId == request.BillingProviderAccountId.Value))
        {
            return Failed("Choose a valid provider-family billing processor account.");
        }

        if (request.FamilyInvoiceId.HasValue && !context.OpenInvoices.Any(x => x.FamilyInvoiceId == request.FamilyInvoiceId.Value))
        {
            return Failed("The selected family invoice is not open or not accessible.");
        }

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyPaymentRecordProcedureName;
        command.Parameters.Add(new SqlParameter("@BillingProviderAccountID", SqlDbType.Int) { Value = request.BillingProviderAccountId!.Value });
        command.Parameters.Add(new SqlParameter("@FamilyBillingAccountID", SqlDbType.Int) { Value = request.FamilyBillingAccountId!.Value });
        command.Parameters.Add(new SqlParameter("@FamilyInvoiceID", SqlDbType.Int) { Value = (object?)request.FamilyInvoiceId ?? DBNull.Value });
        command.Parameters.Add(new SqlParameter("@PaymentMethodTokenID", SqlDbType.Int) { Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@PaymentStatusCodeValueID", SqlDbType.Int) { Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@ExternalTransactionReference", SqlDbType.NVarChar, 200) { Value = string.IsNullOrWhiteSpace(request.ExternalTransactionReference) ? DBNull.Value : request.ExternalTransactionReference.Trim() });
        command.Parameters.Add(new SqlParameter("@PaymentUTC", SqlDbType.DateTime2) { Value = DateTime.UtcNow });
        command.Parameters.Add(new SqlParameter("@Amount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = request.Amount });
        command.Parameters.Add(new SqlParameter("@CurrencyCode", SqlDbType.NChar, 3) { Value = "USD" });
        command.Parameters.Add(new SqlParameter("@ProcessorFeeAmount", SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = DBNull.Value });
        command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 1000) { Value = string.IsNullOrWhiteSpace(request.Notes) ? DBNull.Value : request.Notes.Trim() });
        command.Parameters.Add(new SqlParameter("@CreatedByUserID", SqlDbType.Int) { Value = portalUserId });

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var entityId = await reader.ReadAsync(cancellationToken) ? GetInt32(reader, "PaymentID") : 0;
            return new BillingWriteOutcomeDto { Succeeded = true, Message = "Payment posted.", EntityId = entityId > 0 ? entityId : null };
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Family payment record failed while executing {ProcedureName}.", FamilyPaymentRecordProcedureName);
            return Failed(ex.Message);
        }
    }

    private async Task<IReadOnlyList<BillingCodeOptionDto>> GetCodeOptionsAsync(string codeDomain, CancellationToken cancellationToken)
    {
        var results = new List<BillingCodeOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = CodeListProcedureName;
        command.Parameters.Add(new SqlParameter("@CodeDomain", SqlDbType.NVarChar, 100) { Value = codeDomain });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new BillingCodeOptionDto
            {
                CodeValueId = GetInt32(reader, "CodeValueID"),
                CodeDomain = GetString(reader, "CodeDomain"),
                CodeValue = GetString(reader, "CodeValue"),
                CodeName = GetString(reader, "CodeName")
            });
        }

        return results;
    }

    private async Task<int?> GetCodeValueIdAsync(string codeDomain, string codeValue, CancellationToken cancellationToken)
    {
        var options = await GetCodeOptionsAsync(codeDomain, cancellationToken);
        return options.FirstOrDefault(x => string.Equals(x.CodeValue, codeValue, StringComparison.OrdinalIgnoreCase))?.CodeValueId;
    }

    private async Task<IReadOnlyList<FamilyInvoiceOptionDto>> GetOpenInvoicesAsync(int familyBillingAccountId, CancellationToken cancellationToken)
    {
        var results = new List<FamilyInvoiceOptionDto>();

        await using var connection = await _connectionFactory.OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = FamilyInvoiceListProcedureName;
        command.Parameters.Add(new SqlParameter("@FamilyBillingAccountID", SqlDbType.Int) { Value = familyBillingAccountId });

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var balanceAmount = GetDecimal(reader, "BalanceAmount");
            if (balanceAmount <= 0)
            {
                continue;
            }

            results.Add(new FamilyInvoiceOptionDto
            {
                FamilyInvoiceId = GetInt32(reader, "FamilyInvoiceID"),
                InvoiceNumber = GetString(reader, "InvoiceNumber"),
                InvoiceStatusCode = GetString(reader, "InvoiceStatusCode"),
                InvoiceStatusName = GetString(reader, "InvoiceStatusName"),
                IssuedUtc = GetDateTime(reader, "IssuedUTC"),
                DueUtc = GetNullableDateTime(reader, "DueUTC"),
                TotalAmount = GetDecimal(reader, "TotalAmount"),
                BalanceAmount = balanceAmount
            });
        }

        return results;
    }

    private static BillingWriteOutcomeDto Failed(string message)
        => new()
        {
            Succeeded = false,
            Message = message
        };

    private static byte? GetNullableByte(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetByte(ordinal);
    }

    private static decimal? GetNullableDecimal(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetDecimal(ordinal);
    }
}
