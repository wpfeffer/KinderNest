using DaycareProviderAssistant.Billing.Models;

namespace DaycareProviderAssistant.Billing.Services;

public interface IProviderBillingWriteService
{
    Task<ProviderBillingWriteContextDto> GetWriteContextAsync(int portalUserId, int? familyBillingAccountId = null, CancellationToken cancellationToken = default);
    Task<BillingWriteOutcomeDto> SaveRateScheduleAsync(int portalUserId, ProviderRateScheduleEditRequest request, CancellationToken cancellationToken = default);
    Task<BillingWriteOutcomeDto> SaveFamilyBillingAccountAsync(int portalUserId, FamilyBillingAccountEditRequest request, CancellationToken cancellationToken = default);
    Task<BillingWriteOutcomeDto> SaveChargeAsync(int portalUserId, FamilyChargeEntryRequest request, CancellationToken cancellationToken = default);
    Task<BillingWriteOutcomeDto> GenerateInvoiceAsync(int portalUserId, FamilyInvoiceGenerationRequest request, CancellationToken cancellationToken = default);
    Task<BillingWriteOutcomeDto> PostPaymentAsync(int portalUserId, FamilyPaymentPostRequest request, CancellationToken cancellationToken = default);
}
