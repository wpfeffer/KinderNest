namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteContextDto
{
    public IReadOnlyList<ProviderBillingWriteProviderDto> Providers { get; init; } = Array.Empty<ProviderBillingWriteProviderDto>();
    public IReadOnlyList<ProviderBillingWriteSiteDto> Sites { get; init; } = Array.Empty<ProviderBillingWriteSiteDto>();
    public IReadOnlyList<ProviderBillingWriteHouseholdDto> Households { get; init; } = Array.Empty<ProviderBillingWriteHouseholdDto>();
    public IReadOnlyList<ProviderBillingWriteFamilyAccountDto> FamilyAccounts { get; init; } = Array.Empty<ProviderBillingWriteFamilyAccountDto>();
    public IReadOnlyList<ProviderBillingWriteRateScheduleDto> RateSchedules { get; init; } = Array.Empty<ProviderBillingWriteRateScheduleDto>();
    public IReadOnlyList<ProviderBillingProcessorAccountDto> ProcessorAccounts { get; init; } = Array.Empty<ProviderBillingProcessorAccountDto>();
    public IReadOnlyList<BillingCodeOptionDto> ProviderRateTypes { get; init; } = Array.Empty<BillingCodeOptionDto>();
    public IReadOnlyList<BillingCodeOptionDto> BillingFrequencies { get; init; } = Array.Empty<BillingCodeOptionDto>();
    public IReadOnlyList<BillingCodeOptionDto> FamilyBillingAccountStatuses { get; init; } = Array.Empty<BillingCodeOptionDto>();
    public IReadOnlyList<BillingCodeOptionDto> FamilyChargeTypes { get; init; } = Array.Empty<BillingCodeOptionDto>();
    public IReadOnlyList<FamilyInvoiceOptionDto> OpenInvoices { get; init; } = Array.Empty<FamilyInvoiceOptionDto>();
}
