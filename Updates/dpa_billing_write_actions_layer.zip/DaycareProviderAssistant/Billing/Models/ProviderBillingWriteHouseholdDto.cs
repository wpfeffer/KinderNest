namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteHouseholdDto
{
    public int HouseholdId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string HouseholdDisplayName { get; init; } = string.Empty;
    public int? PrimaryContactPersonId { get; init; }
    public string? PrimaryContactDisplayName { get; init; }
    public string? PrimaryContactEmail { get; init; }
}
