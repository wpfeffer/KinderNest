using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Billing.Models;

public sealed class FamilyBillingAccountEditRequest
{
    public int? FamilyBillingAccountId { get; set; }

    public int? ExistingFamilyBillingAccountId { get; set; }

    [Required]
    public int? HouseholdId { get; set; }

    public int? SiteId { get; set; }

    [Required]
    public int? AccountStatusCodeValueId { get; set; }

    [Required]
    public int? BillingFrequencyCodeValueId { get; set; }

    [Range(1, 31)]
    public byte? BillingDayOfMonth { get; set; }

    [EmailAddress]
    [StringLength(320)]
    public string? BillingEmail { get; set; }

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal CurrentBalanceAmount { get; set; }

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal? CreditLimitAmount { get; set; }

    [Range(0, 365)]
    public int? LateFeeGraceDays { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }
}
