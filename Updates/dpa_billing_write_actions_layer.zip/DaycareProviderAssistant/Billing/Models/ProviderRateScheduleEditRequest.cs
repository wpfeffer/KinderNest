using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderRateScheduleEditRequest
{
    public int? ProviderRateScheduleId { get; set; }

    public int? ExistingRateScheduleId { get; set; }

    public int? SiteId { get; set; }

    [Required]
    [StringLength(200)]
    public string RateName { get; set; } = string.Empty;

    [Required]
    public int? RateTypeCodeValueId { get; set; }

    public int? BillingFrequencyCodeValueId { get; set; }

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal StandardAmount { get; set; }

    [Range(typeof(decimal), "0.0001", "9999999.9999")]
    public decimal StandardQuantityDecimal { get; set; } = 1.0000m;

    public bool AppliesPerChild { get; set; } = true;

    public bool TaxableFlag { get; set; }

    [Required]
    public DateOnly? EffectiveStartDate { get; set; } = DateOnly.FromDateTime(DateTime.Today);

    public DateOnly? EffectiveEndDate { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }
}
