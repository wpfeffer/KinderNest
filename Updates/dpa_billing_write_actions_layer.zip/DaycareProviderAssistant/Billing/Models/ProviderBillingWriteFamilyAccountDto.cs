namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteFamilyAccountDto
{
    public int FamilyBillingAccountId { get; init; }
    public int ProviderId { get; init; }
    public int HouseholdId { get; init; }
    public string HouseholdDisplayName { get; init; } = string.Empty;
    public int? SiteId { get; init; }
    public string? SiteName { get; init; }
    public int AccountStatusCodeValueId { get; init; }
    public string AccountStatusCode { get; init; } = string.Empty;
    public int BillingFrequencyCodeValueId { get; init; }
    public string BillingFrequencyCode { get; init; } = string.Empty;
    public byte? BillingDayOfMonth { get; init; }
    public int? PrimaryBillingContactPersonId { get; init; }
    public string? BillingContactDisplayName { get; init; }
    public string? BillingEmail { get; init; }
    public decimal CurrentBalanceAmount { get; init; }
    public decimal? CreditLimitAmount { get; init; }
    public int? LateFeeGraceDays { get; init; }
    public string? Notes { get; init; }
    public bool IsActive { get; init; }
}
