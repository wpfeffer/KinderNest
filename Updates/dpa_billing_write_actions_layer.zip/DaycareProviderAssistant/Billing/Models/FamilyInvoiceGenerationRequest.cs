using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Billing.Models;

public sealed class FamilyInvoiceGenerationRequest
{
    [Required]
    public int? FamilyBillingAccountId { get; set; }

    [Required]
    public DateTime? BillingPeriodStartUtc { get; set; } = DateTime.UtcNow.Date;

    [Required]
    public DateTime? BillingPeriodEndUtc { get; set; } = DateTime.UtcNow.Date;

    public DateTime? DueUtc { get; set; }

    public bool CreateAsDraft { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }
}
