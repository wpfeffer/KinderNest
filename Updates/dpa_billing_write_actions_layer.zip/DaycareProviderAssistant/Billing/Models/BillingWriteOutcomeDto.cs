namespace DaycareProviderAssistant.Billing.Models;

public sealed class BillingWriteOutcomeDto
{
    public bool Succeeded { get; init; }
    public string Message { get; init; } = string.Empty;
    public int? EntityId { get; init; }
    public string? EntityNumber { get; init; }
}
