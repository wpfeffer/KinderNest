using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Billing.Models;

public sealed class FamilyPaymentPostRequest
{
    [Required]
    public int? FamilyBillingAccountId { get; set; }

    [Required]
    public int? BillingProviderAccountId { get; set; }

    public int? FamilyInvoiceId { get; set; }

    [Range(typeof(decimal), "0.01", "9999999.99")]
    public decimal Amount { get; set; }

    [StringLength(200)]
    public string? ExternalTransactionReference { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }
}
