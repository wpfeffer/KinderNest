namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingProcessorAccountDto
{
    public int BillingProviderAccountId { get; init; }
    public int? ProviderId { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public int AccountUseTypeCodeValueId { get; init; }
    public string AccountUseTypeCode { get; init; } = string.Empty;
    public int ProcessorTypeCodeValueId { get; init; }
    public string ProcessorTypeCode { get; init; } = string.Empty;
    public string ProcessorTypeName { get; init; } = string.Empty;
    public string SettlementCurrencyCode { get; init; } = "USD";
    public bool IsPrimary { get; init; }
    public string? MerchantAccountReference { get; init; }
    public string? ExternalAccountReference { get; init; }
}
