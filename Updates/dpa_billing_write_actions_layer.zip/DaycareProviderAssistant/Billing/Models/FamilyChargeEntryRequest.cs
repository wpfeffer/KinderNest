using System.ComponentModel.DataAnnotations;

namespace DaycareProviderAssistant.Billing.Models;

public sealed class FamilyChargeEntryRequest
{
    [Required]
    public int? FamilyBillingAccountId { get; set; }

    [Required]
    public int? ChargeTypeCodeValueId { get; set; }

    [Required]
    public DateOnly? ServiceDate { get; set; } = DateOnly.FromDateTime(DateTime.Today);

    [Required]
    [StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.0001", "9999999.9999")]
    public decimal QuantityDecimal { get; set; } = 1.0000m;

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal UnitPriceAmount { get; set; }

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal TaxAmount { get; set; }

    [Range(typeof(decimal), "0.00", "9999999.99")]
    public decimal DiscountAmount { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }
}
