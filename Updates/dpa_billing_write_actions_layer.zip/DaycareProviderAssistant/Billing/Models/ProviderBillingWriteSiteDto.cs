namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteSiteDto
{
    public int SiteId { get; init; }
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
    public string SiteName { get; init; } = string.Empty;
}
