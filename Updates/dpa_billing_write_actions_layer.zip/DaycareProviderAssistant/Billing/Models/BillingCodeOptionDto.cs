namespace DaycareProviderAssistant.Billing.Models;

public sealed class BillingCodeOptionDto
{
    public int CodeValueId { get; init; }
    public string CodeDomain { get; init; } = string.Empty;
    public string CodeValue { get; init; } = string.Empty;
    public string CodeName { get; init; } = string.Empty;
}
