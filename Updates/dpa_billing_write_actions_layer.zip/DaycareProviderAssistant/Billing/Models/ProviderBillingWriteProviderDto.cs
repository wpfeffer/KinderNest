namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteProviderDto
{
    public int ProviderId { get; init; }
    public string ProviderName { get; init; } = string.Empty;
}
