namespace DaycareProviderAssistant.Billing.Models;

public sealed class ProviderBillingWriteRateScheduleDto
{
    public int ProviderRateScheduleId { get; init; }
    public int ProviderId { get; init; }
    public int? SiteId { get; init; }
    public string? SiteName { get; init; }
    public string RateName { get; init; } = string.Empty;
    public int RateTypeCodeValueId { get; init; }
    public string RateTypeCode { get; init; } = string.Empty;
    public int? BillingFrequencyCodeValueId { get; init; }
    public string? BillingFrequencyCode { get; init; }
    public decimal StandardAmount { get; init; }
    public decimal StandardQuantityDecimal { get; init; }
    public bool AppliesPerChild { get; init; }
    public bool TaxableFlag { get; init; }
    public DateOnly EffectiveStartDate { get; init; }
    public DateOnly? EffectiveEndDate { get; init; }
    public string? Notes { get; init; }
    public bool IsActive { get; init; }
}
