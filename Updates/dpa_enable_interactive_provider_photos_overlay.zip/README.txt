DPA interactive render mode overlay

Problem:
- The app registers interactive server components in Program.cs.
- But Components/App.razor renders <Routes /> and <HeadOutlet /> without @rendermode.
- In .NET Razor Components, that means route components can render as static SSR.
- Static SSR does not run the interactive component lifecycle needed for the Provider Photos JS import/click wiring.
- Result: the Encrypt and upload button can look alive but behave like a painted-on button.

What this overlay changes:
- DaycareProviderAssistant/Components/App.razor
  - <HeadOutlet @rendermode="InteractiveServer" />
  - <Routes @rendermode="InteractiveServer" />

Apply:
1. Unzip at the repository root and allow overwrite.
2. Rebuild and run.
3. Hard refresh /provider/photos.
4. Open DevTools Console.
5. With the prior JS diagnostic overlay applied, you should see:
   DPA encrypted image module loaded.
6. Click Encrypt and upload. You should see:
   Encrypt and upload clicked.

If you still do not see those console messages after this, the page is not loading the patched JS or the patched Photos.razor file.
