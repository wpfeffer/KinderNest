CREATE PROCEDURE billing.usp_ProviderBillingDashboard_GetSummary
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #ProviderScope
    (
        ProviderID INT NOT NULL PRIMARY KEY,
        ProviderName NVARCHAR(200) NULL
    );

    INSERT INTO #ProviderScope (ProviderID, ProviderName)
    SELECT DISTINCT
        s.ProviderID,
        pr.ProviderName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
      AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME());

    CREATE TABLE #ProviderImageStorage
    (
        ProviderID INT NOT NULL PRIMARY KEY,
        TotalImageStorageBytes BIGINT NOT NULL
    );

    INSERT INTO #ProviderImageStorage (ProviderID, TotalImageStorageBytes)
    SELECT
        s.ProviderID,
        SUM(ISNULL(ia.EncryptedFileLengthBytes, 0) + ISNULL(ia.EncryptedThumbnailLengthBytes, 0))
    FROM party.Site s
    LEFT JOIN image.ImageAsset ia
        ON ia.SiteID = s.SiteID
       AND ia.IsDeleted = 0
       AND ia.IsActive = 1
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = s.ProviderID
    WHERE s.IsDeleted = 0
    GROUP BY s.ProviderID;

    SELECT TOP (1)
        ps.ProviderSubscriptionID,
        ps.ProviderID,
        pr.ProviderName,
        pp.ProviderPlanID,
        pp.PlanCode,
        pp.PlanName,
        SubscriptionStatusCode = ss.CodeValue,
        SubscriptionStatusName = ss.CodeName,
        BillingFrequencyCode = bf.CodeValue,
        BillingFrequencyName = bf.CodeName,
        ps.SubscriptionStartUTC,
        ps.SubscriptionEndUTC,
        ps.NextBillingDateUTC,
        ps.AutoRenewEnabled,
        pp.BasePriceAmount,
        pp.IncludedChildrenCount,
        pp.IncludedImageStorageBytes,
        pp.IncludedUsersCount,
        pp.OverageImageStoragePricePerGb,
        pp.OverageChildPriceAmount,
        CurrentImageStorageBytes = ISNULL(pis.TotalImageStorageBytes, 0),
        ActiveFamilyBillingAccounts =
            (
                SELECT COUNT(1)
                FROM billing.FamilyBillingAccount fba
                WHERE fba.ProviderID = ps.ProviderID
                  AND fba.IsDeleted = 0
                  AND fba.IsActive = 1
            ),
        OpenFamilyInvoices =
            (
                SELECT COUNT(1)
                FROM billing.FamilyInvoice fi
                INNER JOIN billing.FamilyBillingAccount fba
                    ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID
                   AND fba.ProviderID = ps.ProviderID
                   AND fba.IsDeleted = 0
                WHERE fi.IsDeleted = 0
                  AND fi.IsActive = 1
                  AND fi.BalanceAmount > 0
            ),
        RateScheduleCount =
            (
                SELECT COUNT(1)
                FROM billing.ProviderRateSchedule prs
                WHERE prs.ProviderID = ps.ProviderID
                  AND prs.IsDeleted = 0
                  AND prs.IsActive = 1
            )
    FROM billing.ProviderSubscription ps
    INNER JOIN #ProviderScope scope
        ON scope.ProviderID = ps.ProviderID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = ps.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN billing.ProviderPlan pp
        ON pp.ProviderPlanID = ps.ProviderPlanID
       AND pp.IsDeleted = 0
    INNER JOIN ref.CodeValue ss
        ON ss.CodeValueID = ps.SubscriptionStatusCodeValueID
    INNER JOIN ref.CodeValue bf
        ON bf.CodeValueID = pp.BillingFrequencyCodeValueID
    LEFT JOIN #ProviderImageStorage pis
        ON pis.ProviderID = ps.ProviderID
    WHERE ps.IsDeleted = 0
      AND ps.IsActive = 1
    ORDER BY ps.SubscriptionStartUTC DESC, ps.ProviderSubscriptionID DESC;

    SELECT
        pp.ProviderPlanID,
        pp.PlanCode,
        pp.PlanName,
        PlanTypeCode = pt.CodeValue,
        BillingFrequencyCode = bf.CodeValue,
        pp.BasePriceAmount,
        pp.IncludedChildrenCount,
        pp.IncludedImageStorageBytes,
        pp.IncludedUsersCount,
        pp.OverageImageStoragePricePerGb,
        pp.OverageChildPriceAmount,
        pp.IsPublic,
        pp.IsActive
    FROM billing.ProviderPlan pp
    INNER JOIN ref.CodeValue pt
        ON pt.CodeValueID = pp.PlanTypeCodeValueID
    INNER JOIN ref.CodeValue bf
        ON bf.CodeValueID = pp.BillingFrequencyCodeValueID
    WHERE pp.IsDeleted = 0
      AND pp.IsActive = 1
      AND pp.IsPublic = 1
    ORDER BY pp.BasePriceAmount, pp.PlanName;

    SELECT TOP (20)
        pi.ProviderInvoiceID,
        pi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue,
        InvoiceStatusName = ist.CodeName,
        pi.IssuedUTC,
        pi.DueUTC,
        pi.TotalAmount,
        pi.BalanceAmount
    FROM billing.ProviderInvoice pi
    INNER JOIN #ProviderScope scope
        ON scope.ProviderID = pi.ProviderID
    INNER JOIN ref.CodeValue ist
        ON ist.CodeValueID = pi.InvoiceStatusCodeValueID
    WHERE pi.IsDeleted = 0
      AND pi.IsActive = 1
    ORDER BY pi.IssuedUTC DESC, pi.ProviderInvoiceID DESC;

    SELECT
        prs.ProviderRateScheduleID,
        prs.SiteID,
        SiteName = s.SiteName,
        prs.RateName,
        RateTypeCode = rtc.CodeValue,
        BillingFrequencyCode = bfc.CodeValue,
        prs.StandardAmount,
        prs.StandardQuantityDecimal,
        prs.AppliesPerChild,
        prs.TaxableFlag,
        prs.EffectiveStartDate,
        prs.EffectiveEndDate,
        prs.IsActive
    FROM billing.ProviderRateSchedule prs
    INNER JOIN #ProviderScope scope
        ON scope.ProviderID = prs.ProviderID
    INNER JOIN ref.CodeValue rtc
        ON rtc.CodeValueID = prs.RateTypeCodeValueID
    LEFT JOIN ref.CodeValue bfc
        ON bfc.CodeValueID = prs.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = prs.SiteID
       AND s.IsDeleted = 0
    WHERE prs.IsDeleted = 0
    ORDER BY prs.EffectiveStartDate DESC, prs.RateName;

    SELECT
        fba.FamilyBillingAccountID,
        fba.HouseholdID,
        HouseholdDisplayName = h.HouseholdDisplayName,
        fba.SiteID,
        SiteName = s.SiteName,
        AccountStatusCode = acs.CodeValue,
        BillingFrequencyCode = bf.CodeValue,
        BillingContactDisplayName = CASE
            WHEN p.PersonID IS NULL THEN NULL
            ELSE LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName)))
        END,
        BillingEmail = COALESCE(fba.BillingEmail, p.PrimaryEmail),
        fba.CurrentBalanceAmount,
        OpenInvoiceCount =
            (
                SELECT COUNT(1)
                FROM billing.FamilyInvoice fi
                WHERE fi.FamilyBillingAccountID = fba.FamilyBillingAccountID
                  AND fi.IsDeleted = 0
                  AND fi.IsActive = 1
                  AND fi.BalanceAmount > 0
            )
    FROM billing.FamilyBillingAccount fba
    INNER JOIN #ProviderScope scope
        ON scope.ProviderID = fba.ProviderID
    INNER JOIN party.Household h
        ON h.HouseholdID = fba.HouseholdID
       AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue acs
        ON acs.CodeValueID = fba.AccountStatusCodeValueID
    INNER JOIN ref.CodeValue bf
        ON bf.CodeValueID = fba.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = fba.SiteID
       AND s.IsDeleted = 0
    LEFT JOIN party.Person p
        ON p.PersonID = fba.PrimaryBillingContactPersonID
       AND p.IsDeleted = 0
    WHERE fba.IsDeleted = 0
      AND fba.IsActive = 1
    ORDER BY h.HouseholdDisplayName, fba.FamilyBillingAccountID;
END;
GO
