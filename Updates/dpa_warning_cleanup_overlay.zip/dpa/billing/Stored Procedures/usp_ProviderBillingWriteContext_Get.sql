CREATE PROCEDURE billing.usp_ProviderBillingWriteContext_Get
    @PortalUserID INT
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #ProviderScope
    (
        ProviderID INT NOT NULL PRIMARY KEY,
        ProviderName NVARCHAR(200) NULL
    );

    INSERT INTO #ProviderScope (ProviderID, ProviderName)
    SELECT DISTINCT
        s.ProviderID,
        pr.ProviderName
    FROM party.SiteUserAssignment sua
    INNER JOIN party.Site s
        ON s.SiteID = sua.SiteID
       AND s.IsDeleted = 0
       AND s.IsActive = 1
    INNER JOIN party.Provider pr
        ON pr.ProviderID = s.ProviderID
       AND pr.IsDeleted = 0
       AND pr.IsActive = 1
    WHERE sua.PortalUserID = @PortalUserID
      AND sua.IsActive = 1
      AND (sua.EffectiveStartUTC IS NULL OR sua.EffectiveStartUTC <= SYSUTCDATETIME())
      AND (sua.EffectiveEndUTC IS NULL OR sua.EffectiveEndUTC >= SYSUTCDATETIME());

    CREATE TABLE #PrimaryContact
    (
        HouseholdID INT NOT NULL,
        PersonID INT NOT NULL,
        DisplayName NVARCHAR(401) NULL,
        PrimaryEmail NVARCHAR(320) NULL,
        rn INT NOT NULL,
        PRIMARY KEY (HouseholdID, rn)
    );

    INSERT INTO #PrimaryContact (HouseholdID, PersonID, DisplayName, PrimaryEmail, rn)
    SELECT
        hp.HouseholdID,
        hp.PersonID,
        LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName))),
        p.PrimaryEmail,
        ROW_NUMBER() OVER
        (
            PARTITION BY hp.HouseholdID
            ORDER BY CASE WHEN hp.IsPrimaryContact = 1 THEN 0 ELSE 1 END, hp.HouseholdPersonID
        )
    FROM party.HouseholdPerson hp
    INNER JOIN party.Person p
        ON p.PersonID = hp.PersonID
       AND p.IsDeleted = 0
       AND p.IsActive = 1
    WHERE hp.IsDeleted = 0
      AND hp.IsActive = 1;

    SELECT
        ps.ProviderID,
        ps.ProviderName
    FROM #ProviderScope ps
    ORDER BY ps.ProviderName, ps.ProviderID;

    SELECT
        s.SiteID,
        s.ProviderID,
        ps.ProviderName,
        s.SiteName
    FROM party.Site s
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = s.ProviderID
    WHERE s.IsDeleted = 0
      AND s.IsActive = 1
    ORDER BY ps.ProviderName, s.SiteName, s.SiteID;

    SELECT
        h.HouseholdID,
        h.ProviderID,
        ps.ProviderName,
        h.HouseholdDisplayName,
        pc.PersonID AS PrimaryContactPersonID,
        pc.DisplayName AS PrimaryContactDisplayName,
        pc.PrimaryEmail AS PrimaryContactEmail
    FROM party.Household h
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = h.ProviderID
    LEFT JOIN #PrimaryContact pc
        ON pc.HouseholdID = h.HouseholdID
       AND pc.rn = 1
    WHERE h.IsDeleted = 0
      AND h.IsActive = 1
    ORDER BY h.HouseholdDisplayName, h.HouseholdID;

    SELECT
        fba.FamilyBillingAccountID,
        fba.ProviderID,
        fba.HouseholdID,
        h.HouseholdDisplayName,
        fba.SiteID,
        s.SiteName,
        fba.AccountStatusCodeValueID,
        AccountStatusCode = acs.CodeValue,
        fba.BillingFrequencyCodeValueID,
        BillingFrequencyCode = bf.CodeValue,
        fba.BillingDayOfMonth,
        fba.PrimaryBillingContactPersonID,
        BillingContactDisplayName = CASE
            WHEN p.PersonID IS NULL THEN NULL
            ELSE LTRIM(RTRIM(CONCAT(p.FirstName, N' ', p.LastName)))
        END,
        BillingEmail = COALESCE(fba.BillingEmail, p.PrimaryEmail),
        fba.CurrentBalanceAmount,
        fba.CreditLimitAmount,
        fba.LateFeeGraceDays,
        fba.Notes,
        fba.IsActive
    FROM billing.FamilyBillingAccount fba
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = fba.ProviderID
    INNER JOIN party.Household h
        ON h.HouseholdID = fba.HouseholdID
       AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue acs
        ON acs.CodeValueID = fba.AccountStatusCodeValueID
    INNER JOIN ref.CodeValue bf
        ON bf.CodeValueID = fba.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = fba.SiteID
       AND s.IsDeleted = 0
    LEFT JOIN party.Person p
        ON p.PersonID = fba.PrimaryBillingContactPersonID
       AND p.IsDeleted = 0
    WHERE fba.IsDeleted = 0
    ORDER BY h.HouseholdDisplayName, fba.FamilyBillingAccountID;

    SELECT
        prs.ProviderRateScheduleID,
        prs.ProviderID,
        prs.SiteID,
        s.SiteName,
        prs.RateName,
        prs.RateTypeCodeValueID,
        RateTypeCode = rtc.CodeValue,
        prs.BillingFrequencyCodeValueID,
        BillingFrequencyCode = bfc.CodeValue,
        prs.StandardAmount,
        prs.StandardQuantityDecimal,
        prs.AppliesPerChild,
        prs.TaxableFlag,
        prs.EffectiveStartDate,
        prs.EffectiveEndDate,
        prs.Notes,
        prs.IsActive
    FROM billing.ProviderRateSchedule prs
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = prs.ProviderID
    INNER JOIN ref.CodeValue rtc
        ON rtc.CodeValueID = prs.RateTypeCodeValueID
    LEFT JOIN ref.CodeValue bfc
        ON bfc.CodeValueID = prs.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = prs.SiteID
       AND s.IsDeleted = 0
    WHERE prs.IsDeleted = 0
    ORDER BY prs.EffectiveStartDate DESC, prs.RateName, prs.ProviderRateScheduleID;

    SELECT
        bpa.BillingProviderAccountID,
        bpa.ProviderID,
        bpa.DisplayName,
        bpa.AccountUseTypeCodeValueID,
        AccountUseTypeCode = auc.CodeValue,
        bpa.ProcessorTypeCodeValueID,
        ProcessorTypeCode = ptc.CodeValue,
        ProcessorTypeName = ptc.CodeName,
        bpa.SettlementCurrencyCode,
        bpa.IsPrimary,
        bpa.MerchantAccountReference,
        bpa.ExternalAccountReference
    FROM billing.BillingProviderAccount bpa
    INNER JOIN #ProviderScope ps
        ON ps.ProviderID = bpa.ProviderID
    INNER JOIN ref.CodeValue auc
        ON auc.CodeValueID = bpa.AccountUseTypeCodeValueID
    INNER JOIN ref.CodeValue ptc
        ON ptc.CodeValueID = bpa.ProcessorTypeCodeValueID
    WHERE bpa.IsDeleted = 0
      AND bpa.IsActive = 1
      AND auc.CodeDomain = N'BillingProviderAccountUse'
      AND auc.CodeValue = N'PROVIDER_FAMILY_BILLING'
    ORDER BY bpa.IsPrimary DESC, bpa.DisplayName, bpa.BillingProviderAccountID;
END;
GO
