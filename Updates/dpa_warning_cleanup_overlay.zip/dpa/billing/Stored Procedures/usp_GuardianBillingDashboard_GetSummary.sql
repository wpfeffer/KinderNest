CREATE PROCEDURE billing.usp_GuardianBillingDashboard_GetSummary
    @PersonID INT
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #HouseholdScope
    (
        HouseholdID INT NOT NULL PRIMARY KEY
    );

    INSERT INTO #HouseholdScope (HouseholdID)
    SELECT DISTINCT hp.HouseholdID
    FROM party.HouseholdPerson hp
    WHERE hp.PersonID = @PersonID
      AND hp.IsDeleted = 0
      AND hp.IsActive = 1
      AND (hp.EffectiveStartDate IS NULL OR hp.EffectiveStartDate <= CONVERT(date, SYSUTCDATETIME()))
      AND (hp.EffectiveEndDate IS NULL OR hp.EffectiveEndDate >= CONVERT(date, SYSUTCDATETIME()));

    SELECT
        HouseholdCount = (SELECT COUNT(1) FROM #HouseholdScope),
        ActiveFamilyBillingAccounts =
        (
            SELECT COUNT(1)
            FROM billing.FamilyBillingAccount fba
            INNER JOIN #HouseholdScope hs
                ON hs.HouseholdID = fba.HouseholdID
            WHERE fba.IsDeleted = 0
              AND fba.IsActive = 1
        ),
        OpenInvoices =
        (
            SELECT COUNT(1)
            FROM billing.FamilyInvoice fi
            INNER JOIN billing.FamilyBillingAccount fba
                ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID
               AND fba.IsDeleted = 0
            INNER JOIN #HouseholdScope hs
                ON hs.HouseholdID = fba.HouseholdID
            WHERE fi.IsDeleted = 0
              AND fi.IsActive = 1
              AND fi.BalanceAmount > 0
        ),
        OutstandingBalanceAmount =
        (
            SELECT ISNULL(SUM(fi.BalanceAmount), 0.00)
            FROM billing.FamilyInvoice fi
            INNER JOIN billing.FamilyBillingAccount fba
                ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID
               AND fba.IsDeleted = 0
            INNER JOIN #HouseholdScope hs
                ON hs.HouseholdID = fba.HouseholdID
            WHERE fi.IsDeleted = 0
              AND fi.IsActive = 1
        );

    SELECT
        fba.FamilyBillingAccountID,
        fba.ProviderID,
        pr.ProviderName,
        fba.HouseholdID,
        h.HouseholdDisplayName,
        fba.SiteID,
        SiteName = s.SiteName,
        AccountStatusCode = acs.CodeValue,
        AccountStatusName = acs.CodeName,
        BillingFrequencyCode = bf.CodeValue,
        BillingFrequencyName = bf.CodeName,
        fba.BillingDayOfMonth,
        BillingEmail = COALESCE(fba.BillingEmail, p.PrimaryEmail),
        CurrentBalanceAmount = fba.CurrentBalanceAmount
    FROM billing.FamilyBillingAccount fba
    INNER JOIN #HouseholdScope hs
        ON hs.HouseholdID = fba.HouseholdID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = fba.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN party.Household h
        ON h.HouseholdID = fba.HouseholdID
       AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue acs
        ON acs.CodeValueID = fba.AccountStatusCodeValueID
    INNER JOIN ref.CodeValue bf
        ON bf.CodeValueID = fba.BillingFrequencyCodeValueID
    LEFT JOIN party.Site s
        ON s.SiteID = fba.SiteID
       AND s.IsDeleted = 0
    LEFT JOIN party.Person p
        ON p.PersonID = fba.PrimaryBillingContactPersonID
       AND p.IsDeleted = 0
    WHERE fba.IsDeleted = 0
      AND fba.IsActive = 1
    ORDER BY pr.ProviderName, h.HouseholdDisplayName;

    SELECT TOP (50)
        fi.FamilyInvoiceID,
        fi.FamilyBillingAccountID,
        pr.ProviderName,
        h.HouseholdDisplayName,
        fi.InvoiceNumber,
        InvoiceStatusCode = ist.CodeValue,
        InvoiceStatusName = ist.CodeName,
        fi.IssuedUTC,
        fi.DueUTC,
        fi.TotalAmount,
        fi.BalanceAmount
    FROM billing.FamilyInvoice fi
    INNER JOIN billing.FamilyBillingAccount fba
        ON fba.FamilyBillingAccountID = fi.FamilyBillingAccountID
       AND fba.IsDeleted = 0
    INNER JOIN #HouseholdScope hs
        ON hs.HouseholdID = fba.HouseholdID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = fba.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN party.Household h
        ON h.HouseholdID = fba.HouseholdID
       AND h.IsDeleted = 0
    INNER JOIN ref.CodeValue ist
        ON ist.CodeValueID = fi.InvoiceStatusCodeValueID
    WHERE fi.IsDeleted = 0
      AND fi.IsActive = 1
    ORDER BY fi.IssuedUTC DESC, fi.FamilyInvoiceID DESC;

    SELECT TOP (50)
        p.PaymentID,
        p.FamilyBillingAccountID,
        pr.ProviderName,
        PaymentStatusCode = pst.CodeValue,
        PaymentStatusName = pst.CodeName,
        p.PaymentUTC,
        p.Amount,
        p.CurrencyCode,
        p.ExternalTransactionReference
    FROM billing.Payment p
    INNER JOIN billing.FamilyBillingAccount fba
        ON fba.FamilyBillingAccountID = p.FamilyBillingAccountID
       AND fba.IsDeleted = 0
    INNER JOIN #HouseholdScope hs
        ON hs.HouseholdID = fba.HouseholdID
    INNER JOIN party.Provider pr
        ON pr.ProviderID = fba.ProviderID
       AND pr.IsDeleted = 0
    INNER JOIN ref.CodeValue pst
        ON pst.CodeValueID = p.PaymentStatusCodeValueID
    WHERE p.IsDeleted = 0
      AND p.IsActive = 1
    ORDER BY p.PaymentUTC DESC, p.PaymentID DESC;
END;
GO
