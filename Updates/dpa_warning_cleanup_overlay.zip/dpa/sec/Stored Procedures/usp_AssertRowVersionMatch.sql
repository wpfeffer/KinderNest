CREATE PROCEDURE sec.usp_AssertRowVersionMatch
    @SchemaName SYSNAME,
    @TableName SYSNAME,
    @PrimaryKeyColumn SYSNAME,
    @PrimaryKeyValue SQL_VARIANT,
    @RowVersionColumn SYSNAME = N'RowVer',
    @ExpectedRowVersion VARBINARY(8)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Sql NVARCHAR(MAX);
    DECLARE @OutRowVer VARBINARY(8);

    SET @Sql = N'
SELECT @OutRowVer = ' + QUOTENAME(@RowVersionColumn) + N'
FROM ' + QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName) + N'
WHERE ' + QUOTENAME(@PrimaryKeyColumn) + N' = @PkValue;';

    EXEC dbo.sp_executesql
        @Sql,
        N'@PkValue sql_variant, @OutRowVer varbinary(8) OUTPUT',
        @PkValue = @PrimaryKeyValue,
        @OutRowVer = @OutRowVer OUTPUT;

    IF @OutRowVer IS NULL
    BEGIN
        THROW 50001, 'The target record was not found for row version validation.', 1;
    END;

    IF @OutRowVer <> @ExpectedRowVersion
    BEGIN
        THROW 50002, 'The record was changed by another process. Refresh and try again.', 1;
    END;
END;
GO
