DPA temp-table warning cleanup overlay

This overlay replaces the billing procedures that were reusing CTEs across multiple statements.
That pattern works for exactly one following statement in T-SQL, so SSDT warned about unresolved
references to ProviderScope / HouseholdScope / PrimaryContact.

Files included:
- dpa/billing/Stored Procedures/usp_ProviderBillingDashboard_GetSummary.sql
- dpa/billing/Stored Procedures/usp_GuardianBillingDashboard_GetSummary.sql
- dpa/billing/Stored Procedures/usp_ProviderBillingWriteContext_Get.sql
- dpa/sec/Stored Procedures/usp_AssertRowVersionMatch.sql

How to apply:
1. Unzip at the repository root.
2. Overwrite existing files.
3. Rebuild dpa.

Expected result:
- The ProviderScope / HouseholdScope / PrimaryContact unresolved-reference warnings should disappear.
- The sp_executesql ambiguity warning should also disappear because the proc now calls dbo.sp_executesql explicitly.
